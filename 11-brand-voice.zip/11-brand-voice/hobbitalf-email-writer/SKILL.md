---
name: hobbitalf-email-writer
description: >
  Redacta emails de marketing para Hobbitalf (marca española de comida air-dried para perros y gatos). ALWAYS use this skill when Marcel o el equipo pidan redactar, revisar o mejorar emails de Hobbitalf para Klaviyo. Trigger on: "email de Hobbitalf", "redacta el email", "siguiente email", "email de septiembre/octubre/etc", "emails del mes", "vamos con el email", "rehaz el email", "mejora el email". También en cualquier revisión de copy de email de Hobbitalf aunque no se mencione la skill.
---

# Hobbitalf Email Writer

## Estructura fija de cada email

```
Asunto A: [emoji] [frase corta · max 50 caracteres]
Asunto B: [variante con ángulo diferente]
Preview A: [complementa el asunto A · max 90 caracteres]
Preview B: [complementa el asunto B · max 90 caracteres]

---

[HERO EN MAYÚSCULAS · max 8 palabras · sin punto final]

[Párrafo de entrada · 2-3 líneas máx · hook o contexto]

[Bloque visual con emojis · 3-5 ítems · formato:]
emoji Frase corta en minúsculas

[Párrafo de transición · 1-2 líneas · conecta el bloque con el producto]

**Frase en negrita como remate emocional o de beneficio.**

**CTA → [texto del enlace]**
```

## Reglas de formato

- **Párrafos cortos**: máximo 3 líneas por párrafo. Si supera 3 líneas, partir en dos.
- **Bloques visuales obligatorios**: todo email necesita al menos un bloque con emojis que rompa el texto.
- **Sin pegotes**: nunca más de 2 párrafos seguidos sin un bloque visual, negrita o espacio.
- **Hero en MAYÚSCULAS**: siempre, sin punto final, máximo 8 palabras.
- **A/B obligatorio**: siempre dos asuntos y dos previews distintos.
- **CTA en negrita**: siempre al final, con flecha →.

## Reglas de copy

- Sin guiones em (—) en el body del email. Usar coma, punto o dos puntos.
- Sin puntos seguidos estilo copy ("Sin nevera. Sin complicaciones. Sin excusas.").
- Frases completas y naturales, no telegráficas.
- No usar "comida real" → usar "comida natural sin procesar".
- Ingredientes siempre como "carne, pescado, frutas y verduras".
- No repetir el proceso de deshidratación si el lector ya lo conoce (emails 2 en adelante del mes).
- No repetir los ingredientes si ya se mencionaron en emails anteriores del mes.
- No usar "tu compañero" de forma genérica → usar "tu perro" o el nombre del animal según contexto.
- Tono: cercano, educativo, honesto. Sin sycophancy ni superlativos vacíos.

## Contexto de marca

- **Producto**: menús air-dried para perros y gatos. Deshidratado a baja temperatura, sin extrusión.
- **Posicionamiento**: comida natural sin procesar, sin nevera, sin complicaciones.
- **Villanos**: pienso convencional (extrusión a 110-150°C) y BARF (logística imposible).
- **Superalimentos**: raíz de achicoria + MOS (prebióticos), cúrcuma + espirulina + alga kelp (antiinflamatorios), mejillón de labio verde (articulaciones), Bacillus Coagulans (probiótico).
- **Claims aprobados**: 9/10 notan mejora, 98% palatabilidad, 4,7/5 en +1.000 reseñas, 4/5 más vitalidad, 9/10 repiten.
- **Precio**: desde 0,38€/día.
- **Descuentos activos**: REALFOOD10 (carrito/checkout), WELCOME10 (bienvenida).
- **Guardarriles**: nunca "hipoalergénico"; piel/picor → eje intestino-piel; dental → no elimina sarro mineralizado; movilidad y piel → añadir disclaimer vet; no "38 céntimos al día" en ads; no fabricar testimonios; no atacar al BARF como nutrición, solo su logística.

## Ejemplo de email bien formateado

```
Asunto A: 🍂 Septiembre también les afecta a ellos
Asunto B: ¿Tu perro está raro desde que volviste al trabajo?
Preview A: El cambio de rutina se nota en su cuerpo más de lo que crees.
Preview B: Esto es lo que pasa y lo que puedes hacer.

---

LA VUELTA A LA RUTINA TAMBIÉN ES SUYA

Septiembre llega y para ellos también cambia todo: las casas se vacían durante horas, los paseos vuelven a tener horario y la energía de agosto desaparece casi de un día para otro.

Lo que sueles ver en las primeras semanas:

🐾 Más nerviosismo de lo normal
💩 Digestiones algo más irregulares
😴 Menos apetito o más selectivo con la comida
🌡️ Mayor sensibilidad a los cambios de temperatura

No es que estén enfermos, es que están ajustando a una rutina nueva y el organismo necesita tiempo y recursos para hacerlo bien.

**Lo que puedes hacer es asegurarte de que lo que comen les da la base que necesitan para adaptarse.**

**Ver el Starter Pack de Hobbitalf →**
```
