---
name: v-up-voz-dr-carlos
description: "Guía de voz y estilo comunicativo del Dr. Carlos Canencio para guiones de V-UP. Replica sus patrones de comunicación oral: tono, ritmo, estructura de frases, vocabulario, muletillas, y forma de explicar conceptos médicos. ALWAYS use this skill BEFORE writing any script, guion, VSSL, UGC, video ad copy, or spoken-word content where the Dr. Carlos is el talento o narrador. Trigger on: \"guion del doctor\", \"script del doctor Carlos\", \"como habla el doctor\", \"voz del doctor\", \"VSL del doctor\", \"video del doctor\", \"guion V-UP con el doctor\", \"cómo diría el doctor esto\", \"adapta esto a la voz del doctor\". Trigger also when writing any V-UP video script that features Dr. Carlos as speaker, even if not explicitly mentioned."
---

# Voz del Dr. Carlos Canencio — Guía de estilo comunicativo

## Propósito
Esta skill NO es sobre qué dice el doctor. Es sobre CÓMO lo dice. Cada guion donde el Dr. Carlos sea el talento debe sonar como él habla realmente: un médico colombiano con 36 años de práctica integrativa que explica cosas complejas como si estuviera en la sala de su casa hablándote a ti.

---

## 1. RITMO Y ESTRUCTURA DE FRASES

### Patrón central: Oración corta declarativa → Expansión breve
El doctor NO da discursos largos. Lanza una afirmación corta y directa, y luego la expande en 1-2 oraciones. Nunca más de 3 oraciones seguidas sobre la misma idea.

**Ejemplo real:**
> "La depresión y el estrés pueden afectar el colon. Claro que lo pueden afectar en forma indirecta."

**Anti-patrón (NUNCA hacer):**
> "Es importante entender que la depresión y el estrés, si bien no tienen una relación directa con el sistema gastrointestinal, pueden generar alteraciones funcionales que a largo plazo comprometen la salud del colon."

### Regla: Si una oración pasa de 25 palabras, partirla en dos.

---

## 2. DISPOSITIVOS RETÓRICOS RECURRENTES

### 2a. Pregunta retórica → Respuesta cortante
Su recurso estrella. Lanza una pregunta y la responde él mismo en 1-5 palabras. Genera ritmo y mantiene atención.

> "¿Pero quién es el causante? El hígado."
> "¿Y a cuánto bajó? A 50."

**Usar al menos una vez cada 30-40 segundos de guion.**

### 2b. "Le cuento que..."
Muletilla de transición. La usa para introducir un dato interesante o un giro. Crea intimidad, como si estuviera contándote un secreto.

> "Le cuento que interesante: la piel cambia cada 28 días."

**Usar 1-2 veces por guion. Nunca más de 2.**

### 2c. "Es así de sencillo."
Cierra una explicación compleja con esta frase. Refuerza que lo que acaba de decir no es complicado, aunque suene técnico.

> "Si yo desintoxico el hígado, automáticamente la piel se va a limpiar en 28 días. Es así de sencillo."

**Usar máximo 1 vez por guion, idealmente al cerrar el argumento principal.**

### 2d. "Hoy día..." / "Hoy se tiene considerado..."
Ancla temporal. Le da modernidad científica a lo que dice sin citar papers. Implica: "la ciencia actual respalda esto".

> "Hoy se tiene considerado el colon como el segundo cerebro."

### 2e. "Claro que..."
Afirmación empática antes de expandir. No contradice, valida y luego profundiza.

> "Claro que lo pueden afectar, en forma indirecta."

### 2f. "O sea que..."
Reformulación simplificada. Después de una explicación semi-técnica, la traduce a lenguaje llano.

> "O sea que si el colon está estreñido, pues también está estresado."

---

## 3. VOCABULARIO Y REGISTRO

### Mezcla técnico-coloquial
El doctor SÍ usa términos médicos, pero SIEMPRE los traduce inmediatamente. Nunca deja un término técnico solo.

**Patrón: Término técnico → "que es..." / "o sea..." / "uno de los..."**

> "la serotonina, uno de los neurotransmisores que el cerebro necesita"
> "esteatosis hepática" → lo dice, pero antes/después explica: "Cuando el hígado está grasoso"

### Palabras que USA frecuentemente:
- "fenomenal" (para resultados positivos)
- "interesante" (para introducir datos)
- "sencillamente" (para simplificar)
- "complemento nutricional" (nunca "suplemento" a secas)
- "casos clínicos" / "hemos manejado pacientes de..."
- "guerrera/guerrero" (para pacientes con resultados notables)
- "pues" (conector colombiano natural, no forzarlo pero no eliminarlo)

### Palabras que NO usa / Evitar:
- Jerga de marketing: "potenciar", "optimizar", "revolucionario", "innovador"
- Anglicismos: "performance", "wellness", "boost"
- Lenguaje académico denso: "fisiopatología subyacente", "mecanismo de acción molecular"
- Superlativos vacíos: "el mejor", "el más avanzado", "único en el mundo"
- Frases de IA genérica: "en el mundo actual", "no es ningún secreto que", "en este sentido"

---

## 4. ESTRUCTURA ARGUMENTATIVA

### Patrón Causa → Efecto → Solución → Prueba
Así organiza casi cualquier explicación:

1. **Causa raíz** (1-2 oraciones): Identifica el problema real, no el síntoma
2. **Efecto visible** (1 oración): Lo que la persona ve/siente
3. **Solución concreta** (1-2 oraciones): Qué hacer exactamente, con receta/protocolo específico
4. **Prueba clínica** (1-2 oraciones): Dato numérico, caso real, o timeframe específico

**Ejemplo reconstruido:**
> "¿Quién es el causante de los problemas de piel? El hígado. [CAUSA] Cuando está grasoso, la piel se inflama. [EFECTO] Si yo desintoxico el hígado, automáticamente la piel se limpia. [SOLUCIÓN] Hemos manejado pacientes de psoriasis y en menos de 45 días el cambio es fenomenal. [PRUEBA]"

### Escalada de consecuencias
A veces sube las stakes: conecta un síntoma menor con una consecuencia grave para generar urgencia sin ser alarmista.

> "El problema es que si hay estreñimiento, en un futuro puede ser cáncer de colon."

**Usar con moderación. Máximo 1 vez por guion. Debe sonar como advertencia paterna, no como miedo.**

---

## 5. NÚMEROS Y DATOS ESPECÍFICOS

El doctor SIEMPRE da números concretos. Nunca dice "en poco tiempo" — dice "en 28 días". Nunca dice "los resultados mejoraron" — dice "bajó de 600 a 45".

### Regla: Todo claim debe tener al menos un dato numérico asociado.
- Timeframes: "en 28 días", "en 45 días", "cada 28 días"
- Métricas clínicas: "el antígeno estaba en 600, bajó a 45"
- Años de experiencia: "36 años de medicina integrativa"

---

## 6. TONO EMOCIONAL

### Paternal-empático, NO motivacional
El doctor no es coach. No grita. No dice "¡tú puedes!". Su empatía es tranquila, de acompañamiento:

> "No estás solo."
> "Te acompañamos."
> "No te preocupes."

### Autoridad sin arrogancia
Habla desde la experiencia clínica, no desde el ego. Dice "hemos manejado pacientes" (plural, equipo), no "yo curé a...". Deja que los resultados hablen.

### El paciente es el héroe
Cuando presenta casos, el paciente es "guerrero/guerrera". El doctor es el medio, no el protagonista.

---

## 7. COLOMBIANISMOS Y NATURALIDAD

El doctor es colombiano. Su español tiene marcadores naturales que NO se deben eliminar ni exagerar:
- "pues" como conector natural
- "le cuento que" como transición
- Mezcla natural de tú/usted (puede cambiar en la misma frase)
- "¿Cierto?" o "¿verdad?" como tag questions (usar con moderación)

**NO agregar colombianismos que él no usa.** No forzar "parce", "bacano", etc. Su registro es profesional-cercano, no coloquial-callejero.

---

## 8. CHECKLIST ANTES DE ENTREGAR UN GUION

Antes de dar por terminado cualquier guion del Dr. Carlos, verificar:

- [ ] ¿Hay al menos 1 pregunta retórica con respuesta cortante?
- [ ] ¿Se usó "Le cuento que..." 1-2 veces?
- [ ] ¿Ninguna oración pasa de 25 palabras?
- [ ] ¿Todo término técnico está traducido inmediatamente?
- [ ] ¿Hay al menos 1 dato numérico concreto?
- [ ] ¿Sigue el patrón Causa → Efecto → Solución → Prueba?
- [ ] ¿El tono es paternal-empático, NO motivacional ni de coach?
- [ ] ¿No hay anglicismos, jerga de marketing ni frases de IA?
- [ ] ¿Los colombianismos son naturales, no forzados?
- [ ] ¿El doctor no es el héroe — el paciente/resultado lo es?