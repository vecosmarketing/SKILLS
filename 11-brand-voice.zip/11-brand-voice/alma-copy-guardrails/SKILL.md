---
name: alma-copy-guardrails
description: "Reglas de copy, tono y tecnicismos aprobados por el cliente de ALMA (Alma Balance y Creatina Creavitalis). Contiene correcciones validadas sobre qué decir, qué evitar, cómo estructurar gráficas before/after, claims científicos permitidos, referencias al CSIC, precios, y patrones de IA prohibidos. ALWAYS use this skill (ES/EN) BEFORE writing any copy, brief, ad, carousel, static, VSSL, landing, or any creative text for ALMA. Trigger on: any request to write copy for ALMA, brief de ALMA, ad copy ALMA, carrusel ALMA, estático ALMA, VSSL ALMA, landing ALMA, \"copy para Alma Balance\", \"copy para Creatina\", \"brief de creatina Alma\", \"copies de Alma\", or any creative output for Alma Balance or Creatina Creavitalis. This skill is a mandatory filter: load it, apply every rule, then write. It does NOT replace mlo-ad-brief-builder or mlo-brand-brain-alma; it layers on top as a copy compliance check."
---

# ALMA Copy Guardrails
## Reglas de copy, tono y tecnicismos aprobadas por el cliente

> Este skill es un filtro obligatorio. Se carga ANTES de escribir cualquier copy, brief o creativo para ALMA.  
> No reemplaza `mlo-ad-brief-builder` ni `mlo-brand-brain-alma`. Se aplica encima como capa de compliance.

---

## 1. PATRONES DE IA PROHIBIDOS

Estas estructuras delatan que el copy fue generado con IA. El cliente las rechaza. Nunca usarlas.

| Patrón prohibido | Por qué | Qué hacer en su lugar |
|---|---|---|
| "No es X, es Y" | Estructura binaria de IA obvia | Reformular con afirmación directa sin negación previa |
| Contraste "dos cafés" / "menos que un café al día" | Patrón de IA típico (contraste binario tipo consigna) | Usar el precio real: "22 céntimos al día", "Desde 39,99 EUR al mes" |
| Negaciones como gancho principal ("No es para el gym") | Activa objeciones que el lector no tenía | Afirmar el beneficio directo |
| Listas genéricas de beneficios sin jerarquía | Suena a prompt sin editar | Priorizar un beneficio por slide/sección, apoyar con dato concreto |

---

## 2. REGLAS DE TONO Y ESTRUCTURA

- **Frases cortas y directas.** Sin subordinadas largas.
- **Un beneficio por slide/sección.** No apilar 4 beneficios en un párrafo.
- **Datos concretos siempre que existan.** No generalizar ("mejora tu rendimiento") cuando hay un dato ("alcanza ~95% de fuerza recuperada en 72h").
- **Cierres siempre con precio + CTA.** Formato aprobado: "Desde 39,99 EUR al mes" o "22 céntimos al día. Suscríbete y cancela cuando quieras."
- **No usar agua con gas como sugerencia de mezcla.** Alternativas aprobadas: batido de Alma Balance, café, agua, zumo, leche vegetal.

---

## 3. CLAIMS CIENTÍFICOS PERMITIDOS Y PROHIBIDOS

### 3.1 Creatina Creavitalis

**Sí decir:**
- "Creavitalis de AlzChem. La misma materia prima que usan los estudios clínicos."
- "Versión premium de los creadores de Creapure."
- "Pureza mayor o igual a 99,95%."
- "AlzChem, Alemania." (siempre mencionar origen alemán)
- "La creatina que usan los estudios."
- "Recuperación más rápida." (como beneficio directo)
- Sobre origen de la competencia: "Nosotros de AlzChem, Alemania. La mayoría, de Asia."
- Precio: "22,99 EUR" vs competencia "Mínimo 35 EUR" / "30 EUR+"

**No decir:**
- Comparaciones marca contra marca (ej: "mejor que [marca X]"). Solo comparar "con creatina vs sin creatina".
- Claims de volumen/tamaño muscular como hook general (solo válido para perfil Fran en BOFU puro).
- Fase de carga como argumento.

### 3.2 Alma Balance

**Sí decir:**
- "30 ingredientes en dosis clínicas."
- "Fabricado en España."
- "2,8g de espirulina española." (cultivada en Murcia)
- "Magnesio, vitaminas del grupo B, prebióticos y enzimas digestivas."
- "B12, magnesio, hierro y espirulina española."
- "Fibra soluble + proteína vegetal."
- "Una cucharada al despertar."
- "Desde 39,99 EUR al mes."
- Sobre nutrición matutina: "Cubrir las bases de nutrición (proteína y micronutrientes) a diario sin exceso de azúcares, grasas o alimentos procesados que empeoran el metabolismo e inflaman el estómago."

**No decir:**
- "Desarrollado con el CSIC" para Balance. Balance NO tiene colaboración formalizada con el CSIC.
- Sí se puede decir "desarrollado con instituciones científicas" como frase genérica para Balance.
- Las gummies SÍ tienen colaboración formal con el CSIC. Para gummies se puede mencionar el CSIC directamente.
- "Sabor delicioso" o vender el sabor como positivo. El sabor es polarizante y el ángulo correcto es gestionar la expectativa.

---

## 4. GRÁFICAS BEFORE/AFTER: REGLAS DE EJECUCIÓN

El concepto de gráfica before/after está aprobado y el cliente quiere mantenerlo. La ejecución debe cumplir estas reglas:

### 4.1 Reglas generales de todas las gráficas
- **Eje Y en escala humana:** porcentaje (%) o escala 0-10. Nunca unidades abstractas.
- **Eje X en tiempo humano:** 24h, 48h, 72h o 9h, 11h, 13h, 16h. Nunca "Semana 1, Semana 2".
- **Curvas limpias y orgánicas.** Sin oscilaciones tipo ECG. Sin picos artificiales.
- **Cita al pie con fuente.** Siempre. Formato: "Adaptado de [Autor] et al., [Revista]. n=[muestra]." o "Basado en literatura sobre [tema]."
- **Comparación honesta:** "con vs sin" el ingrediente. NUNCA marca vs marca.
- **Cierre debajo de la gráfica** con claim de producto + precio.
- **Producto visible** sobre el eje X, lado derecho.
- **Color verde** = con el producto de ALMA. **Color gris** = sin el producto.

### 4.2 Gráficas aprobadas para CREATINA

**Gráfica 1: Recuperación muscular tras entrenar**
- Subtítulo: Con creatina vs sin creatina
- Eje Y: Fuerza recuperada (%)
- Eje X: 24h, 48h, 72h
- Verde (con creatina): sube progresivamente, alcanza ~95% en 72h
- Gris (sin creatina): sube pero mas lenta, alcanza ~75% en 72h
- Pie: Adaptado de Cooke et al., JISSN. n=14
- Cierre: Creavitalis. Pureza mayor o igual a 99,95%. La misma materia prima que usan los estudios clínicos.

**Gráfica 2: Cuánto tarda el músculo en volver a la línea base**
- Subtítulo: Con y sin creatina diaria
- Eje Y: Capacidad funcional (%)
- Eje X: Día 1, Día 2, Día 3, Día 5
- Verde: curva suave, llega antes al 100%
- Gris: curva suave, llega al 100% mas tarde
- Pie: Basado en literatura sobre creatina y recuperación muscular
- Cierre: Creavitalis. Pureza mayor o igual a 99,95%. La misma materia prima que usan los estudios clínicos.

**Gráfica 3: El daño muscular después de entrenar fuerte**
- Subtítulo: Con y sin creatina
- Eje Y: Daño muscular percibido (0-10). Escala invertida: valor bajo = recuperación mejor
- Eje X: 24h, 48h, 72h, 96h
- Verde (con creatina): pico moderado a 48h, baja hasta valores bajos a 96h
- Roja/gris (sin creatina): pico mas alto a 48h, baja mas lento
- Pie: Basado en literatura sobre creatina y marcadores de daño muscular
- Cierre: Creavitalis. Pureza mayor o igual a 99,95%. La misma materia prima que usan los estudios clínicos.

### 4.3 Gráficas aprobadas para ALMA BALANCE

**Gráfica 1: Cómo se siente el abdomen después de comer**
- Bajada: Con y sin fibra prebiótica
- Eje Y: Hinchazón percibida (0-10)
- Eje X: 1h, 2h, 3h, 4h
- Gris (sin fibra): pico alto a las 2h, baja lentamente, sigue elevada a las 4h
- Verde (con Alma Balance): pico mas bajo a las 2h, desciende mas rápido, vuelve a niveles bajos a las 4h
- Pie: La fibra soluble forma un gel que ralentiza el vaciado gástrico y modula la fermentación intestinal
- Cierre: Prebióticos, enzimas digestivas y fibra soluble en una cucharada. Desde 39,99 EUR al mes.

**Gráfica 2: Cómo cambia la energía cuando arrancas con nutrientes**
- Bajada: Desayuno con base nutricional vs sin ella
- Eje Y: Energía percibida (0-10)
- Eje X: 9h, 11h, 13h, 16h
- Gris (sin desayuno nutricional): sube modestamente a media mañana, cae a las 13h, sigue baja a las 16h
- Verde (con Alma Balance): sube mas alto a media mañana, baja menos en la comida, mantiene mejor a las 16h
- Pie: La energía sostenida depende del aporte de vitaminas B, magnesio y hierro, no solo de cafeína
- Cierre: B12, magnesio, hierro y espirulina española. En una cucharada al despertar. Desde 39,99 EUR al mes.

**Gráfica 3: Glucosa en sangre tras desayuno**
- Título: Por qué un desayuno con Alma Balance cambia el día entero
- Bajada: Glucosa en sangre tras un desayuno con y sin fibra prebiótica
- Eje Y: Glucosa en sangre (mg/dL)
- Eje X: Desayuno, Media mañana, Comida, Tarde
- Gris (sin fibra): pico alto tras desayuno, bajón a media mañana, pico mayor tras comida
- Verde (con Alma Balance): subida mas suave, sin bajón a media mañana, pico de comida controlado
- Pie: El efecto segunda comida: la fibra y la proteína del desayuno moderan la respuesta glucémica de las comidas posteriores. Jenkins et al., 1982
- Cierre: Fibra soluble + proteína vegetal al despertar. Picos y bajones mas estables, todo el día. Desde 39,99 EUR al mes.

**Gráfica 4: Cómo se sostiene la energía durante la mañana**
- Bajada: Café solo, base nutricional sola, o las dos cosas
- Eje Y: Energía percibida (0-10)
- Eje X: 9h, 11h, 13h, 16h
- TRES curvas:
  - Gris (solo café): sube muy rápido, pico alto a 11h, baja con fuerza a 13h, sigue bajando a 16h
  - Verde claro (solo Alma Balance): sube progresivamente, nivel medio-alto a 11h, baja muy poco en comida, estable a 16h
  - Verde intenso (café + Alma Balance): sube alto a 11h, baja menos que solo café en comida, mantiene mejor por la tarde
- Pie: La cafeína da una subida aguda. Las vitaminas B, el magnesio y el hierro sostienen la energía celular. Funcionan en momentos distintos
- Cierre: B12, magnesio, hierro y espirulina española. En una cucharada al despertar. Desde 39,99 EUR al mes.

**Gráfica 5: Regulación del hambre durante todo el día**
- Título: Alma Balance te regula el hambre durante todo el día
- Bajada: Sensación de hambre a lo largo del día con y sin fibra prebiótica al despertar
- Eje Y: Hambre percibida (0-10)
- Eje X: 9h, 11h, 13h, 16h, 19h
- Gris (sin fibra): sube fuerte a 11h (antojo), pico a 13h, baja con comida, sube fuerte a 16h (bajón tarde), alta a 19h
- Verde (con Alma Balance): sube despacio sin pico a 11h, hambre normal a 13h, sube poco a 16h, llega a 19h sin antojo
- Pie: La fibra y la proteína por la mañana regulan la liberación de péptidos de saciedad (GLP-1, PYY) y modulan la respuesta glucémica de las comidas posteriores. Es el llamado "efecto segunda comida"
- Cierre: Cómo arranca el día decide cómo termina. Una cucharada al despertar. Desde 39,99 EUR al mes.

---

## 5. ÁNGULO PRECIO CREAVITALIS: ESTRUCTURA APROBADA

- Título: Misma fábrica. Misma materia prima. 13 EUR menos.
- Bajada: Otras marcas también usan Creavitalis. Pagas el sobreprecio, no la calidad.
- Tabla comparativa (4 filas):
  - Precio: "Mínimo 35 EUR" vs "22,99 EUR"
  - Origen: "AlzChem, Alemania" vs "AlzChem, Alemania"
  - Pureza: "mayor o igual a 99,9%" vs "mayor o igual a 99,9%"
  - Formato: "Micronizada" vs "Micronizada"
- Cierre: 22 céntimos al día. Sin pagar la prima de marca. Suscríbete y cancela cuando quieras.

---

## 6. CARRUSEL "3 CAMBIOS PARA SENTIRTE MEJOR POR LA MAÑANA": ESTRUCTURA APROBADA

**Slide 1:** Título: Tres cambios para sentirte mejor por la mañana. Bajada: Los primeros 90 minutos deciden cómo va tu día.

**Slide 2 (Cambio 1):** Luz natural antes que pantalla. Diez minutos de luz solar al despertar regulan el cortisol y el ritmo circadiano. Cierre: Te levantas mas despierta y con la cabeza mas clara.

**Slide 3 (Cambio 2):** El café, 90 minutos después. La adenosina tarda 90 min en limpiarse. Si tomas café antes, solo la enmascara. Cierre: Energía mas estable durante el día, también por la tarde.

**Slide 4 (Cambio 3):** Nutrición funcional, antes del primer café. Una cucharada de Alma Balance en agua al despertar: 2,8g de espirulina española, magnesio, vitaminas del grupo B, prebióticos y enzimas digestivas.

**Slide 5:** Luz. Tiempo. Alma Balance. Tres cosas. Los primeros 90 minutos. Cierre: 30 ingredientes en dosis clínicas. Fabricado en España. Desde 39,99 EUR al mes.

---

## 7. REGLA CSIC / INSTITUCIONES CIENTÍFICAS

| Producto | Qué se puede decir | Qué NO se puede decir |
|---|---|---|
| Alma Vital Gummies | "Co-desarrolladas con el CSIC" / "Colaboración directa con el CSIC" | Nada fuera de alcance |
| Alma Balance | "Desarrollado con instituciones científicas" (genérico) | "Desarrollado con el CSIC" (Balance NO tiene colaboración formalizada) |
| Creatina Creavitalis | "Creavitalis de AlzChem" / referencias a estudios clínicos | Claims de CSIC (no aplica a creatina) |

---

## 8. SUGERENCIAS DE MEZCLA APROBADAS

- Agua
- Café
- Batido de Alma Balance (mezclar productos entre sí)
- Zumo
- Leche vegetal

**NO sugerir:** agua con gas.

---

## 9. CHECKLIST PRE-ENTREGA

Antes de entregar cualquier copy de ALMA, verificar:

- [ ] No hay ningún "No es X, es Y"
- [ ] No hay contrastes binarios tipo "menos que un café" / "dos cafés"
- [ ] Los precios son los reales (22,99 EUR creatina / 39,99 EUR Balance)
- [ ] Las gráficas usan escala humana (%, 0-10, mg/dL) y tiempo humano
- [ ] Las gráficas comparan "con vs sin", nunca marca vs marca
- [ ] Las gráficas tienen pie con fuente
- [ ] No se menciona CSIC para Balance (solo instituciones científicas en genérico)
- [ ] No se sugiere agua con gas
- [ ] El cierre tiene precio + CTA
- [ ] Creavitalis se menciona con "AlzChem, Alemania" y/o "creadores de Creapure"