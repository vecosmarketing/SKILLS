---
name: voz-moncho-moreno
description: "Guía de voz y estilo comunicativo de Moncho Moreno (founder) para guiones, copys de ads, briefs y cualquier contenido donde Moncho sea el narrador o la voz de la marca. Replica sus patrones de comunicación oral: tono, ritmo, estructura de frases, vocabulario, muletillas, y forma de explicar conceptos técnicos en lenguaje de calle. ALWAYS use this skill BEFORE writing any script, guion, VSL, UGC, video ad copy, carousel copy, static copy, tweet, or spoken-word content donde Moncho Moreno sea el talento, narrador o voz de marca. Trigger on: \"guion de Moncho\", \"script de Moncho\", \"como habla Moncho\", \"voz de Moncho\", \"VSL de Moncho\", \"video de Moncho\", \"guion MMO con Moncho\", \"cómo diría Moncho esto\", \"adapta esto a la voz de Moncho\", \"copy en voz de Moncho\", \"ad copy voz founder\", \"tono Moncho\". Trigger also when writing any Moncho Moreno video script, carousel, or ad copy that features Moncho as speaker, even if not explicitly mentioned. Does NOT replace mlo-ad-brief-builder; it layers on top a"
---

# Voz Moncho Moreno — Guía de estilo comunicativo

## Quién es Moncho
Estilista con más de 40 años de experiencia. Fundador de Moncho Moreno. Trabaja con celebrities (Isabel Preysler, entre otras). Tiene salón en Madrid (Lagasca). Creó la marca desde la experiencia real en sillón, no desde un laboratorio.

---

## TONO GENERAL
- **Experto cercano.** Habla como un amigo que sabe mucho. Nunca como un doctor ni como un vendedor.
- **Directo.** Frases cortas. Va al grano. No rodea.
- **Cariñoso pero firme.** Dice las cosas claras, pero con cariño. "Escucha esto porque te va a interesar."
- **Entusiasta genuino.** Se emociona de verdad con los resultados. No finge. "No sabéis la cara de felicidad que se me queda cuando ves a las clientas que después de usarlo comienzan a recuperar su cabello."

---

## ESTRUCTURA NARRATIVA TÍPICA
Moncho siempre sigue este patrón:
1. **Empieza desde TU problema.** Nunca desde el producto. "Tienes el cabello fino, las raíces grasas y las puntas secas. Escucha esto."
2. **Explica POR QUÉ te pasa.** En lenguaje simple. "Al no lavarse el pelo cuando le toca, lo que conseguimos es que se acumule grasa."
3. **Da la solución como consejo de experto.** No como venta. "Una de las claves para evitar la caída es tener tu cuero cabelludo limpio y sano."
4. **Menciona el producto de forma natural.** Como si fuera una recomendación personal. "Obviamente sabes que mi favorito es el Bond."

---

## FRASES Y MULETILLAS REALES
Usar estas construcciones como base (no copiar literal, pero mantener el espíritu):

### Apertura / Hook
- "Escucha esto porque te va a interesar."
- "Una de las cosas que la gente no sabe sobre [X] es que..."
- "Tienes el pelo [problema]. Vamos a ver qué le pasa."
- "¿Quieres saber cómo [resultado]? Te cuento."
- "Si tienes el pelo [condición], esto te va a cambiar la vida."

### Autoridad
- "Llevo más de 40 años en el mundo de la belleza."
- "Soy Moncho Moreno y llevo más de 40 años como experto en el mundo del cabello."
- "Lo que veo todos los días en el salón es..."
- "Lo desarrollé después de 40 años viendo a clientes que se gastaban fortunas en productos que realmente no hacían nada."

### Transiciones
- "¿Y qué genera esto?"
- "¿Y sabes qué pasa?"
- "Pues es muy sencillo."
- "Os cuento."
- "Vamos a ver."
- "Fíjate."

### Explicación técnica simplificada
- "Tu folículo capilar, o sea tu raíz, se debilita."
- "Es como cuando tú te alimentas bien, tienes más salud. Exactamente igual."
- "Las venas se ponen gordas, cuando se ponen gordas entra el producto."
- "Donde no hay nada que reparar, el propio agua lo elimina."

### Cierre / CTA
- "Yo te animo a que lo pruebes."
- "Anímate a probar el [producto] del que todo el mundo habla."
- "Espero que te haya servido."
- "Estás pasando por esto. Yo te animo a que lo pruebes y que nos mandes un comentario con tu cambio, porque te aseguro que lo tendrás."
- "Así que ya tienes la solución."

---

## REGLAS DE VOZ INAMOVIBLES

### SÍ hacer:
- Tutear siempre. Nunca de usted.
- Frases cortas. Punto. Otra idea. Punto.
- Preguntas retóricas para mantener atención: "¿Y qué genera esto?"
- Explicar lo técnico con analogías del día a día.
- Mostrar emoción real por los resultados de las clientas.
- Numerar consejos cuando da tips: "Lo primero... Lo segundo... Lo tercero..."
- Usar "cabello" y "pelo" indistintamente (Moncho usa ambos).
- Mencionar el salón como prueba de autoridad: "lo que veo en el salón todos los días."
- Hablar de "40 años" como ancla de credibilidad.

### NO hacer:
- Nunca hablar como un anuncio. Nada de "descubre", "aprovecha", "no te lo pierdas".
- Nunca usar tecnicismos sin explicarlos inmediatamente después.
- Nunca meter claims que no estén verificados por la marca.
- Nunca sonar frío o distante. Moncho es cálido siempre.
- Nunca vender de forma agresiva. El producto llega como recomendación, no como pitch.
- Nunca decir "link en bio" o "haz clic aquí". Moncho cierra con invitación, no con orden.
- Nunca inventar tecnologías o ingredientes que no existan en los productos.

---

## CÓMO EXPLICA CADA PRODUCTO (patrones reales)

### Rapunhair (B21 / caída)
"Una de mis prioridades más importantes fue crear un serum de crecimiento capilar, no solamente para fortalecer el folículo, sino también para evitar la caída."
- Habla de la cafeína que activa la circulación.
- Habla de la clorofila para la microbiota del cuero cabelludo.
- Habla del masaje como parte del ritual.
- Emocional: "la cara de felicidad cuando ves a las clientas recuperar su cabello."

### Bond / J'aime Bond (M28 / reparación)
"Lo que hace M28 en tu cabello en los primeros siete días no hay ningún producto que haga lo mismo."
- M28 busca las zonas rotas y las repara.
- Donde no hay daño, el agua lo elimina. No deja peso ni residuo.
- Desde el primer uso se nota.
- A los 3 días el pelo deja de caerse (porque deja de romperse).
- A los 7 días la fibra recupera estructura.

### One Minute Wonder (mascarilla reparadora)
"Tiene una proteína espectacular para recuperar tu cabello."
- Un minuto mínimo de exposición.
- Recupera fuerza y cuerpo.
- Para después de color, mechas o tratamientos.

### Coffee Smoothie (champú)
- Limpia bien pero equilibra.
- Ingredientes como cafeína, romero, extractos botánicos.
- El champú es para cuero cabelludo, no para las puntas.

### Anti-frizz (tratamiento salón)
"Hemos creado un tratamiento que no solamente le da peso al cabello y lo rellena, sino que también le quita el frizz y le da un aspecto más alisado y sobre todo brillante."
- Se pone de mojado, se seca y se pasa la plancha para sellar.
- Recomendación: no lavar en dos días.
- Resultado: pelo más sano, más hidratado, menos aparatos de calor.

---

## CHECKLIST ANTES DE ENTREGAR CUALQUIER COPY EN VOZ MONCHO

1. ¿Empieza desde el problema de la persona, no desde el producto?
2. ¿Las frases son cortas y directas?
3. ¿Lo técnico se explica en lenguaje de calle?
4. ¿Suena a Moncho hablando en un TikTok o a un copywriter escribiendo?
5. ¿El producto aparece como recomendación natural, no como pitch?
6. ¿Hay algún claim inventado? → Si sí, eliminar.
7. ¿Lo diría Moncho exactamente así? → Si no, reescribir.