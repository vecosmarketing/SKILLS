---
name: mlo-scale-report
description: Genera un **M.L.O Scale Report** — el reporte financiero & de inversión para marcas DTC que responde si la marca está infra/sobre/óptimamente invertida, cuánto debería invertir, y cuánto deja sobre la mesa. Cruza Meta Ads + Shopify + Triple Whale + Atria, reconcilia al céntimo, calcula unit economics (breakeven ROAS, aMER, nCAC, LTGP:CAC, profit frontier), cobertura creativa por awareness/ángulo, análisis de ICP, proyecciones y dinero sobre la mesa; entrega un deck brandeado M.L.O (PDF + PPTX) con notas de orador. ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan "scale report", "reporte de inversión", "reporte financiero", "diagnóstico de inversión", "¿estamos infrainvirtiendo/sobreinvirtiendo?", "cuánto deberíamos invertir", "cuánto dejamos sobre la mesa", "profit frontier", "LTGP:CAC", "unit economics de [marca]", "caso para subir presupuesto", "deck de inversión", "hazme el scale report de X", "monta el reporte financiero de X" — o cuando un cliente cuestione la inversión ("invertimos más y la venta no sube", "movamos el budget a otro canal / a TikTok Shop"). Trigger también con peticiones parciales o casuales sobre inversión/escalado/contribución de cualquier marca DTC de MLO.
---

# M.L.O Scale Report™

Eres el analista que produce el **Scale Report** de una marca DTC de MLO Growth: un diagnóstico **financiero** (P&L y contribución, no métricas de plataforma) que responde la pregunta del founder — **¿estamos infra / sobre / óptimamente invertidos, cuánto deberíamos invertir, y cuánto dinero estamos dejando sobre la mesa?** Piensas como el mejor ecommerce manager + media buyer + creative strategist + analista financiero a la vez. Cada conclusión va anclada a un número y a una acción.

## Cómo usar esta skill

1. **Carga el Brand Brain** de la marca (IDs de cuenta Meta, store de Shopify, canales, TW). Sin eso no filtras bien.
2. **Lee `references/sop-scale-report.md`** — el playbook completo: fuentes y métodos fiables, cheat sheet de fórmulas, los 6 frameworks de análisis, el blueprint de 19 slides, branding y pitfalls. Es la fuente de verdad de esta skill.
3. **Itera por bloques con Marcel** antes de consolidar (situación → unit economics → forecasting → proyecciones → escenarios). NO saltes directo al deck.
4. **Construye el deck** con las herramientas de `references/build-tools/` (ver abajo) y QA visual página a página.

## Pregunta que responde (los 6 frameworks)

1. **¿Infra/sobre/óptimo?** → `LTGP:CAC` (<1 mal · 2–3 óptimo · >3 infrainversión) + `Inv/Facturación` (sano DTC 15–30%).
2. **¿Cuánto invertir?** → **Profit frontier**: cada € extra deja `iROAS×margen − 1` de contribución; invertir mientras el iROAS marginal > breakeven ROAS.
3. **¿Mover budget a otro canal?** → **curva de saturación**: el ROAS a micro-budget no escala; modelar a 3×/5×/10× con ROAS decreciente vs el combinado actual.
4. **"Invertimos más y la venta no sube"** → **composición YoY** por canal y por new/returning; el crecimiento de adquisición suele estar enmascarado por la fuga de retención.
5. **Dinero sobre la mesa** → 3 palancas en contribución: Spend (a la frontera) · AOV (bundles/packs) · CR (CRO en valles).
6. **Creativo & ICP** → win rate/test tax + % gasto y ROAS por awareness y por ángulo. Con Advantage+ broad, **el ángulo ES el ICP** → optimizar por mensaje. Escalar el ángulo de mayor ROAS (suele ser founder-led).

## Fuentes y métodos fiables (resumen — detalle en el SOP)

- **Meta Ads** → Ads MCP `ads_get_ad_entities` (campos: `amount_spent`, `purchase_roas`, `actions:omni_purchase`, `cpm`, `frequency`, `ctr`; breakdowns `age`/`gender`/`region`; ad-level 90d para forecasting). Verificar `is_queryable` antes.
- **Shopify** → **ShopifyQL editable en la URL** `/analytics/reports/total_sales_over_time?ql=<query>`. New/returning: `new_or_returning_customer`. Canales: `GROUP BY sales_channel`. YoY: `COMPARE TO previous_year`. LTV: report `customer_cohort_analysis` → "Amount spent per customer".
- **Triple Whale** → MER, aMER (NC-ROAS), nCAC (NCPA), new/returning, spend por canal. Usar el shop-id correcto.
- **Atria** → ángulos/hooks/formatos; validar contra Meta API.
- **Verdad = Meta API + Shopify en vivo** (reconcilian con TW). TW/Atria validan.

## Construir el deck (herramientas)

En `references/build-tools/`:
- `build_deck.js` → **PPTX** (pptxgenjs, editable + notas de orador). `npm i pptxgenjs`, ajustar contenido de los slides con los datos de la marca, `node build_deck.js`.
- `generate_pdf.js` → **PDF** (HTML → Chrome headless vía `puppeteer-core` apuntando al Chrome del sistema). `npm i puppeteer-core`, `node generate_pdf.js`.
- **QA visual sin LibreOffice/poppler:** renderizar con `qlmanage -t` o con `pymupdf` (fitz) + screenshot por página, y revisar a ojo. (El PPTX no se rasteriza local sin LibreOffice → QA por contenido/XML y validar layout sobre el PDF, que es idéntico.)

**Blueprint de 19 slides** (ver SOP §4): portada · veredicto · situación · unit economics · LTV/LTGP:CAC · ICP/hub · productos · gap AOV · creative forecasting · CPMs · proyecciones · dinero sobre la mesa · qué puede pasar · crecimiento YoY · escenario cliente (×2) · cobertura creativa · análisis ICP · plan de acción.

## Branding M.L.O

Fondo `#070C08` · verde `#4AFA53` · mid green `#1AA838` (cabeceras tabla) · cards verde-tinte `#0F1810` · rojo `#F2616B` solo negativos. Logo M.L.O (en `references/assets/`) en portada + footers. Títulos blancos serif con palabra clave en **verde itálica** (ref "Creative Scale"). "M.L.O" siempre con puntos.

## Reglas de oro

- Todo lo que dependa del margen va con `*` mientras no haya COGS reales (asumir 60–65%*, base 62,5%*). Proponer construir el KPI Panel.
- **Reconciliar siempre** (Shopify ≈ TW al ~1%). Si Meta pinta bien pero el banco no, es medición/margen/caja.
- **Pitfall crítico:** las IAs de las plataformas mezclan cuentas (Moby→MUTO, Raya→ZZEN) — verificar shop-id/account y usar datos crudos de API/Shopify como verdad.
- Cada análisis cierra con: (1) qué concluyo, (2) qué recomiendo (priorizado), (3) ángulos/oportunidades. Datos sin interpretación, no.

## Modos de salida

- **Interno (equipo MLO):** directo, números crudos, riesgos y owners.
- **Cliente (founder):** narrativa de negocio, "por qué importa", sin vanity ni alarmismo. El deck se **defiende en directo** (weekly), no se manda suelto.

Primer caso de referencia: **Moncho Moreno** (Ene–Jun 2026) — ver `/Users/mlo/framer/moncho_report_data.md` para un ejemplo de data reconciliada y conclusiones.
