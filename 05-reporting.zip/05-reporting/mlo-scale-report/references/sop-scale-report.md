# SOP — M.L.O **Scale Report**™
### Cómo crear un reporte financiero & de inversión para una marca DTC

> **Concepto.** El *Scale Report* responde, con **números financieros** (P&L y contribución, no métricas de plataforma), a la pregunta del founder: **¿estamos infra / sobre / óptimamente invertidos, cuánto deberíamos invertir, y cuánto dinero estamos dejando sobre la mesa?** Cruza Meta + Shopify + Triple Whale + Atria, reconcilia todo al céntimo, y baja cada conclusión a una acción con su "por qué importa".
>
> **Cuándo se hace.** Revisión trimestral/semestral, antes de decidir presupuesto, o cuando el cliente cuestiona la inversión ("invertimos más y la venta no sube", "movamos todo el budget a X canal").
>
> **Nombre.** *M.L.O Scale Report*. Alternativas: Investment & Scale Report · Growth Frontier Report · Profit Frontier Report.

---

## 1) Fuentes de datos y cómo sacarlas (métodos fiables, probados)

| Fuente | Qué extraigo | Método fiable |
|---|---|---|
| **Meta Ads** | spend, ROAS, compras, CPM, frecuencia, CTR (mensual) · inventario ad-level 90d · breakdown demográfico | **Ads MCP** `ads_get_ad_entities`. Campos válidos: `amount_spent`, `purchase_roas`, `actions:omni_purchase`, `cpm`, `frequency`, `ctr`, `clicks`, `results`. Breakdowns: `age`, `gender`, `region`. Antes, `ads_get_ad_accounts` y comprobar `is_queryable`. |
| **Shopify** | revenue gross/net/total, pedidos, AOV, CVR, sesiones, new vs returning, productos, **canales**, cohorte LTV | **ShopifyQL editable en la URL**: `/analytics/reports/total_sales_over_time?ql=<query-URL-encoded>`. Ej: `FROM sales SHOW gross_sales, net_sales, orders TIMESERIES month SINCE 2026-01-01 UNTIL 2026-06-22`. Canales: `GROUP BY sales_channel`. New/returning: `WHERE new_or_returning_customer = 'New'`. YoY: `COMPARE TO previous_year`. LTV: report `customer_cohort_analysis`, métrica "Amount spent per customer". |
| **Triple Whale** | MER, **aMER (NC-ROAS)**, **nCAC (NCPA)**, % new vs returning, ad spend total por canal | Summary dashboard. ⚠️ Usar el **shop-id correcto** (Moncho = `moncho-moreno.myshopify.com`). |
| **Atria** | hooks, ángulos, USPs, formatos, hook/hold rate | Navegador / Raya. **Validar siempre contra Meta API.** |

**Regla:** la verdad es **Meta API + Shopify en vivo** (reconcilian con TW al céntimo). TW y Atria validan y complementan; nunca son la fuente primaria.

---

## 2) Métricas & fórmulas (cheat sheet)

```
Breakeven ROAS      = 1 / margen bruto*              (62,5%* → 1,60)
MER (blended)       = Facturación total / Ad spend total
aMER (NC-ROAS)      = Revenue de CLIENTE NUEVO / Ad spend
nCAC                = Ad spend / nº clientes NUEVOS  (no CPA de plataforma)
MCPA (1ª compra)    = AOV_nuevo × margen* − costes variables/pedido
MC ROAS             = ROAS × margen bruto*           (breakeven = 1,0)
LTGP                = LTV revenue × margen bruto*
LTGP : CAC          = LTGP / nCAC   (<1 mal · 2–3 óptimo · >3 INFRAINVERSIÓN)
Inv / Facturación   = Ad spend / Facturación         (sano DTC: 15–30%)
Contribución por €  = 1 × (iROAS_marginal × margen* − 1)
Profit frontier     = invertir mientras iROAS_marginal > breakeven ROAS
```
*Todo lo que dependa del margen va con `*` mientras no haya COGS reales (asumir 60–65%*, base 62,5%*).*

---

## 3) Frameworks de análisis (el corazón del reporte)

1. **¿Infra / sobre / óptimo?** → `LTGP:CAC` (brújula) + `Inv/Facturación`. >3 y/o <5% = infrainversión.
2. **Cuánto invertir** → **Profit frontier**: cada € extra deja `iROAS×margen − 1` de contribución; se invierte mientras el iROAS marginal supere el breakeven. Si el ROAS medio es 7–16x y el breakeven 1,6x, la frontera está lejísimos.
3. **"Mover budget a otro canal" (escenario)** → **curva de saturación**: el ROAS a micro-budget NO escala (recoges la demanda más caliente). Modelar a 3×/5×/10× el gasto con ROAS decreciente y comparar contra el combinado actual. Casi siempre destruye valor si además matas el canal probado.
4. **"Invertimos más y la venta no sube"** → **composición YoY**: descomponer por **canal** y por **new vs returning**. El crecimiento de adquisición (cliente nuevo, +X%) suele estar **enmascarado** por la fuga de retención (app/recurrente plano). El paid es ~5% de la facturación → no puede "doblar" la tienda; su trabajo es traer cliente nuevo rentable.
5. **Dinero sobre la mesa** → 3 palancas en contribución: **Spend** (hasta la frontera), **AOV** (bundles/packs → baja el breakeven → habilita más spend), **CR** (CRO en meses valle).
6. **Creativo** → win rate / test tax + **% gasto y ROAS por awareness y por ángulo**. Con Advantage+ broad, **el ángulo ES el ICP** → optimizar por mensaje. Identificar el ángulo de mayor ROAS (suele ser founder-led) y escalarlo.

---

## 4) Blueprint del deck (19 slides)

1. Portada · 2. TL;DR/Veredicto · 3. Situación 6M · 4. Unit economics (sensibilidad margen) · 5. LTV & LTGP:CAC · 6. ICP/hub · 7. Productos · 8. Gap AOV/bundles · 9. Creative forecasting · 10. CPMs al alza · 11. Proyecciones (profit frontier) · 12. Dinero sobre la mesa · 13. Qué puede pasar (2 escenarios) · 14. Crecimiento YoY (composición) · 15–16. Escenario cliente (realidad + matemática) · 17. Cobertura creativa (awareness × ángulos) · 18. Análisis de ICP · 19. Plan de acción.

*1 idea por slide · números grandes · poco texto · notas de orador con el detalle.*

---

## 5) Branding M.L.O (spec)

- Fondo `#070C08` (verde-negro) · verde de marca `#4AFA53` · mid green `#1AA838` (cabeceras de tabla) · cards con tinte verde `#0F1810` · rojo `#F2616B` solo para negativos.
- Logo M.L.O en portada (grande) y footer de cada página (PNG transparente en `assets/`).
- Títulos blancos serif (Georgia) con la palabra clave en **verde itálica** (estilo "Creative *Scale*"). Cuerpo sans. Kicker verde con cuadradito.

---

## 6) Checklist de proceso

1. Cargar Brand Brain de la marca (IDs de cuentas, store, canales).
2. Meta API: serie mensual + ad-level 90d + breakdowns. Reconciliar con el último reporte mensual.
3. Shopify ShopifyQL: revenue/AOV/CVR/sesiones, new vs returning, productos, canales, cohorte LTV, **YoY COMPARE TO previous_year**.
4. Triple Whale: MER/aMER/nCAC + spend total por canal. Reconciliar con Shopify+Meta.
5. Atria/ad-level: awareness, ángulos, ICPs, win rate.
6. Calcular unit economics + LTGP:CAC + profit frontier + dinero sobre la mesa (sensibilidad 60–65%*).
7. **Iterar por bloques con el lead** antes de consolidar. Verificar breakeven, sumas P&L, worked example.
8. Maquetar deck (build_deck.js → PPTX · generate_pdf.js → PDF) y QA visual página a página.

---

## 7) Pitfalls (aprendidos en producción)

- **Las IAs de las plataformas mezclan cuentas** (Moby→MUTO, Raya→ZZEN). SIEMPRE verificar shop-id / account; usar datos crudos de API/Shopify como verdad y cruzar.
- **Triple Whale free tier**: su "Net Margin" es un default placeholder → ignorar, usar el margen asumido.
- **Sin COGS reales** → margen 60–65%*, marcar TODO lo derivado con `*` y proponer construir el KPI Panel.
- **Advantage+ broad**: no hay gasto "por ICP"; el ICP se expresa por el ángulo que convierte.
- **Reconciliar siempre**: si Shopify y TW no cuadran al ~1%, hay un problema de medición antes que de paid.
- **El blended top-line engaña**: descomponer por canal y por new/returning para no leer "plano" lo que en realidad crece en adquisición.

---

*Herramientas de build en este repo: `build_deck.js` (PPTX, pptxgenjs) · `generate_pdf.js` (PDF, HTML→Chrome) · `moncho_report_data.md` (data cruda reconciliada) · `assets/` (logos M.L.O).*
