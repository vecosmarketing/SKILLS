const pptxgen = require("pptxgenjs");
const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5
pres.author = "MLO Growth";
pres.title = "Moncho Moreno — Reporte Financiero & de Inversión";

// ---------- Palette (dark premium / beauty) ----------
// M.L.O Growth brand
const BG    = "070C08";
const CARD  = "0F1810";
const CARD2 = "16241A";
const LINE  = "244430";
const GOLD  = "4AFA53";   // brand green (primary accent)
const GREEN = "4AFA53";   // positive / money
const GREEND= "1AA838";   // mid green (table headers / fills)
const RED   = "F2616B";   // warning / cost of inaction
const WHITE = "FFFFFF";
const MUTE  = "93A79A";
const DIM   = "5F7268";
const LOGO  = "assets/mlo_logo.png";
const LOGO_COVER = "assets/mlo_logo_cover.png";

const TITLE = "Georgia";
const BODY  = "Calibri";

const W = 13.3, H = 7.5, MX = 0.62;
const shadow = () => ({ type: "outer", color: "000000", blur: 9, offset: 3, angle: 135, opacity: 0.35 });

let pageNo = 0;
function base(opts) {
  const slide = pres.addSlide();
  slide.background = { color: BG };
  pageNo++;
  if (opts && opts.kicker) {
    slide.addShape(pres.shapes.RECTANGLE, { x: MX, y: 0.52, w: 0.13, h: 0.13, fill: { color: GOLD } });
    slide.addText(opts.kicker.toUpperCase(), { x: MX + 0.24, y: 0.45, w: 11, h: 0.3, margin: 0,
      fontFace: BODY, fontSize: 11.5, bold: true, color: GOLD, charSpacing: 3, align: "left" });
  }
  if (opts && opts.title) {
    slide.addText(opts.title, { x: MX, y: 0.78, w: 12.1, h: 0.85, margin: 0,
      fontFace: TITLE, fontSize: 29, bold: true, color: WHITE, align: "left" });
  }
  // footer
  slide.addImage({ path: LOGO, x: MX, y: H - 0.44, w: 0.71, h: 0.26 });
  slide.addText("Moncho Moreno · Reporte de Inversión · Ene–Jun 2026", {
    x: 0, y: H - 0.4, w: W, h: 0.3, margin: 0, fontFace: BODY, fontSize: 9, color: DIM, align: "center" });
  slide.addText(String(pageNo).padStart(2, "0"), {
    x: W - 1.1, y: H - 0.42, w: 0.5, h: 0.3, margin: 0, fontFace: BODY, fontSize: 9, color: DIM, align: "right" });
  return slide;
}

// stat callout block
function stat(slide, x, y, w, value, label, color) {
  slide.addText(value, { x, y, w, h: 0.62, margin: 0, fontFace: TITLE, fontSize: 33, bold: true, color: color || WHITE, align: "left" });
  slide.addText(label, { x, y: y + 0.62, w, h: 0.5, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE, align: "left" });
}

function card(slide, x, y, w, h, fill) {
  slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.06,
    fill: { color: fill || CARD }, line: { color: LINE, width: 1 }, shadow: shadow() });
}

// =====================================================================
// S1 — PORTADA
// =====================================================================
(() => {
  const s = pres.addSlide();
  s.background = { color: BG };
  pageNo++;
  // motif: stacked gold bars top-right
  s.addShape(pres.shapes.RECTANGLE, { x: W - 2.0, y: 0, w: 0.16, h: H, fill: { color: GOLD } });
  s.addShape(pres.shapes.RECTANGLE, { x: W - 1.55, y: 0, w: 0.06, h: H, fill: { color: GOLD, transparency: 55 } });
  s.addShape(pres.shapes.RECTANGLE, { x: W - 1.3, y: 0, w: 0.03, h: H, fill: { color: GOLD, transparency: 75 } });

  s.addImage({ path: LOGO_COVER, x: MX, y: 0.8, w: 1.95, h: 0.52 });
  s.addText("Moncho Moreno", { x: MX, y: 2.35, w: 10, h: 1.2, margin: 0, fontFace: TITLE, fontSize: 60, bold: true, color: WHITE });
  s.addText("Reporte Financiero & de Inversión", { x: MX, y: 3.55, w: 10, h: 0.7, margin: 0, fontFace: TITLE, fontSize: 26, color: GOLD, italic: true });
  s.addShape(pres.shapes.RECTANGLE, { x: MX + 0.02, y: 4.5, w: 2.6, h: 0.025, fill: { color: LINE } });
  s.addText("Enero – Junio 2026   ·   España (EUR)", { x: MX, y: 4.7, w: 10, h: 0.45, margin: 0, fontFace: BODY, fontSize: 16, color: WHITE });
  s.addText("Meta Ads · Shopify · Triple Whale · Atria", { x: MX, y: 5.15, w: 10, h: 0.4, margin: 0, fontFace: BODY, fontSize: 12, color: MUTE });
  s.addText("Datos reconciliados a 22 jun 2026", { x: MX, y: H - 0.5, w: 8, h: 0.3, margin: 0, fontFace: BODY, fontSize: 10, color: DIM });
  s.addNotes("Reporte financiero y de inversión de Moncho Moreno España, ene-jun 2026. Objetivo: decidir si infra/sobre/punto dulce de inversión, cuánto invertir, y cuánto dejamos sobre la mesa. Datos de Meta API + Shopify en vivo + Triple Whale first-party, todos reconciliados. Margen 62,5%* asumido (sin COGS reales).");
})();

// =====================================================================
// S2 — TL;DR / VEREDICTO
// =====================================================================
(() => {
  const s = base({ kicker: "01 · Veredicto", title: "Estamos infrainvirtiendo en paid — de forma severa" });
  // three big stats row
  const y = 1.95, cw = 3.85, gap = 0.18, x0 = MX;
  const stats = [
    ["4,4%", "Inversión / Facturación", "sano DTC: 15–30%", GOLD],
    ["21,7x", "MER (blended)", "ROAS Meta 7–16x vs breakeven 1,6", GREEN],
    ["9,7x", "LTGP : CAC", 'zona ">3 = infrainversión"', GREEN],
  ];
  stats.forEach((st, i) => {
    const x = x0 + i * (cw + gap);
    card(s, x, y, cw, 1.7);
    s.addText(st[0], { x: x + 0.3, y: y + 0.25, w: cw - 0.6, h: 0.8, margin: 0, fontFace: TITLE, fontSize: 44, bold: true, color: st[3] });
    s.addText(st[1], { x: x + 0.32, y: y + 1.05, w: cw - 0.6, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: WHITE });
    s.addText(st[2], { x: x + 0.32, y: y + 1.36, w: cw - 0.6, h: 0.3, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUTE });
  });
  // bullets
  const by = 4.1;
  s.addText([
    { text: "Cuánto invertir:  ", options: { bold: true, color: GOLD } },
    { text: "el sistema (unit economics + creativo + recurrencia) aguanta 2–3× más presupuesto.", options: { color: WHITE } },
  ], { x: MX, y: by, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 14.5, bullet: { code: "2022", indent: 18 } });
  s.addText([
    { text: "Cuello de botella:  ", options: { bold: true, color: GOLD } },
    { text: "es el PRESUPUESTO, no el creativo (win rate 28%, excepcional).", options: { color: WHITE } },
  ], { x: MX, y: by + 0.62, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 14.5, bullet: { code: "2022", indent: 18 } });
  s.addText([
    { text: "Dinero sobre la mesa:  ", options: { bold: true, color: GREEN } },
    { text: "≈ €90–130K / año de contribución*.", options: { color: WHITE } },
  ], { x: MX, y: by + 1.24, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 14.5, bullet: { code: "2022", indent: 18 } });

  s.addText("El matiz honesto: parte del ROAS alto es harvesting de demanda branded del fundador → escalar midiendo incrementalidad (geo-holdout), no a ciegas.", { x: MX, y: 6.35, w: 12, h: 0.5, margin: 0, fontFace: BODY, fontSize: 11, italic: true, color: MUTE });
  s.addNotes("Veredicto: infrainversión severa. 4,4% inv/fact vs 15-30% sano. MER 21,7x, ROAS 7-16x sobre breakeven 1,6. LTGP:CAC blended 9,7x (>3 = infrainversión). El sistema aguanta 2-3x más. Cuello de botella = presupuesto, no creativo. Dinero sobre la mesa 90-130K/año. Caveat: ROAS alto en parte es harvesting de marca de fundador; escalar con geo-holdout para medir incrementalidad.");
})();

// =====================================================================
// S3 — SITUACIÓN 6M
// =====================================================================
(() => {
  const s = base({ kicker: "02 · Situación del negocio", title: "Negocio fuerte y estacional — con el paid minúsculo" });
  // left stats column
  const sx = MX, sy = 1.95;
  const items = [
    ["€729,6K", "Facturación gross 6M", WHITE],
    ["11.697", "Pedidos", WHITE],
    ["€33,6K", "Inversión en paid", GOLD],
    ["63%", "Revenue de cliente recurrente", GREEN],
  ];
  items.forEach((it, i) => {
    const yy = sy + i * 1.15;
    s.addText(it[0], { x: sx, y: yy, w: 4.2, h: 0.55, margin: 0, fontFace: TITLE, fontSize: 30, bold: true, color: it[2] });
    s.addText(it[1], { x: sx, y: yy + 0.55, w: 4.2, h: 0.32, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
  });
  // chart card right
  const cx = 5.4, cy = 1.85, cwc = W - cx - MX, chc = 4.05;
  card(s, cx, cy, cwc, chc);
  s.addText("Facturación mensual (€K gross)", { x: cx + 0.3, y: cy + 0.18, w: cwc - 0.6, h: 0.35, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: WHITE });
  s.addChart(pres.charts.BAR, [{ name: "Gross", labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun*"], values: [239.8, 64.2, 94.6, 72.6, 197.7, 60.6] }], {
    x: cx + 0.15, y: cy + 0.6, w: cwc - 0.35, h: chc - 0.8, barDir: "col",
    chartColors: [GOLD], chartColorsOpacity: [100],
    chartArea: { fill: { color: CARD } }, plotArea: { fill: { color: CARD } },
    catAxisLabelColor: MUTE, catAxisLabelFontFace: BODY, catAxisLabelFontSize: 11,
    valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: WHITE, dataLabelFontFace: BODY, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false, showTitle: false, barGapWidthPct: 45,
  });
  s.addText("Picos: Enero (rebajas) y Mayo (Cumple Moncho). Feb–Abr y Jun = valle. El negocio vive de eventos + orgánico del fundador; el paid es solo el 4,4% de la facturación.", { x: MX, y: 6.25, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE, italic: true });
  s.addNotes("Facturación 6M €729,6K, 11.697 pedidos. Estacionalidad fuerte: Ene €240K (rebajas, con 24% descuento) y May €198K (Cumple Moncho) son picos; resto valle 60-95K. 63% del revenue es recurrente (motor de marca del fundador). Paid total €33,6K = 4,4% de la facturación (Meta 69%, Google+TikTok 31%). MER 21,7x.");
})();

// =====================================================================
// S4 — UNIT ECONOMICS
// =====================================================================
(() => {
  const s = base({ kicker: "03 · Unit economics", title: "Rentable desde la primera compra — con margen enorme" });
  // sensitivity table
  const tx = MX, ty = 2.0;
  const rows = [
    [{ text: "Métrica", options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 12.5, align: "left" } },
     { text: "60%*", options: { bold: true, color: WHITE, fill: { color: CARD2 }, fontFace: BODY, fontSize: 12.5, align: "center" } },
     { text: "62,5%*", options: { bold: true, color: GOLD, fill: { color: CARD2 }, fontFace: BODY, fontSize: 12.5, align: "center" } },
     { text: "65%*", options: { bold: true, color: WHITE, fill: { color: CARD2 }, fontFace: BODY, fontSize: 12.5, align: "center" } }],
    ["Breakeven ROAS", "1,67", "1,60", "1,54"],
    ["MCPA · 1ª compra", "€25,4", "€26,7", "€28,0"],
    ["MC ROAS", "6,1", "6,4", "6,6"],
  ];
  const body = rows.map((r, ri) => r.map((c, ci) => {
    if (ri === 0) return c;
    const isLabel = ci === 0;
    return { text: c, options: { color: isLabel ? WHITE : (ci === 2 ? GOLD : MUTE), bold: ci === 2, fill: { color: CARD }, fontFace: BODY, fontSize: 13, align: isLabel ? "left" : "center" } };
  }));
  s.addTable(body, { x: tx, y: ty, w: 6.7, colW: [2.8, 1.3, 1.3, 1.3], rowH: [0.45, 0.55, 0.55, 0.55], border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [3, 6, 3, 6] });
  s.addText("* margen bruto supuesto (sin COGS reales)", { x: tx, y: ty + 2.25, w: 6.7, h: 0.3, margin: 0, fontFace: BODY, fontSize: 9.5, italic: true, color: DIM });

  // right: key first-party stats 2x2
  const gx = 7.7, gy = 2.0, gw = 2.45, gh = 1.0, gp = 0.18;
  const cells = [
    ["€50,7", "New AOV (neto)", WHITE],
    ["€7,70", "nCAC (cliente nuevo)", GOLD],
    ["8,13x", "aMER (NC-ROAS)", GREEN],
    ["€2,87", "CPA blended", WHITE],
  ];
  cells.forEach((c, i) => {
    const x = gx + (i % 2) * (gw + gp);
    const y = gy + Math.floor(i / 2) * (gh + gp);
    card(s, x, y, gw, gh);
    s.addText(c[0], { x: x + 0.22, y: y + 0.14, w: gw - 0.4, h: 0.5, margin: 0, fontFace: TITLE, fontSize: 26, bold: true, color: c[2] });
    s.addText(c[1], { x: x + 0.24, y: y + 0.64, w: gw - 0.4, h: 0.3, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUTE });
  });
  s.addText([
    { text: "La 1ª compra de un cliente nuevo deja ~€26,7* de contribución y cuesta €7,70 adquirirlo", options: { color: WHITE } },
    { text: "  → margen positivo desde el primer pedido, antes de contar recurrencia.", options: { color: GREEN, bold: true } },
  ], { x: MX, y: 5.55, w: 12, h: 0.7, margin: 0, fontFace: BODY, fontSize: 13.5 });
  s.addNotes("Unit economics con sensibilidad de margen 60/62,5/65%*. Breakeven ROAS 1,60* (caso base). MCPA primera compra ~€26,7*. MC ROAS 6,4 (6x sobre breakeven de 1,0). First-party TW: new AOV €50,7, nCAC €7,70, aMER 8,13x, CPA blended €2,87. Conclusión: rentable desde la primera compra.");
})();

// =====================================================================
// S5 — LTV & LTGP:CAC
// =====================================================================
(() => {
  const s = base({ kicker: "04 · LTV & LTGP : CAC", title: "El cliente casi dobla su primer pedido en 12 meses" });
  // big decisive number left
  card(s, MX, 1.95, 4.1, 2.5);
  s.addText("LTGP : CAC", { x: MX + 0.3, y: 2.15, w: 3.5, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: MUTE });
  s.addText("9,7x", { x: MX + 0.3, y: 2.5, w: 3.5, h: 1.0, margin: 0, fontFace: TITLE, fontSize: 64, bold: true, color: GREEN });
  s.addText('zona ">3 = infrainversión"', { x: MX + 0.3, y: 3.65, w: 3.5, h: 0.35, margin: 0, fontFace: BODY, fontSize: 12, italic: true, color: GOLD });
  s.addText("LTV rev €120* · LTGP €75*", { x: MX + 0.3, y: 4.02, w: 3.5, h: 0.3, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUTE });

  // LTV curve right
  const cx = 5.1, cy = 1.95, cwc = W - cx - MX, chc = 2.5;
  card(s, cx, cy, cwc, chc);
  s.addText("LTV acumulado por cliente (€, cohorte madura)", { x: cx + 0.3, y: cy + 0.16, w: cwc - 0.6, h: 0.32, margin: 0, fontFace: BODY, fontSize: 12, bold: true, color: WHITE });
  s.addChart(pres.charts.LINE, [{ name: "LTV", labels: ["M0", "M2", "M4", "M6", "M8", "M10", "M12"], values: [71, 89, 99, 109, 114, 118, 120] }], {
    x: cx + 0.15, y: cy + 0.55, w: cwc - 0.3, h: chc - 0.75,
    chartColors: [GREEN], lineSize: 3, lineSmooth: true,
    chartArea: { fill: { color: CARD } }, plotArea: { fill: { color: CARD } },
    catAxisLabelColor: MUTE, catAxisLabelFontSize: 10, catAxisLabelFontFace: BODY,
    valAxisLabelColor: MUTE, valAxisLabelFontSize: 10, valAxisMinVal: 0, valAxisMaxVal: 140,
    valGridLine: { color: LINE, size: 0.5 }, catGridLine: { style: "none" },
    showLegend: false, showTitle: false, lineDataSymbol: "circle", lineDataSymbolSize: 5,
  });
  s.addText([
    { text: "Mes 0 ~€70  →  Mes 12 ~€120  (+71%). ", options: { color: WHITE, bold: true } },
    { text: "Recompra persistente 9–11 meses (haircare). El blended CAC (€7,70) está inflado por orgánico; con iCAC realista al escalar (€30–50*), LTGP:CAC = 1,5–2,5x → zona óptima.", options: { color: MUTE } },
  ], { x: MX, y: 4.75, w: 12, h: 1.0, margin: 0, fontFace: BODY, fontSize: 13 });
  s.addNotes("LTV real de cohorte Shopify: M0 ~€70 → M12 ~€120, +71%. El cliente casi dobla su primer pedido en un año. LTGP €75* (x62,5%). LTGP:CAC blended 9,7x = >3 infrainversión. Cifra honesta de decisión: con iCAC marginal al escalar 30-50€, LTGP:CAC baja a 1,5-2,5x = zona ajustada/óptima. Justifica pagar mucho más por adquirir.");
})();

// =====================================================================
// S6 — ICPs & HUB
// =====================================================================
(() => {
  const s = base({ kicker: "05 · ICP & hub de adquisición", title: "El hub: mujeres 35–54" });
  const cx = MX, cy = 1.95, cwc = 7.0, chc = 4.0;
  card(s, cx, cy, cwc, chc);
  s.addText("% de compras pagadas por edad", { x: cx + 0.3, y: cy + 0.18, w: cwc - 0.6, h: 0.32, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: WHITE });
  s.addChart(pres.charts.BAR, [{ name: "compras", labels: ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"], values: [1.9, 15.5, 30.7, 38.4, 11.2, 2.1] }], {
    x: cx + 0.15, y: cy + 0.6, w: cwc - 0.35, h: chc - 0.85, barDir: "bar",
    chartColors: [GOLD],
    chartArea: { fill: { color: CARD } }, plotArea: { fill: { color: CARD } },
    catAxisLabelColor: MUTE, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY,
    valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: WHITE, dataLabelFontFace: BODY, dataLabelFontSize: 11, dataLabelPosition: "outEnd",
    showLegend: false, showTitle: false,
  });
  // right cards
  const rx = 8.05, rw = W - rx - MX;
  card(s, rx, 1.95, rw, 1.25, CARD);
  s.addText("69%", { x: rx + 0.28, y: 2.08, w: rw - 0.5, h: 0.6, margin: 0, fontFace: TITLE, fontSize: 34, bold: true, color: GREEN });
  s.addText("de las compras = 35–54 años · ROAS ~10,5x", { x: rx + 0.3, y: 2.7, w: rw - 0.55, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
  card(s, rx, 3.35, rw, 1.25, CARD);
  s.addText("97,5%", { x: rx + 0.28, y: 3.48, w: rw - 0.5, h: 0.6, margin: 0, fontFace: TITLE, fontSize: 34, bold: true, color: GOLD });
  s.addText("mujeres. Marca de mujer.", { x: rx + 0.3, y: 4.1, w: rw - 0.55, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
  card(s, rx, 4.75, rw, 1.2, CARD);
  s.addText("25–34", { x: rx + 0.28, y: 4.86, w: rw - 0.5, h: 0.55, margin: 0, fontFace: TITLE, fontSize: 28, bold: true, color: WHITE });
  s.addText("la palanca de escala (ROAS 10,5x)", { x: rx + 0.3, y: 5.42, w: rw - 0.55, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
  s.addText("55+ pierde eficiencia (ROAS 7–8x) → no forzar ahí.", { x: MX, y: 6.25, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, italic: true, color: MUTE });
  s.addNotes("Hub de adquisición: mujeres 35-54 = 69% de las compras pagadas, ROAS ~10,5x. 97,5% mujeres. 25-34 es la palanca de escala (buen ROAS, audiencia por explotar). 55+ menos eficiente (7-8x). Concentrar escalado en 25-54.");
})();

// =====================================================================
// S7 — PRODUCTOS
// =====================================================================
(() => {
  const s = base({ kicker: "06 · Productos", title: "El motor son productos baratos de volumen" });
  const header = ["Producto", "Net €", "Pedidos", "€/pedido"].map(h => ({ text: h, options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 12.5, align: h === "Producto" ? "left" : "center" } }));
  const data = [
    ["BOND, J'AIME BOND", "88.480", "4.195", "€21"],
    ["Mascarilla One Minute Wonder", "87.154", "2.861", "€30"],
    ["Champú Gorgeous Hair", "53.303", "1.907", "€28"],
    ["Champú Bathman Detox", "47.360", "1.622", "€29"],
    ["Clandestino DUO  (bundle)", "37.094", "1.065", "€35"],
  ];
  const rows = [header, ...data.map((r, ri) => r.map((c, ci) => ({
    text: c, options: { color: ci === 0 ? WHITE : (ci === 3 ? GOLD : MUTE), bold: ci === 0, fill: { color: ri % 2 ? CARD2 : CARD }, fontFace: BODY, fontSize: 12.5, align: ci === 0 ? "left" : "center" } })))];
  s.addTable(rows, { x: MX, y: 2.0, w: 8.5, colW: [4.2, 1.55, 1.45, 1.3], rowH: 0.52, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [3, 7, 3, 7] });

  card(s, 9.4, 2.0, W - 9.4 - MX, 3.15, CARD);
  s.addText("⚠ Sesgo del algoritmo", { x: 9.65, y: 2.2, w: 3.0, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: GOLD });
  s.addText("Meta optimiza a CPA bajo y empuja los productos baratos (BOND €21).", { x: 9.65, y: 2.62, w: 3.05, h: 0.9, margin: 0, fontFace: BODY, fontSize: 12, color: WHITE });
  s.addText("Falta ver contribución por SKU (requiere COGS reales) y segmentar por unit economics, no por CPA.", { x: 9.65, y: 3.55, w: 3.05, h: 1.2, margin: 0, fontFace: BODY, fontSize: 12, color: MUTE });
  s.addText("Los bundles (DUO, Ritual, Packs €35–45) ya existen pero pesan poco → palanca de AOV clara (slide siguiente).", { x: MX, y: 5.7, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 12, italic: true, color: MUTE });
  s.addNotes("Top productos por revenue: BOND (4.195 pedidos, €21) y Mascarilla OMW (2.861, €30) son el motor de volumen, productos baratos que captan cliente. Riesgo: Meta optimiza a CPA bajo y empuja lo barato; falta contribución por SKU (necesita COGS). Bundles ya existen pero infrautilizados = palanca AOV.");
})();

// =====================================================================
// S8 — GAP AOV / BUNDLES
// =====================================================================
(() => {
  const s = base({ kicker: "07 · Gap de AOV", title: "Subir el AOV con bundles habilita más spend rentable" });
  // AOV now -> potential
  card(s, MX, 2.0, 3.4, 2.0, CARD);
  s.addText("AOV actual", { x: MX + 0.28, y: 2.18, w: 2.9, h: 0.3, margin: 0, fontFace: BODY, fontSize: 12, color: MUTE });
  s.addText("€53,6", { x: MX + 0.28, y: 2.5, w: 2.9, h: 0.8, margin: 0, fontFace: TITLE, fontSize: 46, bold: true, color: WHITE });
  // arrow
  s.addText("→", { x: MX + 3.5, y: 2.55, w: 0.8, h: 0.9, margin: 0, fontFace: BODY, fontSize: 40, bold: true, color: GOLD, align: "center" });
  card(s, MX + 4.35, 2.0, 3.4, 2.0, CARD);
  s.addText("AOV potencial (+15%)", { x: MX + 4.63, y: 2.18, w: 2.9, h: 0.3, margin: 0, fontFace: BODY, fontSize: 12, color: MUTE });
  s.addText("€61,7", { x: MX + 4.63, y: 2.5, w: 2.9, h: 0.8, margin: 0, fontFace: TITLE, fontSize: 46, bold: true, color: GREEN });

  // effect card
  card(s, 8.55, 2.0, W - 8.55 - MX, 3.6, CARD2);
  s.addText("Efecto en cadena", { x: 8.8, y: 2.2, w: 3.6, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: GOLD });
  [["+€22–59K*", "contribución / año"],
   ["↓ breakeven ROAS", "el corte de rentabilidad baja"],
   ["↑ spend rentable", "se habilita más inversión"]].forEach((r, i) => {
    const y = 2.65 + i * 0.95;
    s.addText(r[0], { x: 8.8, y, w: 3.6, h: 0.45, margin: 0, fontFace: TITLE, fontSize: 20, bold: true, color: i === 0 ? GREEN : WHITE });
    s.addText(r[1], { x: 8.8, y: y + 0.42, w: 3.6, h: 0.3, margin: 0, fontFace: BODY, fontSize: 11, color: MUTE });
  });

  s.addText("Los bundles ya existen (DUO, Ritual, Packs) pero los top-sellers son singles baratos (BOND €21, Mascarilla €30). Empujarlos sube el AOV, baja el breakeven y aprovecha el LTV que dobla el primer pedido — círculo virtuoso.", { x: MX, y: 4.45, w: 7.4, h: 1.4, margin: 0, fontFace: BODY, fontSize: 12.5, color: MUTE });
  s.addNotes("AOV actual €53,6. Bundles existen pero infrautilizados; top sellers son singles baratos. Subir AOV +15% (€61,7) → +22-59K€ contribución/año*, baja el breakeven ROAS y habilita más spend rentable. Círculo virtuoso con el LTV. Palanca CRO/merchandising clara.");
})();

// =====================================================================
// S9 — CREATIVE FORECASTING
// =====================================================================
(() => {
  const s = base({ kicker: "08 · Creative forecasting", title: "El cuello de botella es el presupuesto, no el creativo" });
  const y = 1.95, cw = 2.85, gap = 0.18;
  const stats = [
    ["28%", "Win rate", "benchmark >20% = excepcional", GREEN],
    ["44 / 62", "ads ≥€50 con ROAS >6x", "calidad altísima", WHITE],
    ["30%", "Test tax", "sano (alerta ~50%)", WHITE],
    ["3%", "spend en top-funnel", "casi todo harvesting", RED],
  ];
  stats.forEach((st, i) => {
    const x = MX + i * (cw + gap);
    card(s, x, y, cw, 1.7);
    s.addText(st[0], { x: x + 0.24, y: y + 0.22, w: cw - 0.45, h: 0.65, margin: 0, fontFace: TITLE, fontSize: 32, bold: true, color: st[3] });
    s.addText(st[1], { x: x + 0.26, y: y + 0.92, w: cw - 0.45, h: 0.35, margin: 0, fontFace: BODY, fontSize: 12, bold: true, color: WHITE });
    s.addText(st[2], { x: x + 0.26, y: y + 1.24, w: cw - 0.45, h: 0.35, margin: 0, fontFace: BODY, fontSize: 10, color: MUTE });
  });
  card(s, MX, 4.0, 12.06, 1.05, CARD2);
  s.addText([
    { text: "Tenéis 56 anuncios rentables ahogados a ~€1,5/día. ", options: { bold: true, color: GOLD } },
    { text: "Hit rate excepcional → la palanca es meter presupuesto, no producir más creativo. Para escalar sin romper ROAS: subir budget/winner + inyectar top-funnel/Unaware.", options: { color: WHITE } },
  ], { x: MX + 0.3, y: 4.2, w: 11.5, h: 0.7, margin: 0, fontFace: BODY, fontSize: 13.5, valign: "middle" });
  s.addText("Winners: Founder-led talking head · M054 Oferta/Urgencia · K042 BOND · Antifrizz · Rapunhair/caída · colab influencer Berta×Zubi.   ·   Formato: Static 39% / Video 35% / Carousel 6%.", { x: MX, y: 5.35, w: 12, h: 0.7, margin: 0, fontFace: BODY, fontSize: 11, italic: true, color: MUTE });
  s.addNotes("Creative forecasting (Meta API 90d, 200 ads). Win rate 28% (excepcional, benchmark >20%). 44 de 62 ads con spend tienen ROAS >6x. Test tax 30% (sano). Solo 3% del spend en top-funnel/Unaware = harvesting. Diagnóstico clave: el cuello de botella es presupuesto, no creativo — hay winners ahogados a 1,5€/día. Para escalar: subir budget/winner + top-funnel. Winners validados con Atria.");
})();

// =====================================================================
// S10 — CPMs AL ALZA
// =====================================================================
(() => {
  const s = base({ kicker: "09 · CPMs al alza", title: "El reloj corre en contra: el CPM ya sube +50%" });
  const cx = MX, cy = 1.95, cwc = 7.6, chc = 3.7;
  card(s, cx, cy, cwc, chc);
  s.addText("CPM mensual (€)", { x: cx + 0.3, y: cy + 0.16, w: cwc - 0.6, h: 0.32, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: WHITE });
  s.addChart(pres.charts.LINE, [{ name: "CPM", labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun*"], values: [3.95, 3.99, 4.85, 4.23, 5.63, 5.93] }], {
    x: cx + 0.15, y: cy + 0.55, w: cwc - 0.3, h: chc - 0.8,
    chartColors: [RED], lineSize: 3, lineSmooth: true,
    chartArea: { fill: { color: CARD } }, plotArea: { fill: { color: CARD } },
    catAxisLabelColor: MUTE, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY,
    valAxisLabelColor: MUTE, valAxisLabelFontSize: 10, valAxisMinVal: 0, valAxisMaxVal: 7,
    valGridLine: { color: LINE, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: WHITE, dataLabelFontFace: BODY, dataLabelFontSize: 10, dataLabelPosition: "t",
    showLegend: false, showTitle: false, lineDataSymbol: "circle", lineDataSymbolSize: 6,
  });
  // right callouts
  const rx = 8.5, rw = W - rx - MX;
  card(s, rx, 1.95, rw, 1.15);
  s.addText("+50%", { x: rx + 0.28, y: 2.05, w: rw - 0.5, h: 0.6, margin: 0, fontFace: TITLE, fontSize: 36, bold: true, color: RED });
  s.addText("CPM Ene €3,95 → Jun €5,93", { x: rx + 0.3, y: 2.68, w: rw - 0.55, h: 0.35, margin: 0, fontFace: BODY, fontSize: 11, color: MUTE });
  card(s, rx, 3.25, rw, 1.15);
  s.addText("6–12x", { x: rx + 0.28, y: 3.35, w: rw - 0.5, h: 0.6, margin: 0, fontFace: TITLE, fontSize: 36, bold: true, color: GOLD });
  s.addText("frecuencia alta = satura la audiencia core", { x: rx + 0.3, y: 3.98, w: rw - 0.55, h: 0.5, margin: 0, fontFace: BODY, fontSize: 11, color: MUTE });
  card(s, rx, 4.55, rw, 1.1);
  s.addText("~€10", { x: rx + 0.28, y: 4.62, w: rw - 0.5, h: 0.55, margin: 0, fontFace: TITLE, fontSize: 30, bold: true, color: WHITE });
  s.addText("CPA proyectado en 12m si el CPM sigue", { x: rx + 0.3, y: 5.18, w: rw - 0.55, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11, color: MUTE });

  s.addText("Cada mes que esperamos, invertir cuesta más caro. Escalar ahora bloquea inventario barato y reparte el coste del aprendizaje antes de que suba el suelo.", { x: MX, y: 5.85, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 12.5, italic: true, color: RED });
  s.addNotes("CPMs al alza: +50% en 6 meses (€3,95 → €5,93). Q1 €4,26 → Q2 €5,26. Frecuencia alta (6-12x, abril 12,57) satura la audiencia core. Si sigue, el CPA podría ir de ~€6,5 a ~€10 en 12 meses. Argumento de urgencia: no es solo 'podéis invertir más', es 'cada mes cuesta más caro'. Escalar ahora bloquea inventario barato.");
})();

// =====================================================================
// S11 — PROYECCIONES
// =====================================================================
(() => {
  const s = base({ kicker: "10 · Proyecciones", title: "Cada € extra deja contribución — la frontera está lejos" });
  const header = ["Escenario", "Spend Meta / mes", "Contrib. inc. (iROAS 4x*)", "Contrib. inc. (iROAS 6x*)"].map(h => ({ text: h, options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 12, align: h === "Escenario" ? "left" : "center" } }));
  const data = [
    ["Actual", "€3.870", "—", "—"],
    ["+50%", "€5.805", "+€2.900", "+€5.320"],
    ["+100%", "€7.740", "+€5.805", "+€10.640"],
    ["+200%", "€11.610", "+€11.610", "+€21.290"],
  ];
  const rows = [header, ...data.map((r, ri) => r.map((c, ci) => ({
    text: c, options: { color: ci === 0 ? WHITE : (ci >= 2 ? GREEN : MUTE), bold: ci === 0 || ci >= 2, fill: { color: ri % 2 ? CARD2 : CARD }, fontFace: BODY, fontSize: 13, align: ci === 0 ? "left" : "center" } })))];
  s.addTable(rows, { x: MX, y: 2.05, w: 12.06, colW: [2.4, 3.0, 3.33, 3.33], rowH: 0.6, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [3, 8, 3, 8] });

  card(s, MX, 5.05, 12.06, 1.2, CARD2);
  s.addText([
    { text: "Profit frontier:  ", options: { bold: true, color: GOLD } },
    { text: "se invierte mientras el ROAS marginal > 1,6x (breakeven). Hoy el medio es ~10x → hay muchísimo recorrido. Cada € extra a iROAS 4x* deja +€1,50 de contribución.", options: { color: WHITE } },
  ], { x: MX + 0.3, y: 5.25, w: 11.5, h: 0.8, margin: 0, fontFace: BODY, fontSize: 13.5, valign: "middle" });
  s.addNotes("Proyecciones de contribución incremental. Regla profit frontier: invertir mientras ROAS marginal > 1,6x (breakeven). Hoy el medio es ~10x, la frontera está lejísimos. Cada € extra a iROAS 4x deja +€1,50 contribución. Escenarios +50/100/200% de spend Meta, contribución incremental mensual a iROAS 4x y 6x. El límite para sostener +100/200% es presupuesto + ~70 lanzamientos/mes, no el creativo.");
})();

// =====================================================================
// S12 — DINERO SOBRE LA MESA
// =====================================================================
(() => {
  const s = base({ kicker: "11 · Dinero sobre la mesa", title: "Lo que nos estamos dejando: €90–130K / año" });
  // big number band
  card(s, MX, 1.9, 12.06, 1.35, CARD2);
  s.addText("≈ €90–130K", { x: MX + 0.4, y: 2.02, w: 6, h: 0.95, margin: 0, fontFace: TITLE, fontSize: 50, bold: true, color: GREEN });
  s.addText("de contribución al año*, repartido en tres palancas — todas activables.", { x: MX + 6.4, y: 2.35, w: 5.4, h: 0.7, margin: 0, fontFace: BODY, fontSize: 13.5, color: WHITE, valign: "middle" });

  const y = 3.5, cw = 3.85, gap = 0.255;
  const levers = [
    ["SPEND", "+€35–64K", "Doblar el paid alimentando winners (iROAS 4x)", GREEN],
    ["AOV", "+€22–59K", "Empujar bundles (+15% de AOV)", GOLD],
    ["CR", "+€32K", "CRO en los meses valle (+0,5pp de CVR)", WHITE],
  ];
  levers.forEach((l, i) => {
    const x = MX + i * (cw + gap);
    card(s, x, y, cw, 2.35);
    s.addShape(pres.shapes.RECTANGLE, { x, y, w: cw, h: 0.12, fill: { color: l[3] } });
    s.addText(l[0], { x: x + 0.3, y: y + 0.35, w: cw - 0.6, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: l[3], charSpacing: 2 });
    s.addText(l[1], { x: x + 0.3, y: y + 0.78, w: cw - 0.6, h: 0.7, margin: 0, fontFace: TITLE, fontSize: 32, bold: true, color: WHITE });
    s.addText(l[2], { x: x + 0.3, y: y + 1.6, w: cw - 0.6, h: 0.6, margin: 0, fontFace: BODY, fontSize: 12, color: MUTE });
  });
  s.addText("Las palancas se potencian entre sí: subir el AOV baja el breakeven → habilita más spend → que aprovecha el LTV que dobla el primer pedido.", { x: MX, y: 6.15, w: 12, h: 0.5, margin: 0, fontFace: BODY, fontSize: 11.5, italic: true, color: MUTE });
  s.addNotes("Dinero sobre la mesa ≈ 90-130K€/año de contribución*, tres palancas activables: SPEND (doblar paid, +35-64K), AOV (bundles +15%, +22-59K), CR (CRO valle +0,5pp, +32K). Se potencian entre sí. Es más contribución que la que genera un mes valle entero de facturación.");
})();

// =====================================================================
// S13 — QUÉ PUEDE PASAR (2 escenarios)
// =====================================================================
(() => {
  const s = base({ kicker: "12 · Qué puede pasar", title: "Dos caminos — y no actuar también tiene precio" });
  const y = 1.95, cw = 5.92, h = 3.85;
  // A - actuar (green)
  card(s, MX, y, cw, h);
  s.addShape(pres.shapes.RECTANGLE, { x: MX, y, w: 0.13, h, fill: { color: GREEN } });
  s.addText("ESCENARIO A · ACTUAR", { x: MX + 0.35, y: y + 0.28, w: cw - 0.6, h: 0.4, margin: 0, fontFace: BODY, fontSize: 14, bold: true, color: GREEN, charSpacing: 1 });
  [
    "Capturamos los €90–130K/año de contribución.",
    "Construimos el motor con el CPM aún en ~€5, no en €8.",
    "El top-funnel baja CPM/frecuencia y trae cliente incremental.",
    "El LTV de €120 justifica pagar más por adquirir → crecemos en clientes nuevos.",
  ].forEach((t, i) => s.addText(t, { x: MX + 0.35, y: y + 0.85 + i * 0.72, w: cw - 0.65, h: 0.7, margin: 0, fontFace: BODY, fontSize: 12.5, color: WHITE, bullet: { code: "2022", indent: 16 } }));

  // B - no actuar (red)
  const bx = MX + cw + 0.3;
  card(s, bx, y, cw, h);
  s.addShape(pres.shapes.RECTANGLE, { x: bx, y, w: 0.13, h, fill: { color: RED } });
  s.addText("ESCENARIO B · SEGUIR IGUAL", { x: bx + 0.35, y: y + 0.28, w: cw - 0.6, h: 0.4, margin: 0, fontFace: BODY, fontSize: 14, bold: true, color: RED, charSpacing: 1 });
  [
    "El CPM sigue +~50%/año → el margen se comprime solo.",
    "La frecuencia (ya 6–12x) satura la audiencia core → cae el ROAS de valle.",
    "Dejamos de captar el cliente nuevo que el LTV justifica.",
    "Coste de inacción: ~€22–32K de contribución por trimestre de espera*.",
  ].forEach((t, i) => s.addText(t, { x: bx + 0.35, y: y + 0.85 + i * 0.72, w: cw - 0.65, h: 0.7, margin: 0, fontFace: BODY, fontSize: 12.5, color: WHITE, bullet: { code: "2022", indent: 16 } }));

  s.addText("Con los CPMs subiendo, no escalar no es “mantener” — es retroceder en cámara lenta.", { x: MX, y: 6.15, w: 12, h: 0.5, margin: 0, fontFace: TITLE, fontSize: 15, italic: true, bold: true, color: GOLD, align: "center" });
  s.addNotes("Dos escenarios. A-Actuar: captura 90-130K, motor barato (CPM ~5 no 8), top-funnel baja CPM y trae incremental, LTV justifica pagar más. B-Seguir igual: CPM +50%/año comprime margen, frecuencia satura, se deja de captar cliente nuevo; coste de inacción 22-32K/trimestre. Mensaje: con CPMs subiendo, no escalar es retroceder en cámara lenta.");
})();

// =====================================================================
// S14 — CRECIMIENTO YoY (insight clienta)
// =====================================================================
(() => {
  const s = base({ kicker: "13 · Crecimiento YoY", title: "El crecimiento es cliente nuevo — y Meta es ese canal" });
  const y = 1.95, cw = 2.85, gap = 0.18;
  const stats = [
    ["+23%", "Online Store", "vs 2025 (total sales)", GREEN],
    ["−15%", "Tapcart (app)", "vs 2025", RED],
    ["+34%", "Clientes nuevos", "+26% en facturación", GREEN],
    ["+13%", "Clientes recurrentes", "pero su € está plano (−1%)", GOLD],
  ];
  stats.forEach((st, i) => {
    const x = MX + i * (cw + gap);
    card(s, x, y, cw, 1.6);
    s.addText(st[0], { x: x + 0.24, y: y + 0.22, w: cw - 0.45, h: 0.62, margin: 0, fontFace: TITLE, fontSize: 36, bold: true, color: st[3] });
    s.addText(st[1], { x: x + 0.26, y: y + 0.9, w: cw - 0.45, h: 0.32, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: WHITE });
    s.addText(st[2], { x: x + 0.26, y: y + 1.2, w: cw - 0.45, h: 0.32, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUTE });
  });
  card(s, MX, 3.85, 12.06, 1.15, CARD2);
  s.addText([
    { text: "Todo el crecimiento viene de CLIENTE NUEVO: ", options: { bold: true, color: GREEN } },
    { text: "+34% en número, +26% en facturación. El recurrente sube en número (+13%) pero su gasto está plano (−1%) — y su canal, la app (Tapcart), cae −15%.", options: { color: WHITE } },
  ], { x: MX + 0.3, y: 4.03, w: 11.5, h: 0.8, margin: 0, fontFace: BODY, fontSize: 13.5, valign: "middle" });
  s.addText([
    { text: "Meta es el canal que trae al cliente nuevo y llena Online Store. ", options: { bold: true, color: GOLD } },
    { text: "La fuga no es la adquisición — es la retención en la app. Mover presupuesto fuera de Meta frenaría justo el motor que crece.", options: { color: MUTE } },
  ], { x: MX, y: 5.4, w: 12, h: 0.7, margin: 0, fontFace: BODY, fontSize: 13 });
  s.addText("Inversión Meta H1: €9,5K (2025) → €23,2K (2026), +144%. Subimos el paid y fue justo a lo que crece.", { x: MX, y: 6.4, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 10.5, italic: true, color: DIM });
  s.addNotes("Insight de la clienta, bajado a datos (2026 vs 2025, Ene-Jun). Online Store +23% (total sales). Tapcart (app) −15%. Clientes nuevos +34% (y +26% en facturación). Clientes recurrentes +13% en número PERO su gasto plano (−1%). Conclusión: TODO el crecimiento viene de cliente nuevo, que es lo que Meta adquiere y vuelca en Online Store. La fuga es la retención en la app (Tapcart), no la adquisición. Por eso Meta es EL canal del crecimiento y mover presupuesto fuera frenaría el motor. Inversión Meta H1 pasó de €9,5K a €23,2K (+144%) y fue justo a lo que crece. El problema a arreglar es Tapcart, no Meta.");
})();

// =====================================================================
// S15 — ESCENARIO CLIENTE · LA REALIDAD
// =====================================================================
(() => {
  const s = base({ kicker: "14 · Escenario cliente", title: "¿Mover todo el paid (€6K/mes) a TikTok Shop?" });
  // proposal strip
  card(s, MX, 1.9, 12.06, 0.95, CARD2);
  s.addText([
    { text: "La propuesta:  ", options: { bold: true, color: RED } },
    { text: "reasignar los ~€6K/mes de paid de Meta a TikTok Shop y dejar Meta a €0.", options: { color: WHITE } },
  ], { x: MX + 0.3, y: 2.04, w: 11.5, h: 0.65, margin: 0, fontFace: BODY, fontSize: 14.5, valign: "middle" });

  s.addText("La realidad de TikTok Shop hoy (canal Silk) — verificada en vivo, y es BUENA:", { x: MX, y: 3.1, w: 12, h: 0.35, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: GOLD });
  const y = 3.55, cw = 3.85, gap = 0.255;
  const cards = [
    ["€7.238", "GMV TikTok Shop · últimos 30d\n(254 pedidos · AOV €28)", GREEN],
    ["~12x", "ROAS a €20/día\n(gross; ~9x net)", GREEN],
    ["€0 → €7K", "en el último mes\n(el canal está despegando)", GOLD],
  ];
  cards.forEach((c, i) => {
    const x = MX + i * (cw + gap);
    card(s, x, y, cw, 1.7);
    s.addText(c[0], { x: x + 0.28, y: y + 0.28, w: cw - 0.5, h: 0.6, margin: 0, fontFace: TITLE, fontSize: c[0].length > 6 ? 26 : 38, bold: true, color: c[2] });
    s.addText(c[1], { x: x + 0.3, y: y + 0.95, w: cw - 0.55, h: 0.65, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
  });
  s.addText([
    { text: "TikTok Shop es un winner real a pequeña escala.  ", options: { color: WHITE, bold: true } },
    { text: "La pregunta no es SI crecerlo (hay que hacerlo) — es CÓMO. Y matar Meta para financiarlo no es el cómo.", options: { color: GOLD, italic: true } },
  ], { x: MX, y: 5.55, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 13.5 });
  s.addNotes("Escenario del cliente: mover los ~6K€/mes de paid de Meta a TikTok Shop, dejando Meta a 0. Reconocer: TikTok Shop (canal Silk en Shopify) SÍ funciona — últimos 30 días 7.238€ GMV gross, 254 pedidos, AOV 28€, a ~20€/día asumidos = ROAS ~12x gross / ~9x net. Y está despegando: de ~0 a 7,2K€ en el último mes (6 meses acumulaba 7,7K). Es un winner real a pequeña escala. El punto NO es descartarlo, es que la pregunta es CÓMO crecerlo, y matar Meta no es el cómo (slide siguiente con la matemática).");
})();

// =====================================================================
// S16 — ESCENARIO CLIENTE · LA MATEMÁTICA
// =====================================================================
(() => {
  const s = base({ kicker: "15 · Escenario cliente", title: "Por qué mover todo a TikTok destruye valor — con números" });
  const header = ["ROAS TikTok @ €6K/mes", "Revenue TikTok", "vs HOY combinado (~€38K/mes)"].map(h => ({ text: h, options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 11.5, align: h.startsWith("ROAS") ? "left" : "center" } }));
  const data = [
    ["12x  (se mantiene — fantasía a 10×)", "€72K", "+€34K  (irreal)"],
    ["5x  (generoso)", "€30K", "−€8K/mes"],
    ["3x  (realista a 10×)", "€18K", "−€20K/mes  (−€240K/año)"],
  ];
  const colorBy = [MUTE, GOLD, RED];
  const rows = [header, ...data.map((r, ri) => r.map((c, ci) => ({
    text: c, options: { color: ci === 0 ? WHITE : (ci === 2 ? colorBy[ri] : MUTE), bold: ci === 2, fill: { color: ri % 2 ? CARD2 : CARD }, fontFace: BODY, fontSize: 12.5, align: ci === 0 ? "left" : "center" } })))];
  s.addTable(rows, { x: MX, y: 1.95, w: 12.06, colW: [4.6, 3.0, 4.46], rowH: 0.56, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [3, 8, 3, 8] });
  s.addText("HOY: Meta €3,9K/mes → ~€31K  +  TikTok €0,6K/mes → €7,2K  =  ~€38K combinado. El plan lo cambia por TikTok solo. Por qué el ROAS no aguanta 10× el gasto: a €20/día recoges la demanda más caliente; al escalar, el CPA sube y el ROAS cae (en Meta, cuando la frecuencia sube a 12x, el ROAS cae a 7x). Es saturación, no opinión.", { x: MX, y: 3.95, w: 12.06, h: 0.7, margin: 0, fontFace: BODY, fontSize: 11, italic: true, color: MUTE });

  // arguments 2x2
  const ax = MX, ay = 4.75, aw = 5.92, ah = 0.78, ag = 0.18;
  const args = [
    ["Cambias lo probado por lo no probado", "Meta: ROAS 7–16x, win rate 28%, hub 35–54, feed del LTV €120."],
    ["Concentración 100% en canal naciente", "TikTok Shop ES inmaduro → riesgo plataforma / región."],
    ["Audiencia más joven", "Peor encaje con haircare €50 de recompra (LTV/retención inciertas)."],
    ["Diversificar SUMANDO, no amputando", "Crecer TikTok con budget incremental cuando aguante — sin matar Meta."],
  ];
  args.forEach((a, i) => {
    const x = ax + (i % 2) * (aw + ag);
    const y = ay + Math.floor(i / 2) * (ah + ag);
    card(s, x, y, aw, ah, i === 3 ? CARD2 : CARD);
    s.addShape(pres.shapes.RECTANGLE, { x, y, w: 0.1, h: ah, fill: { color: i === 3 ? GREEN : GOLD } });
    s.addText(a[0], { x: x + 0.28, y: y + 0.1, w: aw - 0.5, h: 0.32, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: i === 3 ? GREEN : WHITE });
    s.addText(a[1], { x: x + 0.28, y: y + 0.42, w: aw - 0.5, h: 0.32, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUTE });
  });
  s.addText([
    { text: "Y no es comparar lo mismo:  ", options: { bold: true, color: GOLD } },
    { text: "el 12x de TikTok es ROAS gross a microescala (cesta €28, mucha recompra); el 8,13x de Meta es NC-ROAS — cliente nuevo, a escala real. El new-customer ROAS de TikTok a €6K/mes caería por debajo del de Meta.", options: { color: MUTE } },
  ], { x: MX, y: 6.55, w: 12.06, h: 0.4, margin: 0, fontFace: BODY, fontSize: 10, italic: true });
  s.addNotes("La matemática. HOY combinado: Meta 3,9K€→31K + TikTok 0,6K€→7,2K = ~38K€/mes. El plan mueve TikTok a 6K€/mes (10x) y Meta a 0. Si TikTok mantuviera 12x (fantasía a 10x): 72K. A 5x (generoso): 30K = -8K€/mes vs hoy, y encima pierdes hub+LTV+diversificación. A 3x (realista a 10x): 18K = -20K€/mes = -240K€/año. El ROAS no aguanta porque a 20€/día recoges lo más caliente; al escalar 10x el CPA sube (en Meta freq 12x→ROAS 7x). Mensaje: TikTok es un winner, hay que crecerlo CON BUDGET INCREMENTAL, no matando Meta. Diversificar sumando, no amputando. Crecer AMBOS — el paid es solo ~5% de la facturación, hay sitio.");
})();

// =====================================================================
// S17 — COBERTURA CREATIVA (awareness × ángulos)
// =====================================================================
(() => {
  const s = base({ kicker: "16 · Cobertura creativa", title: "Dónde metemos el creativo — y qué rinde" });
  const hdr = arr => arr.map((h, i) => ({ text: h, options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 11.5, align: i === 0 ? "left" : "center" } }));
  const row = (a, c) => a.map((v, i) => ({ text: v, options: { color: i === 0 ? WHITE : (c && c[i] ? c[i] : MUTE), bold: i === 0 || !!(c && c[i]), fontFace: BODY, fontSize: 11.5, align: i === 0 ? "left" : "center", fill: { color: CARD } } }));
  s.addText("POR NIVEL DE AWARENESS", { x: MX, y: 1.95, w: 5.8, h: 0.3, margin: 0, fontFace: BODY, fontSize: 11, bold: true, color: GREEN, charSpacing: 1 });
  s.addTable([hdr(["Nivel", "% gasto", "ROAS"]),
    row(["Problem aware", "36%", "7,2x"]),
    row(["Solution aware", "29%", "9,9x"]),
    row(["Sin tag", "29%", "9,5x"]),
    row(["Unaware (top-funnel)", "4%", "6,2x"], [null, RED, null]),
    row(["Product (retarget)", "2%", "71,8x"], [null, null, GREEN]),
  ], { x: MX, y: 2.3, w: 5.8, colW: [2.9, 1.45, 1.45], rowH: 0.46, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [2, 6, 2, 6] });
  s.addText("POR ÁNGULO GANADOR", { x: 6.75, y: 1.95, w: 5.9, h: 0.3, margin: 0, fontFace: BODY, fontSize: 11, bold: true, color: GREEN, charSpacing: 1 });
  s.addTable([hdr(["Ángulo", "% gasto", "ROAS"]),
    row(["Reparación / pelo dañado", "19%", "7,8x"]),
    row(["Autoridad del fundador (Moncho)", "18%", "16,3x"], [null, null, GREEN]),
    row(["Oferta / pack / urgencia", "15%", "10,6x"]),
    row(["Control del frizz", "12%", "9,0x"]),
    row(["Anti-caída / crecimiento", "8%", "6,2x"], [null, null, RED]),
    row(["Brillo / pelo bonito", "2%", "10,5x"]),
  ], { x: 6.75, y: 2.3, w: 5.93, colW: [3.4, 1.3, 1.23], rowH: 0.46, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [2, 6, 2, 6] });
  s.addText([
    { text: "El contenido del fundador (Moncho) es el de mayor ROAS — 16,3x con solo el 18% del gasto. ", options: { bold: true, color: GREEN } },
    { text: "Ahí escalar, y es el puente perfecto con el contenido orgánico de TikTok. Solo 4% en top-funnel; \"Brillo\" infrainvertido (2% a 10,5x).", options: { color: MUTE } },
  ], { x: MX, y: 6.05, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 12 });
  s.addNotes("Cobertura creativa (Meta 90d). % gasto y ROAS por awareness: Problem 36% (7,2x), Solution 29% (9,9x), sin tag 29%, Unaware solo 4% (palanca top-funnel), Product 2% (71,8x retarget). Por ángulo: Reparación/BOND 19% (7,8x), AUTORIDAD DEL FUNDADOR 18% con 16,3x (el mejor con diferencia), Oferta/pack 15% (10,6x), Frizz 12% (9x), Anti-caída 8% (6,2x, el más flojo), Brillo 2% (10,5x, infrainvertido). Clave: el contenido de Moncho es el de mayor ROAS y es el puente con TikTok.");
})();

// =====================================================================
// S18 — ANÁLISIS DE ICP
// =====================================================================
(() => {
  const s = base({ kicker: "17 · Análisis de ICP", title: "Nuestros ICPs: a quién le hablamos y qué rinde" });
  const header = ["ICP / Persona", "Necesidad (ángulo)", "% gasto", "ROAS"].map((h, i) => ({ text: h, options: { bold: true, color: WHITE, fill: { color: GREEND }, fontFace: BODY, fontSize: 12, align: i < 2 ? "left" : "center" } }));
  const data = [
    ["Fan de Moncho", "Autoridad del fundador", "18%", "16,3x", GREEN],
    ["La Reparadora", "Pelo dañado · BOND", "19%", "7,8x", null],
    ["Cazadora de packs", "Oferta / bundle", "15%", "10,6x", null],
    ["La Anti-frizz", "Control del encrespado", "12%", "9,0x", null],
    ["La Anti-caída", "Pérdida / crecimiento", "8%", "6,2x", RED],
    ["La de Brillo", "Pelo bonito (infrainvertida)", "2%", "10,5x", null],
  ];
  const rows = [header, ...data.map((r, ri) => [
    { text: r[0], options: { color: WHITE, bold: true, fontFace: BODY, fontSize: 12.5, align: "left", fill: { color: ri % 2 ? CARD2 : CARD } } },
    { text: r[1], options: { color: MUTE, fontFace: BODY, fontSize: 12, align: "left", fill: { color: ri % 2 ? CARD2 : CARD } } },
    { text: r[2], options: { color: MUTE, fontFace: BODY, fontSize: 12.5, align: "center", fill: { color: ri % 2 ? CARD2 : CARD } } },
    { text: r[3], options: { color: r[4] || MUTE, bold: !!r[4], fontFace: BODY, fontSize: 12.5, align: "center", fill: { color: ri % 2 ? CARD2 : CARD } } },
  ])];
  s.addTable(rows, { x: MX, y: 2.0, w: 12.06, colW: [3.0, 4.2, 2.4, 2.46], rowH: 0.5, border: { type: "solid", pt: 1, color: BG }, valign: "middle", margin: [2, 8, 2, 8] });
  s.addText([
    { text: "Hub: mujer 35–54 (97,5% female). ", options: { bold: true, color: GREEN } },
    { text: "Dentro hay 6 need-states. La \"Fan de Moncho\" es la más rentable (16,3x) → ahí escalar. \"Brillo\" infrainvertida; \"Anti-caída\" la más floja.", options: { color: "C2D2C8" } },
  ], { x: MX, y: 5.35, w: 12, h: 0.6, margin: 0, fontFace: BODY, fontSize: 13 });
  s.addText("Con Advantage+ broad el algoritmo asigna el gasto; el ICP se expresa por el ÁNGULO que resuena → optimizamos por mensaje, no por audiencia.", { x: MX, y: 6.5, w: 12, h: 0.4, margin: 0, fontFace: BODY, fontSize: 10.5, italic: true, color: MUTE });
  s.addNotes("Análisis de ICP. Hub demográfico: mujer 35-54 (97,5% female). Dentro, 6 personas/need-states con su % gasto y ROAS: Fan de Moncho (autoridad fundador) 18% 16,3x = la más rentable; La Reparadora (BOND) 19% 7,8x; Cazadora de packs 15% 10,6x; Anti-frizz 12% 9x; Anti-caída 8% 6,2x (la más floja); La de Brillo 2% 10,5x (infrainvertida). Caveat: con Advantage+ broad el algoritmo asigna gasto; el ICP se expresa por el ángulo → optimizamos por mensaje, no por audiencia.");
})();

// =====================================================================
// S19 — PLAN DE ACCIÓN
// =====================================================================
(() => {
  const s = base({ kicker: "18 · Plan de acción", title: "Cinco pasos priorizados" });
  const steps = [
    ["Puente creativo Meta ↔ TikTok Shop", "Llevar el contenido del fundador (16,3x ROAS, el que petó en TikTok) a Meta y escalar. Sin canibalizar presupuesto.", "Creative + Media buyer"],
    ["Medir incrementalidad", "Geo-holdout antes de escalar a saco — separar incremental de harvesting.", "MLO Analytics"],
    ["Inyectar top-funnel / Unaware al 100%", "De 4% → 15–20% + nuevos ángulos para captar demanda nueva.", "Creative"],
    ["Desarrollar la vertical de PACKS", "PDPs específicas para packs → subir AOV (palanca hoy infrautilizada).", "CRO + Media buyer"],
    ["Construir KPI Panel con COGS reales", "Cierra breakeven, contribución por SKU y el LTGP:CAC definitivo.", "Marcel / Manu"],
  ];
  const y0 = 1.9, rh = 0.92;
  steps.forEach((st, i) => {
    const y = y0 + i * rh;
    s.addShape(pres.shapes.OVAL, { x: MX, y: y + 0.06, w: 0.62, h: 0.62, fill: { color: i < 2 ? GOLD : CARD2 }, line: { color: GOLD, width: 1 } });
    s.addText(String(i + 1), { x: MX, y: y + 0.06, w: 0.62, h: 0.62, margin: 0, fontFace: TITLE, fontSize: 24, bold: true, color: i < 2 ? BG : GOLD, align: "center", valign: "middle" });
    s.addText(st[0], { x: MX + 0.85, y: y + 0.04, w: 7.0, h: 0.4, margin: 0, fontFace: BODY, fontSize: 15, bold: true, color: WHITE });
    s.addText(st[1], { x: MX + 0.85, y: y + 0.42, w: 8.2, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUTE });
    s.addText(st[2], { x: W - 3.0, y: y + 0.16, w: 2.4, h: 0.4, margin: 0, fontFace: BODY, fontSize: 11.5, bold: true, color: GOLD, align: "right" });
  });
  s.addNotes("Plan de acción priorizado: 1) Alimentar winners + escalar Meta +50-100% (media buyer). 2) Geo-holdout para incrementalidad (analytics). 3) Top-funnel/Unaware 3→15-20% (creative). 4) Bundles para subir AOV (CRO+media buyer). 5) KPI Panel con COGS reales (Marcel/Manu). Los pasos 1-2 son el arranque inmediato.");
})();

pres.writeFile({ fileName: "Moncho Moreno - Reporte Financiero e Inversion - Ene-Jun 2026.pptx" }).then(f => console.log("WROTE: " + f));
