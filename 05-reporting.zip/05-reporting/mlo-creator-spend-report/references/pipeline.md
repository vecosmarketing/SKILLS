# ⚙️ Pipeline — Creator Ad-Spend Report

## 1) Sacar los ads de Meta
Tool: `ads_get_ad_entities` (Meta Ads MCP). Para 8hours:
```
ad_account_id: "1336199457035968"   # 8HOURS (EUR). Otras marcas → ads_get_ad_accounts
level: "ad"
fields: ["id","name","amount_spent","effective_status","impressions"]
date_preset: "last_30d"   # o last_7d / time_range {since,until}
sort: "spend_descending"
limit: 400
client_conversation_id: <20 chars aleatorios>
```
El resultado suele exceder el límite → se guarda en un archivo (JSON con `{"ad_entities": <lista>}`). Léelo del archivo.

## 2) Agregación + xlsx (script validado)
Guarda el path del archivo de resultados en `$F` y corre:
```python
import json,re,datetime
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

ads=json.load(open('$F',encoding='utf-8'))['ad_entities']
if isinstance(ads,str): ads=json.loads(ads)

def spend(a):  # Meta devuelve "1.089,15 € (EUR)"
    s=(a.get('amount_spent') or '').split('€')[0].replace(' ','').replace(' ','').replace('.','').replace(',','.')
    try: return float(s)
    except: return 0.0
def first(a):  # creador = antes del primer "_", sin emoji/símbolos iniciales
    n=re.sub(r'^[^A-Za-z0-9]+','',(a.get('name') or '').strip()).strip()
    return re.split(r'[_/]', n)[0].strip()
GENERIC={'Sleep','Rise','Creator','Creator Ad','CREATOR AD','Rise & Sleep','Life Context','BUNDLE','Bundle','Static','Video'}
def creatorlike(t):
    return bool(re.match(r"^[A-Za-z][A-Za-z .&']{2,}$", t)) and not any(c.isdigit() for c in t) and t not in GENERIC

byc=defaultdict(lambda:[0.0,0])
for a in ads:
    t=first(a); byc[t][0]+=spend(a)
    if a.get('effective_status')=='ACTIVE': byc[t][1]+=1
tot=sum(spend(a) for a in ads)
cre={k:v for k,v in byc.items() if creatorlike(k)}
noncre=tot-sum(v[0] for v in cre.values())
# → construir xlsx con hoja "Creator Spend (t30d)" (Creador|Spend|Ads live|% total, fila "SIN CREADOR", TOTAL)
#   + hoja "Naming Convention". Guardar en la carpeta REPORTING de la marca.
```

## 3) Salida
- **xlsx** → `…/⭐️ CLIENTS/✅ CLIENTES ACTIVOS – AGENCIA/8hours/REPORTING/8HOURS - Ad Spend por Creador (t30d).xlsx`
- **Tabla a Slack** (canal 8hours o DM a Marina): Creador · Spend · Ads live, ordenado por spend, + línea de **cobertura** (`atribuible a creador €X de €Y = Z%`).
- Reporta la cobertura con honestidad; si es baja, recuerda que el resto son ads con nombre de código a renombrar.

## Notas
- `amount_spent` es string europeo (no float) → parsear siempre.
- `effective_status=="ACTIVE"` = ad live (para el conteo). PAUSED/CAMPAIGN_PAUSED/ADSET_PAUSED = no live.
- Un token creador puede aparventar noise (Sleep/Rise/Creator) → GENERIC los saca del bucket creador.
- Para otra marca: `ads_get_ad_accounts` → coger el `ad_account_id` correcto y su `currency`.
