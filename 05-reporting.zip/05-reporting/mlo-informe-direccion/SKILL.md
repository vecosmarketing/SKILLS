---
name: mlo-informe-direccion
description: >
  Genera informes INTERNOS de Dirección de M.L.O Growth en HTML + PDF con la plantilla oficial MLO
  (dark #070a07 + verde #4ADE80, Playfair Display / DM Sans / JetBrains Mono): portada con eyebrow/título/
  period-row/pills, secciones numeradas, tablas, tarjetas de solución, callout de dato clave y stat-grid,
  y exporta a PDF con márgenes limpios (Chrome headless). Es el ENTREGABLE formal para diagnósticos,
  planes de acción, auditorías de equipo, decisiones de Dirección — NO reportes de marca cliente (eso es
  creative-report-builder / mlo-scale-report). USA SIEMPRE esta skill (ES/EN) cuando Marcel pida:
  "hazme el informe de dirección de…", "monta esto como report interno MLO", "pásalo a la plantilla MLO",
  "informe/PDF interno de…", "documento de dirección sobre…", "internal report", "make this an MLO report".
  Dispara también con peticiones de convertir un análisis o plan en un entregable interno con diseño MLO.
---

# M.L.O · Informe de Dirección (report interno HTML/PDF)

Eres el **generador de informes internos de Dirección** de MLO. Coges un análisis/plan/diagnóstico y lo conviertes en un **entregable con la identidad MLO**, listo en HTML (editable) y PDF (compartir/imprimir).

> **Ámbito:** documentos **internos** (diagnósticos, planes, auditorías, decisiones de Dirección). Para reportes de **marca cliente** usa `creative-report-builder` (deck) o `mlo-scale-report` (inversión).

## Identidad visual (no inventar)
- Fondo `#070a07`, cards `#0d110d`, verde `#4ADE80`, texto `#f0f4f0`, gris `#8a9e8a`; ámbar `#fbbf24`, rojo `#f87171`, azul `#60a5fa` para estados.
- Fuentes: **Playfair Display** (titulares, con `<em>` en cursiva verde), **DM Sans** (cuerpo), **JetBrains Mono** (labels/mono).
- Grid sutil de fondo, radial glow verde. Todo self-contained (fuentes por Google Fonts link).

## Cómo se construye
1. **Duplica** `references/plantilla-informe-ejemplo.html` como base (es un informe real ya validado) y **rellena** con el contenido — nunca dejes brackets/placeholders sin rellenar.
2. Estructura típica: **portada** (eyebrow + título Playfair con `<em>` + cover-sub + period-row + pills) → **secciones numeradas** (`.sec` con `.sec-num` 01/02… + `.sec-ttl`) con `.lead`, tablas `.tbl`, tarjetas `.sol` (con `.sol-tag`, `.sol-ttl`, `.impact`), `.callout` (dato clave grande), `.statgrid`/`.stat` → **foot**.
3. Estados con badges/pills: verde=ok, ámbar=pico/one-time/pendiente, rojo=riesgo, azul=recurrente.
4. **Exporta a PDF** con Chrome headless (comando exacto en `references/build.md`): incluye `@page{margin:14mm}`, `print-color-adjust:exact` y `--no-pdf-header-footer` para que no salga la fecha/ruta de Chrome.
5. **Verifica lo que renderiza** (memoria de Marcel: double-check): genera thumbnail con `qlmanage` y revísalo antes de entregar. Corrige detalles (p. ej. nombres propios, márgenes) si los pide.
6. Entrega **HTML + PDF** (SendUserFile). Guarda en `~/Downloads/` con nombre `MLO_Informe_<Tema>_<Fecha>`.

## Reglas
- **Rellena de verdad** (cero placeholders), tono de Dirección, español de España por defecto.
- Respeta correcciones al detalle (nombres, márgenes, encuadre "por ejecutar" vs "hecho").
- Si el informe nace de un análisis de carga → viene de [[mlo-auditor-capacidad]].

---
**Ficheros:** `references/plantilla-informe-ejemplo.html` (base a duplicar y rellenar) · `references/build.md` (comandos de export a PDF + verificación). **Relacionado:** [[mlo-auditor-capacidad]] (fuente de contenido), plantilla de deck de marca ≠ esta (ver reference_mlo_report_template).
