# Setting up a recurring report

Use this when the user wants this deck to run on a cadence (weekly, monthly) rather than as a one-off. A recurring brand needs three things beyond the deck itself: a directory, its brand profile, and a `state.md`. The profile is defined in `references/brand-profile.md` and is not unique to recurring runs, a one-time brand can save one too. What's unique to recurring is the `state.md` history and the scheduled task.

## 1. A directory for this brand

Create `<brand-slug>-creative-report/` (e.g. `lumina-creative-report/`) as a sibling to wherever the one-off deck would otherwise be saved, containing:
- `reports/` — every generated deck, one file per run, named `<brand-slug>-creative-report-<window-start-date>.html` (e.g. `lumina-creative-report-2026-08-04.html`, using the Monday of the reported week or the first day of the reported month). Once at least one real run exists, a new run starts from the actual most-recent file here, not from `assets/template-*.html` again, so any consistent evolution of the design carries forward.
- `PROFILE.md` — the brand's ficha (see `references/brand-profile.md`). How every section is built, the hit rule, tagging, currency, which sections apply. Written once, reloaded every run.
- `state.md` — pure period-over-period data, no methodology prose (that's the profile's job).

## 2. The brand profile

This is the same `PROFILE.md` described in `references/brand-profile.md`. For a recurring brand it lives in the directory above and is the first thing every scheduled run loads. Don't duplicate its contents into `state.md` or into the scheduled task, one source of truth for "how we build this brand's deck."

## 3. `state.md`'s schema

This is what makes week-over-week and month-over-month comparisons possible without re-pulling history every run. Structure it as:

```markdown
# <Brand> Creative Report — State

## Last completed period
<date range>
<every number the next run needs to diff against: topline KPIs, New Customer % if included, per-product/per-owner hit rates, etc.>

## Prior period (one period back from "last completed")
<same shape as above, kept for the WoW/MoM delta on the *next* run>

## Same period, prior month
<only needed if the New Customer % section is included, since it compares against the same window one month back, not just the immediately prior period. Keep this even though it duplicates data that might otherwise age out of "prior period" above, a month-back comparison needs its own retention, it doesn't fall out of a simple two-period rolling window.>

## Open action items
<carried from the last deck's closing Strategist Read slide, so the next run can report on what happened to each one>
```

Keep exactly this much history, no more. A `state.md` that tries to retain every past week indefinitely becomes a second source of truth to keep in sync; three periods (last, prior, same-period-last-month) is enough to support every comparison the template actually shows.

## 4. Wiring up the schedule

Ask the user whether to actually create the scheduled task now (via the `schedule` skill, or the `CronCreate`/`create_scheduled_task` tooling if available in this environment) or just hand back the deck, profile, and state file for them to wire up later. If creating it now, point the scheduled task at the brand directory: its job each run is to load `PROFILE.md`, pull fresh numbers, generate the new deck into `reports/`, render and verify it (Step 4 of the main skill), and rewrite `state.md` at the end, not to re-derive methodology from scratch. The methodology already lives in the profile.
