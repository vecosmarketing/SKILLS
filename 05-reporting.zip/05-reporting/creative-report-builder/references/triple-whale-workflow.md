# Pulling the report's metrics from Triple Whale

Use this when the user says their attribution/analytics source is Triple Whale. It generalizes the proven workflow from this account's own recurring Hears weekly report, don't assume the brand you're building this for uses the same tags, table names, or SQL patterns; treat everything below as a method, not a fixed script.

## Setup, every run

1. Call `get-shop-info` once. It returns currency, timezone, default attribution model/window, and today's date in shop time. Everything downstream uses this.
2. Call `get-date-range` to resolve the reporting window ("last week," "last 30 days," whatever the user asked for) into exact ISO dates in the shop's timezone. Trust this over manual date math.
3. Call `get-available-tables` and `get-table-schemas` for any table you plan to query before writing SQL. Never reference a column you haven't confirmed exists.
4. Call `find-sql-examples` with the metric you're trying to compute before drafting new SQL. Adapt the closest verified example rather than writing logic from scratch, it encodes correct table choices and metric definitions for this specific warehouse.
5. Run everything through `run-sql`. Every query needs an explicit `event_date` filter, or the tool may silently default to the last 7 days.

## The one gotcha that bites every time

ClickHouse throws "Aggregate function found inside another aggregate function" if you reuse a raw column name (like `spend`) as an outer alias when it's also being summed inside the same SELECT. Always alias sums to a distinct name first:

```sql
-- wrong: will error
SELECT SUM(spend) AS spend, SUM(revenue)/SUM(spend) AS roas FROM ...

-- right
SELECT SUM(spend) AS ad_spend, SUM(revenue)/NULLIF(SUM(spend),0) AS roas FROM ...
```

This shows up constantly once you start computing NC ROAS, hit rates, and blended metrics in the same query, watch for it every time you nest an aggregate inside a ratio.

## Mapping the report's sections to likely tables

Every Triple Whale account is tagged differently, so don't assume the exact table/column names below exist, confirm with `get-available-tables`/`get-table-schemas` first. But this is the general shape:

- **Overview KPIs, New Customer %:** a pixel-attribution table (commonly `pixel_joined_tvf()` or similar) filtered to the ad channel(s) in scope, at whatever attribution model/window the brand actually uses (ask them, don't assume first-click/1-day just because that's common). New Customer % is typically `SUM(new_customer_orders) / SUM(orders_quantity)`, pulled for the current window, the prior week, and the same window one month back, three separate date-filtered queries, not one query with a WoW column baked in.
- **Product breakdown:** classify by ad `destination_url`, not by regex-matching the ad name. Ad names describe the audience or creative concept far more often than the product, and URL classification works even on ads with zero revenue (unlike order-level tables, which only populate once there's an attributed order). Run a quick `GROUP BY destination_url` first to see what pages actually have spend before deciding on buckets.
- **Owner/Editor performance:** if the brand tags ownership in the ad name (a prefix, a suffix, a keyword), extract it with a `match()`/`extract()` regex. If they use a native platform tag (Meta's "Wizard" tag, a CRM field, an ads-manager custom field), pull that instead, don't force a name-regex where a clean tag already exists.
- **Landing pages:** join ad-side spend/revenue (grouped by `destination_url`) to a web-analytics table's sessions (grouped by `landing_page`), stripping both down to the URL path before joining. Flag any page with real spend but zero session data rather than showing a false 0% CVR, that usually means the pixel isn't firing on that template.
- **Awareness stage / funnel stage / audience:** these are almost always read off the ad name or campaign name via keyword tags, ask the brand's team what tagging convention they already use rather than inventing one. If they don't tag this at all yet, it's fine to drop those slides for this run and note it as a gap.
- **Best Creators:** same idea as Owner, but scoped to whoever is credited as talent/UGC creator in the ad name or a platform tag, separate from the strategist/editor credit if the brand distinguishes the two roles.
- **Launch Analysis:** classify by an ad's first delivery date (`MIN(event_date)` per ad_id) falling inside the trailing window, not by the ad platform's creation timestamp, the two can diverge by days and the delivery-date version matches what actually reached an audience.

## Applying the hit-rule threshold

Whatever spend/ROAS bar the user gave you in setup, apply it consistently as `spend >= X AND nc_roas >= Y`, evaluated per ad (or per creative concept, if the brand wants concepts rolled up across variants, ask this explicitly since it changes which ads clear the bar). Use this same bar everywhere a slide needs a Hit/Miss call: Product, Owner, Top Performers, Launch Analysis. Don't let it drift between slides.

## Cross-checking against a second data source

If the brand also has a creative/ad-management tool (Rule1-style tagging, a native ad-platform dashboard) alongside Triple Whale, use Triple Whale as the source of truth for revenue/ROAS metrics (it usually has cleaner attribution) and the other tool only for things Triple Whale can't compute (creative-level tags, hit/miss badges from a UI). If the two disagree on total spend by more than a few percent, say so explicitly rather than silently picking one.
