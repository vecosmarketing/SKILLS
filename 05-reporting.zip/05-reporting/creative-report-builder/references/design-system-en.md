# Weekly Creative Strategy Report — Template Generation Guide

This is a brand-agnostic version of a weekly paid-media creative report deck. It is not tied to any specific brand, ad platform, or analytics tool — the structure, section order, and design system are the reusable asset. Use this guide to explain the template to a prospective brand, or to hand to an agent/writer who needs to fill it in for a real client.

## What this is

A single self-contained HTML file (`weekly-creative-report-template.html`), styled as a dark-themed, full-bleed slide deck (one `<section>` per slide, meant to be viewed like a presentation, not scrolled like a report). It reads at a glance in a leadership meeting: big numbers, short callouts, no walls of text.

The template ships with every section, every CSS class, and every layout already built. Filling it in means replacing bracketed placeholders like `[Brand Name]`, `$[XX,XXX]`, `[X.XX]x` with real numbers, nothing about the HTML/CSS structure needs to change for a normal week.

## The 13 sections, in order

1. **Cover** — brand name, report title, date range, who it's for, attribution basis.
2. **Overview KPIs** — 8-card grid: Spend, Revenue, ROAS, NC ROAS (new-customer ROAS), Orders, AOV, CPA, Active Ads, each with a delta vs. the prior period.
3. **Ad Accounts** — only if the brand runs more than one ad account (e.g. a core account plus a secondary/whitelisted advertorial account). Delete this slide entirely if there's just one account.
4. **Spend & Hit Rate by Product** — 4-card grid, one per top product/category plus an "Uncategorized" catch-all for spend that can't be attributed to a specific product.
5. **Performance by Owner** — table of who owns which creative (could be a strategist, an agency, an in-house team), with spend, ads tested, hits, hit rate, and week-over-week movement.
6. **Top Landers: CTR → CVR Funnel** — table of landing pages ranked by spend, showing the full click-to-buy funnel (CTR then CVR) plus NC ROAS, so a page that gets clicks but doesn't convert is visible at a glance.
7. **Where Awareness-Stage Spend Lives** — 4-card grid by awareness stage (Problem Aware / Solution Aware / Product Aware / Unaware — standard messaging-funnel terms, not brand-specific).
8. **Funnel Stage Performance** — a 3-bar "tower" chart for TOF / MOF / BOF, ranked by NC ROAS, with a dashed threshold line marking the profitability bar.
9. **Top 3 Performing Ads** — the three highest-spend ads, each marked Hit or Miss against whatever bar the brand uses.
10. **Best & Worst Ads of the Week** — two sub-sections: small-spend ads showing an early positive signal ("Rising"), and real-spend ads performing badly ("Wasting Spend"). Not ranked by spend.
11. **Best & Worst Audience** — table of target audiences/segments ranked by NC ROAS.
12. **Launch Analysis** — a rolling window (commonly 14 days) classifying every newly-launched ad as Promising, Flop, or Too Early to Call.
13. **Creative Strategist Read** — the closing slide: a pull-quote naming the single biggest finding of the period, an optional industry-benchmark callout, and a numbered action list. This is also where the "what do we do next" list lives — there is no separate action-items slide.

## Design rules (do not deviate)

- **Never touch the `<style>` block.** Colors, spacing, card/table/pill CSS, and the glow-orb positions are the visual identity being demonstrated. Swap only the content inside the sections.
- **One `<section>` per slide.** Each already has a unique `.glow-orb` position, don't reuse the same orb placement twice in a row.
- **No em dashes anywhere in generated copy.** Use a period, colon, comma, or parentheses instead. This applies to callouts, card labels, and quote text.
- **Callouts carry the analysis, not the data.** Tables and cards show numbers; `.callout` boxes explain what the numbers mean and what to do about it. Lead with the number, not the setup ("Best efficiency: $1,750 at 2.87x" beats "The best-performing ad this week was one that spent $1,750...").
- **Any callout naming 3+ examples must be bulleted** (`<ul class="tight">` inside the callout), not a run-on paragraph.
- **Color logic:** `.up` / green for good, `.down` / red for bad, `.flat` / gray for neutral. Never color-code the same value twice (if a card's number is already green, its sub-label stays neutral).
- **Pills are earned, not decorative.** Only award a `pill-solid` ("Top Spend," "Dominant," "Best Performer") or `pill-hit`/`pill-bad` badge to a card/row that actually has the best or worst number in its group, recomputed fresh each time, never hardcoded from a previous week.
- **The "Uncategorized" or "Untagged" bucket never gets a pill or highlight styling**, even if its numbers happen to look good. It's a data-quality bucket, not a competitor.
- **The currency symbol is a brand value, not a fixed template detail.** Placeholders default to `$`, but confirm the brand's actual currency during setup and swap it consistently throughout the document (symbol, symbol position, decimal separator convention) before delivering the deck.

## How to fill this in for a real brand

1. **Get the brand's basics:** name, logo (or use the generic placeholder mark), reporting window, ad platform(s), attribution model and window (e.g. "Pixel-based, first-click, 1-day"), and who the report is for.
2. **Define the "hit" bar** for that account: usually a minimum spend and a minimum ROAS or NC ROAS. This bar is used throughout the deck (Product, Owner, Landing Page, Top Performers slides) — pick it once and apply it consistently, don't let it drift slide to slide.
3. **Pull the metrics** from whatever analytics source the brand uses (Triple Whale, GA4, native ad-platform reporting, a data warehouse, etc.) for each section: topline KPIs, spend/ROAS by product, by owner, by landing page, by awareness stage, by funnel stage, by audience, plus the top/bottom ad lists and new-launch classification.
4. **Replace every bracketed placeholder** with the real value. Delete any slide that doesn't apply (most commonly: the Ad Accounts slide, if there's only one account).
5. **Write the callouts last**, after all the numbers are in. Every callout should say something a strategist would actually say out loud in the meeting, not a description of how the number was computed. Methodology notes and data caveats belong in a small subtitle line or a `.callout.warn`, never as the main analytical point.
6. **Recompute every pill and badge fresh** against the numbers you just filled in, don't carry over a "Top Spend" or "Best" pill from a template example.
7. **Sanity-check the deck reads top to bottom as one story**: Overview sets the headline number, each middle slide adds a layer of detail, and the closing Strategist Read slide ties it back to 4-6 concrete actions that reference numbers already shown earlier in the deck.

## What NOT to do

- Don't invent data. Every bracketed placeholder should be replaced with a real, sourced number, not a plausible-looking guess.
- Don't add new slide types or CSS components without a real need. If a brand's reporting genuinely doesn't need an "Ad Accounts" slide, delete it, don't leave it half-filled.
- Don't turn callouts into a list of definitions or a methodology writeup. That content, if it needs to exist, belongs in a separate internal doc, not in front of the room.
