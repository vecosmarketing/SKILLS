# The brand profile (the per-brand "ficha")

The skill itself is brand-agnostic on purpose, it ships no account's thresholds, tags, or currency baked in. Everything specific to one brand lives in that brand's **profile**: a small `PROFILE.md` written once and reloaded every run so the setup interview never repeats. This is the "genérico + ficha por marca" model.

A profile is not a schedule. A one-time run can have a profile; a recurring run reuses the same profile plus a `state.md` (see `references/recurring-setup.md`). Keep the two concerns separate: the profile answers "how do we build this brand's deck," `state.md` answers "what were last period's numbers to diff against."

## Where it lives

Save `PROFILE.md` next to where this brand's decks are saved:
- **Recurring brand:** `<brand-slug>-creative-report/PROFILE.md` (alongside `reports/` and `state.md`).
- **One-time brand that opted to save a profile:** create the same `<brand-slug>-creative-report/` folder so a future run finds it, even if there's no `reports/` history yet.

At the start of every run, look for `<brand-slug>-creative-report/PROFILE.md`. If it exists, load it and skip the questions it already answers. If it doesn't, run the full Step 1 setup and offer to write one at the end.

## What it captures

Write only what a future run would otherwise have to re-ask. Keep it data, not prose.

```markdown
# <Brand> Creative Report — Profile

## Basics
- Deck language: English | Spanish (Spain)
- Currency + formatting: e.g. EUR, "1.234,56 €" (Spain convention) | USD, "$1,234.56"
- Attribution basis (shown on nearly every slide subtitle): e.g. "Triple Whale, Pixel first-click, 1-day"
- Ad accounts: single | multiple (list them; keeps or drops the Ad Accounts slide)
- Prepared for: team / founder / client name

## Data source
- Source(s): Triple Whale | native ad platform | native platform + creative-tagging tool | GA4 | warehouse | export
- Exactly how each section is pulled (specific tables / reports / exports, not just the tool name)
- Which source is authoritative for revenue/ROAS if more than one is blended
- Known data-quality caveats (a channel with weaker data, a landing template missing session tracking, a new-customer signal that's approximate)

## Hit rule
- Spend minimum + ROAS/NC ROAS minimum (the exact bar, in this brand's currency)
- Scoring: per individual ad | per creative concept (variants folded together)
- The same bar is applied on Product, Owner, Landing Page, Top Performers, Launch Analysis, confirm it's used everywhere

## Tagging conventions (from the brand's team, not inferred)
- Owner/editor: convention + 2-3 real examples
- Awareness stage: convention or "not tagged, slide dropped"
- Funnel stage TOF/MOF/BOF: convention or "not tagged, slide dropped"
- Audience segment: convention or "not tagged, slide dropped"
- Creator credit (if Best Creators applies): convention or "n/a"

## Sections in play
- Full list of which of the 13 (EN) / 15 (ES) sections are included, and the reason any is dropped
  (e.g. "single ad account → Ad Accounts dropped"; "no funnel-stage tags → Funnel Stage dropped until tagging exists")
- If porting New Customer % / Best Creators into an English deck, note it here so it's not re-decided each run
```

## Keeping it honest

- A profile records what was true when it was written. If a brand starts tagging a dimension it wasn't tagging before, or changes currency, or moves data source, update the profile the same run you discover it, don't let a stale ficha silently drop a slide that's now buildable.
- Never copy one brand's profile onto another as a shortcut. The whole point of the skill being generic is that each brand's ficha is its own, thresholds and tags do not transfer.
