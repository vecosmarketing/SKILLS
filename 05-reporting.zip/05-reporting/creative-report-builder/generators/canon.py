import re, os
# SKIN MLO empaquetado (portable): head (style+fuentes) y logo base64 oficiales de M.L.O Growth.
_here=os.path.dirname(os.path.abspath(__file__))
HEAD=open(os.path.join(_here,"mlo_head.html"),encoding="utf-8").read()
LOGO=open(os.path.join(_here,"mlo_logo.html"),encoding="utf-8").read().strip()

# CANONICAL middle sections (footer_label, eyebrow, h2, glow-orb style)
SECS=[
 ("RESUMEN","Resumen","KPIs Generales","top:-220px; right:-180px; width:950px; height:950px; opacity:0.55"),
 ("CRECIMIENTO","Crecimiento","% de Clientes Nuevos","top:-200px; left:-160px; width:900px; height:900px; opacity:0.5"),
 ("EMBUDO","Embudo","Embudo de Conversión: Dónde se Cae el Tráfico","top:-200px; left:-160px; width:900px; height:900px; opacity:0.5"),
 ("PRODUCTO","Producto","Inversión y Tasa de Aciertos por Producto","top:-180px; left:-200px; width:850px; height:850px; opacity:0.5"),
 ("ÁNGULO","Ángulo","Inversión y Rendimiento por Ángulo","top:-160px; right:-180px; width:820px; height:820px; opacity:0.48"),
 ("OWNER","Owner","Rendimiento por Responsable","bottom:-200px; right:-200px; width:900px; height:900px; opacity:0.5"),
 ("CONOCIMIENTO","Fase de Conocimiento","Dónde Vive la Inversión por Fase de Conocimiento","bottom:-220px; right:-160px; width:920px; height:920px; opacity:0.45"),
 ("EMBUDO","Fase del Embudo","Rendimiento por Fase del Embudo","top:-200px; left:30%; width:800px; height:700px; opacity:0.4"),
 ("MEJORES ANUNCIOS","Mejores Anuncios","Los 3 Anuncios de Mayor Inversión","top:-140px; right:-240px; width:700px; height:700px; opacity:0.5"),
 ("MEJORES Y PEORES","En Ascenso vs. Bajo Rendimiento","Mejores y Peores Anuncios de la Semana","bottom:-180px; right:-260px; width:820px; height:820px; opacity:0.45"),
 ("CREADORES","Creadores","Mejores Creadores","bottom:-200px; left:-180px; width:900px; height:900px; opacity:0.5"),
]
KEYS=["kpis","crecimiento","embudo","producto","angulo","owner","conocimiento","fase_embudo","top3","mejores","creadores"]

def build(brand_up, title, subtitle, meta_html, inner, lectura_inner, outpath):
    head=re.sub(r"<title>.*?</title>",f"<title>{title}</title>",HEAD,flags=re.DOTALL)
    parts=[head,"<body>\n"]
    # 01 cover
    parts.append(f'''<section>
  <div class="glow-orb" style="bottom:-200px; left:-200px; width:1000px; height:1000px; opacity:0.55;"></div>
  <div class="logo">{LOGO}</div>
  <h1>Informe Semanal de<br><span class="hl">Estrategia Creativa.</span></h1>
  <div class="subtitle">{subtitle}</div>
  <div class="meta-row">{meta_html}</div>
</section>\n''')
    # 02-10 middle
    for i,(fl,eb,h2,orb) in enumerate(SECS):
        num=i+2; key=KEYS[i]
        body=inner.get(key) or f'<div class="callout warn">Sección canónica sin datos suficientes para {brand_up} esta semana. Se mantiene por estructura; pendiente de datos/etiquetado.</div>'
        parts.append(f'''<section>
  <div class="glow-orb" style="{orb};"></div>
  <div class="eyebrow">{eb}</div>
  <h2>{h2}</h2>
  {body}
  <div class="footer-tag"><span>{brand_up} · {fl} · {num:02d}</span><span>{WINDOW}</span></div>
</section>\n''')
    # 11 lectura
    parts.append(f'''<section>
  <div class="glow-orb" style="top:-200px; left:-180px; width:900px; height:900px; opacity:0.5;"></div>
  <div class="eyebrow">Lectura del Estratega Creativo</div>
  {lectura_inner}
  <div class="footer-tag"><span>{brand_up} · LECTURA · {len(SECS)+2:02d}</span><span>{WINDOW}</span></div>
</section>\n''')
    parts.append("</body>\n</html>")
    open(outpath,"w",encoding="utf-8").write("".join(parts))
    import subprocess
    n=open(outpath).read().count("<section>")
    print(f"{brand_up}: {n} sections -> {outpath}")

WINDOW='<span>3–9 ago, 2026</span>'
def metarow(base, moneda):
    return f'''
    <div><div class="meta-label">Semana</div><div class="meta-value">3–9 ago, 2026</div></div>
    <div><div class="meta-label">Preparado para</div><div class="meta-value">{PREP}</div></div>
    <div><div class="meta-label">Base</div><div class="meta-value">{base}</div></div>
    <div><div class="meta-label">Moneda</div><div class="meta-value">{moneda}</div></div>'''
print("canon.py loaded")
