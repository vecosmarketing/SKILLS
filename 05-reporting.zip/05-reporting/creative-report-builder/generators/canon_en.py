import re, os
# SKIN MLO empaquetado (portable): head (style+fuentes) y logo base64 oficiales de M.L.O Growth.
_here=os.path.dirname(os.path.abspath(__file__))
HEAD=open(os.path.join(_here,"mlo_head.html"),encoding="utf-8").read()
LOGO=open(os.path.join(_here,"mlo_logo.html"),encoding="utf-8").read().strip()

# CANONICAL middle sections (footer_label, eyebrow, h2, glow-orb style)
SECS=[
 ("OVERVIEW","Overview","Overview KPIs","top:-220px; right:-180px; width:950px; height:950px; opacity:0.55"),
 ("GROWTH","Growth","New Customer %","top:-200px; left:-160px; width:900px; height:900px; opacity:0.5"),
 ("FUNNEL","Funnel","Conversion Funnel: Where Traffic Drops","top:-200px; left:-160px; width:900px; height:900px; opacity:0.5"),
 ("PRODUCT","Product","Spend & Hit Rate by Product","top:-180px; left:-200px; width:850px; height:850px; opacity:0.5"),
 ("ANGLE","Angle","Spend & Performance by Angle","top:-160px; right:-180px; width:820px; height:820px; opacity:0.48"),
 ("OWNER","Owner","Performance by Owner","bottom:-200px; right:-200px; width:900px; height:900px; opacity:0.5"),
 ("AWARENESS","Awareness Stage","Where Awareness-Stage Spend Lives","bottom:-220px; right:-160px; width:920px; height:920px; opacity:0.45"),
 ("FUNNEL","Funnel Stage","Funnel Stage Performance","top:-200px; left:30%; width:800px; height:700px; opacity:0.4"),
 ("TOP PERFORMERS","Top Performers","Top 3 Performing Ads","top:-140px; right:-240px; width:700px; height:700px; opacity:0.5"),
 ("BEST & WORST","Emerging vs. Underperforming","Best & Worst Ads of the Week","bottom:-180px; right:-260px; width:820px; height:820px; opacity:0.45"),
 ("CREATORS","Creators","Best Creators","bottom:-200px; left:-180px; width:900px; height:900px; opacity:0.5"),
]
KEYS=["kpis","crecimiento","embudo","producto","angulo","owner","conocimiento","fase_embudo","top3","mejores","creadores"]

def build(brand_up, title, subtitle, meta_html, inner, lectura_inner, outpath):
    head=re.sub(r"<title>.*?</title>",f"<title>{title}</title>",HEAD,flags=re.DOTALL)
    parts=[head,"<body>\n"]
    # 01 cover
    parts.append(f'''<section>
  <div class="glow-orb" style="bottom:-200px; left:-200px; width:1000px; height:1000px; opacity:0.55;"></div>
  <div class="logo">{LOGO}</div>
  <h1>Weekly Creative<br><span class="hl">Strategy Report.</span></h1>
  <div class="subtitle">{subtitle}</div>
  <div class="meta-row">{meta_html}</div>
</section>\n''')
    # 02-10 middle
    for i,(fl,eb,h2,orb) in enumerate(SECS):
        num=i+2; key=KEYS[i]
        body=inner.get(key) or f'<div class="callout warn">Canonical section, not enough data this week for {brand_up} esta semana. Kept for structure; pending data/tagging.</div>'
        parts.append(f'''<section>
  <div class="glow-orb" style="{orb};"></div>
  <div class="eyebrow">{eb}</div>
  <h2>{h2}</h2>
  {body}
  <div class="footer-tag"><span>{brand_up} · {fl} · {num:02d}</span><span>{WINDOW}</span></div>
</section>\n''')
    # 11 lectura
    parts.append(f'''<section>
  <div class="glow-orb" style="top:-200px; left:-180px; width:900px; height:900px; opacity:0.5;"></div>
  <div class="eyebrow">Creative Strategist Read</div>
  {lectura_inner}
  <div class="footer-tag"><span>{brand_up} · THE READ · {len(SECS)+2:02d}</span><span>{WINDOW}</span></div>
</section>\n''')
    parts.append("</body>\n</html>")
    open(outpath,"w",encoding="utf-8").write("".join(parts))
    import subprocess
    n=open(outpath).read().count("<section>")
    print(f"{brand_up}: {n} sections -> {outpath}")

WINDOW='<span>3–9 ago, 2026</span>'
def metarow(base, moneda):
    return f'''
    <div><div class="meta-label">Week</div><div class="meta-value">Aug 3–9, 2026</div></div>
    <div><div class="meta-label">Prepared for</div><div class="meta-value">{PREP}</div></div>
    <div><div class="meta-label">Basis</div><div class="meta-value">{base}</div></div>
    <div><div class="meta-label">Currency</div><div class="meta-value">{moneda}</div></div>'''
print("canon_en.py loaded")
