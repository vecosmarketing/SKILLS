import importlib.util
spec=importlib.util.spec_from_file_location("canon","canon.py"); canon=importlib.util.module_from_spec(spec)
canon.PREP="Equipo MLO · V-UP"; canon.WINDOW='<span>3–9 ago, 2026</span>'
spec.loader.exec_module(canon)
import growth, prod
crecimiento=growth.block("es",71.6,63,88,69.4,78.0,
  '''<div class="callout">V-UP mantiene una adquisición fuerte: el 71,6% de los pedidos (63 de 88) son de clientes nuevos, con un 28% de recompra. Sube +2,2 pts vs. la semana anterior (69,4%) y baja ‒6,4 pts vs. el mismo periodo del mes pasado (78,0%): el mix se mantiene sano en torno al 70%, y la ligera bajada mensual es normal a medida que crece la base de recurrentes. Cuesta $115.436 COP adquirir cada cliente nuevo (NCPA sobre gasto MLO), subiendo levemente desde $104.613. Motor de captación funcionando. Fuente: Shopify (first-time vs returning, toda la tienda); la slide de KPIs es lo atribuido a Meta (solo campañas MLO).</div>''',
  ncpa=115436, prev_ncpa=104613, cur="$", source="Shopify (first-time vs returning, toda la tienda)")

kpis='''<div class="subtitle">Meta Ads · SOLO campañas MLO (ventas) · base atribuido pixel · vs. semana anterior (27 jul – 2 ago)</div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-label">Inversión</div><div class="kpi-value">$7.272.449</div><div class="kpi-delta up">▲ 17,8% vs $6.172.176</div></div>
    <div class="kpi-card"><div class="kpi-label">Ingresos</div><div class="kpi-value">$20.680.200</div><div class="kpi-delta up">▲ 6,7% vs $19.373.600</div></div>
    <div class="kpi-card"><div class="kpi-label">ROAS (MLO)</div><div class="kpi-value">2,84x</div><div class="kpi-delta down">▼ 9,4% vs 3,14x</div></div>
    <div class="kpi-card"><div class="kpi-label">Pedidos</div><div class="kpi-value">85</div><div class="kpi-delta up">▲ 13,3% vs 75</div></div>
    <div class="kpi-card"><div class="kpi-label">Ticket Medio</div><div class="kpi-value">$243.296</div><div class="kpi-delta down">▼ 5,8% vs $258.315</div></div>
    <div class="kpi-card"><div class="kpi-label">CPA</div><div class="kpi-value">$85.558</div><div class="kpi-delta down">▲ 4,0% vs $82.296</div></div>
    <div class="kpi-card"><div class="kpi-label">CTR</div><div class="kpi-value">3,23%</div><div class="kpi-delta up">▲ 7,7% vs 3,00%</div></div>
    <div class="kpi-card"><div class="kpi-label">Frecuencia</div><div class="kpi-value">4,97</div><div class="kpi-delta up">▼ vs 5,85 (menos saturación)</div></div>
  </div>
  <div class="callout"><b>Semana sólida de escalado eficiente.</b> Las campañas de MLO subieron inversión un 17,8% ($7,27M COP) y vendieron un 6,7% más ($20,68M), con pedidos +13,3%. El ROAS baja levemente (3,14x → 2,84x) pero sigue sano, y lo hace expandiendo a audiencia FRESCA: alcance +33% y menos frecuencia. No es saturación: es crecimiento.</div>
  <div class="callout warn"><b>⚠ Importante:</b> este reporte usa SOLO las campañas de MLO (objetivo Ventas). El ROAS "blended" de toda la cuenta sale 1,99x porque el cliente corre en paralelo campañas propias ("Ventas [ciudad] 2026", "Citas", captación de leads) que gastan ~$3,12M COP con 0 ventas trackeadas por el pixel. Ver slide de Owner.</div>'''

embudo='''<div class="subtitle">Embudo de sitio (pixel Meta, solo campañas MLO) · Alcance ~127K &middot; Impresiones 584.592 &middot; CTR 3,23% &middot; barra = volumen relativo a Clics</div>
  <div class="table-panel"><table>
    <tr><th>Etapa</th><th>Volumen</th><th>Tasa de paso</th></tr>
    <tr><td>Clics</td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:100%"></div></div><span class="small">18.887</span></div></td><td class="flat">base</td></tr>
    <tr><td><b>Landing (LPV)</b></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:43%"></div></div><span class="small">8.186</span></div></td><td class="flat">43,3%</td></tr>
    <tr><td><b>Añadir al Carrito</b> <span class="pill pill-bad" style="margin-left:6px;">Fuga</span></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill bad2" style="width:3%"></div></div><span class="small">626</span></div></td><td class="down">7,6%</td></tr>
    <tr><td>Checkout</td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:1.5%"></div></div><span class="small">247</span></div></td><td class="flat">39,5% del carrito</td></tr>
    <tr><td><b>Compras</b></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:0.6%"></div></div><span class="small">85</span></div></td><td class="down">0,45% de clics</td></tr>
  </table></div>
  <div class="callout">Con el embudo medido SOLO sobre campañas MLO, el 43,3% de los clics llega a la landing (sano). La fuga principal es Añadir al Carrito (7,6% de la landing): ahí está el margen de conversión. De carrito a compra el paso es razonable (626 → 247 → 85). Nota: si se mira la cuenta entera, la tasa de landing parece caer al 15% porque las campañas del cliente meten decenas de miles de clics de tráfico que no convierten; por eso hay que aislar MLO.</div>'''

angulo='''<div class="small" style="margin-bottom:4px;">Ángulo del producto único · ROAS Meta atribuido (campañas MLO)</div>
  <div class="product-grid">
    <div class="product-card highlight"><div class="product-title-row"><div class="product-title"><span class="product-num">01</span><span class="product-name">Energía / Fatiga Mental</span></div><div class="pill pill-solid">Motor</div></div><div class="product-spend">$5.072.810</div><div class="product-share">69,8% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:100%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value" style="color:var(--good)">3,20x <span class="up">▲</span></div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">66</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">11</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-title"><span class="product-num">02</span><span class="product-name">Tests / iteraciones</span></div><div class="badge badge-warn">Sin ángulo fijo</div></div><div class="product-spend">$1.934.204</div><div class="product-share">26,6% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:38%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value">2,05x</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">17</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">6</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-title"><span class="product-num">03</span><span class="product-name">Memoria</span></div><div class="pill pill-bad">Flojea</div></div><div class="product-spend">$265.435</div><div class="product-share">3,6% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:5%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value" style="color:var(--bad)">1,73x <span class="down">▼</span></div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">2</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">2</div></div></div></div>
  </div>
  <div class="callout">Producto único, así que esto es corte por ÁNGULO. El ángulo <b>Energía / Fatiga Mental</b> es el motor absoluto: 70% del gasto a 3,20x y 66 de los 85 pedidos. El ángulo <b>Memoria</b> no arranca (1,73x) y apenas tiene inversión. Un cuarto del gasto va en tests/iteraciones sin ángulo fijo (2,05x). Lectura: doblar en el ángulo de energía/fatiga mental (donde está el hero "Sobrevivir una enfermedad"), y replantear o pausar el de Memoria.</div>'''

owner='''<div class="small" style="margin-bottom:4px;">Owner de la campaña · lo que gestiona MLO vs. lo que corre el cliente · ROAS Meta atribuido</div>
  <div class="table-panel"><table>
    <tr><th>Owner</th><th>Inversión</th><th>% Gasto cuenta</th><th>Pedidos</th><th>Ingresos</th><th>ROAS</th></tr>
    <tr><td><b>MLO</b> (campañas de Ventas) <span class="pill pill-solid" style="margin-left:6px;">Lo nuestro</span></td><td>$7.272.449</td><td>70,0%</td><td>85</td><td>$20.680.200</td><td class="up">2,84x</td></tr>
    <tr><td>Cliente (Ventas ciudad / Citas / Leads)</td><td>$3.123.187</td><td>30,0%</td><td class="down">0*</td><td class="down">$0*</td><td class="down">n/d</td></tr>
  </table></div>
  <div class="callout warn">Esta es la slide clave de V-UP. <b>Las campañas de MLO generan el 100% de las ventas trackeadas: 85 pedidos a 2,84x.</b> En paralelo, el cliente corre ~$3,12M COP (30% del gasto de la cuenta) en campañas propias: "Ventas Bogotá/Cali/Ibagué…", "Citas Medellín", y captación de leads, que NO registran ventas por el pixel (*probablemente cierran por WhatsApp/llamada fuera de Shopify). Eso hunde el ROAS "blended" de la cuenta a 1,99x y esconde el rendimiento real de MLO. Acción: reportar siempre MLO por separado y decidir con el cliente qué hacer con esas campañas.</div>
  <div class="callout">Dentro de MLO, por estrategia: <b>Scaling BidCap</b> $3,50M a 3,30x (42 ped, el motor) · <b>Creative Diversification</b> $2,35M a 2,04x (23 ped) · <b>Retargeting</b> $0,92M a 3,23x (14 ped, muy eficiente) · <b>Testing</b> $0,50M a 2,69x (6 ped).</div>'''

conocimiento='''<div class="subtitle">Fase de conocimiento leída del nombre del anuncio (campañas MLO) · ROAS Meta atribuido</div>
  <div class="product-grid">
    <div class="product-card"><div class="product-title-row"><div class="product-name">TOFU (Problem/Unaware)</div><div class="pill pill-solid">Volumen</div></div><div class="product-spend">3,01x</div><div class="product-share">ROAS · $4.345.018 (59,7%)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$4,35M</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">7</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">53</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-name">BOFU (Oferta)</div><div class="pill pill-solid">Rinde</div></div><div class="product-spend">3,06x</div><div class="product-share">ROAS · $1.633.254 (22,5%)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$1,63M</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">4</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">23</div></div></div></div>
    <div class="product-card highlight"><div class="product-title-row"><div class="product-name">MOFU</div><div class="pill pill-hit">Máx. eficiencia</div></div><div class="product-spend">12,35x</div><div class="product-share">ROAS · $131.142 (1,8%)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$131K</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">5</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">6</div></div></div></div>
  </div>
  <div class="callout">Embudo sano y equilibrado: el TOFU (frío, 60% del gasto) trae el volumen a 3,01x y el BOFU (oferta) cierra a 3,06x. El MOFU es minúsculo (1,8% del gasto) pero rinde 12,35x: hay hueco para alimentarlo más. A diferencia de otras cuentas, aquí el frío convierte bien porque el ángulo de fatiga mental engancha en TOFU. (16% del gasto va en tests sin etiqueta de fase.)</div>'''

fase='''<div class="subtitle">TOF / MOF / BOF por ROAS de pixel (campañas MLO) · escala 0–6x · línea de media MLO ~2,84x · breakeven ~1,5x</div>
  <div class="tower-track-row">
    <div class="tower-threshold-line" style="bottom:100px;"><span class="tower-threshold-label">2,84x media MLO</span></div>
    <div class="tower-track"><div class="tower-value">3,01x</div><div class="tower-bar-track"><div class="tower-fill" style="height:50%"></div></div></div>
    <div class="tower-track"><div class="tower-value">12,35x</div><div class="tower-bar-track"><div class="tower-fill" style="height:100%"></div></div></div>
    <div class="tower-track"><div class="tower-value">3,06x</div><div class="tower-bar-track"><div class="tower-fill" style="height:51%"></div></div></div>
  </div>
  <div class="tower-label-row">
    <div class="tower-col-label"><div class="tower-label">TOF</div><div class="tower-sub">$4,35M · 7 ads · 53 ped</div></div>
    <div class="tower-col-label"><div class="tower-label">MOF</div><div class="tower-sub" style="color:var(--good);">$131K · 5 ads · 6 ped</div></div>
    <div class="tower-col-label"><div class="tower-label">BOF</div><div class="tower-sub">$1,63M · 4 ads · 23 ped</div></div>
  </div>
  <div class="callout" style="margin-top:30px;">Las tres fases están por encima de breakeven (~1,5x), señal de una cuenta bien construida. TOF (3,01x) sostiene el volumen y BOF (3,06x) cierra con oferta, ambos por encima de la media MLO. El MOF (12,35x) es la joya infra-financiada: solo $131K. Palanca: subir presupuesto de MOFU y mantener el equilibrio TOF↔BOF que ya funciona.</div>'''

top3='''<div class="small">Ordenados por inversión, 3–9 ago · campañas MLO · base Meta atribuido · barra de acierto: ROAS ≥ 2,84x (media MLO)</div>
  <div class="ad-card-grid">
    <div class="ad-card hit"><div class="ad-status hit">✓ Hero (45% de los pedidos)</div><div class="ad-name">Sobrevivir una enfermedad (V8)</div><div class="ad-meta">Vídeo · TOFU Problem Aware · Energía</div><div class="ad-headline"><div class="ad-spend">$3.010.077</div><div class="ad-roas up">3,42x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">38</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">3,17%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$393</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$79K</div></div></div></div>
    <div class="ad-card miss"><div class="ad-status miss">✕ Bajo la media</div><div class="ad-name">K040 Feature Callout (4 ingredientes)</div><div class="ad-meta">Estático · BOFU Product Aware · Energía</div><div class="ad-headline"><div class="ad-spend">$862.085</div><div class="ad-roas down">2,33x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">9</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">2,41%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$523</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$96K</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">✓ Sobre la media</div><div class="ad-name">J043 Ugly Ad (Oferta)</div><div class="ad-meta">Estático · BOFU · Oferta/Urgencia</div><div class="ad-headline"><div class="ad-spend">$607.432</div><div class="ad-roas up">3,49x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">11</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">2,37%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$462</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$55K</div></div></div></div>
  </div>
  <div class="callout">El hero absoluto es el vídeo <b>"Sobrevivir una enfermedad"</b>: $3,01M (41% del gasto MLO), 3,42x y <b>38 de los 85 pedidos (45%)</b>. Es el concepto ganador a proteger e iterar. El estático de oferta J043 (3,49x) es el segundo motor y el más eficiente por CPA ($55K). El feature callout K040 rinde por debajo de la media (2,33x) pese al volumen: candidato a iterar.</div>'''

mejores='''<div class="small">Ganadores de gasto pequeño con ROAS altísimo, y el gasto que rinde por debajo de la media MLO (2,84x).</div>
  <div style="margin-top:22px; font-size:11px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:var(--good);">🚀 A escalar</div>
  <div class="ad-card-grid" style="margin-top:10px;">
    <div class="ad-card hit"><div class="ad-status hit">✓ Motor</div><div class="ad-name">J043 Ugly Ad Oferta</div><div class="ad-meta">Estático · BOFU</div><div class="ad-headline"><div class="ad-spend">$607K</div><div class="ad-roas up">3,49x</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">11</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$55K</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">🌱 Escalar</div><div class="ad-name">JL016.3 ISA Diagnóstico</div><div class="ad-meta">Vídeo · TOFU · creadora ISA</div><div class="ad-headline"><div class="ad-spend">$189K</div><div class="ad-roas up">4,63x</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">4</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">3,76%</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">🌱 Semilla</div><div class="ad-name">J052 VSL Dr. Carlos</div><div class="ad-meta">Vídeo · TOFU Unaware · VSL</div><div class="ad-headline"><div class="ad-spend">$137K</div><div class="ad-roas up">4,15x</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">3</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">5,68%</div></div></div></div>
  </div>
  <div style="margin-top:22px; font-size:11px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:var(--bad);">⚠ Bajo la media / a depurar</div>
  <div class="ad-card-grid" style="margin-top:10px;">
    <div class="ad-card miss"><div class="ad-status miss">✕ Ángulo Memoria</div><div class="ad-name">J040.3 Memoria Cortisol B/A</div><div class="ad-meta">Estático · TOFU · Memoria</div><div class="ad-headline"><div class="ad-spend">$252K</div><div class="ad-roas down">0,68x</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">1</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">1,15%</div></div></div></div>
    <div class="ad-card miss"><div class="ad-status miss">✕ Creadora floja</div><div class="ad-name">JL010 Ana Ramírez (UGC)</div><div class="ad-meta">Vídeo · TOFU · Ana Ramírez</div><div class="ad-headline"><div class="ad-spend">$168K</div><div class="ad-roas down">1,01x</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">1</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">4,21%</div></div></div></div>
  </div>
  <div class="callout good" style="margin-top:18px;">Señales a escalar: el estático de oferta J043 (3,49x), la creadora <b>ISA</b> (JL016.3, 4,63x) y las VSL del <b>Dr. Carlos</b> (J052, 4,15x). Micro-ganadores por ROAS (gasto en céntimos): K038 Before/After 55,95x, J043 original 25,60x, Michelle ranking 21,04x, UGC Dra villano 19,44x, Ganoderma 12,73x.</div>
  <div class="callout bad">A depurar: el ángulo <b>Memoria</b> (J040.3, 0,68x), la creadora <b>Ana Ramírez</b> (1,01x, engancha por CTR pero no cierra) y el <b>lote de tests MLO sin conversión</b> ($763K COP, 0 ventas): pausar y reasignar a los ganadores.</div>'''

creadores='''<div class="subtitle">Creadores por nombre · campañas MLO · ordenados por inversión · ROAS Meta atribuido (media MLO 2,84x)</div>
  <div class="table-panel"><table>
    <tr><th>Creador</th><th>Anuncios</th><th>Inversión</th><th>Pedidos</th><th>ROAS</th></tr>
    <tr><td><b>Dr. Carlos</b> (VSL, médico creador) <span class="pill pill-solid" style="margin-left:6px;">Autoridad</span></td><td>2</td><td>$679.042</td><td>8</td><td class="down">2,09x</td></tr>
    <tr><td><b>ISA</b> (diagnóstico / UGC) <span class="pill pill-solid">Mejor</span></td><td>2</td><td>$236.328</td><td>5</td><td class="up">4,42x</td></tr>
    <tr><td>Ana Ramírez (UGC) <span class="pill pill-bad">Floja</span></td><td>1</td><td>$167.916</td><td>1</td><td class="down">1,01x</td></tr>
    <tr><td>UGC Dra (villano)</td><td>2</td><td>$89.408</td><td>3</td><td class="up">8,39x</td></tr>
    <tr><td>Michelle (dra, ranking)</td><td>1</td><td>$13.780</td><td>1</td><td class="up">21,04x</td></tr>
  </table></div>
  <div class="callout">V-UP se apoya mucho en creadores tipo médico/paciente (encaja con un suplemento de un doctor, Dr. Canencio). <b>ISA</b> es la mejor con volumen (4,42x, formato diagnóstico), y <b>UGC Dra</b> (8,39x) y <b>Michelle</b> (21,04x) dan señales muy fuertes con poco gasto. El <b>Dr. Carlos</b> (VSL de autoridad) trae 8 pedidos pero a 2,09x (por debajo de la media): funciona para captar, no para eficiencia pura. <b>Ana Ramírez</b> (1,01x) es la que menos cierra. Dirección: escalar ISA + UGC Dra + Michelle, iterar las VSL del Dr. Carlos, y retirar a Ana Ramírez.</div>'''

lectura='''<div class="quote-mark">&ldquo;</div>
  <div class="quote-text">Las campañas de MLO en V-UP corren a <span class="hl2">2,84x</span> y escalaron bien esta semana (+18% gasto, +13% pedidos, a audiencia fresca). El "blended" de la cuenta (1,99x) engaña: el cliente gasta <span class="hl2">~$3,12M COP en campañas propias con 0 ventas trackeadas</span>. El motor es el vídeo <span class="hl2">"Sobrevivir una enfermedad" (3,42x, 45% de los pedidos)</span> y el ángulo de fatiga mental.</div>
  <div class="quote-attr"><div class="avatar-circle">CE</div><div><div class="quote-attr-name">Lectura del Estratega Creativo</div><div class="quote-attr-role">3–9 ago, 2026 · solo campañas MLO</div></div></div>
  <div class="callout warn" style="margin-top:28px;"><b>Base: Meta atribuido, SOLO campañas MLO.</b> Excluidas las campañas del cliente (Ventas ciudad / Citas / Leads), que no registran ventas por pixel. Clientes nuevos: 71,6% (Shopify). Producto único; corte por ángulo/awareness.</div>
  <div style="margin-top:22px;"><ol class="num-list">
    <li><b style="color:var(--accent);">Reportar siempre MLO por separado.</b> El ROAS real de MLO es 2,84x, no el 1,99x de la cuenta. Decidir con el cliente qué hacer con sus $3,12M en campañas ciudad/citas/leads (¿cierran por WhatsApp? ¿medir de otra forma? ¿pausar?).</li>
    <li><b style="color:var(--accent);">Proteger e iterar el hero.</b> "Sobrevivir una enfermedad" hace el 45% de los pedidos a 3,42x. Sacar variantes del mismo concepto y ángulo (fatiga mental / energía, 3,20x) antes de abrir ángulos nuevos.</li>
    <li><b style="color:var(--accent);">Escalar el motor con cabeza.</b> Scaling BidCap (3,30x) y Retargeting (3,23x) son los más eficientes. Seguir subiendo mientras el ROAS aguante &gt;2,5x y la frecuencia no se dispare.</li>
    <li><b style="color:var(--accent);">Alimentar señales pequeñas.</b> MOFU (12,35x), ISA (4,42x), UGC Dra (8,39x), Michelle (21x) y los estáticos de oferta BOFU rinden por encima de la media con poco gasto.</li>
    <li><b style="color:var(--accent);">Depurar lo que no cierra.</b> Ángulo Memoria (1,73x), Ana Ramírez (1,01x) y el lote de tests MLO sin conversión ($763K). Pausar y reasignar a los ganadores.</li>
  </ol></div>'''

producto=prod.single("V-UP · Suplemento Fatiga Mental","$7.272.449","2,84x","85","~19",
  '''<div class="callout">V-UP es una cuenta de UN solo producto (el suplemento para fatiga mental / energía / memoria del Dr. Canencio), así que el 100% del gasto MLO va a este producto a 2,84x (sano; el "blended" de la cuenta baja a 1,99x por las campañas del cliente, ver Owner). No hay mix de producto: las palancas son el ÁNGULO de mensaje (slide siguiente), el formato y el embudo.</div>''',"es")
inner=dict(kpis=kpis,crecimiento=crecimiento,embudo=embudo,producto=producto,angulo=angulo,owner=owner,conocimiento=conocimiento,fase_embudo=fase,top3=top3,mejores=mejores,creadores=creadores)
canon.build("V-UP","V-UP · Informe Semanal de Estrategia Creativa · 3–9 ago 2026",
  "V-UP: qué funcionó, qué no, y dónde mover el presupuesto (solo campañas MLO).",
  canon.metarow("Meta Ads (atribuido pixel) · solo campañas MLO · suplemento fatiga mental","COP ($)"),
  inner,lectura,"/Users/mlo/framer/vup-creative-report/reports/vup-creative-report-2026-08-03.html")
