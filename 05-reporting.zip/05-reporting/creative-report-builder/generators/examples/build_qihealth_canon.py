import importlib.util
spec=importlib.util.spec_from_file_location("canon","canon.py"); canon=importlib.util.module_from_spec(spec)
canon.PREP="Equipo MLO · QiHealth"; canon.WINDOW='<span>3–9 ago, 2026</span>'
spec.loader.exec_module(canon)

import growth, prod
crecimiento=growth.block("es",82.4,103,125,81.8,82.7,
  '''<div class="callout">QiHealth tiene un motor de adquisición fuerte y MUY estable: el 82,4% de los pedidos (103 de 125) son de clientes nuevos, prácticamente plano vs. la semana anterior (81,8%, +0,6 pts) y vs. el mismo periodo del mes pasado (82,7%, ‒0,3 pts). Clave: la caída de ROAS de esta semana NO viene del mix (la cuenta sigue captando igual de bien), sino de eficiencia de audiencia (frecuencia 4,11). Cuesta $433 MXN adquirir cada cliente nuevo (NCPA), subiendo desde $316 al escalar contra saturación. El ~18% de recurrentes alimenta el ángulo de Recompra (BOFU, 8,79x), el más rentable. Fuente: Shopify (first-time vs returning, toda la tienda); la slide de KPIs es lo atribuido a Meta.</div>''',
  ncpa=433, prev_ncpa=316, cur="$", source="Shopify (first-time vs returning, toda la tienda)")

kpis='''<div class="subtitle">Meta Ads · base atribuido pixel · vs. semana anterior (27 jul – 2 ago)</div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-label">Inversión</div><div class="kpi-value">$44.601</div><div class="kpi-delta up">▲ 20,7% vs $36.942</div></div>
    <div class="kpi-card"><div class="kpi-label">Ingresos</div><div class="kpi-value">$304.012</div><div class="kpi-delta down">▼ 7,9% vs $330.224</div></div>
    <div class="kpi-card"><div class="kpi-label">ROAS</div><div class="kpi-value">6,82x</div><div class="kpi-delta down">▼ 23,7% vs 8,94x</div></div>
    <div class="kpi-card"><div class="kpi-label">Pedidos</div><div class="kpi-value">105</div><div class="kpi-delta down">▼ 7,9% vs 114</div></div>
    <div class="kpi-card"><div class="kpi-label">Ticket Medio</div><div class="kpi-value">$2.895</div><div class="kpi-delta flat">≈ vs $2.897</div></div>
    <div class="kpi-card"><div class="kpi-label">CPA</div><div class="kpi-value">$424,77</div><div class="kpi-delta down">▲ 31,1% vs $324,05</div></div>
    <div class="kpi-card"><div class="kpi-label">CTR</div><div class="kpi-value">3,16%</div><div class="kpi-delta down">▼ 8,7% vs 3,46%</div></div>
    <div class="kpi-card"><div class="kpi-label">Frecuencia</div><div class="kpi-value">4,11</div><div class="kpi-delta down">▲ 19,1% vs 3,45 · saturación</div></div>
  </div>
  <div class="callout warn">Cuenta sana pero semana de SATURACIÓN. QiHealth escaló la inversión un 20,7% ($44.601) pero los ingresos CAYERON un 7,9% ($304.012) y el ROAS se hundió (‒23,7%, de 8,94x a 6,82x). La frecuencia subió a 4,11 (+19,1%) con menos alcance (‒7,3%): se empujó presupuesto sobre la MISMA audiencia, ya cansada. Sigue muy rentable (6,82x), pero esta semana el dinero extra compró fatiga, no crecimiento.</div>
  <div class="callout">Base Meta atribuido. Sin Triple Whale confirmado (ROAS de caja / % cliente nuevo van por Shopify). Ticket alto (~$2.895 MXN): producto de recompra.</div>'''

embudo='''<div class="subtitle">Embudo de sitio (pixel Meta) · Alcance 107.871 &middot; Impresiones 443.376 &middot; CTR 3,16% &middot; Frec. 4,11 &middot; barra = volumen relativo a Clics</div>
  <div class="table-panel"><table>
    <tr><th>Etapa</th><th>Volumen</th><th>Tasa de paso</th></tr>
    <tr><td>Clics</td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:100%"></div></div><span class="small">14.018</span></div></td><td class="flat">base</td></tr>
    <tr><td><b>Landing (LPV)</b> <span class="pill pill-bad" style="margin-left:6px;">Fuga</span></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill bad2" style="width:46%"></div></div><span class="small">6.449</span></div></td><td class="down">46,0%</td></tr>
    <tr><td>Añadir al Carrito <span class="badge badge-warn" style="margin-left:6px;">infra-trackeado</span></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:3%"></div></div><span class="small">424</span></div></td><td class="flat">el evento infra-dispara</td></tr>
    <tr><td>Checkout</td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:4%"></div></div><span class="small">587</span></div></td><td class="flat">&gt; carrito (ATC no fiable)</td></tr>
    <tr><td><b>Compras</b></td><td><div class="mini-bar-cell"><div class="mini-bar-track"><div class="mini-bar-fill" style="width:1%"></div></div><span class="small">105</span></div></td><td class="down">0,75% de clics</td></tr>
  </table></div>
  <div class="callout warn">El evento Añadir al Carrito infra-dispara (424 &lt; checkout 587), así que la cadena fiable es Landing → Checkout → Compra. El 46% de los clics llegan a la landing (sano para el CTR 3,16%), y de checkout a compra hay margen: 587 → 105 (18%). El cuello está en el cierre del checkout, no en el tráfico. Con el ticket alto ($2.895) y ROAS 6,82x, la palanca es sostener la eficiencia de audiencia (frecuencia) y afinar el checkout.</div>'''

angulo='''<div class="small" style="margin-bottom:4px;">Ángulo del producto único · ROAS Meta atribuido · media de cuenta 6,82x</div>
  <div class="product-grid">
    <div class="product-card highlight"><div class="product-title-row"><div class="product-title"><span class="product-num">01</span><span class="product-name">Recompra (BOFU)</span></div><div class="pill pill-solid">Mejor ángulo</div></div><div class="product-spend">$5.424</div><div class="product-share">12,2% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:100%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value" style="color:var(--good)">8,79x <span class="up">▲</span></div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">13</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">4</div></div></div></div>
    <div class="product-card highlight"><div class="product-title-row"><div class="product-title"><span class="product-num">02</span><span class="product-name">Competencia (Ya usa sensor)</span></div><div class="pill pill-solid">Rinde</div></div><div class="product-spend">$2.550</div><div class="product-share">5,7% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:47%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value">7,55x <span class="up">▲</span></div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">8</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">3</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-title"><span class="product-num">03</span><span class="product-name">Villano Aguja (Se Pincha)</span></div><div class="pill pill-bad">Flojea</div></div><div class="product-spend">$4.288</div><div class="product-share">9,6% de la inversión</div><div class="bar-track"><div class="bar-fill" style="width:79%"></div></div><div class="product-stats"><div><div class="stat-label">ROAS</div><div class="stat-value" style="color:var(--bad)">3,70x <span class="down">▼</span></div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">8</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">8</div></div></div></div>
  </div>
  <div class="callout">Producto único, así que esto es corte por ÁNGULO. El ángulo estrella de la cuenta, "Se Pincha / Villano Aguja" (el dolor de pincharse), es el que más anuncios tiene pero rinde peor (3,70x): el mensaje de entrada se está fatigando. Lo que convierte es la parte caliente: Recompra/BOFU (8,79x) y "Ya usa sensor / Competencia" (7,55x). El 72% del gasto va sin etiqueta de ángulo (UGC, carruseles y refreshes) y se lee en las slides de Owner y Creadores. Palanca: renovar el ángulo "Se Pincha" y alimentar Recompra + Competencia.</div>'''

owner='''<div class="small" style="margin-bottom:4px;">Owner / producción del creativo · ROAS Meta atribuido · media de cuenta 6,82x</div>
  <div class="table-panel"><table>
    <tr><th>Owner / Producción</th><th>Inversión</th><th>% Gasto</th><th>Anuncios</th><th>Pedidos</th><th>ROAS</th></tr>
    <tr><td><b>MLO</b> (estáticos + carrusel + refresh) <span class="pill pill-solid" style="margin-left:6px;">Más eficiente</span></td><td>$25.017</td><td>56,1%</td><td>25</td><td>61</td><td class="up">7,84x</td></tr>
    <tr><td>Cliente / Creador (UGC + vídeo)</td><td>$19.583</td><td>43,9%</td><td>11</td><td>45</td><td class="flat">5,61x</td></tr>
  </table></div>
  <div class="callout">El creativo de MLO rinde por encima del de creadores: 7,84x vs 5,61x, y con más pedidos (61 vs 45). Dentro de MLO, los CARRUSELES son la joya escondida (20,65x, ver slide de Mejores/Peores) y están infra-financiados. El UGC no es malo (5,61x, sobre la media de muchas cuentas) pero aquí es el segmento menos eficiente y concentra a la creadora que más sangra (Isabella). Lectura: subir peso a MLO (sobre todo carrusel) y depurar el pool de UGC hacia las creadoras que sí cierran.</div>'''

conocimiento='''<div class="subtitle">Fase de conocimiento leída del nombre del anuncio · ROAS Meta atribuido · el 72% del gasto va sin etiqueta (UGC/carrusel/refresh)</div>
  <div class="product-grid">
    <div class="product-card highlight"><div class="product-title-row"><div class="product-name">BOFU / Most Aware</div><div class="pill pill-solid">Motor</div></div><div class="product-spend">8,79x</div><div class="product-share">ROAS · $5.424 gasto (12%)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$5.424</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">4</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">13</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-name">TOFU / Problem Aware</div></div><div class="product-spend">5,13x</div><div class="product-share">ROAS · $6.839 gasto (15%)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$6.839</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">11</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">16</div></div></div></div>
    <div class="product-card"><div class="product-title-row"><div class="product-name">Sin etiqueta</div><div class="badge badge-warn">72% del gasto</div></div><div class="product-spend">6,90x</div><div class="product-share">ROAS · $32.337 (UGC/carrusel/refresh)</div><div class="product-stats"><div><div class="stat-label">Gasto</div><div class="stat-value">$32.337</div></div><div><div class="stat-label">Anuncios</div><div class="stat-value">21</div></div><div><div class="stat-label">Pedidos</div><div class="stat-value">77</div></div></div></div>
  </div>
  <div class="callout warn">Señal clara donde hay etiqueta: lo caliente (BOFU / Most Aware, con el ángulo de Recompra) rinde 8,79x, muy por encima del frío (TOFU / Problem Aware, 5,13x). El producto es de recompra y ticket alto, así que tiene sentido que la parte baja del embudo trabaje mejor. El 72% del gasto (UGC, carruseles, refreshes) va sin etiquetar y rinde 6,90x (la media). Recomendación: etiquetar awareness en UGC/carrusel para poder optimizar, y proteger el presupuesto de BOFU.</div>'''

fase='''<div class="subtitle">TOF / BOF por ROAS de pixel · escala 0–10x · línea de media de cuenta ~6,82x · el 75% del gasto va sin etiqueta de fase</div>
  <div class="tower-track-row">
    <div class="tower-threshold-line" style="bottom:150px;"><span class="tower-threshold-label">6,82x media cuenta</span></div>
    <div class="tower-track"><div class="tower-value">5,27x</div><div class="tower-bar-track"><div class="tower-fill under" style="height:53%"></div></div></div>
    <div class="tower-track"><div class="tower-value">8,79x</div><div class="tower-bar-track"><div class="tower-fill" style="height:88%"></div></div></div>
  </div>
  <div class="tower-label-row">
    <div class="tower-col-label"><div class="tower-label">TOF</div><div class="tower-sub">$5.565 · 9 ads · 12 pedidos</div></div>
    <div class="tower-col-label"><div class="tower-label">BOF</div><div class="tower-sub" style="color:var(--good);">$5.424 · 4 ads · 13 pedidos</div></div>
  </div>
  <div class="callout warn" style="margin-top:30px;">Con datos etiquetados, el fondo del embudo (BOF, 8,79x) supera con claridad al TOF (5,27x): coherente con un producto de recompra y ticket alto. No hay MOF etiquetado, y el 75% del gasto va sin fase (UGC/carrusel/refresh). Palanca: mantener alimentado el BOF/retargeting de recompra (es el más rentable) y usar el TOF para renovar el ángulo de entrada, que se está fatigando.</div>'''

top3='''<div class="small">Ordenados por inversión, 3–9 ago · base Meta atribuido · barra de acierto: ROAS ≥ 6x (media de cuenta)</div>
  <div class="ad-card-grid">
    <div class="ad-card hit"><div class="ad-status hit">✓ Motor de volumen</div><div class="ad-name">UGC Pao (vivecondiabetes)</div><div class="ad-meta">UGC creadora · vídeo</div><div class="ad-headline"><div class="ad-spend">$6.250</div><div class="ad-roas up">8,36x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">4,55%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$2,09</div></div><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">17</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$368</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">✓ Sobre la media</div><div class="ad-name">Refresh Julio 2 (Copia)</div><div class="ad-meta">MLO · refresh</div><div class="ad-headline"><div class="ad-spend">$5.329</div><div class="ad-roas up">6,78x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">3,56%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$2,66</div></div><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">14</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$381</div></div></div></div>
    <div class="ad-card miss"><div class="ad-status miss">✕ Arrastra la media</div><div class="ad-name">UGC Isabella (Copia 2)</div><div class="ad-meta">UGC creadora · vídeo</div><div class="ad-headline"><div class="ad-spend">$4.192</div><div class="ad-roas down">1,93x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">3,96%</div></div><div><div class="ad-metric-label">CPC</div><div class="ad-metric-value">$2,48</div></div><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">5</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$838</div></div></div></div>
  </div>
  <div class="callout">Los tres de mayor inversión suman $15.771 (35% de la cuenta) y cuentan la historia: la UGC de Pao es el motor (8,36x, 17 pedidos) y el refresh de MLO cumple (6,78x, 14), pero la UGC de Isabella (1,93x) tiene BUEN CTR (3,96%) y MAL cierre: engancha pero no vende, y con $4.192 arrastra la media de la cuenta. Nota: en QiHealth los grandes ganadores por ROAS son de gasto pequeño (carruseles, ver siguiente slide); el gasto grande está en creativos que solo cumplen.</div>'''

mejores='''<div class="small">Ganadores de gasto pequeño con ROAS altísimo, y el gasto grande que rinde por debajo de la media.</div>
  <div style="margin-top:22px; font-size:11px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:var(--good);">🚀 A escalar (ROAS altísimo, gasto pequeño)</div>
  <div class="ad-card-grid" style="margin-top:10px;">
    <div class="ad-card hit"><div class="ad-status hit">🚀 Escalar</div><div class="ad-name">Carrusel 2 (Copias)</div><div class="ad-meta">MLO · carrusel · 2 variantes</div><div class="ad-headline"><div class="ad-spend">$924</div><div class="ad-roas up">44–49x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">8</div></div><div><div class="ad-metric-label">Ingresos</div><div class="ad-metric-value">$42.834</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">🚀 Escalar</div><div class="ad-name">JU03 Recompra (BOFU)</div><div class="ad-meta">MLO · estático · Most Aware</div><div class="ad-headline"><div class="ad-spend">$1.358</div><div class="ad-roas up">20,77x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">4</div></div><div><div class="ad-metric-label">Ingresos</div><div class="ad-metric-value">$28.196</div></div></div></div>
    <div class="ad-card hit"><div class="ad-status hit">🌱 Semilla</div><div class="ad-name">JU10.1 Competencia (Ya usa sensor)</div><div class="ad-meta">MLO · estático · IA</div><div class="ad-headline"><div class="ad-spend">$31</div><div class="ad-roas up">73,5x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">1</div></div><div><div class="ad-metric-label">CTR</div><div class="ad-metric-value">3,10%</div></div></div></div>
  </div>
  <div style="margin-top:22px; font-size:11px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:var(--bad);">⚠ Sangría (gasto grande bajo la media 6,82x)</div>
  <div class="ad-card-grid" style="margin-top:10px;">
    <div class="ad-card miss"><div class="ad-status miss">✕ Mayor sangría</div><div class="ad-name">UGC Isabella (Copia 2)</div><div class="ad-meta">UGC creadora · vídeo</div><div class="ad-headline"><div class="ad-spend">$4.192</div><div class="ad-roas down">1,93x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">5</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$838</div></div></div></div>
    <div class="ad-card miss"><div class="ad-status miss">✕ Bajo la media</div><div class="ad-name">JU03 Recompra [2] (Copia)</div><div class="ad-meta">MLO · estático · BOFU</div><div class="ad-headline"><div class="ad-spend">$3.175</div><div class="ad-roas down">2,84x ROAS</div></div><div class="ad-metrics"><div><div class="ad-metric-label">Pedidos</div><div class="ad-metric-value">5</div></div><div><div class="ad-metric-label">CPA</div><div class="ad-metric-value">$635</div></div></div></div>
  </div>
  <div class="callout good" style="margin-top:18px;">Los CARRUSELES son la palanca nº1: 20,65x de media y variantes a 44–49x con céntimos ($924 → $42.834). Están infra-financiados (6% del gasto). Junto al estático de Recompra (20,77x) y el estático de Competencia (73,5x en semilla), el patrón es claro: estático/carrusel MLO en ángulos calientes = máxima eficiencia.</div>
  <div class="callout bad">La sangría es de gasto grande: la UGC de Isabella ($4.192 a 1,93x) y la copia [2] del estático de Recompra ($3.175 a 2,84x, muy por debajo del [1] a 20,77x → problema de ejecución de la copia, no del ángulo). Cortar/depurar estas dos libera presupuesto para carruseles y Pao.</div>'''

creadores='''<div class="subtitle">Creadores por nombre · ordenados por inversión · ROAS Meta atribuido (media de cuenta 6,82x)</div>
  <div class="table-panel"><table>
    <tr><th>Creador</th><th>Anuncios</th><th>Inversión</th><th>Pedidos</th><th>ROAS</th></tr>
    <tr><td><b>Isabella</b> <span class="pill pill-bad">Peor</span></td><td>3</td><td>$9.304</td><td>16</td><td class="down">4,11x</td></tr>
    <tr><td><b>Pao / Paola</b> (vivecondiabetes) <span class="pill pill-solid">Mejor</span></td><td>3</td><td>$7.267</td><td>22</td><td class="up">8,31x</td></tr>
    <tr><td>Mariana (nutri)</td><td>2</td><td>$547</td><td>2</td><td class="flat">6,27x</td></tr>
    <tr><td>Alexandra Ortega (vídeo)</td><td>1</td><td>$995</td><td>2</td><td class="down">4,59x</td></tr>
    <tr><td>Regina (vídeo)</td><td>1</td><td>$280</td><td>2</td><td class="down">4,44x</td></tr>
  </table></div>
  <div class="callout">El pool de creadores tiene un ganador claro y un lastre claro. <b>Pao/Paola</b> (perfil "vivecondiabetes") es la mejor con diferencia: 8,31x y 22 pedidos, la voz que conecta con el avatar (diabético real). <b>Isabella</b> es la que más gasto lleva ($9.304) y peor rinde (4,11x): engancha por CTR pero no cierra. Los vídeos de creadoras (Alexandra, Regina) van por debajo de la media. Dirección: dar más presupuesto y guiones a Pao/Paola, recortar Isabella, y probar más creadoras del perfil "paciente real" antes que actrices genéricas.</div>'''

lectura='''<div class="quote-mark">&ldquo;</div>
  <div class="quote-text">QiHealth es una cuenta sana (<span class="hl2">6,82x</span>) que esta semana <span class="hl2">escaló contra fatiga</span>: +21% de gasto, pero ingresos ‒8%, ROAS ‒24% y frecuencia 4,11. El dinero está mal repartido: los <span class="hl2">carruseles (20,65x) y el creativo MLO (7,84x)</span> están infra-financiados, mientras la UGC de Isabella (1,93x) se lleva $9.304.</div>
  <div class="quote-attr"><div class="avatar-circle">CE</div><div><div class="quote-attr-name">Lectura del Estratega Creativo</div><div class="quote-attr-role">3–9 ago, 2026 · la palanca de la semana</div></div></div>
  <div class="callout warn" style="margin-top:28px;"><b>Base: Meta atribuido.</b> Sin Triple Whale (el % de clientes nuevos va por Shopify, slide 03 pendiente). ATC infra-trackeado: leer Landing → Checkout → Compra. Ticket alto ($2.895) y producto de recompra: el BOFU manda.</div>
  <div style="margin-top:22px;"><ol class="num-list">
    <li><b style="color:var(--accent);">Frenar el escalado y renovar audiencia.</b> El +21% de gasto compró frecuencia 4,11, no ventas. Bajar/ampliar públicos para que la frecuencia vuelva hacia ~3 antes de volver a empujar.</li>
    <li><b style="color:var(--accent);">Financiar los carruseles.</b> 20,65x de media (variantes a 44–49x) con solo el 6% del gasto: es la palanca de eficiencia nº1. Subir presupuesto y producir más carruseles.</li>
    <li><b style="color:var(--accent);">Reasignar el UGC: menos Isabella, más Pao/Paola.</b> Isabella $9.304 a 4,11x (engancha, no cierra) vs Pao/Paola 8,31x/22 pedidos. Mover gasto hacia la voz "paciente real".</li>
    <li><b style="color:var(--accent);">Proteger el BOFU / Recompra.</b> 8,79x, el motor con ticket alto. Mantener alimentado el retargeting de recompra; arreglar la copia [2] del estático (2,84x vs 20,77x del [1]).</li>
    <li><b style="color:var(--accent);">Renovar el ángulo "Se Pincha".</b> Es el ángulo de entrada con más anuncios pero peor ROAS (3,70x): está fatigado. Testear nuevos ángulos TOFU (usar los ganadores de "Competencia / Ya usa sensor", 7,55x).</li>
  </ol></div>'''

producto=prod.single("QiHealth · Sensor de Glucosa","$44.601","6,82x","105","~90",
  '''<div class="callout">QiHealth es una cuenta de UN solo producto (el sensor de glucosa / monitoreo continuo), así que el 100% de la inversión va a este producto a 6,82x (muy rentable, ticket alto $2.895). No hay mix de producto que optimizar: las palancas son el ÁNGULO de mensaje (slide siguiente), el formato (carruseles) y el embudo. Esta slide es la cabecera del producto; el corte por ángulo va en la slide de Ángulo.</div>''',"es")
inner=dict(kpis=kpis,crecimiento=crecimiento,embudo=embudo,producto=producto,angulo=angulo,owner=owner,conocimiento=conocimiento,fase_embudo=fase,top3=top3,mejores=mejores,creadores=creadores)
canon.build("QIHEALTH","QiHealth · Informe Semanal de Estrategia Creativa · 3–9 ago 2026",
  "QiHealth: qué funcionó, qué no, y dónde mover el presupuesto.",
  canon.metarow("Meta Ads (atribuido pixel) · sensor de glucosa","MXN ($)"),
  inner,lectura,"/Users/mlo/framer/qihealth-creative-report/reports/qihealth-creative-report-2026-08-03.html")
