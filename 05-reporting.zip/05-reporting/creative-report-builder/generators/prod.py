# Slide PRODUCTO para marcas de UN SOLO producto (producto real, NO ángulo)
def single(name, spend, roas, orders, ads, note, lang="es"):
    L={"es":("Producto único · inversión, ROAS y pedidos del producto (el corte por ángulo está en la slide siguiente)","Producto único","100% de la inversión","ROAS","Pedidos","Anuncios"),
       "en":("Single product · spend, ROAS and orders (the angle cut is on the next slide)","Single product","100% of spend","ROAS","Orders","Ads")}[lang]
    return f'''<div class="small" style="margin-bottom:4px;">{L[0]}</div>
  <div class="product-grid">
    <div class="product-card highlight" style="grid-column: span 2;">
      <div class="product-title-row"><div class="product-title"><span class="product-num">01</span><span class="product-name">{name}</span></div><div class="pill pill-solid">{L[1]}</div></div>
      <div class="product-spend">{spend}</div>
      <div class="product-share">{L[2]}</div>
      <div class="bar-track"><div class="bar-fill" style="width:100%"></div></div>
      <div class="product-stats">
        <div><div class="stat-label">{L[3]}</div><div class="stat-value">{roas}</div></div>
        <div><div class="stat-label">{L[4]}</div><div class="stat-value">{orders}</div></div>
        <div><div class="stat-label">{L[5]}</div><div class="stat-value">{ads}</div></div>
      </div>
    </div>
  </div>
  {note}'''
