def _int(n,lang):
    s=f"{int(round(n)):,}"
    return s.replace(",",".") if lang=="es" else s
def _pct(x,lang):
    s=f"{x:.1f}"
    return (s.replace(".",",") if lang=="es" else s)+"%"
def _pts(d,lang):
    a="▲" if d>=0 else "▼"; s=f"{abs(d):.1f}"
    return a,(s.replace(".",",") if lang=="es" else s)
def _money(v,cur,lang):
    if v>=1000:
        s=f"{int(round(v)):,}"; s=s.replace(",",".") if lang=="es" else s
    else:
        s=f"{v:.1f}"; s=s.replace(".",",") if lang=="es" else s
    return f"{cur}{s}"
def block(lang, cur_pct, new_o, tot_o, prev_wk_pct, prev_mo_pct, callout,
          ncpa=None, prev_ncpa=None, cur="$", source="Triple Whale (toda la tienda)"):
    wow=cur_pct-prev_wk_pct; mom=cur_pct-prev_mo_pct
    a1,p1=_pts(wow,lang); a2,p2=_pts(mom,lang)
    cl1="up" if wow>=0 else "down"; cl2="up" if mom>=0 else "down"
    if lang=="es":
        sub=f"Porcentaje de pedidos de clientes nuevos + coste de adquirir cada uno (NCPA): la señal principal de crecimiento neto de la cuenta. Fuente: {source}."
        l1,d1="% Clientes Nuevos (Actual)",f"{_int(new_o,lang)} de {_int(tot_o,lang)} pedidos totales"
        l2,d2="vs. Semana Anterior",f"{_pct(prev_wk_pct,lang)} la semana pasada"
        l3,d3="vs. Mismo Periodo Mes Anterior",f"{_pct(prev_mo_pct,lang)} en el mismo periodo del mes pasado"
        l4="NCPA · Coste por Cliente Nuevo"; pts="pts"
    else:
        sub=f"Share of orders from new customers + the cost to acquire each one (NCPA): the account's headline net-growth signal. Source: {source}."
        l1,d1="New Customers (Current)",f"{_int(new_o,lang)} of {_int(tot_o,lang)} total orders"
        l2,d2="vs. Last Week",f"{_pct(prev_wk_pct,lang)} last week"
        l3,d3="vs. Same Period Last Month",f"{_pct(prev_mo_pct,lang)} same period last month"
        l4="NCPA · Cost per New Customer"; pts="pts"
    cols="repeat(4, 1fr)" if ncpa is not None else "repeat(3, 1fr)"
    ncpa_card=""
    if ncpa is not None:
        if prev_ncpa:
            dpct=(ncpa-prev_ncpa)/prev_ncpa*100
            arr="▲" if dpct>=0 else "▼"; ncl="down" if dpct>=0 else "up"  # subir NCPA = peor (rojo)
            dtxt=(f"{arr} {abs(dpct):.0f}% vs {_money(prev_ncpa,cur,lang)}").replace(".",",") if lang=="es" else f"{arr} {abs(dpct):.0f}% vs {_money(prev_ncpa,cur,lang)}"
        else:
            ncl="flat"; dtxt=("por cliente nuevo" if lang=="es" else "per new customer")
        ncpa_card=f'''\n    <div class="kpi-card"><div class="kpi-label">{l4}</div><div class="kpi-value">{_money(ncpa,cur,lang)}</div><div class="kpi-delta {ncl}">{dtxt}</div></div>'''
    return f'''<div class="subtitle">{sub}</div>
  <div class="kpi-grid" style="grid-template-columns: {cols}; margin-top:24px;">
    <div class="kpi-card hero"><div class="kpi-label">{l1}</div><div class="kpi-value gradient-num">{_pct(cur_pct,lang)}</div><div class="kpi-delta flat">{d1}</div></div>
    <div class="kpi-card"><div class="kpi-label">{l2}</div><div class="kpi-value">{a1} {p1} {pts}</div><div class="kpi-delta {cl1}">{d2}</div></div>
    <div class="kpi-card"><div class="kpi-label">{l3}</div><div class="kpi-value">{a2} {p2} {pts}</div><div class="kpi-delta {cl2}">{d3}</div></div>{ncpa_card}
  </div>
  {callout}'''
