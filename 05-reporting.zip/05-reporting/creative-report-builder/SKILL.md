---
name: creative-report-builder
description: Builds a polished, dark-themed "Weekly Creative Strategy Report" slide deck (self-contained HTML, one slide per section) for any paid-media brand, in English or Spanish (Spain). Runs an interactive setup first (or loads the brand's saved profile if one exists), confirming the data source, the spend/ROAS "hit rule," which optional sections apply, and one-time vs recurring, then pulls real numbers and fills the template rather than leaving placeholders. Renders and visually verifies the deck before delivering, never ships unfilled brackets. ALWAYS use this skill (ES/EN) when the user says "build/generate/update the weekly creative report", "creative strategy report", "spend/ROAS/hit-rate report for [brand]", "adapt this report for a new brand", "recurring weekly/monthly paid-media report", or, in Spanish, "hazme el reporte creativo semanal de [marca]", "monta el informe de estrategia creativa de [marca]", "reporte de spend/ROAS/tasa de aciertos de [marca]", "informe semanal de paid de [marca]", "adapta este reporte a [marca nueva]", "deja programado el reporte creativo de [marca]". Trigger on partial or casual asks about a slide deck comparing spend and ROAS by product/owner/creator/landing-page/awareness/funnel/audience, or setting up a recurring creative-performance reporting cadence, even if the skill is not named.
---

# Creative Report Builder

Generates the "Weekly Creative Strategy Report" deck, the same dark, glow-orb, pill-and-callout design system already proven on a real recurring paid-media report, generalized so it works for any brand's numbers. The output is one self-contained HTML file: a full-bleed slide per section, meant to be presented, not scrolled through like a spreadsheet.

**The core difference from just handing someone the template:** don't silently fill brackets with guesses or leave them for the user to figure out later. Confirm the setup below first (or load the brand's saved profile), pull real numbers, fill the deck, then render it and check it with your own eyes before delivering. A deck built on unconfirmed assumptions (wrong hit-rule bar, wrong data source) is worse than no deck: it looks authoritative and isn't. A deck that ships with a visible `[placeholder]` or a broken layout is worse still.

## THE CANONICAL STRUCTURE IS FIXED (read this first, it is non-negotiable)

Every report, for every brand, has the SAME 13 sections in the SAME order. This is the whole point of the system: the client and the team see one consistent deck, brand after brand. You do **NOT** get to drop, swap, reorder, rename, or "adapt" sections because a brand's data looks thin or because another cut feels more interesting. That is exactly the failure this system exists to prevent.

The 13 canonical sections (the "Bala di Gala structure"), in order:

1. **Portada** (cover)
2. **Resumen — KPIs Generales** (8-card grid)
3. **Crecimiento — % de Clientes Nuevos** (New Customer %). ⚠️ **This is the single most important per-brand slide and was historically the one most often dropped — it is NON-NEGOTIABLE and ALWAYS present as slide 03, right after KPIs.** FOUR cards: current % (hero, with "[new] de [total] pedidos totales"), vs. last week (± pts), vs. same period last month (± pts), and **NCPA · Coste por Cliente Nuevo** (always included — = ad spend / new customers, with its WoW delta; rising NCPA = red). Then a callout explaining whether the move is mix vs. volume vs. real acquisition change. **Data source, in order (use the RELIABLE one — the attributed Triple Whale table under-counts and inflates new% for retention-heavy brands, so do NOT trust it):** ① Triple Whale MCP `run-sql` on `orders_table` (`SUM(is_new_customer)/uniq(order_id)`) when the shop is on an MCP plan; ② otherwise **Shopify** — the `new_vs_returning_customer_sales` report via ShopifyQL URL (`FROM sales SHOW orders WHERE new_or_returning_customer IS NOT NULL GROUP BY new_or_returning_customer SINCE ... UNTIL ...`), read New/Returning/Total. This is a WHOLE-STORE metric (all channels), not Meta-attributed — say so on the slide.
4. **Embudo — Embudo de Conversión: Dónde se Cae el Tráfico** (the CRO / conversion funnel: Clics → Landing → Carrito → Checkout → Compra + coste por etapa). Source order of preference: internal-software / Shopify funnel if the user provides it → otherwise Meta pixel funnel events (`omni_landing_page_view`, `omni_add_to_cart`, `omni_initiated_checkout`, `omni_purchase`). This slide is ALWAYS present.
5. **Producto — Inversión y Tasa de Aciertos por Producto.** ⚠️ **PRODUCTO = producto REAL / SKU, NUNCA el ángulo.** Para marcas de un solo producto, esta slide muestra ESE producto (con sus KPIs + variantes/formatos si aplica) y una nota, pero NO se rellena con ángulos.
6. **Ángulo — Inversión y Rendimiento por Ángulo.** ⚠️ **Slide SEPARADA de Producto, siempre.** El corte por ángulo de mensaje (p.ej. Stress/Cortisol, Sleep, HRV, Fatiga Mental, Se-Pincha, Villano-Aguja) vive AQUÍ, nunca en Producto. No confundir jamás producto con ángulo.
7. **Owner — Rendimiento por Responsable**
8. **Fase de Conocimiento — Dónde Vive la Inversión por Fase de Conocimiento** (awareness)
9. **Fase del Embudo — Rendimiento por Fase del Embudo** (TOF / MOF / BOF)
10. **Mejores Anuncios — Los 3 Anuncios de Mayor Inversión**
11. **Mejores y Peores — Mejores y Peores Anuncios de la Semana**
12. **Creadores — Mejores Creadores**
13. **Lectura del Estratega Creativo**

**Producto vs Ángulo (regla dura):** son DOS dimensiones distintas y DOS slides distintas, siempre. Producto = qué SKU/artículo se vende. Ángulo = con qué mensaje/gancho se vende. Nunca metas ángulos en la slide de Producto ni al revés, aunque la marca tenga un solo producto.

**NCPA en Crecimiento (regla dura):** la slide 03 SIEMPRE incluye el NCPA (coste por cliente nuevo = gasto publicitario / clientes nuevos) además del % de clientes nuevos, con su comparación semanal.

**Generadores empaquetados:** `generators/canon.py` (ES), `generators/canon_en.py` (EN) y `generators/growth.py` (helper de la slide 03 con NCPA) producen la estructura canónica de 13 secciones automáticamente y renumeran los footers solos. `generators/BRAND_DATA.md` guarda los datos de clientes nuevos + NCPA ya sacados por marca.

**BRANDING = SKIN M.L.O SIEMPRE — IMPEPINABLE (gate bloqueante).** ⚠️ Ese branding (el de M.L.O Growth, el del deck de 8HOURS) o NINGUNO. Sí o sí. NO existe una versión con branding genérico: si el HTML final NO contiene `#4ADE80` **y** `class="logo-img"`, **NO se entrega** — se reconstruye con los generadores (que ya inyectan el skin M.L.O byte-idéntico al de 8HOURS). El deck se entrega SIEMPRE con el branding de M.L.O Growth, NUNCA con el verde neutro genérico de ejemplo. El skin oficial está EMPAQUETADO y es portable en `generators/mlo_head.html` (`<style>` + fuentes) y `generators/mlo_logo.html` (logo M.L.O en base64) — los generadores lo inyectan solos, no dependen de ninguna ruta local. Colores: `--bg:#070a07`, `--accent:#4ADE80`, `--text:#F0F4F0`, `--text-dim:#8A9E8A`, `--bad:#F87171`, `--warn:#FBBF24`. Fuentes: DM Sans (body) + Playfair Display itálica (palabra acento verde) + JetBrains Mono. Logo M.L.O incrustado. **Verificación antes de entregar:** el HTML DEBE contener `#4ADE80` y `class="logo-img"` (logo M.L.O). Si sale con `#478358` u otro verde, o con `logo-mark`/`logo-word`, es el skin genérico MAL: reconstruir con los generadores (que ya traen el skin MLO). Las plantillas `assets/template-*.html` también llevan ya el skin MLO. Ejemplo de diseño de referencia = `assets/EJEMPLO-DISENO-8hours.html` (el deck de 8HOURS).

Rules, absolute:
- **Never remove a canonical section.** If a brand doesn't tag a dimension (no owner tag, no awareness tag, single product, no creators), the section STILL appears. Populate it with the closest real data you have and add an honest `.callout.warn` or `.small` note saying what's missing or untagged (e.g. "sin owner etiquetado", "producto único", "el 57% del gasto va sin etiqueta de awareness"). A section with a caveat is correct; a missing section is a system violation.
- **Never reorder, rename, or swap sections.** Not "Formato instead of Owner", not "Ángulo dentro de Producto". Same eyebrows, same titles, same footer numbering (02…13), every time.
- **New Customer % (slide 03) is never optional.** If a brand has neither Triple Whale nor accessible Shopify, keep the slide and state honestly that the number is pending a source, but never silently omit it. It is the most-dropped and most-important slide — treat leaving it out as a system violation on par with dropping the funnel.
- **Only ADD sections when the user explicitly asks for one** (a brand-specific extra, e.g. Fajitex's "Online Store vs Draft Orders"). Added sections go where the user says and are recorded in the brand PROFILE; they never replace a canonical section.
- **The only thing that changes per run is the reporting window** (last week / last month / last 15 days, as the user specifies) and the brand's data. The skeleton is invariant.

If you ever feel the urge to drop or restructure, stop: fill the canonical section with a caveat instead.

## Step 0: Look for a saved brand profile first

Before asking anything, check whether this brand already has a profile (see `references/brand-profile.md`). A profile is a small `PROFILE.md` capturing everything confirmed in a prior run: data source and exactly how each section is pulled, the hit-rule threshold, per-ad vs per-concept scoring, tagging conventions, currency/formatting, and which optional sections apply and why.

- **Profile exists:** load it. Don't re-ask what it already answers. Confirm only what genuinely changes run to run (the reporting window, and anything the user says has changed), then jump to Step 2 to pull the metrics.
- **No profile:** run the full Step 1 setup below. At the end of the run, offer to save a profile so the next run skips the interview, this applies to one-time runs too, not just recurring ones. The profile is the "genérico + ficha por marca" model: the skill stays brand-agnostic, the brand's specifics live in its profile.

## Step 1: Interactive setup

Ask these as an actual conversation, not a form dump, use `AskUserQuestion` for anything with a real decision behind it. Skip any question the user already answered in their initial request or that a loaded profile already covers, don't re-ask what you already know. A few of these (marked below) can't be fully answered until you've seen real data in Step 2, ask what you can now and note explicitly what's still pending.

**1. Brand basics**
- Brand name
- Language for the deck: English or Spanish (Spain), this selects which template to start from (`assets/template-en.html` or `assets/template-es.html`)
- Reporting window (e.g. "last Monday–Sunday," "the calendar month of July")
- Who it's for (a team, a founder, a client)
- One ad account or multiple? Multiple keeps the Ad Accounts slide; one deletes it entirely, don't leave it half-filled with a single card.
- Currency and attribution model/window (e.g. "USD, Pixel-based first-click 1-day" or "EUR, GA4 data-driven"). Both templates default every placeholder to `$` and reference an attribution basis on nearly every slide subtitle, get the real values now rather than discovering mid-build that every card needs a symbol swap.

**2. Tagging conventions**
Ask the brand's team (don't infer this from ad names yourself) how they currently tag: who owns/edits each piece of creative, awareness stage, funnel stage (TOF/MOF/BOF), audience segment, and, if the Best Creators section applies, creator credit separate from owner/editor credit. If a convention exists (a naming prefix, a keyword, a platform-native tag field), get 5-10 real examples to confirm the pattern before writing any extraction logic in Step 2. If no convention exists for a given dimension, say so now, that section gets dropped in Step 3 rather than force-built from a guessed pattern.

**3. Data source**
Ask what they're pulling from.
- **Triple Whale:** read `references/triple-whale-workflow.md` before writing any queries. It has the exact MCP call sequence, the ClickHouse gotcha that trips up every hit-rate/ROAS query, and how to map each slide to likely tables.
- **Anything else** (a native ad-platform dashboard like Meta or Google Ads, a native platform paired with a separate creative-tagging tool, GA4, a data warehouse, a manual export): read `references/generic-data-source-workflow.md` before pulling anything. It walks through the decisions that actually matter here, whether a reliable new-customer signal exists at all, whether the attribution models across sources even agree, whether ad-level joins are possible, where qualitative tags would live, and the "native platform + creative tool" split (spend/ROAS from the ad platform, hit/miss and creative tags from the tagging tool). Don't treat this as a lesser version of the Triple Whale path, it's a genuinely different set of constraints and needs its own methodology decisions made explicit before you pull a single number.

**4. The hit-rule threshold**
Don't leave this as a placeholder. Ask directly: "What spend and ROAS (or new-customer ROAS) makes an ad a real win for you, not just breaking even?" Offer a sensible starting point to react to, spend ≥ $200 and NC ROAS ≥ 1.1 is a reasonable default many accounts land near, but let them override both numbers, and swap in the currency confirmed in Step 1.1. This bar gets reused across the Product, Owner, Landing Page, and Top Performers slides, pick it once here and apply it everywhere, don't let it drift slide to slide.

Also ask whether performance should be scored per individual ad or rolled up per creative concept (multiple landing-page/format variants of the same idea, counted together). If you don't yet know whether this brand's ad names actually contain that kind of variant structure, say so and flag it as pending, confirm it once real ad names are visible in Step 2, then circle back before Step 3, don't guess either way. This matters: an ad that looks like a hit alone can average out to a miss once its sibling variants are folded in.

**5. Brand-specific ADDED sections (the 11 canonical ones are never in question)**
The 11 canonical sections are always present, full stop (see "THE CANONICAL STRUCTURE IS FIXED" above). The only thing to confirm here is whether the user wants any **extra, brand-specific** section added on top (e.g. Fajitex's "Online Store vs Draft Orders" channel split). Do not ask "which sections apply" or "which to drop", that framing is banned. Where a canonical dimension is untagged for this brand, you keep the slide and note the gap; you never drop it. Record any user-approved added section in the brand PROFILE so it recurs.

**6. One-time or recurring**
If recurring, read `references/recurring-setup.md` before doing anything else for this item, it has the concrete directory structure, the `state.md` schema (including why New Customer %, if included, needs a full month of retained history), and how the brand profile and scheduled task fit together. Ask the user whether to actually wire up the scheduled task now (via the `schedule` skill or `CronCreate`/`create_scheduled_task` tooling) or just hand back the deck for them to set up later. Note: a **one-time** run can still save a brand profile (Step 0), a profile is not the same thing as a schedule.

## Step 2: Pull the real metrics

Once the source and tagging conventions are confirmed, pull every number the chosen template needs: topline KPIs, the New Customer % with its two comparison periods (if included), spend/ROAS by product, by owner, by landing page, by awareness stage, by funnel stage, by audience, by creator (if included), plus the top/bottom ad lists and the new-launch classification. Cross-reference `references/design-system-en.md` or `references/design-system-es.md` for exactly what each section expects, don't reinvent the section list from memory.

If Step 1.4 was left pending (whether to score per-ad or per-concept), resolve it now against real ad names before computing anything that depends on it, then go back and confirm the choice with the user before moving to Step 3.

If a number genuinely isn't available (the brand doesn't track funnel-stage tags, say), don't fabricate it. Drop that slide and say so, the design system doc's "What NOT to do" section covers this.

## Step 3: Fill the template

1. Copy the chosen template file (`assets/template-en.html` or `assets/template-es.html`) as the starting point, or, if this is a recurring brand with at least one prior run, copy the most recent file from that brand's `reports/` folder instead (see `references/recurring-setup.md`), never regenerate the CSS or layout from scratch, that consistency is the entire point of having a template.
2. **If porting New Customer % / Best Creators into an English deck (Step 1.5):** this is the one sanctioned exception to never touching the `<style>` block. Copy these two CSS rules verbatim from `assets/template-es.html` into the English file's `<style>` block, they don't exist there by default:
   ```css
   .kpi-card.hero { border-color: rgba(71,131,88,0.4); background: linear-gradient(135deg, rgba(71,131,88,0.14), rgba(71,131,88,0.03)); }
   .kpi-value.gradient-num { background: linear-gradient(120deg, #8FBF9E 0%, var(--accent) 60%, #2E5940 100%); -webkit-background-clip: text; background-clip: text; color: transparent; }
   ```
   Then copy the two sections' markup from `template-es.html` (the "% de Clientes Nuevos" section right after Overview KPIs, and the "Mejores Creadores" section right before the closing Strategist Read slide) and translate the copy to English. Renumber every section's footer tag and eyebrow number to match the new 15-slide order, and give both new `<section>` elements their own `.glow-orb` position, don't reuse a position already used elsewhere in the deck. This is a multi-step structural edit, not a placeholder fill, budget real attention to it rather than treating it as incidental.
3. Replace every bracketed placeholder with the real, sourced value, including swapping the default `$` for the brand's actual currency confirmed in Step 1.1.
4. **Never delete a canonical slide.** All 11 sections are always present in the fixed order (see "THE CANONICAL STRUCTURE IS FIXED"). If a dimension is untagged or single-valued for this brand, keep the section, fill it with the closest real data, and add an honest caveat (`.callout.warn` or `.small`); do not leave literal `[placeholders]`, but do keep the slide.
5. Recompute every pill and badge fresh against this run's actual numbers, "Top Spend," "Best Performer," "Dominant," never carried over from a template example or a prior week.
6. Write every `.callout` last, after all the numbers are in. A callout says what a strategist would say out loud in the room, not a description of how the number was computed, methodology notes belong in a small `.small` subtitle or a `.callout.warn`, never as the main point.
7. Follow the writing rules in the design-system reference exactly: no em dashes anywhere, lead with the number not the setup, any callout naming three or more examples gets bulleted, never color-code the same value twice.
8. Read the deck top to bottom once you're done and confirm it tells one story, the Overview slide sets the headline number, each middle slide adds a layer, and the closing Strategist Read slide ties back to 4-6 concrete actions that reference numbers already shown earlier in the deck.

## Step 4: Render and verify (do not skip)

Reading the source is not the same as seeing the output. Before delivering, render the file and confirm it with your own eyes, this is the step that catches the failures a source read misses.

1. Open the finished HTML in the browser preview (`preview_start` with the file's `url`, or navigate to it).
2. **Placeholder sweep:** confirm zero literal `[` brackets survive anywhere. `grep -c '\[' <file>` should return 0 for the bracket-placeholder pattern (allow for legitimate content), and a visual scan should show no `[XX,XXX]`, `[X.XX]x`, `[Brand Name]`, `[Owner]`, etc. still on screen.
3. **Currency + formatting:** every money value uses the brand's confirmed symbol and decimal convention (Spain: `.` thousands, `,` decimals), no stray default `$` if the brand is in `€` or another currency.
4. **Layout integrity:** no card, table, or tower bar overflows or collapses; every slide that should exist exists and every dropped slide is actually gone; footer tags are renumbered consecutively with no gaps or duplicates.
5. **Pills earned:** each `pill-solid` / `pill-hit` / `pill-bad` sits on the row or card that genuinely holds the best/worst number in its group, and the Uncategorized/Untagged bucket carries no pill.
6. Take a screenshot for the delivery message. If anything is off, fix the source and re-render, don't hand over a deck you haven't seen rendered clean.

## Step 5: Deliver

Save the final self-contained HTML file as `<brand-slug>-creative-report-<window-start-date>.html` (e.g. `lumina-creative-report-2026-08-04.html`, using the Monday of the reported week or the first day of the reported month). For a one-time run, save it wherever the user is working, or ask if unclear. For a recurring run, save it into that brand's `reports/` folder per `references/recurring-setup.md`, and also write/update the brand profile and `state.md` there, then either set up the scheduled task or hand off clear instructions for doing so.

If a profile doesn't exist yet, offer to save one now (`references/brand-profile.md`) so the next run skips the interview, do this even for a one-time deck.

Tell the user what you dropped (sections removed, data gaps, any currency/attribution caveats worth surfacing) as plainly as you'd report a real finding, don't bury it. Attach the rendered screenshot and offer to open or send the file rather than only stating the path.
