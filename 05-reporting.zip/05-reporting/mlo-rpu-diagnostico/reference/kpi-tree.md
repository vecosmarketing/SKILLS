# KPI Tree — Referencia profunda (RPU Diagnóstico)

Base: **Accelerated Advisory** (agencia CRO/direct-response detrás de AG1, Huel, Hormozi, The Oodie, Kinobody +200 marcas 8-9 cifras), módulos 01 (1.3 KPIs/RPU), 04 (4.7) y 18 (eCom_Variables). Adaptado a la realidad MLO. La tesis del curso: **RPU es la métrica reina — el CPC tiene suelo, el RPU tiene techo mucho más alto** → el apalancamiento vive en la web.

---

## 1. El árbol, nivel a nivel

```
                              ROAS  (número compuesto → ENGAÑA por sí solo)
                 ┌──────────────────────┴──────────────────────┐
          AD PERFORMANCE  (pre-click)              WEBSITE PERFORMANCE  (post-click)
          "¿cuánto cuesta traer 1 clic?"           "¿cuánto ingresa cada clic que llega?"
                 │                                          │
          CPM ── CTR ── CPC                          CVR ── AOV ── RPU
                 │                                          │
                 └──────────── Front-end ROAS = RPU ÷ CPC ──┘
```

| Nivel | Qué es | Fórmula | Fuente | Palanca / tope |
|---|---|---|---|---|
| **CPM** | coste por 1.000 impresiones | dato | Meta / Atria | subasta, competencia, creativo |
| **CTR** | % de impresiones que hacen clic | dato | Meta / Atria | **creativo** (hook, thumbstop) |
| **CPC** | coste por clic a la web | `CPM ÷ 1000 ÷ CTR` | Meta / calc. | **tiene SUELO** → palanca menor |
| **CVR** | % de sesiones que compran | dato | Shopify / TW | **web/LP/PDP + oferta** |
| **AOV** | ticket medio del pedido | dato | Shopify / TW | bundles, upsell, umbral envío gratis |
| **RPU** | ingreso por cada usuario/clic | `CVR × AOV` | calc. | **techo alto → PALANCA REINA** |
| **Front-end ROAS** | ROAS del 1er pedido, reconstruido | `RPU ÷ CPC` | calc. | debe cuadrar con Meta/TW |
| **Margen (CM%)** | margen de contribución tras COGS | dato | Shopify / Brand Brain | pricing, COGS, mix |
| **CPA** | coste de adquirir 1 pedido | gasto ÷ pedidos | Meta / TW | baja con CTR↑ y CVR↑ |
| **Front-End Profit** | beneficio en la 1ª compra | `AOV × margen − CPA` | calc. | ¿escalas con caja propia? |
| **CLV 90d** | ingreso acumulado por cliente a 90 días | dato | TW / Shopify | back-end, recompra, email |
| **90D Profit** | beneficio real a 90 días | `CLV_90d × margen − CPA` | calc. | el que decide el techo de CPA |

> **RPU ≈ RPV** (Revenue Per Visitor) del vocabulario de `mlo-ecom-financials-2026`. En el curso 18 se escribe como **RPU = AOV × CVR = la métrica conectora site→revenue**.

---

## 2. Escenario canónico (Single Case)

El caso base del KPI Sheet. Memorízalo como patrón; sustituye por los números reales de la marca.

| Input (amarillo en el Sheet) | Valor | Cálculo | Resultado |
|---|---|---|---|
| CPM | **$30** | — | — |
| CTR | **2%** | 30 ÷ 1000 ÷ 0,02 | **CPC = $1,50** |
| CVR | **5%** | — | — |
| AOV | **$60** | 0,05 × 60 | **RPU = $3,00** |
| — | — | 3,00 ÷ 1,50 | **Front-end ROAS = 2,0x** |
| Margen COGS | **80%** | 60 × 0,80 − 30 | **Front-End Profit = $18** |
| CPA | **$30** | (incluido arriba) | — |
| CLV 90d | **$150** | 150 × 0,80 − 30 | **90D Profit = $90** |

Lectura: ROAS 2,0x con **$18 de beneficio en la primera compra** y **$90 a 90 días**. Aunque el front-end estuviera en break-even (profit ≈ 0), el negocio seguiría siendo sano por los $90 del back-end. **Ese es el punto donde el ROAS a secas miente.**

---

## 3. La lección del apalancamiento (por qué RPU manda)

Misma inversión en ads (**CPC intacto en $1,50**), tocando SÓLO la web:

| Palanca | Antes | Después | RPU | Front-end ROAS |
|---|---|---|---|---|
| Base | CVR 5% · AOV $60 | — | $3,00 | 2,00x |
| Sube CVR | 5% → **6,5%** | AOV $60 | $3,90 | 2,60x |
| Sube AOV | CVR 5% | $60 → **$80** | $4,00 | 2,67x |
| **Ambas (web)** | 5%→6,5% | $60→**$80** | **$5,20** | **3,47x** |

Comparación con la palanca ad-side (bajar CPC, que tiene suelo): bajar CPC de $1,50 a $1,20 (−20%, difícil, la subasta te frena) sólo lleva el ROAS a 2,50x — menos que tocar CVR **o** AOV por separado, y muy por debajo del 3,47x de tocar la web. **Conclusión operativa: el foco es Website Performance / RPU.**

---

## 4. eCom Variables — Birds Eye Monthly (segunda pestaña del KPI Sheet)

Vista mensual de negocio que sube desde el árbol de una sesión al P&L del mes. Todo se deriva del árbol × volumen:

| Variable | Fórmula | Nota |
|---|---|---|
| Ad Spend | dato | del mes |
| Impresiones | Ad Spend ÷ CPM × 1000 | |
| Clics | Impresiones × CTR | = tráfico pagado |
| Pedidos | Clics × CVR | |
| Revenue | Pedidos × AOV  (= Clics × RPU) | **RPU × Clics = Revenue: la métrica conectora** |
| ROAS | Revenue ÷ Ad Spend | = RPU ÷ CPC |
| CPA | Ad Spend ÷ Pedidos | |
| Contribution (front) | Revenue × margen − Ad Spend | beneficio de contribución del mes (front) |
| Revenue 90d | Pedidos × CLV_90d | back-end proyectado |
| Profit 90d | Revenue 90d × margen − Ad Spend | |

Uso: rellena el árbol de una sesión, multiplica por el volumen del mes y tienes el birds-eye. Sirve para simular "si subo RPU un X%, cuánto beneficio de mes gano con el mismo spend".

---

## 5. "Clona el KPI Sheet"

El artefacto original es un **spreadsheet de 2 pestañas** — **Single Case** (§2) y **Birds Eye Monthly** (§4) — con los **inputs en amarillo** autocalculados (CPM, CTR, CVR, AOV, margen, CPA, CLV). Para estandarizarlo en MLO:

- **Clona una copia por marca** en el onboarding (calculadora RPU/unit-economics estándar) y guárdala junto al reporting de la marca.
- Inputs amarillos = sólo esos se tocan; el resto se autocalcula con las fórmulas de §1.
- Convención MLO al escribir en Sheets: coma decimal en ES, moneda **nativa** de la marca (MXN Bala di Gala, COP V-UP/i-Energy, GBP Bridge/MUTO, EUR resto ES, USD si aplica). Ver `reference_sheets_editing` y `reference_control_semanal` para la mecánica de escritura.
- Es el **módulo 1** de la academia MLO / onboarding de cliente (el árbol KPI + KPI Sheet), reutilizable como formación.

---

## 6. Checklist de veredicto ads-vs-web

Compara cada mitad **contra el benchmark propio de la marca** (no la industria). Diagnóstico:

**Cuello en AD PERFORMANCE** (pre-click) si:
- CTR por debajo de su histórico / CPM disparado → **creativo** (hook, thumbstop, fatiga). → `hooks-expert`, `static-ads-expert`, `framework-scriptwriter`, `mlo-estratega-creativo`.
- CPC alto con CTR sano → **segmentación / subasta / puja**. → `mlo-media-buying-2026`.

**Cuello en WEBSITE PERFORMANCE** (post-click) si:
- CVR bajo → **landing/PDP, congruencia anuncio→página, fricción**. → `mlo-cro-2026` (testing), `mlo-page-cooker` (construir la página). El intake de behaviour-data (heatmaps ≥2.000 pv, rank relativo, scroll reach, surveys) diagnostica el porqué del CVR bajo (módulo 04 del curso).
- AOV bajo → **oferta, bundles, upsell, umbral de envío gratis**. → `mlo-offer-simulator`.

**Ambas mitades sanas pero no hay beneficio** → no es un problema del árbol front-end: revisa **margen (COGS)** y **back-end (CLV/recompra)**. → `mlo-ecom-financials-2026` (unit economics, break-even ROAS, LTGP:CAC, caja).

**El front-end ROAS reconstruido no cuadra con Meta/TW** → atribución o ventana de conversión, no matemática. Replica filtros+orden de la vista y verifica lo que RENDERIZA (`feedback_double_check_always`); usa clientes NUEVOS de TW donde toque (`feedback_ncpa_hitrate_methodology`).

---

## 7. Definition of Done

Un diagnóstico RPU está terminado cuando:
1. El **árbol está relleno** con números reales (CPM, CTR, CPC, CVR, AOV, RPU) y fuente citada.
2. El **front-end ROAS reconstruido cuadra** con Meta/TW (o el desfase está explicado como atribución/ventana).
3. Están calculados **Front-End Profit y 90D Profit** con margen y CLV (o marcados como supuesto si falta el dato).
4. Hay un **veredicto claro**: ads o web, con el "por qué" apoyado en el benchmark propio.
5. Está **cuantificado el apalancamiento** (qué mueve más el ROAS) mostrando que la web gana.
6. Hay un **siguiente paso concreto** y a qué skill/SOP pasa el balón.

Regla transversal (del curso, módulo 18): sólo hay 2 resultados válidos de una iteración — **Winner o Learning**, nunca "inconclusive". El diagnóstico debe dejar una hipótesis accionable, no un "depende".
