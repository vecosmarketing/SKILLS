# mlo-klaviyo-email-report

M.L.O Growth skill — genera el Klaviyo Email Marketing Report (deck skin M.L.O) desde Klaviyo.
Ver `SKILL.md` y `references/pipeline.md`.
