# 📐 Metodología — Auditor de Capacidad MLO

## 1) Normalización de horas
- **Efectivas vs presencia:** Clockify registra tiempo con el timer activo; se para en pausas. Conversión mental: **~6–6,5 h efectivas ≈ un día completo de 8 h** normal. Un día a **9 h efectivas ≈ ~40% por encima** de lo normal (jornada real de 10–11 h de presencia).
- **Full-time teórico:** 40 h/sem × 52 ÷ 12 = **173,33 h/mes**. Aproximación de calle 160 h (peor). Es referencia, no objetivo.
- **Días laborables reales:** cuenta los del período (excluye findes/festivos/vacaciones). Ej: 1ª quincena = ~10 días.
- **Pico vs media:** SIEMPRE compara el período caliente contra otro (mes anterior). Ej. real: Julio 143 h (~6,2 h/día = normal) vs Ago 1–14 90 h (9 h/día = pico). Nunca extrapoles la quincena de pico a mes completo.

## 2) One-time vs recurrente (la clasificación clave)
Marca cada bloque:
- **ONE-TIME (inversión que no se repite):** montar un repositorio, setup de reportes/dashboards, definir un criterio/estándar, migraciones. → **horas recuperadas** el mes siguiente.
- **RECURRENTE (steady-state):** operativa diaria, coordinación/reuniones internas, reportes semanales, briefing, feedback a editores, carga de ads.
- **Retrabajo:** subconjunto evitable (algo hecho 2 veces por falta de estándar). Se ataca con decisión de Dirección, no con más horas.

Regla: el % de interno alto de un mes suele ser **inversión puntual**. Recalcula el **interno recurrente real** quitando lo one-time (suele bajar de ~38% a ~15%).

## 3) Capacidad recuperable (el número que importa)
`Recuperable ≈ (one-time que no vuelve) + (tareas que caen al automatizar o mudar de sitio)`
Ejemplos de "caen": ad copy que se hace una vez y vive en el Creative Engine; reportes que bajan de 2 h a 30' con IA. Exprésalo en **h/quincena o /mes** y di a dónde va (cliente o colchón anti-pico).

## 4) Los 2 cuellos de botella típicos de MLO
La mayoría de "8 problemas" son **síntomas** de 2 cuellos:
1. **Las urgencias de cliente se comen la capacidad de briefing** del estratega. → Solución: **filtro de urgencia** (real vs cola) + un PM que haga de muro; lo no-urgente va batcheado.
2. **Demasiadas calls del estratega** (tiempo que no es briefing ni estrategia). → Solución: **calls de cliente quincenales** (el PM da el update semanal; el estratega reporta cada 15 d). Recupera ~3 h/sem por estratega.
Otros síntomas frecuentes: caos de tempos (→ días fijos o cadencia por marca), feedback repetitivo (→ checklist editor + SOPs), Creative Engine infra-registrado (→ todo ticket con Brief ID).

## 5) ¿Volumen o proceso?
- **Cuello de VOLUMEN** = faltan briefs/creativos para el objetivo. Cruza con `mlo-estratega-creativo` (hit rate, briefs necesarios = winners ÷ hit rate). 
- **Cuello de PROCESO/cadencia** = hay volumen pero se **apila** (varias marcas el mismo día). Solución: cadencia/días fijos.

## 6) KPIs que se pueden sacar
| KPI | Cálculo | Fuente |
|---|---|---|
| Briefs / estratega / semana | nº briefs ÷ estratega ÷ semana | Creative Engine |
| Briefs / marca / semana | nº briefs ÷ marca ÷ semana | Creative Engine |
| Gap de briefing | briefs necesarios (winners ÷ hit rate) − reales | mlo-estratega-creativo |
| Horas/sem en calls de cliente | Σ (calls × duración) | Fireflies (dedup) |
| Horas recuperadas al pasar a quincenal | ~½ de la parte que atiende el estratega | aritmética |
| % urgencias que no lo eran | sobre registro de tickets | Tickets/Slack |
| Rondas de revisión por creativo | veces que un ticket vuelve | Tickets (Status) |

## 7) Tono del diagnóstico
Honesto y sin dramatizar. Si un mes fue normal, dilo. Si hubo pico, sepáralo de la media. Reconoce el retrabajo como fallo de proceso (de Dirección), no de la persona. Cierra siempre con accionables + quién + qué se recupera.
