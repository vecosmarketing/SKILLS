---
name: mlo-cold-friendly-offer
description: >
  MLO Growth's AUTHOR of cold-traffic offers. Given a brand's profiling output (product, avatar/VoC, pains, margin,
  AOV, sophistication), it WRITES an irresistible Cold Friendly Offer — one that stays profitable on the FRONT END
  so paid can scale on cold/unaware traffic — plus a full Master Offer Doc using Carl Weische's A–E framework
  (A. Mass Market Desires · B. Perceived Value · C. Persuasion · D. Opportunity Analysis · E. Market Sophistication),
  the offer archetypes (bundle / 30-day challenge / BOGO), and the Kinobody bundle+community case. Output = the written
  offer + a congruent landing-page brief. ALWAYS use this skill (ES/EN) when the user says "crea la oferta de [marca]",
  "cold friendly offer", "oferta escalable en frío", "oferta irresistible para tráfico frío", "master offer doc",
  "cómo bundleo para subir AOV", "arma un bundle / challenge / BOGO", "monta la oferta que escale en paid",
  "build the offer", "author an offer for [brand]", "irresistible offer for cold traffic", "offer that scales on paid",
  "how do I bundle to raise AOV", "make my front-end profitable". Trigger for any MLO brand (ZZEN, 8hours, Bala di Gala,
  Moncho Moreno, QiHealth, Nurse is Love, V-UP, i-Energy, Alma, HobbitAlf, Chic&Love, etc.). It COMPLEMENTS
  mlo-offer-simulator (that one SCORES/simulates offers; this one AUTHORS them) and mlo-ecom-financials-2026
  (front-end profit / NCPA / unit-economics guardrails) — reference both, don't fork them.
---
# Cold Friendly Offer (Author)

## What it does
Turns a brand's **profiling output** into a **written Cold Friendly Offer** and a **Master Offer Doc** — an offer engineered to be **profitable on the first sale to cold/unaware traffic**, so media buying can scale without warm-audience crutches. It authors the actual offer copy (headline, stack, price/anchor, guarantee, scarcity) using Carl Weische's **A–E framework**, picks the right **archetype** (bundle / 30-day challenge / BOGO), lifts perceived value to **5–10× the price without discounting**, and hands off a **congruent landing-page brief** so the message that won in the ad is the message that monetizes on the page.

It is the AUTHOR in MLO's offer stack. Its twins:
- **`mlo-offer-simulator`** — SCORES and simulates offers (discount matrix, bundle math, CAC/AOV sim). Author here → paste into the simulator to pressure-test the numbers.
- **`mlo-ecom-financials-2026`** — the unit-economics brain (break-even ROAS = 1/CM%, NCPA, LTGP:CAC, front-end profit). Pull the margin/CAC guardrails from there; this skill turns them into an offer.

## When to use (ES + EN trigger phrases)
- **ES:** "crea/arma/monta la oferta de [marca]", "oferta escalable en frío", "cold friendly offer", "oferta irresistible para tráfico frío / unaware", "master offer doc", "cómo bundleo para subir el AOV", "arma un bundle / un challenge de 30 días / un BOGO", "cómo hago rentable el front-end", "necesito una oferta que escale en paid", "sube el valor percibido sin bajar el precio", "qué meto en el bundle".
- **EN:** "build/author the offer for [brand]", "cold friendly offer", "irresistible offer for cold traffic / unaware", "master offer doc", "how do I bundle to raise AOV", "make a bundle / 30-day challenge / BOGO", "make my front-end profitable", "an offer that scales on paid", "raise perceived value without discounting", "what goes in the bundle".
- **Do NOT use for:** SCORING/simulating an existing offer's economics → `mlo-offer-simulator`; the deep unit-economics/P&L/"is this brand profitable" question → `mlo-ecom-financials-2026`; building the actual landing page in code → `mlo-page-cooker` / `mlo-cro-2026`; writing the VSL → `mlo-vsl-writer`; generating raw angles → `angle-generator`; the funnel map across steps → funnel work (page-cooker/cro). This skill AUTHORS the offer and the LP brief; it does not build the page or score the math.

## Inputs needed
1. **Brand / product** (+ its Brand Brain for VoC, tone, catalog if an MLO brand).
2. **Profiling output** — avatar, top pains, desired outcome, real customer language (Amazon/store reviews, surveys, Reddit). If missing, ask for it or derive from the Brand Brain; **do not invent claims**.
3. **Unit economics** — current AOV, COGS/margin, target CAC / break-even ROAS. Pull from `mlo-ecom-financials-2026`; a Cold Friendly Offer needs **enough gross margin to spend aggressively**.
4. **Market sophistication** (1–5: how many times this market has heard the claim) and **awareness stage** (cold = Unaware–Solution). Decides how the same product must be marketed.
5. Optional: existing offer, catalog for bundling, proof assets (reviews/authority/press), digital-asset capacity (guide/community), currency & language (ES/EN).

## Method (numbered — author the offer, then the doc, then the LP brief)
1. **Profiling → pain map.** From the profiling, list the pains, then **maximize the dominant pain** (urgency) and name the desired outcome in the customer's own words. Offer sells the outcome, not the product (product ≠ offer).
2. **Pick the Mass Market Desire(s) (A).** Anchor the offer to ≥1 of the four hard-wired desires — **Reproduction/attractiveness · Status · Social belonging · Safety/health (avoid pain)**. Everything downstream ladders to this.
3. **Engineer Perceived Value (B) — value UP, never price down.** Discounting kills the margin that funds cold spend. Instead: become the **All-In-One** (solve more of the problem, be a must-have not a nice-to-have), and use **resourcefulness > resources** to build value cheaply: (a) **change the narrative**, (b) **bundle** (turn an isolated product into a holistic system). Use a **bundle as a price anchor** to lift AOV. Target **perceived value = 5–10× price**.
4. **Choose the archetype.** **Bundle** (complementary / more-of-same / info-product / community), **30-Day Challenge** (habit + accountability → CLV), or **BOGO** (volume, gifting). Pick by pain + margin + catalog, not taste. Add a **digital product** (guide, method, app, community) whenever possible — near-zero COGS is what makes the front end profitable and the offer non-copyable.
5. **Load Persuasion (C).** Stack **social proof · authority · certainty/guarantee · scarcity · urgency · exclusivity**. Always include a strong guarantee — **100-day no-questions / 3-year / 30-day try-before-buy** — to hit "no-brainer at zero risk."
6. **Run Opportunity Analysis (D).** Where's the edge: an unsolved problem · a superior business/offer structure · a new market/avatar · an untapped traffic source. Name the one you're exploiting → this is the "category of one" wedge (artificial blue ocean via a message upgrade).
7. **Set the price & anchor (E-aware).** Price against the bundle anchor (e.g. "$97 not $197"), keeping CM% high enough that **break-even ROAS is scalable in cold**. As **sophistication rises, market the SAME product differently** (claim → +amplified → +new mechanism → +stacked benefits → +identity/authority). Don't shout a bare claim into a soph-4/5 market.
8. **Write the offer.** Output the offer name, the value stack (each item + its standalone value), the anchor, the price, the guarantee, and the scarcity/urgency mechanism (see Output shape).
9. **Write the Master Offer Doc.** The full A–E doc using the reference template — this is the brand's canonical offer artifact.
10. **Write the congruent LP brief.** The cold visitor doesn't fail to buy — the message **leaks between ad and page**. Brief a **dedicated page built from the winning ANGLE, not the product** (1 page = 1 angle = 1 desire = 1 problem): headline = the ad's promise, sub = clarification, first section = emotional continuation, then the 8-section spine. "Winning ads discover the message; congruent pages monetize it."

## Rules & standards (MLO non-negotiables)
- **Front-end profitability is the whole point.** If the offer only works on warm/returning traffic, it's not a Cold Friendly Offer. It must profit (or break even scalably) on the first cold sale.
- **Value up, not price down.** Never lead with a discount to build the offer — it destroys the margin that funds aggressive cold spend. Raise perceived value to 5–10× price instead.
- **Resourcefulness > resources.** Build value with narrative + bundling before spending on new product; the unsold bundle is a price anchor, not a giveaway.
- **Add a digital/community layer whenever possible.** Near-zero COGS + accountability = the Kinobody lever (front-end profit + CLV + non-copyable).
- **Sophistication sets how you sell the same product.** Rising sophistication ⇒ change the message, not the product; match the claim type to soph 1–5.
- **Data, not brainstorm.** Bundle and angle decisions come from reviews/surveys/Reddit (VoC), never invention. If proof is missing, flag it — don't fabricate a stat, testimonial, or guarantee the brand can't honor.
- **Congruence is a conversion lever.** The LP brief must continue the ad's promise (same problem/desire/language/emotion/awareness) on a dedicated page built from the angle.
- **Stay in your lane.** Author the offer + LP brief here. Send the numbers to `mlo-offer-simulator`, the unit economics to `mlo-ecom-financials-2026`, the page build to `mlo-page-cooker`, the VSL to `mlo-vsl-writer`.

## Output (exact shape + concrete example)
Deliver two blocks — the **Written Offer** and the **Congruent LP Brief** — and, on request or by default for a canonical artifact, the full **Master Offer Doc** (reference template).

```
WRITTEN OFFER — [Brand] · Archetype: [bundle / 30-day challenge / BOGO] · Awareness: [stage] · Sophistication: [1–5]
Mass Market Desire(s) [A]: [Reproduction/Status/Belonging/Safety — the ≥1 chosen]
Dominant pain (maximized): [the pain, in customer's words] → Desired outcome: [outcome]
Offer name: "[the named offer]"
Value stack [B]:
  - [Core product] — value [$X]
  - [Complement / more-of-same] — value [$X]
  - [Digital product: guide/method/app] — value [$X]  (COGS ~0)
  - [Community / accountability] — value [$X/mo]  (CLV lever)
  Total perceived value: [$Y]  (target 5–10× price)
Price & anchor [E]: [$price] (anchored vs [$anchor])  → est. CM% [__] → break-even ROAS [__]
Persuasion [C]: proof [..] · authority [..] · guarantee [100-day/3-yr/try-before-buy] · scarcity [..] · urgency [..] · exclusivity [..]
Opportunity edge [D]: [unsolved problem / better structure / new market / untapped traffic]
Sophistication move [E]: [how the SAME product is marketed at this soph level]
Front-end thesis: [why this profits/breaks-even scalably on the first cold sale]

CONGRUENT LP BRIEF — built from ANGLE not product (1 page = 1 angle = 1 desire = 1 problem)
Winning angle it expands: [the ad angle]
Headline (= ad promise): "[..]"   Sub (clarification): "[..]"
Section 1 (emotional continuation of the ad): [..]
8-section spine: hero+VSL / value prop / success stories / offer breakdown / offer+CTA / testimonials / guarantee / FAQ
Congruence check: same problem/desire/language/emotion/awareness from ad frame 1 → first scroll? [yes + note]
```

**Example — Brand: QiHealth (glucose sensor, healthtech MX) · profiling: 45+ pre-diabetic, fears complications, tried apps that didn't stick · Soph 3 · AOV low, needs front-end profit:**
```
WRITTEN OFFER — QiHealth · Archetype: 30-Day Challenge (bundle + community) · Awareness: Solution-Aware · Sophistication: 3
Mass Market Desire(s) [A]: Safety/health (avoid the pain of complications) + Belonging (a group doing it with you)
Dominant pain (maximized): "veo el número alto y no sé qué hacer, y solo no lo mantengo" → Outcome: glucosa estable en 30 días, con guía y acompañamiento
Offer name: "Reto QiControl 30 Días"
Value stack [B]:
  - Sensor QiTrax (14 días) x2 — value $X
  - Plan de comidas anti-picos + recetas (digital) — value $X (COGS ~0)
  - App de lecturas + alertas — value $X
  - Comunidad QiControl + check-ins semanales — value $X/mo (CLV)
  Total perceived value ≈ 6–8× price
Price & anchor [E]: [precio] anclado vs comprar sensores sueltos → CM% alto por el peso del digital → break-even ROAS escalable
Persuasion [C]: testimonios de bajada de glucosa · aval clínico (guardrails COFEPRIS, sin claim médico prohibido) · garantía try-before-buy 30 días · plazas del reto limitadas · urgencia de cohorte mensual · acceso exclusivo a la comunidad
Opportunity edge [D]: problema no resuelto (adherencia: apps que no se mantienen) + estructura superior (challenge+community, no venta suelta de sensor)
Sophistication move [E]: soph 3 → liderar con NUEVO MECANISMO ("no es medir, es el método de 30 días"), no con el claim genérico de "mide tu glucosa"
Front-end thesis: el digital+comunidad casi sin COGS sube el AOV y el margen → el reto profita en la 1ª venta fría y la comunidad extiende CLV (modelo Kinobody)

CONGRUENT LP BRIEF — built from ANGLE not product
Winning angle it expands: "no basta con medir la glucosa — necesitas el método y a alguien que te acompañe 30 días"
Headline (= ad promise): "Estabiliza tu glucosa en 30 días — con el método y la comunidad, no solo un sensor"
Sub: "El Reto QiControl te da el sensor, el plan anti-picos y check-ins semanales."
Section 1: continúa el miedo del ad (complicaciones + hacerlo solo) → esperanza del reto
8-section spine: hero+VSL / value prop / success stories / offer breakdown / offer+CTA / testimonials / guarantee / FAQ
Congruence check: mismo problema (adherencia), mismo deseo (salud+pertenencia), mismo lenguaje del ad → sí; página dedicada al reto, no la PDP del sensor
```

## Guardrails
- Never invent the offer's proof, guarantee, or margin — ground in the Brand Brain / VoC / financials. If the brand can't honor a 100-day guarantee or lacks the digital asset, say so and design within reality.
- Don't hand back a discount dressed as an offer. If the only lever proposed is "% off," stop and rebuild value (bundle + narrative + digital).
- Don't ship an offer that only pencils on warm traffic — check the front-end thesis against `mlo-ecom-financials-2026` guardrails (CM%, break-even ROAS, target NCPA).
- Don't mismatch sophistication and claim (bare claim into a soph-4/5 market). Move the offer's message up the ladder.
- Always pair the offer with the congruent LP brief — an offer with no page to monetize it leaks. Build the page from the angle, not the product.
- ES/EN: write in the brand's language and MLO voice — **no literal translation** from English; rewrite the idea in plain, natural language, MLO decimal/format conventions on numbers.
- This skill AUTHORS; it does not SCORE (→ `mlo-offer-simulator`), do the P&L (→ `mlo-ecom-financials-2026`), build the page (→ `mlo-page-cooker`), or write the VSL (→ `mlo-vsl-writer`).

## References
- **Full framework, checklist & cases:** `reference/master-offer-doc.md` (the A–E Master Offer Doc template + the 5-part irresistible-offer test, the archetype library, the Kinobody case with numbers, the Native Static "mechanism is the hero" doctrine, worked case walkthroughs, and the congruent-LP spine).
- **Course grounding:** `~/Documents/CODEX/accelerated-advisory/modules/07-cold-friendly-offer.md` (Carl Weische, Cold Friendly Offer / Master Offer Doc) and `10-funnel-building.md` (funnel spine, congruence, awareness × sophistication).
- **Sibling skills (reference, do not fork):** `mlo-offer-simulator` (scores/simulates the offer's economics), `mlo-ecom-financials-2026` (unit economics, front-end profit, NCPA, break-even ROAS, LTGP:CAC), `mlo-page-cooker` / `mlo-cro-2026` (builds the congruent page + 8-section LP), `mlo-vsl-writer` (the VSL), `angle-generator` / `mlo-sistema-creativo-2026` (angles + creative volume for the ad layer).
