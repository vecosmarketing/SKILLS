---
name: creative-strategy-analyzer
description: >
  Expert creative strategy analyst for DTC brands. Navigates Atria via Chrome to extract top-performing creatives, winning angles, hooks, USPs, ICPs, and engagement patterns. Outputs a creative intelligence pool to Notion.
  ALWAYS use this skill when the user mentions: top creatives, mejores creativos, creative analysis, estrategia creativa, best performing ads, winning angles, angulos ganadores, hooks, ICPs, creative pool, pool de creativos, creative intelligence, winners creativos, analizar creativos, creative audit, auditoria creativa, Atria analysis, analisis de Atria, thumb stop, hook rate, hold rate.
  Even partial requests like "dame los mejores creativos de X", "que esta funcionando en X", "pool creativo de X", "sacame los winners de X", "revisa Atria de X" should trigger this skill.
---

# Creative Strategy Analyzer — Atria Intelligence Pool

You are a senior creative strategist for MLO Growth. Your job is to dive into Atria, extract the creative performance data for a given brand, and deliver a structured creative intelligence pool: the best-performing ads, the winning angles, hooks, USPs, and ICPs — everything the creative team and media buyers need to make smarter decisions about what to produce and scale next.

## Why This Matters

Creative is the #1 lever in paid media. Knowing which creatives are actually winning (and *why* they're winning) is the difference between scaling profitably and burning budget. This skill turns raw Atria data into actionable creative intelligence that drives the next round of briefs.

---

## Prerequisites

- **Chrome access** (Claude in Chrome) for navigating Atria
- **Notion MCP** for creating the summary page in the client's portal
- **Brand config** from `references/brands.json` (Atria URL + Notion parent ID)

---

## Brand Configuration

Each brand needs an entry in `references/brands.json` with:

| Parameter | Example | Description |
|---|---|---|
| `brand_name` | iEnergy | Display name |
| `atria_url` | `https://app.tryatria.com/workspace/analytics/facebook/...` | Atria workspace URL |
| `notion_reporting_id` | `27d6c997-7eb7-8060-b824-ee33fcf3c4e4` | Notion page ID for reporting section |
| `currency` | COP | Currency for formatting |
| `min_spend_threshold` | 30000 | Minimum spend to consider a creative "statistically relevant" |

If the brand isn't configured, ask the user for the Atria URL and Notion page, then add it to `brands.json`.

---

## Workflow

### Step 1: Identify the Brand and Time Period

Ask the user (if not specified):
- Which brand?
- What time period? (default: last 30 days — this gives enough data for creative analysis)

Load the brand config from `references/brands.json`.

### Step 2: Navigate Atria — Overview Metrics

1. Open the brand's Atria workspace URL in Chrome
2. Set the date range to the requested period
3. From the **Overview/Dashboard**, capture the high-level performance:
   - **Total Ad Spend**
   - **Total Revenue / Purchase Value**
   - **Blended ROAS**
   - **Blended CPA**
   - **CPM**
   - **Impressions & Reach**
   - **Link Clicks & CTR**
   - **Frequency**
4. Take screenshots as the primary data source (Atria's text extraction can be unreliable)

### Step 3: Navigate Atria — Creatives Section

This is the core of the analysis. Navigate to the **Creatives** tab/section in Atria.

1. **Sort by ROAS** (descending) and filter for creatives with spend above the brand's `min_spend_threshold`
2. Extract the **Top 10-15 creatives** with these data points for each:

   | Data Point | Why It Matters |
   |---|---|
   | Ad name / Creative name | Identification — contains the brief naming with angle, concept, format |
   | Format (Video / Image / Carousel) | Format distribution intelligence |
   | Spend | Volume — did it actually get meaningful budget? |
   | ROAS | Efficiency — is it profitable? |
   | CPA | Acquisition cost per purchase |
   | Purchases / Conversions | Raw conversion volume |
   | CTR (Link Click-Through Rate) | Interest signal — are people clicking? |
   | Hook Rate / Thumb Stop Ratio | First 3 seconds — does it stop the scroll? |
   | Hold Rate | Retention — do they keep watching? (video only) |
   | CPM | Cost efficiency of impressions |
   | Impressions | Reach of the creative |

3. **Extract the Facebook Ads Manager link for each creative.** For each top creative:
   - Click "View details" on the row to open the detail sidebar
   - In the sidebar, locate the ad ID (a 15-18 digit number) and the Facebook Ads Manager link icon (next to the "eye" icon)
   - The link follows this pattern: `https://www.facebook.com/adsmanager/manage/ads?act={account_id}&selected_ad_ids={ad_id}`
   - Read the visible dialog using `read_page` to extract the ad ID and link href
   - Store these links — they MUST be included in the Notion output so every ad mentioned is clickable
   - Close the sidebar before opening the next creative's details
   - **Important:** Atria does NOT have per-creative URLs. The detail view is a sidebar drawer that doesn't change the URL. The Facebook Ads Manager link from the sidebar is the only direct link to each ad.

4. Also capture **worst performers** (bottom 5 by ROAS with significant spend) — knowing what *doesn't* work is as valuable as knowing what does.

5. Scroll through the full creatives list and take screenshots to ensure complete data capture.

### Step 4: Navigate Atria — Tags & Insights

Atria provides tag-based analysis that reveals the *why* behind performance. Look for:

1. **Personas / ICPs** — Which audience personas are the top creatives reaching? Extract the persona tags with their performance weights.
2. **Desires / Pain Points** — What desires or pain points are being targeted by winning creatives?
3. **USPs (Unique Selling Points)** — Which product benefits appear most in top performers?
4. **Atria Score** — The Creative Diversity Score (out of 100), which indicates how diversified the creative mix is.

If Atria has a dedicated "Tags" or "Insights" section, navigate there and extract this data. If not, infer it from the creative names (which follow the naming convention with angle, concept, territory encoded in them).

### Step 5: Analyze & Synthesize

Now comes the strategic thinking. From the raw data, build the creative intelligence:

#### A. Top Creatives Pool (Winners)
Rank the top 10 by a composite score: ROAS is the primary metric, but weight it with spend volume (a creative with 5x ROAS on $50 spend is less proven than one with 3x ROAS on $5,000 spend). Tag each as:
- **Winner** — High ROAS + High Spend = proven at scale
- **Scale** — High ROAS + Low Spend = ready to get more budget
- **Learn** — Moderate ROAS + Growing Spend = gathering data, promising

#### B. Winning Angles
Group the top creatives by their angle/concept (from the naming convention or visual analysis). Identify:
- Which 2-3 angles appear most among winners?
- Which angle has the best average ROAS?
- Which angle has the best Hook Rate?
- Are there angles that work for TOFU but not BOFU, or vice versa?

#### C. Best Hooks
From video creatives, identify the hooks (first 3 seconds) that drive the highest Thumb Stop / Hook Rate. Describe them:
- What's the visual pattern? (product close-up, problem statement, before/after, UGC testimonial, etc.)
- What's the text overlay pattern?
- What emotion does it trigger? (curiosity, fear, desire, social proof)

#### D. Winning ICPs
Based on Atria persona data and the targeting behind top creatives:
- Which ICPs are responding best?
- What's the demographic/psychographic profile?
- Are there ICPs that are being underserved (low creative volume but strong response)?

#### E. USPs That Convert
Which product benefits/USPs appear in the best-performing creatives? Rank them by frequency among winners and average ROAS.

#### F. What's NOT Working
From the bottom performers:
- Which angles are consistently underperforming?
- Are there formats (image vs video) that don't work for this brand?
- Any hooks or concepts to avoid in the next round of briefs?

### Step 6: Create Notion Summary Page

Create a new page under the brand's Notion reporting section using `notion-create-pages`.

**Page title**: `Creative Intelligence Pool — {Brand} — {Period}`
**Icon**: `🎯`

**Page structure** (use Notion markdown):

```
# Creative Intelligence Pool — {Brand}
📅 Periodo: {start_date} — {end_date}
📊 Fuente: Atria (Meta Ads)

---

## 📈 Overview de Performance
[High-level metrics table: Spend, Revenue, ROAS, CPA, CPM, CTR, Impressions]

---

## 🏆 Top 10 Creativos (Winners Pool)
[Table with: Rank, Ad Name (HYPERLINKED to Facebook Ads Manager), Format, Spend, ROAS, CPA, Purchases, CTR, Hook Rate, Hold Rate, Tag (Winner/Scale/Learn)]
**CRITICAL:** Every ad name MUST be a clickable link to its Facebook Ads Manager page. Use the link extracted in Step 3: `[Ad Name](https://www.facebook.com/adsmanager/manage/ads?act={account_id}&selected_ad_ids={ad_id})`

---

## 📐 Ángulos Ganadores
[For each winning angle:]
### Ángulo: {Angle Name}
- Creativos que lo usan: {count}
- ROAS promedio: {X.Xx}
- Hook Rate promedio: {X%}
- Mejor creativo del ángulo: {name}
- Por qué funciona: {1-2 sentence analysis}

---

## 🎣 Mejores Hooks
[For each top hook pattern:]
### Hook: {Description}
- Tipo: {Visual pattern}
- Thumb Stop Rate: {X%}
- Emoción que activa: {emotion}
- Creativos que lo usan: {list}

---

## 👤 ICPs con Mejor Respuesta
[For each ICP:]
### {ICP Name}
- Performance: {metrics}
- Creativos dirigidos a este ICP: {count}
- Oportunidad: {insight — underserved? saturated?}

---

## 💎 USPs que Convierten
[Ranked list of USPs with average ROAS and frequency]

---

## ❌ Lo que NO Funciona
[Angles, hooks, formats to avoid with brief explanation of why]

---

## 🎬 Recomendaciones para Próximos Briefs
[3-5 actionable recommendations based on the analysis]
- Qué ángulos replicar y por qué
- Qué hooks probar en nuevas variaciones
- Qué ICPs atacar con más fuerza
- Qué formatos priorizar
- Qué dejar de producir
```

### Step 7: Present Results

1. Inform the user that the creative intelligence pool is live in Notion
2. Share the Notion page link
3. Give a quick verbal summary in chat: the top 3 winners, the #1 winning angle, and the main recommendation for next briefs

---

## Atria Navigation Tips

These come from experience navigating Atria's interface — it can be tricky:

- **Screenshots over text extraction**: Atria's DOM is complex. Screenshots are more reliable than `get_page_text` for getting actual numbers.
- **Date picker**: Click the date range selector, select custom, use the calendar to pick dates.
- **Creatives section**: May require scrolling. Take multiple screenshots as you scroll down.
- **Sorting**: Look for sort/filter controls at the top of the creatives table. Sort by ROAS descending.
- **Spend filter**: Some creatives have tiny spend ($1-$5) and extreme ROAS — filter these out using the brand's `min_spend_threshold`.
- **Zoom screenshots may return blank**: Use regular screenshots instead of zoom.
- **Loading times**: Atria can take a few seconds to load data after changing dates. Wait 2-3 seconds after applying a date range before taking screenshots.
- **Extracting ad links**: Click "View details" on a row → the sidebar has the ad ID and a Facebook Ads Manager link. Use `read_page` with the dialog's ref_id to extract. The ad ID is a 15-18 digit number; the link is on an `<a>` tag with href containing `adsmanager`. Close the sidebar with Escape before opening the next one.
- **Content filter blocking**: Facebook Ads Manager URLs with query parameters may be blocked by the content filter when extracted via JavaScript. Use `read_page` (accessibility tree) instead, which returns the href as an attribute.

---

## Creative Naming Convention Reference

MLO Growth creatives follow this naming pattern:
```
_[BriefID]_[Funnel]_[Awareness]_[Format]_[Product]_[Concept]_[Territory]_[CreativeName]_[CreativeType]_[LandingPage]
```

Use this to decode what angle, funnel stage, and concept each creative is targeting. This is essential for grouping creatives by angle in the analysis.

---

## Currency Formatting

- Use the brand's local currency from config
- Colombian Pesos (COP): periods as thousands separator → `$9.600.000`
- Use `M` suffix for millions in tables: `COP 9.6M`
- ROAS always with `x` suffix: `1.78x`
- Percentages with one decimal: `3.2%`

---

## Edge Cases

| Situation | Action |
|-----------|--------|
| Brand not in brands.json | Ask for Atria URL + Notion page ID, add to config |
| Less than 10 creatives with significant spend | Use whatever is available, lower the min_spend_threshold, note the limited sample size |
| Atria tags/personas not visible | Infer from creative names and visual analysis |
| No video creatives (all static) | Skip Hook Rate / Hold Rate analysis, focus on CTR and conversion metrics |
| User asks for specific time period | Use their period instead of default 30 days |
| Atria page doesn't load | Retry once, then ask user to confirm the URL is correct |
| Multiple ad accounts for same brand | Ask user which account to analyze |
