# Script Doctor — Knowledge Base (QA / Quality-Gate for Ad Scripts)

Distilled from MLO's Scripting Playbook + the reused expert brain. This is the scoring engine behind the skill. Cite the module when you apply a rule.

---

## 1. The scoring rubric (0-100)

Weights are tuned to MLO's own priorities: the hook is the 80/20, market fit and the winner-anatomy carry the rest. Score each criterion, sum, then map to a verdict.

| # | Criterion | Weight | What "full marks" looks like | Source |
|---|---|---|---|---|
| 1 | **Hook strength (first 3s)** | 25 | Contrast/curiosity loop, one avatar, 4 components aligned, strong key VISUAL, no product in a cold hook, passes `visual→speech→visual` | M4 Hooks; Ogilvy "80% of spend" |
| 2 | **Framework adherence (1 of 12)** | 15 | Every acronym beat present, in order, doing its job; framework chosen by avatar/awareness not taste | M3 Frameworks |
| 3 | **Awareness × sophistication match** | 15 | Runway length fits awareness; mechanism present if sophistication ≥3; no offer-ad-to-unaware, no bare-claim-in-saturated-market | Schwartz grid (`experts-direct-response.md`) |
| 4 | **Single-message / Trinidad** | 10 | One avatar, one angle, one core promise; no hedging across audiences/benefits | M1/INDEX (Trinidad) |
| 5 | **Mechanism + proof** | 15 | Named unique mechanism (reason-why); multi-angle proof; language from real VoC | M1/M3; Hormozi/Schwartz/Hopkins |
| 6 | **Clarity & pacing** | 10 | 10-year-old could follow; ~70% fluff cut; each line earns the next (slippery slide); VSL time budget respected | M4/UGLY; Sugarman |
| 7 | **CTA (reason to act now)** | 5 | Specific next step + risk-reversal / scarcity / urgency | M3 checklist; VWO (+28%) |
| 8 | **FFM readiness** | 5 | 3-5 hooks with distinct VISUAL hooks for separate ad sets; predicted to clear hook/hold benchmarks | M4; FFM preset |

**Verdict bands:**
- **90-100 — SHIP.** Ready to brief/shoot. Note any micro-polish.
- **75-89 — MINOR FIXES.** Strong; apply the redline then ship.
- **60-74 — NEEDS WORK.** A core beat is broken; rewrite before shooting.
- **<60 — REBUILD.** Wrong market fit or dead hook; rebuild from the axes up.

**Diagnostic shortcut (which second to rebuild):** weak first 3s → hook rate fails → fix criterion 1. Strong stop but drop by ~15s → hold rate fails → fix agitation/pacing (criteria 5-6). Full watch-through but no sales → CTR/ROAS fail → fix mechanism/proof/offer/CTA (criteria 3,5,7). Source: hook/hold rate diagnostic, `experts-offers-hooks.md`.

---

## 2. The two axes you diagnose BEFORE scoring

### Awareness (the prospect — Schwartz, 5 stages)
Unaware → Problem-Aware → Solution-Aware → Product-Aware → Most-Aware. **Rule: the less aware, the longer the runway before the product; the more aware, the faster to the offer.**
- Cold/broad Meta, no problem recognition → Unaware/Problem-Aware → story/education/symptom hook, **no product in hook**.
- Warm/site visitors → Product-Aware → objections, proof, guarantees.
- Cart abandoners/list → Most-Aware → offer + CTA + urgency.

### Sophistication (the market — Schwartz, 5 stages)
1 First-to-market (state claim plainly) · 2 Second wave (enlarge the claim) · 3 **Mechanism** (claim no longer believed → need a named "how") · 4 Elaborated mechanism (out-prove: studies, certs, demos) · 5 Identification/reinvent (sell identity, "for the [X] who…").
- **Saturated DTC (supplements, skincare, weight-loss) = stage 4-5 → a bare benefit claim is invisible.** No mechanism/identity = auto-fail on criterion 3.

### The two failures the grid catches (flag on sight)
1. **Offer ad to an unaware audience** ("20% off" to cold traffic). Fix: move left to a story/problem hook.
2. **Bare claim in a saturated market.** Fix: add a mechanism (stage 3) or shift to identity (stage 5).

**Angle-decay rule:** if the user says a proven script fatigued, first ask "has the market heard this claim too many times?" → add/deepen mechanism or move to identification, don't shout louder.

Source: `experts-direct-response.md` (Awareness × Sophistication grid).

---

## 3. The anatomy of a winner (every script must complete it)

`Hook → Problema/Deseo → Mecanismo (por qué funciona) → Prueba → CTA con razón para actuar ya`. The 12 frameworks are 12 ways to walk this same anatomy. Score each link:

- **Hook** — criterion 1 (see §4).
- **Problem/Desire** — named in the avatar's own words (VoC), precise, not generic.
- **Mechanism** — the *named, unique* reason it works. Two layers usable together: mechanism of the **problem** (hidden root cause the prospect didn't know) + mechanism of the **solution** (proprietary fix). "High quality" is NOT a mechanism. Give it a proprietary name ("Cold-Pressed Micellar Complex", "3-Phase Time-Release"). This is what escapes price comparison (Schwartz stage-3; `experts-offers-hooks.md` "Unique Mechanism").
- **Proof** — multi-angle (customer results, before/after data, expert endorsement, research, reviews). Two testimonials is not enough (VSL proof-stack). Language must come from real reviews.
- **CTA** — specific next step + reason to act now (risk-reversal / scarcity / urgency). Specific CTAs beat generic by ~28%.

Source: M3 `01-Modulo-Frameworks-y-Script-to-Brief.md` §0; `experts-offers-hooks.md` (VSL flow, unique mechanism, value equation).

---

## 4. Hook QA — the 80/20 (grade this hardest)

A hook is the first 1-5s; its only job is to open a **curiosity loop by CONTRAST** (viewer believes A → you show B; bigger contrast = stronger hook). Score against:

**The 4 components (must be ALIGNED):** Spoken · Visual · Text · Audio. 500 vs 500,000 views = alignment. The brain consumes `visual → audio → visual`, so **the VISUAL is the key visual and weighs most** — changing the visual hook moves performance more than the line. Misalignment → confusion → scroll.

**The 6 viral formats (pick the highest-contrast one for the visual you have):** Fortune Teller (present vs future) · Experimenter (peer demo) · Teacher (lesson) · Magician (stun + visual pacifier; combines with the other 5) · Investigator (secret/finding) · Contrarian (opposite belief).

**Proven money hooks (bank):** Investment ("I tried X for 3 years before…") · Scam ("I thought it was a scam…") · POV · Founder (name + title overlay) · Emotional · Cognitive dissonance ("why did nobody tell me?") · Identity ("if you're over 40…" = self-selection).

**6 curiosity generators (usually off the mechanism):** Metaphor (naturals best) · Paradoxical question · Characterization/nickname · Testable proof ("press your shin 5s…") · Quiz · Surprising culprit ("the problem behind the problem").

**Hook gut-check:** watch `visual → speech → visual`. If not instantly clear + aligned, the hook fails — no partial credit for a clever line over a dead visual. Cold hook = **no product**.

**Common hook fails to flag:** generic "talks to everyone"; spoken/visual/text misaligned; product in a cold hook; optimizing the text while ignoring the visual; only one hook (needs 3-5 distinct-visual variants in separate ad sets — Andromeda, not 3-in-one-ad-set); invented curiosity that never connects to the mechanism.

Source: M4 `04-Modulo-Hooks.md`; `experts-offers-hooks.md` (hook archetypes, hook/hold rate, Zeigarnik/open loops).

---

## 5. The 12 frameworks — beat checklist for adherence scoring

Map each script line to a beat; a missing/weak beat = adherence dock. (Each acronym letter = one beat.)

1. **Bandwagon / CROWD** — Call out movement · Reject old way · Onboard new way · Wave proof · Direct viewer (benefit in the CTA). *Awareness: Solution/Product.*
2. **Industry Contrarian / DISRUPT** — Declassify secret · Industry failure · Solution · Reinforce evidence · Upstage competition · Provide proof · Trigger movement. *Problem/Solution.*
3. **Listicle / CURE** — Curiosity (list hook + reason for the number) · Uncover failures · Remedy · Evidence · Engage. *Problem-aware.*
4. **Founder / FOUNDER** — Feature founder · Opposing force · Unlocking idea (eureka) · Numbers · Destiny · Engage. *Unaware/Problem.*
5. **How-to-X-without-Y / SIMPLE** — State the escape · Identify pain · Minimal solution · Prove (because→so) · Lifestyle win · Escape CTA. *Solution-aware.*
6. **Organic / PURE** — Problem uncovered · Unfiltered chaos (day-diary scenes) · Real evidence · Effortless freedom. *Any cold.*
7. **PAS** — Problem (their words) · Agitate (loss aversion + social-proof gap) · Solution (unique mechanism + fast relief + proof; identity shift close). *Problem-aware.*
8. **Ugly Ads / UGLY** — NOT a structure; a filter over any framework. 3 questions: make it simpler (≤5 words, cut 70%, 10-yr-old test) · show it cheap (vertical, natural light, Paint graphics) · opposite of the competitor. *TOFU cold.*
9. **Founder Objections / PROVE** — Problem (raw truth) · Reframe (critics vs your identity) · Objection (verbalize the doubt) · Victory (crush with results) · Expand (bigger vision). *Product-aware.*
10. **Us vs Them / SHOW** — Set the challenge · Head-to-head showdown · Outcome & why (the feature that wins) · Win & CTA. *Solution/Product.*
11. **Triple G** — Goal (with concrete year) · Gap (missing piece) · Gains (product as bridge + proof). *Problem-aware.*
12. **TEASE** — Tease (impossible claim) · Engage · Advantage · Satisfy (clever resolution) · Encourage (CTA + urgency/bonus). *Unaware/Problem.*

**Framework-choice check:** was it chosen by avatar + awareness + available psychological asset (social proof / founder / mechanism) — or "because it's cool"? The latter is a Trinidad violation (criterion 4). Source: M3 §1-2.

---

## 6. Clarity, pacing & single-message

- **Single-message (Trinidad):** one avatar, one angle, one promise. Hedging across two avatars or stacking three unrelated benefits = dock criterion 4. The framework is the vehicle; the message rides it.
- **UGLY clarity test:** could a 10-year-old follow it? Is 70% of the words cuttable? Say it in ≤5 words where possible; replace lines with text cards where sharper.
- **Slippery slide (Sugarman):** every line's only job is to earn the next. Flag any line that doesn't move the viewer forward; flag feature-dumps and dead air.
- **VSL time budget (short-form):** hook 0-5s · problem+agitate to ~0:30 · mechanism · proof · offer/stack · CTA. Hooks carry ~80% of a VSL's performance. Source: `experts-offers-hooks.md` (VSL structure), M4/M3.

---

## 7. FFM readiness (measurability gate)

**FFM preset = the numbers the script will be judged on:** hook rate, hold rate, CTR, ROAS.

- **Hook Rate = 3-second video plays ÷ Impressions.** Benchmarks: ~20-25% table stakes · >30% good · >40% elite. Below ~20%, Meta raises CPMs. *Predict: is the first 3s strong enough to clear ~25%?*
- **Hold Rate = ThruPlays ÷ 3-second plays.** ~40-50% table stakes · >50% good. *Predict: does seconds 3-15 (agitation/retain) hold?*
- **Fix hook rate before hold rate** — nobody sees the message if they don't stop.
- **Variant discipline:** the script must ship **3-5 hooks with DISTINCT visual hooks**, each destined for a **separate ad set** (Andromeda variation). Three hooks in one ad set tests nothing → dock.

Source: `experts-offers-hooks.md` (hook/hold rate formulas + benchmarks); M4 (FFM link); FFM preset (INDEX).

---

## 8. Redline conventions & rewrite rules

- Mark lines: ❌ hard defect (breaks a non-negotiable) · ⚠️ soft defect (weak, improve) · ✅ keep.
- Every fix names the rule it enforces ("product in cold hook — M4", "no mechanism, stage-4 — Schwartz").
- Rewrite **keeps the brand's avatar/angle** unless the strategy itself is the bug (then say so explicitly).
- Never invent proof/stats/testimonials/mechanisms — mark `[NEEDS REAL PROOF]` / `[NEEDS REAL VoC]` where the brand must supply them.
- Rewrite in the **same language** as the draft (ES/EN).
- Rewrite ships brief-ready: framework beats labelled + 3-5 distinct-visual hooks + a specific CTA with risk-reversal.

---

## 9. Fast QA checklist (MLO's own, from M3 §4 + M4 §7)
- [ ] Hook speaks to ONE avatar and stops the scroll in 0-3s.
- [ ] Curiosity loop opened by contrast; 4 components aligned; strong visual; no product in a cold hook.
- [ ] Unique **mechanism** visible (why it works when nothing else did).
- [ ] **Proof** present (study / social proof / demo), language from real reviews.
- [ ] **CTA** has a reason to act now (scarcity / risk-reversal).
- [ ] Framework beats all present, chosen by avatar/awareness.
- [ ] Awareness × sophistication matched (mechanism if ≥3; no offer-to-unaware).
- [ ] 3-5 distinct-visual hooks for separate ad sets.
- [ ] Passes the `visual→speech→visual` gut-check.

---

## Sources

**MLO Scripting Playbook** (`/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/`):
- `01-Modulo-Frameworks-y-Script-to-Brief.md` (M3) — the 12 frameworks, the 3 rules, anatomy of a winner, Script→Brief, quality checklist, common errors.
- `04-Modulo-Hooks.md` (M4) — hook mechanics, 4 components/alignment, 6 viral formats, 6 curiosity generators, proven money hooks, 5-step process, quality checklist.
- `00-INDEX-Sistema-Scripting-MLO.md` (M1/INDEX) — Trinidad, awareness, 3A, FFM preset, message-first philosophy.
- `02-Modulo-Libreria-Prompts-IA-MLO.md` — FFM defined as hook rate / CTR / ROAS success metric.

**Reused expert brain** (`/Users/mlo/.claude/skills/mlo-winner-strategist/reference/`):
- `experts-direct-response.md` — Schwartz Awareness × Sophistication grid (master cheat-sheet), Ogilvy (headlines = 80%, specifics), Halbert (starving crowd, AIDA), Hopkins (reason-why, test everything), Sugarman (slippery slide, triggers), Cialdini (7 principles).
- `experts-offers-hooks.md` — Hook Rate / Hold Rate formulas + benchmarks + diagnostic, unique mechanism, short-form VSL structure & time budget, Hormozi value equation, hook archetypes, Zeigarnik/open loops, the "Winner Ad Stack".

**External (via the reused files, URLs cited there):** insights.vaizle.com & sovran.ai (hook/hold rate), thrivethemes.com/adcrafty.ai (VSL), prealgo.com (hook archetypes), kingeshop.com/leadgen-economy (Schwartz), VWO (specific-CTA +28%).
