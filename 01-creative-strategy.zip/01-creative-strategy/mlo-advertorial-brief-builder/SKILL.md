---
name: mlo-advertorial-brief-builder
description: >-
  Formateador técnico que convierte un ángulo publicitario en un Brief de Producción de Advertorial
  escalable (Unaware/Problem Aware) para el equipo de diseño/edición de MLO Growth, con plantilla
  cerrada. ALWAYS use this skill (ES/EN) cuando Marcel o un estratega creativo (Facu, Marc, Xavi,
  Andrey) pidan: "brief de advertorial", "brief advertorial para [marca]", "formatea este ángulo",
  "brief Unaware/Problem Aware", "advertorial escalable para [marca]", "clona este winner a [marca]",
  "brief de producción para el equipo creativo", "brief nativo tipo editorial", o convertir un
  ángulo/concepto de advertorial en brief listo para producción. Trigger también con parciales como
  "hazme el brief de esto", "adáptame este esqueleto a [marca]", "sácame 2-3 briefs de advertorial".
  Es la skill del ejercicio semanal de advertorials cross-brand. NO reemplaza mlo-ad-brief-builder (ads
  directos); esta es para advertorials nativos con funnel de dos piezas (ad ligero → advertorial largo).
---

# MLO Advertorial Brief Builder

Convierte un ángulo publicitario en un **Brief de Producción de Advertorial Escalable** estandarizado, listo para diseño/edición. El formato imita contenido nativo (editorial, UGC, noticia, comentario de red social) para romper la ceguera publicitaria, y separa lo que va en el **ad** de lo que va en el **advertorial largo**.

## Regla de oro de formato

Cuando generes el brief final, **empieza directamente en la línea `---` de apertura y termina en la `---` de cierre. Sin introducciones, saludos, explicaciones ni comentarios.** Sigue el orden estricto de los bloques de la plantilla. (Todo el análisis previo o las notas al usuario van FUERA del bloque del brief, nunca dentro.)

## Inputs que recibes

- **Marca** — nombre.
- **Producto** — qué vende.
- **Ángulo** — la idea/psicología (mito desmentido, alerta de patrón, descubrimiento, historia relacionable…).
- **Nivel de Conciencia** — Unaware / Problem Aware.
- **Mecanismo** — cómo funciona el producto (la lógica/ciencia que blinda el Beat 3). Debe ser VERDADERO y defendible por el cliente.
- **Oferta/CTA** — gancho de precio o acción.
- **Referencia apalancada** *(opcional pero recomendado)* — el winner que estás clonando: hook + primeras líneas + formato + tiempo activo. Si no hay, usa "esqueleto genérico +1100".
- **FORMATO** — Vídeo UGC/VSL 30-60s · Estático · Screenshot/Comentario nativo · Carrusel.

Si falta el **Mecanismo** o la **Oferta/CTA**, pídelos antes de generar (sin ellos el brief sale genérico). El resto puedes inferirlo del ángulo.

## Principio funnel de dos piezas (REGLA DURA)

Los advertorials escalables son **dos piezas**, no una:

1. **El ad (creativo de Meta)** = la punta. Su ÚNICO trabajo es vender el **clic**, no cerrar la venta. Va ligero: hook + un roce del síntoma + prueba social nativa + CTA al artículo.
2. **El advertorial (landing/artículo)** = donde los **4 beats respiran completos** y se cierra la venta.

**Los 4 beats NO se meten desarrollados dentro del ad.** Cuánto del esqueleto entra en el ad depende del FORMATO:
- **Vídeo UGC/VSL 30-60s:** recorre los 4 beats exprés (cada beat en 2-3 frases).
- **Estático / Screenshot / Comentario nativo:** SOLO hook + prueba social nativa + CTA.
- **Carrusel:** ~1 beat por tarjeta + cierre con CTA.

Regla mnemotécnica: **el ad sella el clic, el advertorial cierra.**

## El esqueleto maestro (cómo funciona el advertorial largo)

Cada advertorial se construye sobre 5 beats. Los beats 1-4 son el cuerpo; el 5 es el puente:

1. **Hook / Titular** — rompe la ceguera. NO nombra producto ni categoría. Entra por: alerta de patrón, mito desmentido, descubrimiento o historia hiper-relacionable. Se lee como titular de medio, no como copy de ad.
2. **Beat 1 — El Síntoma** — nombra el dolor que la persona ya siente y escala la consecuencia de no resolverlo. Cero producto.
3. **Beat 2 — El Mito / Error Común** — por qué lo que ha intentado antes falló, y que no es culpa suya (desactiva la auto-culpa).
4. **Beat 3 — El Nuevo Mecanismo** — la verdadera raíz del problema, usando la lógica/ciencia del producto. Convierte Unaware→Problem Aware→Solution Aware. Sin mecanismo creíble, el advertorial es un ad disfrazado.
5. **Beat 4 — Introducción Orgánica** — el producto aparece SOLO ahora, como la única consecuencia lógica de la raíz recién explicada. No "compra esto", sino "esto hace X que las otras opciones no hacían".
6. **CTA suave** — puente, no puerta. Invita a seguir leyendo el artículo / probar el método / hacer el test. La conversión ocurre en la landing.

## Guardarraíles de calidad

- El producto **no puede aparecer antes del Beat 4**.
- El **mecanismo tiene que ser verdadero y defendible** por el cliente — nada de claims que no pueda respaldar (ojo especial en salud, suplementos, resultados).
- **Prueba social nativa creíble:** resultado específico + plazo corto + aspiracional, en formato de comentario/red social real (foto, timestamp, reacciones). Es el activo que más rompe la ceguera.
- **Cero logos al inicio**; estilo nativo; tipografía de sistema.
- Un mismo esqueleto → N variaciones cambiando solo **hook + escena**. Ahí está la escala de producción.

## PLANTILLA CERRADA (OUTPUT REQUERIDO)

Rellena y devuelve exactamente esta estructura. En **la sección 2b incluye SOLO la línea que corresponde al FORMATO** indicado en los inputs.

```
---
## 📑 BRIEF DE PRODUCCIÓN: ADVERTORIAL ESCALABLE
**[MARCA]:** {Insertar Marca}
**[CONCEPTO]:** {Insertar nombre del ángulo}
**[NIVEL DE CONCIENCIA]:** {Unaware / Problem Aware}
**[ARQUETIPO]:** {Estático+comentario · UGC how-to · VSL "2 errores/raíz real" · Testimonial/transformación · Founder story · Advertorial-artículo largo}
**[FORMATO]:** {Vídeo UGC/VSL 30-60s · Estático · Screenshot/Comentario nativo · Carrusel}
**[REFERENCIA APALANCADA]:** {winner: hook + tiempo activo — o "esqueleto genérico +1100"}

### 1. 🧲 HOOK / TITULAR (Frame 0-3s) · VA EN EL AD
*Objetivo: Romper la ceguera publicitaria simulando contenido nativo o editorial.*
* **Opción Visual A:** [Escena visual UGC o captura de red social/noticia de alta retención]
* **Opción Visual B:** [Escena visual alternativa de alta retención]
* **Texto en Pantalla / Gancho:** "{Titular o copy principal impactante — sin nombrar el producto}"

### 2. 📝 GUION DEL ADVERTORIAL (Landing/artículo · 4 Beats)
*Los 4 beats se desarrollan en el advertorial largo DETRÁS del clic — NO se meten enteros en el ad.*
* **Beat 1 (El Síntoma):** {Copy/voz en off sobre el dolor que siente el avatar}
* **Beat 2 (El Mito / Error Común):** {Por qué lo que intentó antes falló — no es culpa suya}
* **Beat 3 (El Nuevo Mecanismo):** {La verdadera raíz, con la lógica/ciencia del producto}
* **Beat 4 (Introducción Orgánica):** {El producto como consecuencia lógica de esa raíz}

### 2b. ✂️ QUÉ ENTRA EN EL AD (compresión según FORMATO)
*Regla: el ad sella el clic, el advertorial cierra.*
* {Insertar SOLO la línea del FORMATO elegido:}
  * Vídeo UGC/VSL 30-60s → recorre los 4 beats exprés (hook → síntoma → mito+mecanismo en una frase → prueba social nativa → CTA).
  * Estático / Screenshot / Comentario nativo → SOLO hook + prueba social nativa + CTA.
  * Carrusel → ~1 beat por tarjeta + cierre con CTA.

### 3. 🎯 LLAMADO A LA ACCIÓN (CTA) · VA EN EL AD
* **Texto del Botón / Enlace:** "{Insertar Oferta/CTA}"
* **Pauta Visual Final:** [Qué se muestra para incentivar el clic hacia el advertorial largo]

### 4. 🎨 NOTAS DE EDICIÓN PARA EL EQUIPO CREATIVO
* **Estilo Visual:** Formato nativo (TikTok/UGC), captura de tweet/noticia o interfaz de blog. Cero logos al inicio. La prueba social en comentario nativo es el activo central.
* **Tipografía:** Fuentes de sistema (ej. Arial, Inter, Helvetica) para que no parezca un anuncio tradicional.
---
```

## Sistema ganador de referencia (bicheo 9 winners — Based Supplies)

Patrón validado sobre 9 winners del mismo advertiser (3 productos, múltiples problemas, ads de 100-480+ días). La espina no se toca; se clona cambiando villano, raíz nombrada y resultado/prueba al avatar de la marca.

**La espina (constantes):** villano industria/sintético ("lo que no te cuentan" / "el tratamiento que usas te empeora") + hook no-producto + mecanismo como educación con **raíz nombrada** + producto natural/bioidéntico que reemplaza·reconstruye + resultado con plazo (timeline escalado) + escasez/garantía + formato nativo.

**Los 6 arquetipos (elige uno en [ARQUETIPO]):**
1. **Estático + comentario nativo** — hook alerta/miedo + prueba en comentario FB.
2. **UGC how-to educativo** — hook curiosidad/beneficio + listicle de ingredientes + creador prueba ("Age: X") + demo.
3. **VSL "2 errores / raíz real"** — hook Problem-Aware + mata alternativas + mecanismo pseudocientífico + timeline + garantía + autoridad.
4. **Testimonial / transformación** — hook emocional 1ª persona + punto bajo + escepticismo superado + prueba en directo.
5. **Founder / origin story** — founder narrador + arco de origen + autoridad prestada + prueba por volumen + trust de comunidad.
6. **Advertorial-artículo largo** — editorial 1ª persona (estructura abajo).

**Menú de hooks:** alerta/miedo · secreto/beneficio · síntoma+esperanza · emocional 1ª persona · "¿qué pasaría si usas X durante [plazo]?" · "la raíz real de [problema]".

**Menú de pruebas:** comentario nativo · creador/"Age:X"/sin maquillaje · testimonial · testimonials apilados · estudio+stat · autoridad/experto · mentor · volumen.

**Estructura del advertorial largo (para el Beat "GUION" cuando el arquetipo es artículo):** lead confesional → momento del síntoma (especificidad brutal) → espiral de fallidos/mito → punto de giro con mentor → mecanismo/raíz + metáfora vívida → producto introducido nativo → journey honesto con timeline realista (incluye lo feo) → reflexión + producto explícito + CTA-acción.

Un mismo producto se **re-angula por problema/avatar** (un producto → N advertorials).

## MODO LANDING — brief de la advertorial-landing (listicle "5 razones")

La skill produce **dos tipos de brief**: **brief de AD** (plantilla de arriba, la punta que vende el clic) y **brief de ADVERTORIAL-LANDING** (la página a la que apunta el ad y que cierra la venta). Cuando el deliverable sea la landing, usa este molde.

**Esqueleto común de la advertorial-landing** — validado sobre 6 landings de Based Supplies (all-in-one, skincare-4, skincare-5, skincare-80, skincare-105, skincare-772) que cubren ángulos distintos (piel seca genérica · anti-Botox · eczema · psoriasis) con el MISMO molde. Nota de mecanismo: la "raíz nombrada" de la Razón 1 puede ir por carencia ("tu piel/scalp está hambriento de X") o por sabotaje ("lo que usas te empeora / suprime en vez de alimentar"); ambas valen. La ARQUITECTURA es fija; lo que cambia entre variantes es el **ángulo/problema**, el **titular**, el **testimonio** y el **framing del mecanismo** (mismo villano, distinta "raíz nombrada"). Corren decenas de variantes numeradas (skincare-N), una por ángulo, con message-match al ad. Un producto → N landings, una por problema/avatar.

Template de salida (rellena todos los bloques; entre `---` y `---`, sin comentarios fuera):

```
---
## 📄 BRIEF DE ADVERTORIAL-LANDING
**[MARCA]:** {Insertar}
**[ÁNGULO / PROBLEMA]:** {el problema/avatar concreto — message-match al ad}
**[NIVEL DE CONCIENCIA]:** {Unaware / Problem Aware / Solution Aware}
**[PRODUCTO]:** {Insertar}
**[REFERENCIA APALANCADA]:** {landing-winner clonada}

### 1. Cabecera editorial
* **Logo** discreto arriba + **Titular por ángulo:** "{Por fin, un [X] natural que de verdad [beneficio] — sin [fricción]}" (o "Tu [problema] no es una condena. [reencuadre de raíz]")
* **Cita-testimonio (subtítulo):** "{nombre + edad + resultado específico y creíble}"
* **Fecha/hora editorial** (para que parezca artículo, no tienda) + **imagen hero** + línea "Nota: te va a encantar tanto que será parte de tu rutina".

### 2. Lead que iguala la conciencia
{"Ya sabes lo que es [dolor / haberlo probado todo]… pero esto es lo que nadie te cuenta: [reencuadre de raíz]. Vas a descubrir POR QUÉ te falla lo de siempre y cómo [mecanismo/remedio] lo cambia."} → cierra con: "Aquí están las 5 razones por las que miles se pasan a [producto]:"

### 3. Las 5 razones (listicle — el cuerpo)
* **Razón 1 · La raíz real / villano:** {"lo que usas te empeora" o "tu [X] está hambriento de [Y]"}
* **Razón 2 · Por qué falla lo tradicional + mecanismo:** {"tu [órgano/mente] no reconoce lo sintético/lo de siempre, pero sí [lo bioidéntico/natural/el método correcto]"}
* **Razón 3 · Por qué el NUESTRO (diferenciación):** {qué hace único al producto vs. "los demás usan la versión barata / hacen lo de siempre"}
* **Razón 4 · Resultados + testimonios reales:** {timeline Día 1 / Días 2-7 / Semanas 2-3 / Semana 4+ } + {3-4 mensajes reales con nombre} + **reframe de coste** ("menos de [X]/día" / "un pago vs. alquilar alivio")
* **Razón 5 · Escasez + identidad:** {proyecto/negocio pequeño y honesto, "casi sin stock / plazas", "no somos [el gigante del sector]"}

### 4. Cómo conseguirlo (pasos 1-2-3)
{pide hoy → llega/accede en [X] → pruébalo} + bundle/regalo + inventario/plazas limitadas.

### 5. Cierre de conversión
* **CTA:** "{Comprobar disponibilidad / Empezar ahora}" → a la PDP/checkout.
* **Prueba + autoridad:** logos "as seen in" (o prensa/resultados) + **reviews** (nota + nº) + **garantía** tejida.
---
```

**Adaptación cross-brand:** el villano, la "raíz nombrada", la diferenciación y la autoridad se sustituyen por los de la marca. Ej. English-Path: villano = academias/apps de rachas; raíz = "hablar es reflejo, no conocimiento; a tu ritmo y sin exponerte"; diferenciación = libros estructurados vs. Open English/academia; autoridad = resultados/testimonios/creadora; escasez = por lanzamiento/precio.

## Recordatorio final

Análisis, dudas o notas al usuario van SIEMPRE fuera del bloque `---…---`. El brief entregado empieza y termina en las líneas horizontales, sin nada más dentro.
