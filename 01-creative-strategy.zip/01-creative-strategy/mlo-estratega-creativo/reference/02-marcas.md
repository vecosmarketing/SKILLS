# Mapa de marcas · fuentes de datos

Cuenta Meta para el rendimiento, Creative Engine para el ADN, KPI Panel para el umbral de winner.

---

## Cuentas Meta

| Marca | Meta account ID | Moneda | Notas |
|---|---|---|---|
| Bala di Gala | `494771354724536` | MXN | México nativo. Creative Engine muy poblado. |
| B3TTER | `583365276040494` | EUR | |
| ZZEN Labs | `1755269528638876` | EUR | Google-driven; Meta secundario |
| 8hours | `1336199457035968` | EUR | Meta ROAS históricamente flojo |
| The Bridge | `1743450026034840` | **GBP** | |
| Moncho Moreno (ES) | `1083475165419487` | EUR | |
| Moncho Moreno (US) | `1166235702289816` | USD | LLC Miami |
| MUTO | `8923257947713583` | **GBP** | |
| Nurse is Love | `797602994895930` | EUR | |
| Ancestra | `1555748052135703` | EUR | |
| Alma Balance | `1212005727039270` | EUR | |
| HobbitAlf | `887307452432304` | EUR | |
| BEALGND | `2246575502221291` | EUR | |
| V-UP | `869452190813903` | COP | Colombia |
| i-Energy | `557682626318415` | COP | Colombia |
| Claudia & Julia | `288782593` | EUR | (handover) |

**Cuentas que el MCP de Meta NO alcanza** → usar el conector **Windsor `facebook`** (`action_values_purchase` + `spend`):
- **Chic&Love** → account_name `Serena - Varios` (la cuenta CHIC LOVE `175036476906707` está deshabilitada)
- **English-Path** → account_name `englishpath 14-GF` (EUR). Las cuentas `1828407267889073` (Aleph, USD) y `1314578009964501` (TecDo) no son consultables.

Antes de asumir que una cuenta no responde, comprueba `is_queryable` con `ads_get_ad_accounts`.

---

## KPI Panel (define qué es winner)

Cada marca tiene el suyo. **Ruta:** portal de cliente en Notion → apartado **Links** → Sheet *"Panel de KPIs META — [Marca]"* → pestaña **⭐ KPIs Objetivo**.

Contiene unit economics y los umbrales de corte: **ROAS objetivo**, **breakeven ROAS**, **CPA objetivo**, AOV y margen por producto.

SOPs de referencia en Notion:
- *SOP — Panel de KPIs (Meta Ads)* → qué es y cómo se lee
- *M01.B — KPI Panel: Construcción y Entrega durante Onboarding* → cómo se construye para marca nueva
- *SOP — Ecommerce Paid Media: KPI Panel & Unit Economics Calculator*

⚠️ **Antes de calcular hit rate, confirma si el umbral del panel está en ROAS de Meta o en ROAS de caja.** Si es de caja y lo comparas contra el `purchase_roas` de la API, el hit rate saldrá inflado. Cuando no lo puedas confirmar, dilo en la respuesta.

---

## Creative Engine (el ADN del creativo)

Una DB por marca, dentro del portal de cliente. Ej. Bala di Gala: `collection://790c0492-f9ee-4d1a-9c93-7792c558c50c`.

Campos que importan para el análisis:

| Campo | Uso |
|---|---|
| `Brief ID` | **clave de unión** con el nombre del ad en Meta |
| `Ad Framework` | hit rate por framework |
| `Funnel Placement` (TOFU/MOFU/BOFU) | mezcla de embudo; explica el churn |
| `Awareness` (Unaware→Most Aware) | mezcla de conciencia |
| `Buyer Persona` | hit rate por persona |
| `Net New / Iteration` | ratio de exploración vs explotación |
| `Format` (Video/Static/Carousel) | coste de producción vs retorno |
| `Status` | qué está lanzado y qué en producción |

**Naming convention documentada:**
```
[BriefID]_[Format]_[Funnel]_[Awareness]_[Framework]_[NetNew|Iter]_[CM]
```
En la práctica varía por marca. Extrae siempre el **Brief ID** (lo que va antes del primer `_`, ej. `J044.1/26`, `A013/26`, `JL0015/26`) y usa eso para unir; el resto del nombre tómalo como pista, no como verdad. El ADN fiable está en el Creative Engine, no en el nombre.

---

## El objetivo (facturación / clientes nuevos)

⚠️ **No hay conector de Triple Whale en este entorno.** Windsor solo tiene `facebook`, `google_ads` y `googleanalytics4`. Así que el objetivo **no se lee solo**: entra por una de estas tres vías, en este orden:

1. **Lo da quien pregunta** — es lo normal: el objetivo de facturación o de beneficio lo fija la marca, no se deduce de los datos.
2. **Triple Whale → SIEMPRE vía Google Chrome** (`mcp__claude-in-chrome__*`). No hay conector ni API: se abre el dashboard en el navegador y se lee. Es la vía oficial, no un apaño.
3. **Shopify vía Chrome** (reporte ShopifyQL en el admin) como alternativa para facturación y clientes nuevos.

Metodología que se mantiene: para NCPA usa clientes **nuevos** (NCP), no `omni_purchase` de Meta.

---

## Volumen contratado por pod (Creative Scale)

| Pod | Inversión | Creativos/mes contratados |
|---|---|---|
| Foundation | 10-30k | 25-30 |
| Growth | 30-60k | 40-50 |
| Scale | 60k+ | 50-65 |

Es el **suelo contractual**, no el número que la marca necesita. Compara siempre contra el forecast y muestra la brecha.
