# Cohortes, proyección y gráficas

El método completo de Oli Hudson (*Creative Forecasting Masterclass*, DC Diaries Ep 76). El fichero `01-formulas.md` da la foto de un mes; **esto da la película**.

---

## 1. Análisis de supervivencia por cohortes

El churn como ratio simple mezcla winners de edades distintas y sale sesgado. El método correcto es **cohortar**.

### Cómo se construye

1. Saca los **90 días** de inventario de ads.
2. Clasifica cada ad en tres estados, no en dos:

| Estado | Definición |
|---|---|
| **Hit** | superó el umbral del KPI Panel |
| **Performing** | por debajo del umbral pero sigue activo y con gasto |
| **In testing** | aún no ha alcanzado el suelo de gasto — no cuenta en el hit rate |

3. Agrupa los hits por **mes de lanzamiento** = su cohorte.
4. Para cada cohorte, mide qué % sigue siendo hit en M+1, M+2, M+3.

```
Cohorte        M0     M+1    M+2    M+3
Abril         100%    58%    31%    12%
Mayo          100%    62%    35%     —
Junio         100%    55%     —      —
```

### Qué sacas de ahí

- **Half-life** = el punto donde la curva cruza el 50%. En el ejemplo, entre M+1 y M+2 → ~35-40 días. Benchmark de mercado: **27 días**.
- **Churn B** = 1 − supervivencia media a M+1, ponderada por cohorte. Mucho más fiable que el ratio de un solo periodo.
- **Tendencia**: si las cohortes recientes sobreviven menos que las antiguas, el sistema se está degradando aunque el hit rate aguante. Es una alarma temprana que el ratio simple no ve.

Usa **mediana**, no media: un winner eterno distorsiona.

---

## 2. Proyección 6-12 meses (modelo recursivo)

El forecast de un mes asume winners actuales fijos. Para proyectar hay que **encadenar los meses**, porque los winners de cada mes son los supervivientes del anterior más los nuevos.

```
W(0) = winners activos hoy

Para cada mes t = 1..12:
    W_necesarios(t)     = inversión_objetivo(t) / gasto_medio_por_winner
    W_supervivientes(t) = W(t−1) × (1 − churn_B)
    W_nuevos(t)         = max(0, W_necesarios(t) − W_supervivientes(t))
    Lanzamientos(t)     = W_nuevos(t) / hit_rate × (1 + buffer)
    W(t)                = W_supervivientes(t) + W_nuevos(t)
```

Asume hit rate, churn y gasto por winner **constantes**, salvo lo que corrija el escenario (punto 4).

**Lo que revela y que el cálculo mensual esconde:** los lanzamientos requeridos **aceleran más rápido que el gasto**. Duplicar la inversión no duplica los creativos: los multiplica más. Por eso hay que planificar recursos con meses de antelación — pasar de 100 a 200 creativos/mes no se hace en dos semanas, y menos en formatos que requieren rodaje.

**El buffer baja con la confianza.** Empieza en 20% y bájalo hacia 10% conforme el modelo demuestre acierto en esa marca.

---

## 3. Las gráficas (el entregable visual)

Genera siempre que se pida un forecast. Inline con `show_widget`; para cliente, con el template de deck MLO (fondo `#090909`, verde `#4AFF53`).

### Gráfica 1 · Curva de forecast
- **X** = lanzamientos/mes · **Y** = nivel de gasto sostenible
- Muestra la curva de esta marca con sus tasas actuales.
- **Lectura:** cuanto más plana, peor — significa que hacen falta muchísimos creativos para mover poco el gasto.

### Gráfica 2 · Estado actual vs estado deseado ⭐
La más importante. **Dos curvas superpuestas** en los mismos ejes:
- curva con el **hit rate actual**
- curva con el **hit rate objetivo** (normalmente 10-15%)

**Lectura:** el gasto crece mucho más rápido **y** hacen falta menos activos para cada salto. Es el argumento visual de por qué arreglar el hit rate sale más barato que comprar volumen. Es la gráfica que se le enseña al cliente.

### Gráfica 3 · Curva de supervivencia
- **X** = días desde el lanzamiento · **Y** = % de winners aún vivos
- Línea horizontal en el 50% marcando el **half-life**.
- Una curva por cohorte para ver si el sistema mejora o se degrada.

### Gráfica 4 · Requerimiento mensual
- Barras: **creativos requeridos** vs **creativos contratados**, mes a mes 6-12 meses.
- El área entre ambas es **la brecha**. Es la conversación con el cliente.

---

## 4. Scenario planning

El forecast plano es mentira: el calendario comercial mueve las variables. Antes de dar una proyección, mapea los hitos de los próximos meses y aplica modificadores:

| Evento | Qué se mueve | Dirección |
|---|---|---|
| **Oferta fuerte / Black Friday** | gasto medio por winner ↑, hit rate ↑ | el descuento mejora conversión → cada winner aguanta más → **hacen falta menos creativos** |
| **Producto nuevo** | hit rate ↓ durante 2-3 meses | el proceso creativo aún no tiene aprendizajes → **hacen falta más creativos** |
| **Entrada en mercado nuevo** | hit rate ↓, gasto por winner ↓ | creadores locales, ángulos sin validar |
| **Escalado agresivo de presupuesto** | churn ↑ | más frecuencia → los winners mueren antes |
| **CPA objetivo más estricto** | hit rate ↓ | menos ads superan el listón |

Presenta la proyección en **tres escenarios** — base, optimista, conservador — no como número único. Un número único invita a discutirlo; tres escenarios invitan a decidir.

---

## 5. Coste del aprendizaje y retorno sobre el capital creativo

Cierra el círculo con la pregunta que nadie hace: **¿el testing sale rentable?**

```
coste_del_aprendizaje  = creativos_no_winners × coste_unitario_producción
coste_real_por_winner  = (creativos_lanzados × coste_unitario) / winners
retorno_capital_creativo = margen de contribución generado por los winners
                           / coste total de producción del periodo
```

**Cómo se lee:**
- Si `coste_real_por_winner` > margen que aporta un winner medio → el motor **destruye valor**. Hay que subir hit rate o bajar coste unitario antes de tocar nada más.
- Compara `coste_real_por_winner` **por formato**. Un estático puede costar 50 € y rendir 300 €, y un vídeo costar 500 € y rendir 400 €. Aunque el vídeo tenga mejor ROAS, el estático es mejor inversión. Es un cálculo que casi nadie hace y que cambia el reparto de producción.

**Referencia de presupuesto:** 25% del media budget a producción en el tramo 30-100k/mes; ~10% por encima de 100k. Si la marca está muy por debajo, ese es el cuello de botella real.

---

## 6. Churn real con DOS ventanas (cuando no hay cohortes completas)

Si no puedes reconstruir cohortes por mes (p.ej. Windsor no da fecha de lanzamiento), calcula el churn con **dos ventanas comparadas** — es lo mínimo para que NO sea un proxy:

1. Pull de winners en la **ventana actual** (últimos 30d) y en la **ventana anterior** (30d previos).
2. `churn_B = 1 − (winners de la ventana anterior que siguen siendo winners en la actual) / winners de la ventana anterior`.
3. La cruza por Brief ID / ad ID entre las dos ventanas.

Con un solo snapshot NO hay churn real: lo que se puede dar es un **proxy** (ej. "22 de 41 winners de la ventana ya no están activos") y hay que **marcarlo como proxy**, no como churn medido. Nunca lo presentes como dato firme.

**Regla:** siempre que sea posible, tira las dos ventanas. Si solo hay una, di explícitamente "churn = proxy, requiere histórico" y usa el modelo (40%) como referencia, no como verdad.
