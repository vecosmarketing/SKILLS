# El proceso · quién hace qué

El sistema solo funciona si alguien concreto lo ejecuta en una fecha concreta. Esto es el reparto.

---

## Tabla de responsabilidades

| Pieza | Responsable | Cuándo |
|---|---|---|
| **Ejecutar la skill** y sacar los números de la marca | **Creative Strategist** de esa marca | Cada lunes |
| **Validar la lectura de cuenta** (¿esto cuadra con lo que veo?) | **Media Buyer** de esa marca | Cada lunes, mismo día |
| **Mantener el Panel Creativo** en el portal de la marca | Creative Strategist | Actualiza semanal · revisa en cierre de CM |
| **Recalcular el forecast del mes** y compararlo con lo contratado | Creative Strategist → presenta a Marcel | Día 26 (cierre CM) |
| **Higiene del naming** al subir ads | **Media Buyer** | En cada subida |
| **Definir el umbral de winner** (KPI Panel) | Quien hace el onboarding de la marca | Al onboardear + revisión trimestral |
| **Mantener la skill** (fórmulas, benchmarks, cuentas nuevas) | **Marcel** | Al entrar marca nueva o cambiar el método |
| **Mantener el SOP y los dos módulos** | **Marcel** | Cuando cambia la skill |
| **La conversación con el cliente** cuando aparece brecha | **Marcel** | Cuando el forecast supera lo contratado |

---

## El punto de escalado

Cuando el forecast dice que la marca necesita **más creativos de los que tiene contratados**, el Creative Strategist **no se lo come ni lo absorbe en silencio**. Lo sube a Marcel con el número calculado.

De ahí salen tres decisiones posibles, y hay que nombrarlas todas:
1. **Subir el pod** (más producción contratada)
2. **Subir el hit rate** (trabajo de estrategia: personas, ángulos, gaps de formato)
3. **Bajar el objetivo** del cliente

No decidir es decidir la cuarta: incumplir el objetivo. Eso también hay que decirlo.

---

## Regla de creación y mantenimiento

**Las skills y los SOPs los crea y mantiene Marcel** (o Claude a petición suya). El equipo **consume y reporta fricción**, no edita.

Si cada estratega ajusta el cálculo a su gusto, en tres meses hay cinco versiones del mismo número y el sistema deja de servir para comparar marcas entre sí — que es la mitad de su valor.

Cuando alguien detecte que una fórmula no encaja con la realidad de su marca: **lo reporta, no lo cambia.**

---

## Al responder desde la skill

Si quien pregunta es un **Creative Strategist** → céntrate en hit rate de brief, mix semanal e iteraciones.
Si es un **Media Buyer** → céntrate en churn, salud de cartera, concentración de gasto y si hay inventario para escalar.
Si es **Marcel** → añade siempre la brecha contrato vs modelo y la lectura comercial.

Y cuando el resultado active el punto de escalado, **dilo explícitamente**: *"esto hay que subirlo a Marcel"*.
