# Calidad del dato · limpiar antes de calcular

Los números creativos se falsean con una facilidad tremenda. Esta limpieza es **obligatoria** antes de dar cualquier KPI, y los avisos que genere van **en la respuesta**.

---

## Limpieza obligatoria (en este orden)

### 1. Duplicados de Meta → fuera del denominador
Patrones: `- Copia`, `- Copia 2…N`, `Copy of`, `- copia`.

Son **relanzamientos del mismo asset**, no creativos nuevos. Si los cuentas:
- el **hit rate baja** artificialmente (denominador inflado),
- el **churn sube** artificialmente (muertes duplicadas),
- el **volumen lanzado** parece mayor del real.

**Regla:** agrupa el ad "madre" y sus copias como **un solo creativo**; suma el gasto de todas.

Ejemplo real (Bala di Gala): `24/06_FLUX MITS 001` + `24/06_FLUX MITS 001 - Copia` = **1 creativo**, 346.000 MXN combinados. Contarlos como dos falsea todo.

### 2. Sufijos de versión → depende
`-v2`, `-v4`, `V1…V5` con **archivo distinto** = creativos distintos (Meta les da creative ID propio y alcanzan público nuevo) → **cuentan**.
Si es el mismo archivo relanzado → no cuenta.

### 3. Ads LEGACY y sin naming → segmentar, no descartar
Los ads que no siguen naming (`LEGACY_…`, `CATÁLOGO+STOCK`, nombres libres) **entran en el hit rate global** —son creativos reales que gastaron— pero **no** en el análisis por framework/persona/awareness, porque no se pueden unir al Creative Engine.

Reporta siempre el **% de gasto no atribuible**. Si supera el 30%, el análisis segmentado es indicativo, no concluyente, y hay que decirlo.

### 4. Ruido en el nombre → ignorar
Algunos ads llevan resultados escritos a mano en el nombre:
`J053/26 FLUX MITS HUESO V4_(DONE 07/07-13/07 (7 Días) ROAS 2.22x · CPA MXN 861 (26 ventas))`

Ignóralo para el cálculo (usa siempre la API), pero **anótalo**: es señal de que el equipo está haciendo a mano lo que este sistema automatiza.

### 5. Excluir del denominador
- Ads con gasto **por debajo del suelo** (no tuvieron oportunidad) → fuera de numerador y denominador.
- Campañas de **retargeting / bottom-funnel puro** cuando midas hit rate de prospección: su ROAS no es comparable. Sepáralas.

---

## Unidad de medida: ad o brief

Decide y **dilo explícitamente**:

- **Ad** → es lo que Meta distribuye y lo que fatiga. Es la unidad del **forecast**.
- **Brief** → es lo que produce el equipo creativo. Es la unidad para **juzgar la estrategia**.

Un mismo Brief ID puede aparecer varias veces en Meta (variaciones/hooks). Ej.: `J054.2/26` con 3 ad IDs distintos = **1 brief, 3 ads**.

Da los dos hit rates. Mezclarlos es la fuente nº1 de discusiones sin datos.

---

## Bloque de avisos en la respuesta

Cierra siempre con un bloque corto tipo:

```
⚠️ Calidad del dato
· 4 ads agrupados como duplicados (- Copia)
· 31% del gasto sin Brief ID → análisis por framework indicativo
· Umbral del KPI Panel sin confirmar (¿ROAS Meta o de caja?) → hit rate puede estar inflado
```

Si no hay avisos, dilo también: **"dato limpio"** es información valiosa.

---

## Naming recomendado (cuando pregunten cómo arreglarlo)

Corto, estable y suficiente para unir:
```
[BriefID]_[Format]_[Funnel]_[Awareness]_[Framework]_[NN|IT]
```

Reglas:
- **Buyer personas fuera del nombre** — ya están en el Creative Engine, se unen por Brief ID. Meterlas hace nombres de 200+ caracteres y con varias personas por ad no se puede atribuir a ninguna.
- **Prohibido `- Copia`** — si hay que relanzar, se renombra manteniendo el Brief ID.
- **Nada de resultados en el nombre** — eso lo da la API.
- **El Brief ID siempre primero.** Es la única parte innegociable: sin él no hay unión posible.
