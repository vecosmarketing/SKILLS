# Cómo entregas · nunca solo texto

Un muro de texto con números no se lee y no se decide sobre él. **Siempre que haya datos, hay visual.**

---

## Regla base

| Lo que piden | Cómo lo entregas |
|---|---|
| Un KPI suelto ("¿hit rate de X?") | Titular en una frase + el número grande + su benchmark al lado. Widget pequeño. |
| Panel de marca / "¿cómo va X?" | **Widget dashboard**: los 6 KPIs en tarjetas con semáforo + curva de supervivencia + el veredicto |
| Forecast / "¿cuántos creativos necesita?" | **Widget con las 4 gráficas** + la tabla contrato/modelo/brecha |
| Comparativa entre marcas | **Widget tabla** con semáforos por columna |
| Algo para enseñar al cliente | **Artifact** con el template de deck MLO |
| Una pregunta conceptual | Texto. No fuerces un gráfico donde no hay datos. |

Usa `mcp__visualize__show_widget` para lo inline (llama antes a `read_me` en silencio, sin narrarlo). Usa `Artifact` solo cuando sea para el cliente o el usuario pida algo compartible.

---

## Marca MLO

```
Fondo    #090909      Verde    #4AFF53
Texto    #FFFFFF      Alarma   #FF4A4A      Aviso  #FFC24A
```

Titulares en serif, datos en sans. Números grandes y con aire — el KPI es el protagonista, no la etiqueta.

Respeta el tema claro/oscuro del visor cuando el widget lo permita, pero el acento verde `#4AFF53` se mantiene siempre.

---

## Dashboard de marca — la estructura por defecto

1. **Titular** — una frase con el número que importa. *"B3TTER necesita 62 creativos este mes; el pod da 30."*
2. **Fila de tarjetas** — los 6 KPIs, cada uno con su valor, su benchmark y un semáforo 🔴🟡🟢
3. **La cadena del forecast** — los 5 pasos en horizontal, con el número de cada paso. Que se vea el razonamiento, no solo el resultado.
4. **Tabla contrato / modelo / brecha** — con la brecha destacada
5. **Gráficas** — las que apliquen (ver abajo)
6. **Diagnóstico** — 1 frase + 1-3 acciones
7. **Avisos de calidad del dato** — pequeño, al pie

---

## Las 4 gráficas (especificación visual)

**1 · Curva de forecast** — línea. X: lanzamientos/mes · Y: gasto sostenible. Punto marcado donde está la marca hoy.

**2 · Estado actual vs deseado** ⭐ — dos líneas. Gris apagada = hit rate actual. Verde `#4AFF53` = hit rate objetivo. **Sombrea el área entre ambas**: eso es lo que se gana arreglando el motor. Es la gráfica del cliente.

**3 · Curva de supervivencia** — línea descendente. X: días · Y: % de winners vivos. Línea horizontal punteada en el 50% y etiqueta con el half-life en el cruce. Una línea por cohorte si hay datos.

**4 · Requerimiento mensual** — barras agrupadas. Requerido vs contratado, 6-12 meses. La brecha en rojo.

---

## Reglas de lectura

- **Semáforo siempre.** Un número sin su benchmark al lado no dice nada. `8,2% 🟡` comunica; `8,2%` no.
- **El titular primero.** Si alguien solo lee la primera línea, tiene que salir sabiendo qué hacer.
- **Muestra el razonamiento del forecast**, no solo el resultado. La cadena de 5 pasos visible es lo que hace que el equipo confíe en el número y aprenda a calcularlo.
- **Nada de decorar.** Sin gradientes, sin iconos de relleno, sin gráficos 3D. Si un elemento no ayuda a decidir, fuera.
- **Móvil.** Tarjetas que se apilen, tablas anchas con scroll propio.

---

## Cuando falten datos

No dejes el hueco en blanco ni inventes. Marca la tarjeta en gris con `—` y una nota corta: *"falta umbral del KPI Panel"*. Un dashboard honesto con dos huecos vale más que uno completo con dos números inventados.

---

## Formato deck HTML (el "documento de volumen")

Además del widget inline, la skill produce un **deck HTML de una sola página, descargable** (tema oscuro MLO) cuando se pide el documento completo de volumen creativo. Es el entregable estrella para media buyers y estrategas.

**Estructura del deck** (en este orden):
1. **Hero** — el número que manda + una frase de "y esto qué significa". El héroe SIEMPRE es el €/winner, no el volumen.
2. **Inversión para el objetivo** — paid total/mes y split por canal (di si es solo-Meta o multicanal).
3. **Qué pushear por producto** — hit rate/ROAS/% gasto hoy vs propuesto/€ propuesto, con reasignación de presupuesto.
4. **Volumen por producto — MODO A (hoy) vs MODO B (target)** + gráfica.
5. **Los 6 KPIs** con semáforo y fuente en cada uno.
6. **Forecast** (cadena de 5 pasos) + tabla de escenarios (pesimista/base/optimista/hoy).
7. **Sensibilidad al hit rate** (20/15/10%).
8. **Curva de supervivencia** por tramo de gasto (winners ≥€50 → ≥€3.000).
9. **Diagnóstico** (semáforo).
10. **Recomendaciones priorizadas.**
11. **Avisos de calidad del dato** + **fuentes** al pie.

**Modo**: ofrece "resumen (1 pantalla)" o "deck completo" — no todo pide 11 secciones.

**Paleta/estilo del deck**: fondo `#090909`, card `#121212`, verde `#4AFF53`, texto `#EDEDED`, alarma `#FF4A4A`, aviso `#FFC64A`. Gráficas con Chart.js (CDN cdnjs). Fuente en CADA número; lo proxy/ausente en gris y marcado.
