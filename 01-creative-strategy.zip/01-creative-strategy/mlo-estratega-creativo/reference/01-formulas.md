# Fórmulas y definiciones exactas

Todo lo que calcula la skill. Si una definición no está aquí, no la improvises: pregunta.

---

## 0. Definiciones base

### Winner
```
winner = (gasto ≥ SUELO_GASTO) Y (ROAS ≥ UMBRAL_KPI_PANEL de la marca)
```
- **UMBRAL_KPI_PANEL**: se lee del KPI Panel de cada marca. NO hay valor global.
- **SUELO_GASTO**: por defecto **50 €** (o equivalente en la moneda de la marca). Existe para que el ad haya tenido oportunidad real. Si el AOV de la marca es alto, súbelo a ~1× el CPA objetivo.
- **Ventana**: 90 días para calibrar tasas; 30 días para el estado actual.

### Creativo lanzado
Un **ad único** publicado en el periodo. **Excluye**:
- duplicados de Meta (`- Copia`, `- Copia 5`, `Copy of…`) → son relanzamientos del mismo asset, no creativos nuevos;
- ads reactivados que ya se contaron en un periodo anterior.

Las variaciones de hook con archivo distinto **sí cuentan** (Meta les da creative ID propio y alcanzan audiencia nueva).

### Brief
Fila del Creative Engine. Un brief puede generar varios ads (variaciones, hooks). Se une por **Brief ID** al principio del nombre del ad.

---

## 1. Hit rate

### Hit rate de ANUNCIO (alimenta el forecast)
```
hit_rate_ad = winners / ads_lanzados_con_gasto_≥_suelo
```
⚠️ El denominador es **todo el set testeado que superó el suelo**, no el top-N por gasto. Coger solo los que más gastan infla el hit rate.

### Hit rate de BRIEF (juzga al estratega creativo)
```
hit_rate_brief = briefs_con_≥1_winner / briefs_lanzados
```

Calcula también, cuando haya datos suficientes, el hit rate **segmentado** por: framework, funnel placement, awareness, buyer persona y Net New vs Iteration. Ahí es donde están las decisiones.

---

## 2. Los tres churn

### Churn A — Vida media del winner (días)
```
vida_media = mediana(fecha_fin_como_winner − fecha_inicio_como_winner)
```
`fecha_fin` = el día que se apaga, o el día que cae bajo umbral de forma sostenida (≥3 días).
Usa **mediana**, no media: un winner eterno distorsiona la media.

Métrica hermana, la del vídeo de forecasting: **half-life** = días hasta que muere el 50% de la cohorte de winners actual.

### Churn B — % de winners que dejan de serlo (el que entra en el forecast)
```
churn_B = 1 − (winners del periodo N−1 que siguen siendo winners en N) / winners del periodo N−1
```
Se calcula en **mensual** (para el forecast) y en **semanal** (para vigilancia).

### Churn C — % de ads apagados bajo umbral
```
churn_C = ads_pausados_sin_llegar_a_winner / ads_pausados_totales
```
Es la foto del desperdicio. Complementa al test tax.

---

## 3. Volumen y eficiencia

```
creativos_lanzados_semana = ads únicos con primera impresión en esa semana
gasto_medio_por_winner    = suma(gasto de winners) / nº winners
test_tax                  = gasto en no-winners / gasto total   (%)
concentracion_top4pct     = gasto del 4% de ads que más gasta / gasto total
```

`concentracion_top4pct` es la métrica de **riesgo de cartera**. Si ese 4% sostiene >60-64% del gasto, la cuenta es frágil aunque hoy vaya bien.

---

## 4. El forecast — cuántos creativos necesita este mes

### Paso 0 — traducir el objetivo a inversión
El objetivo llega como **facturación** o como **beneficio neto a mantener**.

```
inversion_objetivo = facturacion_objetivo / MER_objetivo
```
(el MER/ROAS objetivo sale del KPI Panel de la marca)

Si el objetivo es mantener beneficio neto, resuelve primero qué facturación e inversión lo sostienen con el margen de la marca, y luego entra aquí.

### Pasos 1-5
```
1. winners_necesarios  = inversion_objetivo / gasto_medio_por_winner
2. winners_sobreviven  = winners_activos_hoy × (1 − churn_B_mensual)
3. winners_nuevos      = winners_necesarios − winners_sobreviven
4. creativos_a_lanzar  = winners_nuevos / hit_rate_ad
5. KPI_creativo_mes    = creativos_a_lanzar × (1 + buffer)     buffer = 0,10 a 0,20
```
Si el paso 3 sale ≤ 0, la marca ya tiene inventario para su objetivo: el mensaje es **"no necesitas más volumen, necesitas proteger lo que tienes"** — y ahí el foco pasa a iteración y diversificación de cartera.

Divide entre 4,33 para dar el número semanal.

### Presentación obligatoria
Siempre las tres cifras:

| | Creativos/mes |
|---|---|
| Contrato (pod) | X |
| Modelo (necesita) | Y |
| **Brecha** | **Y − X** |

Y la lectura: si Y > X, o se sube el pod o se sube el hit rate. Son las dos únicas palancas.

---

## 5. Ejemplo trabajado

Marca ficticia. Objetivo: **facturar 120.000 €/mes**. MER objetivo del KPI Panel: **3,0**.

```
Paso 0  inversión objetivo   = 120.000 / 3,0            = 40.000 €
Paso 1  winners necesarios   = 40.000 / 2.500           = 16 winners
Paso 2  sobreviven           = 10 × (1 − 0,45)          = 5,5 → 6
Paso 3  winners nuevos       = 16 − 6                   = 10
Paso 4  creativos a lanzar   = 10 / 0,08                = 125
Paso 5  + buffer 15%         = 125 × 1,15               = 144 creativos/mes
                                                        ≈ 33/semana
```

**Lectura:** con hit rate 8% y winners que aguantan 2.500 €, este objetivo pide 144 creativos/mes. Si el pod contratado da 45, hay una brecha de 99. Las opciones son tres y hay que decirlas: subir el pod, subir el hit rate, o bajar el objetivo.

**El mismo caso con el motor sano** (hit rate 15%, gasto por winner 4.000 €):
```
16 → 10 winners necesarios · sobreviven 6 · nuevos 4 · /0,15 = 27 · +15% = 31 creativos/mes
```

👉 **Esta es la enseñanza central de la skill:** entre un motor malo y uno bueno la diferencia no es 20%, es **4,6×** en volumen requerido. Por eso arreglar el hit rate siempre es más barato que comprar volumen.

---

## 6. Sensibilidad — qué palanca mover

Antes de recomendar "más creativos", comprueba cuál de las tres palancas mueve más:

| Palanca | Efecto | Coste de moverla |
|---|---|---|
| **Hit rate** | inversamente proporcional al volumen requerido | medio — es trabajo de estrategia (personas, ángulos, gaps) |
| **Gasto medio por winner** | inversamente proporcional a winners necesarios | alto — depende de TAM, oferta y calidad del top-funnel |
| **Churn B** | cuantos más sobreviven, menos nuevos hacen falta | medio — se baja subiendo la mezcla hacia arriba del embudo |
| **Volumen** | lineal | alto y recurrente — es el más caro |

Recomienda volumen **solo** cuando el hit rate ya está en benchmark. Si no, estás pidiendo hacer más de lo que no funciona.

---

## 7. €/winner target — derivado de la marca, no un número de libro

El forecast es hipersensible al **gasto medio por winner**. Usar un €700 genérico (benchmark) hace que el MODO B parezca arbitrario. Deriva el target de la **propia marca**:

1. Ordena los winners por **gasto sostenido** y mira el embudo de supervivencia por tramo (≥€50 → ≥€200 → ≥€700 → ≥€1.500 → ≥€3.000).
2. El **€/winner target** = lo que sostienen los winners que **sí aguantan el escalado** en esta cuenta (la mediana de los que llegan al tramo alto), no el promedio de todos.
3. Si casi ninguno sobrevive al escalado (ej. 3 de 41 llegan a €700), ese es **el hallazgo**: el problema no es producir, es que el winner no aguanta gasto. El €700 pasa a ser el objetivo a alcanzar, no un dato.

**Regla:** el €700 es solo **fallback** cuando no hay señal. Siempre que haya datos, el target sale de los winners reales de la marca.

---

## 8. Ingeniería inversa por PRODUCTO + MODO A vs MODO B

El forecast por marca es la foto; el forecast **por producto** es donde se decide el presupuesto.

**Por cada producto/línea** (atribuido por el naming / Creative Engine):
- hit rate, ROAS, % de gasto hoy, **% propuesto** (recomendación) y €/mes propuesto;
- reasigna presupuesto **desde** los productos bajo breakeven **hacia** los de mejor hit rate infrafinanciados;
- el volumen de creativos necesario por producto (pasos 1-5 con los números de ESE producto).

**Dos modos, misma inversión:**
- **MODO A — con los números de HOY** (€/winner real, churn real, variaciones/concepto real). Suele salir un volumen inviable → demuestra que el volumen no es la palanca.
- **MODO B — economía target** (€/winner derivado, churn objetivo, 3-4 variaciones/concepto). Mismo presupuesto, una fracción del volumen — porque cada winner rinde.

El contraste A vs B **es el mensaje**: el trabajo no es producir N conceptos, es convertir los que ya ganan en winners que sostengan el €/winner target.
