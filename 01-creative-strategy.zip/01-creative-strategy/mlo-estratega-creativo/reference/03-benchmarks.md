# Benchmarks y umbrales de alarma

Destilado de: *Creative Forecasting Masterclass (DC Diaries Ep 76)*, *The D2C Reset (Ep 55)*, *Meta Ads Creative Strategy 2026*, *Ad Creative Full Course (99ads)*. Sirven para **calibrar el juicio**, no para sustituir el KPI Panel de la marca.

---

## Tabla maestra

| KPI | 🔴 Alarma | 🟡 Aceptable | 🟢 Bueno | ⭐ Excelente |
|---|---|---|---|---|
| **Hit rate de anuncio** | <3% | 5% | 10% | 15% (techo real ~20%) |
| **Churn B mensual** | >53% | 45% | 40% | <35% |
| **Vida media / half-life** | <15 días | ~20 días | **27 días** | >35 días |
| **Test tax** | ~50% | 40% | <30% | <25% |
| **Concentración top 4%** | >70% del gasto | 64% | <50% | <40% |
| **Frecuencia en ad frío** | >2,0 | 1,8 | <1,5 | <1,2 |

**El 20% es techo.** Por encima de ~20% de hit rate, a escala, es más barato **hacer más** que **hacer mejor**. Por debajo de 10%, al revés: subir volumen es tirar dinero.

---

## Volumen

**Regla rápida:** ~**1 creativo nuevo por cada 1.000 € de inversión mensual**.
30k/mes → ~30 creativos. 100k/mes → ~100 creativos.

Es una aproximación grosera: el forecast de 5 pasos (`01-formulas.md`) siempre manda. Úsala solo para sanity-check.

**Gasto medio por ad:** 700-1.500 € es el rango típico por unidad de ad. Los winners reales aguantan 2.500-4.000 €.

**Para validar un concepto nuevo** hacen falta ≥10 ads, y con hit rate 5%, ~20 ads para esperar un winner. Lanzar un concepto con 2-3 ads no es un test: es una anécdota.

---

## Mezcla de embudo

**70-90% del volumen creativo debe ser top-of-funnel** (unaware / problem aware). 20% medio. 5-10% bottom.

Esto ya no se controla con estructura de campaña sino con **el reparto de la producción creativa**.

⚠️ **Causa nº1 de churn alto:** demasiado producto/solution/most-aware. Ese creativo habla a un público estrecho, satura antes y muere antes. Si el churn está disparado, mira la mezcla de awareness **antes** de pedir más volumen.

---

## Mezcla de producción semanal

Dos reparticiones válidas según el objetivo:

**Por leverage (Ep 76 / Meta 2026):**
- 50-60% replicación de winners
- 20-30% iteración de casi-ganadores
- 20-30% conceptos nuevos

**Por tipo de winner (99ads):**
- 20% iteraciones de grand slams
- 60% iteraciones de low-profile winners (los casi-ganadores: es donde está la mina)
- 20% big swings

En ambas, **la iteración es la palanca principal y lo nuevo es la apuesta lateral**. El error habitual es el revés: 80% conceptos nuevos y abandonar a los ganadores.

**Regla del 20% de especulación:** en cada iteración, 80% bloques ya validados y 20% la apuesta nombrada que estás testeando. Si no sabes decir cuál es tu 20%, no estás testeando: estás apostando.

---

## Presupuesto de producción creativa

| Inversión mensual | % a producción | Equipo |
|---|---|---|
| 4-30k | tiempo del founder | founder + editor freelance |
| 30-100k | **25%** del media budget | 2-3 creators + estratega |
| 100k+ | **10%** (≈2,5% de facturación a MER 25%) | equipo completo: scripting, editor, 4-6 creators, diseñador |

El tramo 30-100k es el que más incomoda y el que más se incumple. Es también el que más explica por qué una cuenta se estanca.

---

## Los 3 tipos de winner

| Tipo | Señal | Qué hacer |
|---|---|---|
| **False winner** | espectacular a 24-72h, se cae al subir presupuesto | no lo relances. Extrae los bloques validados y archiva. |
| **Low-profile winner** | rentable y estable a presupuesto modesto; se ahoga al escalar | **mantenlo vivo en su punto dulce**. 10 de estos a 100 €/día son 1.000 €/día estables. Itera un cuello de botella cada vez. |
| **Grand slam** | aguanta y mejora al subir presupuesto, en varias campañas | protege el original y multiplícalo. No lo "mejores" hasta matarlo. |

Matar low-profile winners porque "no escalan" es uno de los errores más caros que existen.

---

## Escalera de iteración

Cuando un winner empieza a fatigar, en este orden:
1. **Refresco de hook** — cambia los primeros 3-5 s, mismo cuerpo y CTA. Casi gratis.
2. **Ajuste de guión** — usa el gráfico de retención para localizar la caída y opera solo ese bloque.
3. **Nuevo actor / localización** — misma estructura, distinta cara.
4. **Spin-offs tardíos** — mezcla de todo lo anterior. Apuesta, no iteración segura.

Empieza a iterar **desde el día 1**, no cuando el winner ya está cayendo. El objetivo es tener el banquillo listo antes de necesitarlo.

---

## Métricas suaves vs duras

| | Métricas | Qué dicen | Fiabilidad |
|---|---|---|---|
| **Suaves** | hook rate, hold rate, CTR, CPC | si el creativo hace su trabajo básico | alta, y rápidas (pocos cientos de impresiones) |
| **Duras** | CVR, CPA, ROAS | la realidad de negocio | afectadas por atribución |

| Suaves | Duras | Lectura | Acción |
|---|---|---|---|
| 🟢 | 🟢 | winner real | proteger y multiplicar |
| 🟢 | 🔴 | el creativo va, el back-end no | oferta / landing / targeting |
| 🔴 | 🟢 | "patito feo" | mismo mensaje, mejor producción |
| 🔴 | 🔴 | malo | matar |

---

## Advertencias de lectura

- **El gasto es el mejor proxy de rendimiento a nivel de ad**, mejor que el ROAS. Meta reparte presupuesto según lo que funciona en la secuencia completa; el ROAS del ad es last-click y miente. Un ad con el doble de gasto y menos ROAS suele ser mejor ad.
- **No juzgues creativos a nivel de ad por ROAS aislado.** Sube a ad set o campaña para decidir.
- **Nadie acierta prediciendo qué creativo ganará.** Ni los mejores estrategas. Por eso el juego es fijar un listón de calidad y maximizar volumen por encima de él — no intentar adivinar el ganador.
