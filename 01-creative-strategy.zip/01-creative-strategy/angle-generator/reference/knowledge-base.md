# Angle Generator — Knowledge Base

Distilled knowledge for generating diversified, non-overlapping ad **angles** for MLO Growth DTC brands.
An **angle = the promise/framing** of an ad — it lives in the *brief*, not the ad. It is distinct from the
**hook** (first 0–3s, lives in the ad) and the **offer** (what the buyer receives). *Muchos hooks por
ángulo, muchos ángulos por audiencia.* — MLO Playbook M3 / `_FUENTES-videos-destilado.md` V1.

---

## 1. Árbol de Cascada — the angle's origin (MLO)
*Source: `00-INDEX-Sistema-Scripting-MLO.md`, `01-Modulo-Frameworks-y-Script-to-Brief.md`.*

The angle is not invented in a vacuum. MLO's rule: **"el avatar y el ángulo salen del Árbol de Cascada; el
framework es solo el vehículo."** The cascade is:

```
DESEO (mass desire, pre-existing)  →  AVATAR (identity + motivation + buying context)  →  ÁNGULO (promise/framing)
```

- **Deseo:** you *channel* an existing mass desire (health, status, ease, safety, freedom, connection,
  belonging), you never manufacture it (Schwartz — see §4).
- **Avatar:** not demographics — **identity + motivation + buying context** (V1). Different avatar = different
  angle even for the same product.
- **Ángulo:** the promise/framing that connects this avatar's desire to the product. This is the deliverable.

**Trinidad-first / message > format:** decide the *what to say* (angle) before any format or hook. The
framework (one of MLO's 12) is only the *vehicle* that tells the angle.

---

## 2. EPIC angles — the diversification map (MLO)
*Source: `_FUENTES-videos-destilado.md` V1 (Alessio/99ads); `00-INDEX` "ángulos EPIC".*

EPIC is a 2×2 plane on two axes — **feelings ↔ facts** and **indirect ↔ direct** — giving four quadrants.
Generate angles in ALL FOUR. **"Si solo has tocado Practical, ahí están tus gaps."**

| Quadrant | Axis position | What the angle does | Typical move |
|---|---|---|---|
| **E — Emotional** | feelings · indirect | Sells the *feeling* / benefit-of-the-benefit; story, relief, aspiration, fear | Open on the emotional pain/desire (Halbert: "selling is pure emotion") |
| **P — Practical** | facts · direct | Sells the functional job: convenience, speed, ease, "one step, no routine change" | Kill Time Delay / Effort in the Value Equation (§6) |
| **I — Identity** | feelings · direct | Sells belonging / "this is who you are"; tribe, values, self-selection call-out | Schwartz stage-5 identification + Cialdini Unity (§4, §5) |
| **C — Critical** | facts · indirect | Contrarian / myth-buster / "the guilty party"; challenges a belief, exposes a hidden cause | Sacred-cow, surprising-culprit, "the X everyone gets wrong" |

EPIC is the **primary diversification axis** — the hard gate rejects two angles sharing the same quadrant
*and* the same awareness *and* the same ICP *and* the same objection.

---

## 3. 3A Framework — where the angle sits in the risk/reward hierarchy (MLO)
*Source: `_FUENTES-videos-destilado.md` V1.*

3A = circle (**Oferta**) containing a triangle (**A**udience · **A**ngle · **A**d). Risk/reward hierarchy:
**Oferta (max) → Audiencia → Ángulo → Ad (min).** New angles are a *mid-leverage* lever — bigger than a new
ad, smaller than a new audience or offer. This is why MLO's **5-phase roadmap** puts angle diversification at
the **100k–500k** phase ("3–5 nuevos ángulos, EPIC"); below that you exhaust cheaper Ad-level iterations
first. Rule of operations: exhaust the lowest-risk lever before climbing; keep feeding the level below.

---

## 4. Awareness × Sophistication — the two axes every angle must respect (Schwartz)
*Reused from `mlo-winner-strategist/reference/experts-direct-response.md` (Schwartz, the master grid). Cite that file.*

**Awareness (the prospect, 5 stages)** sets the *runway length*:
Unaware → Problem-Aware → Solution-Aware → Product-Aware → Most-Aware. Less aware = longer runway before the
product; more aware = go straight to offer. Cold Meta traffic sits 1–3; retargeting 4–5. A diversified angle
set biases **cold (Unaware/Problem/Solution)** because that's where scale lives (and where MLO's Unaware
masterclass says the biggest TAM is).

**Market Sophistication (the market, 5 stages)** sets *what kind of claim survives*:
1 plain claim · 2 enlarge claim · 3 introduce mechanism · 4 elaborate/out-prove mechanism · 5 identity/reinvent.
**Angles in a stage ≥3 category (supplements, skincare, weight-loss, most mature DTC) MUST carry a mechanism
or identity reframe — a bare benefit claim is invisible.** Angle decay = the market advanced a stage; respond
by deepening the mechanism or shifting to identification, not shouting louder.

**Grid intersection = the hook family the angle implies** (full table in the winner-strategist file). Use it
to check each angle's promise is *phraseable* at its diagnosed awareness × sophistication cell.

---

## 5. Emotion / trigger palette — a diversification dimension
*Reused from `experts-direct-response.md` (Cialdini 7, Sugarman triggers) + `experts-offers-hooks.md`.*

- **Cialdini 7:** Reciprocity · Commitment/Consistency · Social Proof · Authority · Liking · Scarcity · **Unity**
  (Unity = "you're one of us" > Liking = "you're like me" — strongest tribe/identity angles use Unity).
- **Sugarman triggers** worth cycling across angles: Honesty (admit a flaw), Curiosity (open loop), Greed,
  Urgency/Scarcity, Involvement/Ownership, Specificity, Hope, Authority, Satisfaction-conviction (guarantee).
- **Core emotions** to spread across the set: relief · frustration · fear/loss-aversion · pride/belonging ·
  curiosity · aspiration · distrust (for Critical angles) · nostalgia.

Each angle should fire a *different* dominant emotion/trigger from its neighbors — a set that fires only
"curiosity" is under-diversified even if EPIC-varied.

---

## 6. Hormozi Value Equation — a lens for the PROMISE
*Reused from `experts-offers-hooks.md`. Cite that file.*

```
          Dream Outcome  ×  Perceived Likelihood
Value  =  ─────────────────────────────────────────
              Time Delay  ×  Effort & Sacrifice
```
Each angle's **promise** should lean on one lever: Emotional angles usually push **Dream Outcome**; Critical/
proof angles push **Perceived Likelihood**; Practical angles kill **Time Delay** and **Effort & Sacrifice**.
Diagnosing *which lever a promise moves* is a quick way to confirm two angles aren't secretly the same promise.

---

## 7. ICP & objection dimensions — the other diversification axes
- **ICP** = avatar segments (identity + motivation + buying context), e.g. "failed-solution buyer",
  "ingredient-savvy 28–40", "gift buyer", "45+ needs trust-building & slower pace" vs "25 fast/edgy" (V7).
  Mine from VoC/reviews and Grok+X / Google Trends persona pulls (V7).
- **Objections** = the doubts an angle neutralizes ("I've tried everything", "is it hype?", "too expensive",
  "does it taste awful?", "will it work for me?"). Source from reviews/support tickets (Ogilvy: mine real
  customer language). Every major objection should be answered by ≥1 angle in the set.

---

## 8. Andromeda — naming + variation discipline (downstream)
*Source: `01-Modulo-Frameworks-y-Script-to-Brief.md`, `04-Modulo-Hooks.md`.*

After angles are generated: **one angle → many hooks → many ads**, and each variation is tested **one variable
per ad set** (that's *variación*, NOT "3 hooks in the same ad set"). Give each angle a short **slug** for the
naming convention so testing/analysis can attribute results back to the angle. Measurement downstream = **FFM**
preset (hook rate, hold rate, CTR, ROAS). Angles are **hypotheses**, validated by data, not opinion.

---

## 9. The generation procedure (checklist)
1. Fix Deseo → Avatar → Ángulo (Árbol de Cascada). Confirm/assume mechanism.
2. Diagnose awareness spread + sophistication stage.
3. List levers: EPIC quadrants (4) · awareness stages · ICPs · objections · emotions.
4. Generate N angles combining levers → ≥1 per EPIC quadrant · ≥3 awareness stages · ≥3 ICPs · every major
   objection covered. Attach mechanism reframe where sophistication ≥3.
5. Write each: awareness · EPIC · emotion/trigger · ICP · promise · one-line concept · objection · slug.
6. **Hard gate:** reject any two angles sharing {EPIC + awareness + ICP + objection}. Replace collisions.
7. Output the table + coverage scorecard (EPIC x/4, awareness x/5, ICP count, objections answered, collisions).

---

## Sources

### MLO Playbook modules (source of truth)
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, Market Sophistication, EPIC angles,
  Árbol de Cascada, Andromeda, FFM.
- `01-Modulo-Frameworks-y-Script-to-Brief.md` — angle ≠ hook ≠ offer; framework = vehicle; Andromeda variation.
- `04-Modulo-Hooks.md` — 4-component hook (spoken/visual/text/audio), downstream of the angle.
- `_FUENTES-videos-destilado.md` — EPIC axes (feelings↔facts, indirect↔direct: E/P/I/C); 3A risk hierarchy;
  5-phase roadmap (angles = 100k–500k phase); persona diversification (V7).

### Reused MLO expert brain (do not re-research)
- `mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz Awareness×Sophistication grid,
  Ogilvy (specifics/benefit headline), Cialdini 7 (incl. Unity), Sugarman triggers.
- `mlo-winner-strategist/reference/experts-offers-hooks.md` — Hormozi Value Equation, hook archetypes,
  PAS/AIDA awareness routing.
