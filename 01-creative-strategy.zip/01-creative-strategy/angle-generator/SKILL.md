---
name: angle-generator
description: >
  Generates N distinct, non-overlapping advertising ANGLES for a DTC product, spread across awareness
  levels, emotions, ICPs and objections, using MLO Growth's EPIC angle framework + the Árbol de Cascada,
  and enforcing diversification (no two angles on the same lever). Output = a table of angles, each with
  awareness stage, emotion/trigger, ICP, promise, and a one-line concept. ALWAYS use this skill (ES/EN)
  when the user says "genera ángulos", "dame N ángulos para [producto/marca]", "necesito ángulos nuevos",
  "ángulos EPIC", "diversifica los ángulos", "ideas de ángulos para escalar", "angle generator",
  "generate angles", "give me ad angles", "new angles for [brand]", "angle ideas". Trigger for any MLO
  brand (8hours, ZZEN, Bala di Gala, Moncho Moreno, Alma, Chic&Love, etc.). Angles feed the ad-brief /
  scripting skills — this skill produces the ÁNGULO (promise/framing), not the hook or the full script.
---
# Angle Generator — EPIC angles + Árbol de Cascada (MLO)

## What it does
Takes one product/offer and produces **N distinct advertising angles** — the *promise/framing* layer that
lives in the brief, not the hook (0–3s, lives in the ad) and not the offer (what the buyer receives).
Every angle is placed on MLO's **EPIC** map, tagged with an **awareness stage** (Schwartz 5), an
**emotion/trigger**, an **ICP**, a **promise**, and a **one-line concept**. The skill **enforces
diversification**: no two angles may share the same lever (same EPIC quadrant + same awareness + same ICP +
same objection). It is the engine behind Phase 3 of MLO's roadmap ("100–500k = 3–5 nuevos ángulos, EPIC").

## Relationship to existing MLO skills (align, don't fork)
- Consumes the **Árbol de Cascada** (Deseo → Avatar → Ángulo) — the same doctrine as `mlo-creative-strategy`.
- Feeds `mlo-ad-brief-builder` / `mlo-advertorial-brief-builder` / `nil-script-builder` (angle → brief → script).
- Complements `mlo-psychological-coverage` (that skill audits coverage of existing ads; this one *generates*
  the angles to fill the gaps) and `mlo-winner-strategist` (that skill iterates proven winners).

## When to use (ES + EN trigger phrases)
- ES: "genera N ángulos para [producto]", "dame ángulos nuevos", "ángulos EPIC", "diversifica los ángulos",
  "ideas de ángulos para escalar [marca]", "necesito ángulos que no se pisen", "cubre todos los awareness".
- EN: "generate angles", "give me N ad angles", "new angles for [brand]", "EPIC angles", "diversify angles",
  "angle ideas to scale", "angles across awareness levels".

## Inputs needed
1. **Product / offer** (what it is, price band, category).
2. **Mass desire(s)** it serves (health / status / ease / safety / freedom / connection / belonging).
3. **Mechanism** — the named reason it works (if none, infer a candidate and flag it).
4. **N** — how many angles (default 8; typical 5–12).
5. *Optional:* known ICPs, top objections, VoC/review snippets, market sophistication read, brand.
If desire/avatar/mechanism are missing, ask ≤3 questions OR infer and label assumptions — don't stall.

## Method (numbered — this is the core)
1. **Árbol de Cascada first.** Fix **Deseo → Avatar → Ángulo** before generating. The angle is a *promise/
   framing* that channels an already-existing desire (Schwartz: you channel desire, you don't create it).
   Never let a format or hook drive the angle — message > format (Trinidad-first).
2. **Diagnose the two axes for the product** (see knowledge-base): the **awareness** spread of the traffic
   (Schwartz 5: Unaware→Most-Aware) and the **market sophistication** stage (1–5). These set the runway
   length and whether a bare claim, a mechanism, or an identity play is required.
3. **Map the EPIC plane.** EPIC = two axes: *feelings↔facts* and *indirect↔direct*, giving 4 quadrants —
   **E**motional, **P**ractical, **I**dentity, **C**ritical. You will deliberately place angles in ALL four.
   If you only produced Practical angles, that gap *is* the opportunity.
4. **Enumerate levers.** Before writing, list the ICPs, the objections (from VoC/reviews), and the emotions/
   triggers (Cialdini/Sugarman set + fear/pride/relief/curiosity/belonging). These are the diversification
   dimensions.
5. **Generate the angle grid.** Produce N angles by combining levers so the set spans: ≥1 angle per EPIC
   quadrant, ≥3 distinct awareness stages (bias cold TOFU: Unaware/Problem/Solution-aware), ≥3 distinct
   ICPs, and each major objection answered by at least one angle. Attach a **mechanism-based reframe** to
   angles in sophistication stage ≥3 (bare claims are invisible in saturated categories).
6. **Write each angle** as: *awareness · EPIC quadrant · emotion/trigger · ICP · promise · one-line concept.*
   The **promise** is the WIIFM the angle makes; the **concept** is one sentence a strategist can hand to
   scripting (it implies a hook family but is NOT a hook).
7. **Run the diversification check (hard gate).** Reject any two angles that share the SAME
   {EPIC quadrant + awareness stage + ICP + objection}. If a collision exists, replace one — do not ship
   near-duplicates. Report the coverage (EPIC ×4, awareness ×5, ICP, objections) as a mini scorecard.
8. **Andromeda note.** Remind that each angle → many hooks → many ads, tested one variable per ad set
   (variation, not "3 hooks in one ad set"). Give each angle a short slug for the naming convention.

## Rules & standards (MLO non-negotiables)
- **Trinidad-first / message > format.** The angle (the *what to say*) is decided before any format or hook.
- **Árbol de Cascada** governs: Deseo → Avatar → Ángulo. Ángulo ≠ hook ≠ oferta (keep the three distinct).
- **Cover all four EPIC quadrants** and multiple awareness stages — one-lever sets are the failure mode.
- **Sophistication-aware:** stage ≥3 angles must carry a mechanism/identity reframe, not a louder claim.
- **Diversification is enforced**, not suggested: no two angles on the same lever combination.
- **Precisión > relleno.** Concrete promises in the customer's language (VoC), no vapid adjectives (Ogilvy).
- Measured with **FFM** downstream (hook rate, hold rate, CTR, ROAS) — angles are hypotheses to test.

## Output (exact shape + concrete example)
A markdown table (one row per angle) + a coverage scorecard + Andromeda slugs. Columns:
`# · Angle name · EPIC · Awareness · Emotion/Trigger · ICP · Promise · One-line concept · Objection handled · Slug`

Example (product: apple-cider-vinegar capsules, mechanism "acetic-acid time-release"):

| # | Angle | EPIC | Awareness | Emotion/Trigger | ICP | Promise | One-line concept | Objection | Slug |
|---|---|---|---|---|---|---|---|---|---|
| 1 | The 3pm crash | E-motional | Problem-aware | Relief/frustration | Busy mum 35–45 | End the afternoon energy crash without more coffee | Story of the daily 3pm slump → the hidden blood-sugar spike behind it | "I've tried everything" | acv-3pm-crash |
| 2 | One capsule, no vinegar shots | P-ractical | Solution-aware | Ease/convenience | Wellness shopper who quit the liquid | All the ACV benefit, none of the gagging morning shot | Side-by-side: the shot ritual vs one time-release capsule | "Doesn't it taste awful?" | acv-no-shot |
| 3 | For people who read labels | I-dentity | Solution-aware | Belonging/pride | Ingredient-savvy 28–40 | The ACV made for people who actually check what's inside | "This is you" call-out to the label-reader tribe | "Is it just hype?" | acv-label-reader |
| 4 | The gummies lied to you | C-ritical | Unaware→Problem | Distrust/curiosity | Failed-gummy buyers | Why ACV gummies barely work — and the acetic-acid math nobody shows you | Contrarian teardown of the category's sugar-loaded gummies | "Aren't gummies the same?" | acv-gummy-myth |

Scorecard: EPIC 4/4 · Awareness 3/5 (Unaware, Problem, Solution) · ICPs 4 · Objections 4 answered · 0 collisions.

## Guardrails
- Do NOT output hooks or full scripts — this skill stops at the **angle** (promise + concept). Hand off to
  the brief/scripting skills.
- No invented "MLO frameworks." EPIC, 3A, Árbol de Cascada, Andromeda, FFM are the real ones — use only these.
- No two angles on the same lever; if you can't diversify to N, return fewer strong angles and say why.
- Flag any inferred mechanism/desire/avatar as an assumption to confirm; never present a guess as VoC fact.
- Angles are **testable hypotheses**, not guaranteed winners — frame them for Andromeda testing + FFM.

## References
See `reference/knowledge-base.md`. Grounded in MLO Playbook `00-INDEX-Sistema-Scripting-MLO.md`
(EPIC, 3A, Awareness, Árbol de Cascada, Andromeda, FFM), `01-Modulo-Frameworks-y-Script-to-Brief.md`
(angle≠hook≠offer; framework = vehicle), `04-Modulo-Hooks.md` (4-component hook, downstream of angle), and
`_FUENTES-videos-destilado.md` (EPIC axes; 3A hierarchy; 5-phase roadmap). Reuses
`mlo-winner-strategist/reference/experts-direct-response.md` (Schwartz awareness×sophistication grid,
Cialdini, Sugarman, Ogilvy) and `experts-offers-hooks.md` (Hormozi Value Equation, hook archetypes, PAS/AIDA).
