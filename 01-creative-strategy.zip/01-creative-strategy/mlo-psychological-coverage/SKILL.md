---
name: mlo-psychological-coverage
description: "Expert psychological coverage framework for Meta Ads creative strategy based on Sarah Levinger's methodology. Covers the 3-dimension psychological matrix (Valence Zone, Self-Concept Anchor, Language Intensity), coverage audits, batch distribution strategy, and copy review framework. ALWAYS use (ES/EN) when Marcel passes a copy for review, asks how to distribute a creative batch, discusses psychological diversity, mentions Creative Similarity Score or rising CPMr, asks \"what to produce this week\", or any request involving copy feedback, ad batch planning, valence zones, self-concept testing, intensity calibration, or psychological coverage audits for any MLO brand."
---

# SKILL: Psychological Coverage — Copy & Batch Strategy
## MLO Growth | Based on Sarah Levinger's Framework (2026)

---

## CUÁNDO USAR ESTE SKILL

Activar SIEMPRE (ES/EN) cuando Marcel o el equipo:

- Pasen un copy de ad para revisión o feedback
- Pidan ayuda para estructurar un batch de creativos
- Pregunten cómo distribuir un conjunto de ads (qué tipo hacer, cuántos, en qué orden)
- Hablen de diversidad creativa / psychological diversity
- Pregunten si sus ads "son suficientemente distintos"
- Quieran saber qué zona emocional testear
- Discutan el copy de un brief o script
- Mencionen: valence, zonas psicológicas, identidad, intensidad de copy
- Quieran auditar su cuenta desde el ángulo del contenido psicológico
- Pregunten cómo escalar sin aumentar volumen
- Hablen de Creative Similarity Score / CPMr subiendo
- Quieran hacer un coverage audit de su cuenta
- Digan "necesito más ads" o "¿qué produzco esta semana?"

---

## EL PROBLEMA CENTRAL QUE RESUELVE ESTE SKILL

**Volumen sin varianza psicológica = wallpaper caro.**

La mayoría de cuentas lanzan 40–100 ads al mes que en realidad son el mismo concepto empaquetado de formas distintas. El algoritmo (Andromeda) los agrupa como redundantes → sube CPMs → reduce reach → la cuenta se estanca.

**La data lo prueba:** marcas que redujeron volumen un 56.7% aumentaron simultáneamente spend, aMER y revenue. El problema nunca fue el volumen — fue la falta de cobertura psicológica.

**El 70–80% del performance de un ad viene de la precisión psicológica del creativo.** El media buying y el targeting representan el 20–30% restante.

---

## EL FRAMEWORK: LA MATRIZ PSICOLÓGICA (3 DIMENSIONES)

Antes de escribir copy o armar un batch, toda decisión creativa pasa por estas tres dimensiones. Cambiar una sola dimensión produce un ad genuinamente distinto para el algoritmo y para el cerebro humano.

---

### DIMENSIÓN 1: VALENCE ZONE (Carga Emocional)

Qué estado neurológico quieres activar.

| Zona | Descripción | Cuándo usar |
|---|---|---|
| **High Valence Positivo** | Aspiración, euforia, transformación, celebración | Audiences calientes, momentos de deseo |
| **High Valence Negativo** | Urgencia, miedo, shock, "lo estás haciendo mal" | Cold con problema agitado, personas en pain activo |
| **Low Valence Positivo** | Calma, confianza, revelación suave, orgullo tranquilo | Cold traffic, contenido orgánico, audiences fatigadas de urgencia |
| **Low Valence Negativo** | Decepción silenciosa, resignación, cansancio acumulado | Personas que ya normalizaron el problema (Jorge en V-UP) |

**El error más común:** el 90% de las cuentas vive en **High Valence Negativo** (zone 4). Funciona para los usuarios ya en estado elevado, pero ignora a todos los demás.

**Regla práctica:** no testees Hook A vs Hook B dentro de la misma zona de valence. Testea una zona positiva contra una negativa. Ese dato vale más que saber si prefieren hook de 3 o 5 segundos.

---

### DIMENSIÓN 2: SELF-CONCEPT ANCHOR (Capa de Identidad)

A qué versión del "yo" del usuario se dirige el ad.

| Self | Mecanismo | Ejemplo de copy |
|---|---|---|
| **Actual Self** | Reconocimiento del problema hoy. "Te entiendo, estás aquí ahora." | "¿Te cuesta recordar nombres que antes te sabías de memoria?" |
| **Ideal Self** | Aspiración. La versión futura que quieren ser. | "El Don Luis que siempre has sido, sin perder velocidad mental." |
| **Ought Self** | Deber, responsabilidad, culpa convertida en determinación. | "No lo hagas por ti. Hazlo para seguir siendo su referente." |

**El error más común:** el 75% de marcas solo produce Actual Self. Dos ads que dicen "eres un padre ocupado" y "los padres ocupados necesitan soluciones" son el mismo Self-Concept con distinto copy.

**Testear los tres Self-Concepts** revela si tu audiencia está en modo "soluciona mi problema actual" o "ayúdame a ser algo mejor" → eso redefine toda tu jerarquía de mensajes.

---

### DIMENSIÓN 3: LANGUAGE INTENSITY (Fricción Cognitiva)

El tono y la agresividad del copy.

| Intensidad | Descripción | Cuándo usar |
|---|---|---|
| **Alta** | Directa, superlativa, urgente, lenguaje de direct response | Audiencias calientes, retargeting, purchase-level, ya en shopping mode |
| **Baja** | Conversacional, orgánica, no parece ad, genera "Trust Equity" | Cold traffic, contenido que interrumpe el feed, audiences fatigadas |

**Trust Equity:** cuando el usuario no activa sus defensas de "me están vendiendo algo" → mayor engagement, más watch time, mejor CVR.

**Señal de alerta:** si todos tus ads están en intensidad máxima, estás entrenando a tu audiencia a ignorarte. El algoritmo también detecta malas experiencias de usuario (scroll rápido, hide) y te penaliza en la subasta.

---

## CÓMO APLICAR LA MATRIZ: AUDIT DE COBERTURA

Antes de producir un nuevo batch, hacer este ejercicio toma 20 minutos y evita desperdiciar producción:

**1. Listar todos los ads activos (últimos 60–90 días)**

**2. Plotear cada uno en las 3 dimensiones:**
- Valence: ¿High/Low? ¿Positivo/Negativo?
- Self: ¿Actual / Ideal / Ought?
- Intensity: ¿Alta / Baja?

**3. Identificar el cluster** → casi siempre el 80–90% cae en 1–2 combinaciones (típicamente: High Negativo / Actual Self / Alta Intensidad)

**4. Identificar el white space** → zonas psicológicas que no se han testeado

**5. El nuevo batch se diseña para ocupar ese white space**, no para iterar la misma zona con distinto hook.

---

## CÓMO REVISAR UN COPY CON ESTE FRAMEWORK

Cuando Marcel pase un copy para revisión, evaluar en este orden:

### PASO 1 — Clasificar las 3 dimensiones
- ¿Qué Valence Zone activa? ¿High o Low? ¿Positivo o Negativo?
- ¿A qué Self-Concept habla? ¿Actual / Ideal / Ought?
- ¿Qué nivel de intensidad tiene el lenguaje?

### PASO 2 — Verificar coherencia interna
- ¿El hook, el cuerpo y el CTA viven en la misma zona psicológica o hay saltos?
- ¿La intensidad es apropiada para el placement y el temperature de la audiencia (cold/warm)?
- ¿El Self-Concept es consistente de inicio a fin?

### PASO 3 — Identificar oportunidades de mejora
- Si el copy está en High Negativo / Actual Self / Alta intensidad (el default de todos): ¿hay forma de reescribirlo en otra zona para cubrir más terreno psicológico?
- ¿El lenguaje suena a copy de marketing o a cómo un cliente real describiría su problema?

### PASO 4 — Output concreto
- Clasificación del copy actual (dimensión × dimensión × dimensión)
- Diagnóstico: qué funciona, qué rompe la coherencia psicológica
- Versión mejorada o alternativa en una zona distinta si aplica

---

## CÓMO DISTRIBUIR UN BATCH DE CREATIVOS

Cuando Marcel traiga un batch ("voy a sacar X ads esta semana"), seguir este proceso:

### PASO 1 — Hacer el Coverage Audit primero
¿Qué zonas ya tiene cubiertas en cuenta? ¿Cuál es el white space real?

### PASO 2 — Asignar distribución psicológica al batch
Ejemplo para un batch de 6 ads:

| Ad | Valence | Self | Intensity | Persona (V-UP) |
|---|---|---|---|---|
| Ad 1 | High Negativo | Actual Self | Alta | Don Luis — identidad cognitiva |
| Ad 2 | Low Negativo | Actual Self | Baja | Jorge — normalización del deterioro |
| Ad 3 | Low Positivo | Ideal Self | Baja | Don Luis — preservar quien soy |
| Ad 4 | High Positivo | Ideal Self | Alta | Diana — energía recuperada |
| Ad 5 | Low Negativo | Ought Self | Baja | Paola — miedo por su papá |
| Ad 6 | Low Positivo | Ought Self | Baja | Paola — determinación de cuidar |

### PASO 3 — Verificar que no haya redundancia psicológica
Si dos ads tienen la misma combinación de dimensiones, uno es redundante para el algoritmo. Reemplazar uno por una zona sin cubrir.

### PASO 4 — Priorizar por white space y potential de aprendizaje
- Testear primero las zonas que no se han probado nunca → mayor aprendizaje estratégico
- Luego iterar dentro de zonas validadas con volumen

---

## CUÁNDO SÍ Y CUÁNDO NO PRODUCIR VOLUMEN

### Sí producir volumen cuando:
- Ya se identificaron las zonas psicológicas que funcionan → producir variaciones DENTRO de esa zona (distintos customer proof points, distintos hooks, misma estructura psicológica)
- Evaluación/Consideration: múltiples objections que manejar (15–20 ads psicológicamente distintos)
- Q4 / temporada alta → pero incluso aquí, volumen psicológicamente diverso supera a volumen redundante

### NO producir volumen cuando:
- No se ha mapeado el coverage psicológico → estás repitiendo el mismo error 40 veces
- Estás iterando variables de superficie (hook, B-roll, color) dentro de la misma zona psicológica → eso no es testeo estratégico, es actividad que se siente productiva
- Estás copiando competitors → construyes sobre su base psicológica, no la tuya

**Regla de oro de Sarah:** el volumen viene DESPUÉS del discovery psicológico, no antes. Un unlock psicológico en la fase de research vale más que 100 iteraciones en la fase de producción.

---

## SEMANA OPERATIVA TIPO (Workflow)

| Día | Actividad |
|---|---|
| **Lunes** | Coverage Review: performance de la semana anterior. ¿Qué zonas funcionaron? ¿Cuál es el white space? |
| **Martes–Miércoles** | Research & Briefing: 2–3h en research de cliente (reviews, Reddit, CS transcripts, comentarios sociales). Identificar el lenguaje real del cliente en ese estado emocional. Escribir Zero-Waste Briefs que especifiquen el psychological job del ad. |
| **Jueves–Viernes** | Producción + testing orgánico: 1–3 ads hero en zonas estratégicas. Contenido orgánico para zonas que se quieren explorar sin invertir budget paid todavía. Post orgánico, observar saves/shares el fin de semana. |

**Zero-Waste Brief:** especifica el trabajo psicológico que el ad debe hacer (zona de valence, self-concept, intensidad), no solo la ejecución táctica. Esto reduce tiempo de brief, elimina iteraciones ciegas, y produce primera versión más alineada.

---

## SEÑALES DE ALERTA EN CUENTA (Performance Indicators)

| Señal | Diagnóstico | Solución |
|---|---|---|
| CPMr subiendo | Estás sirviendo los mismos ads a las mismas personas → cobertura psicológica redundante | Audit + nuevas zonas |
| Creative Similarity Score alto | Los ads son psicológicamente idénticos para el algoritmo | Rediseñar batch con dimensiones distintas |
| ROAS estancado a pesar de más volumen | Más iteración en la misma zona, no más cobertura | Parar producción, hacer coverage audit primero |
| Ads que "deberían" funcionar no escalan | El hook puede ser bueno pero la zona psicológica no resuena | Testear misma oferta en otra Valence Zone |

---

## APLICACIÓN ESPECÍFICA A V-UP

**Mapa psicológico actual de V-UP:**

| Persona | Zona dominante actual | White space a explorar |
|---|---|---|
| Don Luis | High Negativo / Actual Self / Alta intensidad | Low Positivo / Ideal Self / Baja intensidad |
| Paola | High Negativo / Ought Self / Alta intensidad | Low Negativo / Ought Self / Baja (conversacional, íntima) |
| Diana | High Negativo / Actual Self / Alta | Low Positivo / Ideal Self / Baja |
| Jorge | (poco testeado) | Low Negativo / Actual Self / Baja (normalización suave) |

**Regla de copia para V-UP:** el lenguaje real del cliente no suena a marketing. Usar las palabras exactas de reviews, comentarios, testimonios → automáticamente baja la intensidad y sube la Trust Equity.

---

## DIFERENCIA CLAVE: ITERACIÓN vs. VARIACIÓN

| Iteración (no es diversidad) | Variación real (sí es diversidad) |
|---|---|
| Cambiar el hook de pregunta a estadística | Cambiar de High Negativo a Low Positivo |
| Cambiar el B-roll | Cambiar de Actual Self a Ought Self |
| Swapping testimonials dentro del mismo ángulo | Testear Intensidad Alta vs Baja en el mismo concept |
| Reordenar los puntos del script | Reescribir el script para un Self-Concept distinto |

**Si el algoritmo no puede detectar la diferencia psicológica, no es una variación real.** Es producción redundante que eleva tu Creative Similarity Score y tus CPMs.