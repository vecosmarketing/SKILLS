# Hooks Expert — Knowledge Base

The distilled hook knowledge for the `hooks-expert` skill. **MLO's own M4 · Hooks system is the source of truth**; the expert frameworks (reused from `mlo-winner-strategist/reference/`) and the hook-rate metric provide the diagnostic and testing scaffolding. MLO system first — generic advice never.

---

## 1. MLO's M4 · Hooks system (source of truth)
*Cite: `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/04-Modulo-Hooks.md` — "Módulo 4 — Hooks: el sistema completo".*

### 1.1 What a hook is and why it rules
- The hook is the **first 1–5 seconds** and it is the **80/20 of the ad**: if it doesn't stop the scroll, nobody sees the rest.
- Its only job: **open a curiosity loop** the viewer can't leave unresolved.
- **Curiosity is created by CONTRAST.** Viewer believes A → you show B. The distance A→B *is* the curiosity. Bigger contrast = stronger hook. (Ex: "everyone thinks cashews are healthy → the cashew is in the poison-ivy family.")
- **MLO rule:** the hook speaks to **ONE avatar** at their **awareness level** (M1). A cold (TOFU) hook opens with curiosity/problem, **not the product**. Multiple hook variants on the *same body*, each in a *separate ad set*, = variation (Andromeda) — not "3 hooks in one ad set".

### 1.2 The 4 components + Maximum Alignment
Every hook lands **4 layers at once**:
1. **Spoken hook** — what is SAID (voice/VO).
2. **Visual hook** — what is SHOWN on screen.
3. **Text hook** — the on-screen TEXT overlay.
4. **Audio hook** — the SOUND / music / effect.

- **500 vs 500,000 views = maximum alignment across the 4.** Say one thing but show another → confusion → the brain loses comprehension → they leave. All 4 pointing at the same thing → total comprehension → they stay.
- **How the brain consumes video (real order): `visual → audio → visual`.** Eyes process 10–100× faster than ears: they see first, then hear, then **return to the visual to confirm what they heard**.
- ➡️ **The visual leads.** It is the "key visual." Changing the visual hook impacts performance **more** than changing the text or the voice. This is why unaware/UGC tests use 3 variants with **different visual hooks**, everything else held constant.

### 1.3 The 6 viral hook formats
Any video idea can be told with any of the 6. Don't ask "which fits" — pick the one that gives **most contrast** with the visual you have.

| Format | What it does | Template example |
|---|---|---|
| **Fortune Teller** (adivino) | Present vs **future** | "This is going to change [category] forever" |
| **Experimenter** (experimentador) | **Peer-to-peer** demo/experiment | "I took this 7,000 km and it has 3 design flaws" |
| **Teacher** (profesor) | **Teacher-to-student** lesson | "If you travel this summer, here's how you do X" |
| **Magician** (mago) | Visual/verbal **stun** ("check this out") + *visual pacifier* (background action that retains) | "Check this out…" + fast match-cut |
| **Investigator** (investigador) | A **secret/finding** you didn't know → now you do | "This is the smartest campaign I've ever seen…" |
| **Contrarian** (contrario) | Belief **opposite** to convention, direct | "You're doing your branding wrong. You should…" |

- **Magician stacks on any of the other 5** — use it as the opening stun, then run the real format underneath.

### 1.4 Tangible curiosity — 6 generators of infinite hooks
Take an idea from the offer (**usually the mechanism**) and make it concrete + visual:
1. **Metaphor** — connect the unknown to something known for an instant aha. *Naturals are best* (rivers, fire, pipes), mechanical (buttons, switches, doors), object. "Your metabolism is like a bonfire."
2. **Paradoxical question** — "Why does your dog pull HARDER when you try to stop him?"
3. **Characterization / nickname** — give the mechanism/result a concrete, visual name: *ice-water trick, purple peel, white-napkin effect, "1,000 buyers a day"*. Secret: visual + concrete + tied to a metaphor.
4. **Testable proof** — ask them to **verify something** now or from their past: "press your shin 5s; if it's slow to bounce back, that's water retention." Pulls them inside the ad.
5. **Quiz** — "Which of these 4 jobs has the highest cavity risk? I'll tell you in a minute." (Quiz funnels perform.)
6. **Surprising culprit** — the problem *behind* the problem; or a "good" thing that's actually bad: "these veggies are making you fat", "your cutting board is making you fat".

> **Master trick (opposite of what everyone does):** start from the **curiosity** (e.g. "an ice cube") and *then* find how to connect it to the mechanism — not the other way round. Never invent, but explore where nobody looks. (*Brick logic:* creativity = how many uses you find for a brick; force tenuous connections.)

### 1.5 Proven money hooks (bank, tested on 1000+ ads)
- **Investment hook** — the time/money they spent before finding you: "I tried X for 3 years before I discovered…" (comes from reviews = failed attempts → builds trust).
- **Scam hook** — "I thought it was a scam…" = loss aversion + curiosity, unresolved tension.
- **POV** — 10–15% of top ads used it. "POV: …".
- **Founder hook** — introduce yourself with **name + title in overlay** (against common advice; works, feels organic).
- **Emotional hook** — strong reaction: "Why did I start crying over this?".
- **Cognitive dissonance** — "Why did nobody tell me?" (positions you as authority).
- **Identity-based** — "If you're over 40…" = **self-selection** (the right avatar identifies itself).

**Visual-hook resources:** *drip*/slow-mo, abstract/surreal art for emotional topics, *explosion clips* (better **after** the hook). **Multiple-hook strategy:** chain them (investment hook → explosion clip) to retain longer.

### 1.6 The 5-step process to write a winning hook
1. **What VISUAL do I have?** Start from the key visual. Weak visual → question the video (or fabricate one with motion graphics/stock).
2. **What data/angle gives the most CONTRAST** with that visual? → decides which of the 6 formats.
3. **Write the spoken hook** (2–4 lines): `context-lean` (describe what's seen) → `contrast` → `snapback` to the visual.
4. **Add the text hook** that supports the visual and reconfirms what they hear.
5. **Comprehension gut-check:** watch it `visual → speech → visual`. Crystal clear? If not aligned/clear, **kill the hook** (or the video) and redo. Ideas are infinite.

### 1.7 Quality checklist (M4 §7)
- [ ] Opens a curiosity loop by **contrast** (believe A → show B).
- [ ] Speaks to **one avatar** at their awareness (cold = no product in the hook).
- [ ] The **4 components** (spoken/visual/text/audio) are **aligned**.
- [ ] The **visual** is strong (it carries the most weight).
- [ ] There are **3–5 visual-hook variants** to test (in separate ad sets).
- [ ] Passes the `visual→speech→visual` comprehension gut-check.

### 1.8 Common mistakes (M4 §8)
- Generic hook that talks to "everyone" → stops nobody.
- Spoken/visual/text **misaligned** → confusion → scroll.
- Starting from the product in a cold hook.
- Optimizing the hook's text while forgetting **the visual leads**.
- Stacking hook variants in the same ad set (you test nothing; see Andromeda).
- Inventing curiosity that doesn't connect to the mechanism.

---

## 2. Where the hook sits in the MLO system
*Cite: `00-INDEX-Sistema-Scripting-MLO.md`.*
- **Trinidad / message first:** the hook serves the avatar + angle, never a cool edit.
- **3A (Audience · Angle · Ad):** the hook is the top of the **Ad**; the avatar + angle upstream determine it.
- **Awareness × Sophistication (M1):** cold/unaware hooks carry no product and open with curiosity/symptom; higher-awareness hooks can name the product/offer.
- **Andromeda taxonomy:** hook variants = *variation*, each in its own ad set.
- **FFM preset:** the hook is measured as **video capture = hook rate**. Fix the hook before the hold.
- The hook is **row 1 of the Script→Brief** (M3); this skill produces that row, `framework-scriptwriter` builds the rest.

---

## 3. Hook rate — the metric & testing method
*Cite: `mlo-winner-strategist/reference/experts-offers-hooks.md` (Hook Rate section) + `experts-dtc-creative.md` (benchmark reference).*

**Formulas:**
```
Hook Rate (thumb-stop) = 3-second video plays ÷ Impressions        (×100 for %)
Hold Rate              = ThruPlays ÷ 3-second video plays           (×100 for %)
```
Meta metric names: **3-second video plays**, **ThruPlays** (15s/completion), **Impressions**.

**Benchmarks (calibration; benchmark vs your own account first):**

| Metric | Weak | Good / scalable | Elite |
|---|---|---|---|
| Hook Rate | <20% | 25–35% | 40%+ |
| Hold Rate | <40% | 40–50%+ | — |

- Below ~20% hook rate Meta treats the creative as low quality and **raises CPMs**; 35%+ earns cheaper distribution and broader reach.
- **Fix hook rate before hold rate** — nobody sees the message if they don't stop.
- **Diagnostic split:** weak **hook rate** = the first 3s (visual/opening line) is broken → re-test hooks (this skill). Strong hook rate but weak **hold rate** = seconds 3–15 broke (retain/agitation) → *not* a hook problem; hand to the body/script.

**Testing method (Andromeda + Sanchez hook-swap):**
- Hold the body constant; vary **only the opener's visual** (Meta only registers a new variation on a *visual* change in the first 3–5s, not a text swap).
- One variant per **ad set** — never stack in one ad set.
- Read the winner by **hook rate** over enough impressions (~2–3 days of stable delivery).
- Static ads have no 3-sec play → judge the "hook" by **CTR / first-frame**, not hook rate.

---

## 4. Reused expert frameworks (name them, don't paraphrase vaguely)

### 4.1 Hook archetypes (the first 3 seconds)
*Cite: `experts-offers-hooks.md` — "Hook Archetypes".* The opener is a **pattern interrupt**. Winning hooks: open a specific gap, feel credible (specific), deliver on the promise inside the video. Archetypes: **Question · Bold Claim · Negativity/Mistake Callout (loss aversion beats positive framing) · Curiosity Gap · Callout (self-selection) · Social Proof (specific number + specific behavior) · Visual Break/Pattern Interrupt**. Timeline: 0–3s hook, 3–15s value delivery. → These map onto MLO's 6 formats/generators; use them as extra angles when a MLO format is exhausted.

### 4.2 Zeigarnik / open loops
*Cite: `experts-offers-hooks.md` — "Curiosity, Open Loops & The Zeigarnik Effect".* People fixate on unfinished information; incomplete info creates cognitive tension the brain seeks to close (left caudate / dopamine reward). **Never resolve the curiosity before the CTA.** This is the mechanism *underneath* MLO's "curiosity loop by contrast" — cite it when explaining *why* a hook works.

### 4.3 Sanchez — hook is ~90% of the job; hook-swap testing
*Cite: `experts-dtc-creative.md` — Savannah Sanchez.* Put nearly all effort into the first 3s. To test a hook, change the **first 3–5s *visual***, not just the on-screen text (Meta won't see a text-only change as a new variation). Weekly 2×2×2 slate (2 inspirations × 2 written hooks × 2 opening visuals) for 30k–100k/mo budgets. → Direct backing for MLO's "the visual leads" + "variants in separate ad sets."

### 4.4 Barry Hott — judge "Second 0" first; ugly/native
*Cite: `experts-dtc-creative.md` — Barry Hott.* If the first frame doesn't stop the *right* scroller, nothing downstream matters. Ugly/native beats polished; heavy branding in frame 1 reads as "an ad." → Use in diagnosis: check second-0 imagery + de-polish over-produced hooks.

### 4.5 Nick Theriot — 5 stages of awareness; hook formula matrix
*Cite: `experts-dtc-creative.md` — Nick Theriot.* Build a distinct hook per awareness stage (Unaware → Problem → Solution → Product → Most Aware); most brands over-index on the Most-Aware discount opener ("lowest marketing IQ"). Target by the bait (the ad) on broad. He runs a fixed **hook-formula matrix** to mass-produce openers (the shape is public; the 13 formulas are gated — treat as a known mental model, not a published list). → Backs MLO's "cold hook = no product, self-select by awareness."

### 4.6 Motion / Denney — vocabulary + content-first
*Cite: `experts-dtc-creative.md` — Motion/Denney.* Precise layers: **Hook** (attention-grabber, first seconds) vs **Angle** (sustaining argument) vs **Concept** (hook+angle) vs **Format**. When testing, be explicit you're changing the *hook* (not the angle). Content analysis > metrics analysis; metrics confirm the story. → Keeps this skill scoped to the hook layer and hands the angle to `angle-generator`.

---

## 5. Relationship note (record for SKILL.md alignment)
- **`hooks-expert`** (this, scripting suite) = the **hooks brain**: engineers hooks from MLO's M4 system at the script/brief stage, before anything is live.
- **`meta-hook-optimizer`** (Meta-ads repo: `/Users/mlo/Documents/CODEX/mlo-ads-skills/skills/meta-hook-optimizer/`) = the **metrics-optimizer cousin**: same hook-rate math, but starts from a live ad's metrics to diagnose and generate 5–10 variants + a Meta test plan. Same taxonomy, two entry points — creative-system vs account-data.
- Sits inside the suite between `angle-generator` / `framework-scriptwriter` (upstream) and `script-doctor` / `edit-guide` (downstream); orchestrated by `creative-strategist`; feeds `unaware-ads-expert` for cold hooks.

---

## Sources
**MLO Playbook modules (source of truth):**
- `04-Modulo-Hooks.md` — full hook system: 4 components, 6 viral formats, 6 curiosity generators, proven money hooks, 5-step process, checklist, mistakes.
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness × Sophistication, Andromeda, FFM (where the hook sits).

**Reused MLO expert brain** (`/Users/mlo/.claude/skills/mlo-winner-strategist/reference/`):
- `experts-offers-hooks.md` — hook archetypes; hook-rate & hold-rate formulas + benchmarks; Zeigarnik effect / open loops; VSL timeline.
- `experts-dtc-creative.md` — Savannah Sanchez (hook = 90%, hook-swap/visual-distinct testing), Barry Hott (Second 0, ugly/native), Nick Theriot (5 awareness stages, hook-formula matrix, broad + bait), Motion/Dara Denney (Angle vs Concept vs Hook vs Format; content > metrics).

**External URLs** (carried through the reused files, for hook-rate/benchmarks/archetypes):
- Hook & hold rate formulas + benchmarks — https://insights.vaizle.com/hook-rate-hold-rate/ · https://sovran.ai/blog/hook-rate-for-meta-ads-ultimate-guide · https://www.exposure.com.au/blog/what-is-a-good-hook-rate · https://billo.app/blog/hook-rate-to-hold-rate/
- Hook archetypes — https://prealgo.com/blog/hook-archetypes-2026 · https://www.gethookd.ai/learn/8-best-facebook-ad-hook-examples-for-2026/ · https://www.trendtrack.io/blog-post/best-performing-ad-hooks
- Zeigarnik / open loops — https://marketingagency.sg/zeigarnik-effect-marketing/ · https://www.leadalchemists.com/marketing-psychology/ziegarnik-effect/
- Sanchez — https://motionapp.com/library/expert/savannah-sanchez/ · https://tydo.com/blog/deepdive-savannah
- Barry Hott — https://www.buildingadswithbarry.com/ · https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads
- Nick Theriot — https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk
- Motion / Denney — https://motionapp.com/blog/creative-strategy · https://motionapp.com/library/expert/dara-denney/
