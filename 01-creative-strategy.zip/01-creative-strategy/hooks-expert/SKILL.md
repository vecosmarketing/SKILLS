---
name: hooks-expert
description: >
  MLO Growth's hooks brain — the first 3 seconds (opening line + key visual) engine for DTC ad
  scripts. Given a product/angle/awareness stage it GENERATES many hooks across MLO's real hook
  taxonomy (4 aligned components; the 6 viral formats — Fortune Teller, Experimenter, Teacher,
  Magician, Investigator, Contrarian; the 6 tangible-curiosity generators; the proven money hooks),
  and given an existing hook it DIAGNOSES and rewrites it, always with hook-rate context (3-sec
  plays ÷ impressions) and the Andromeda test method. ALWAYS use this skill (ES/EN) when the user
  says "dame hooks para [producto/marca]", "genera ganchos", "hooks para este ángulo", "diagnostica
  este hook / por qué no engancha", "mejora este gancho", "hooks unaware/frío", "key visual para el
  hook", "give me hooks for [product]", "generate hooks", "diagnose/fix this hook", "opening line /
  first 3 seconds / scroll-stopper for [brand]". Works for any MLO brand (ZZEN, 8hours, Moncho
  Moreno, Bala di Gala, HobbitAlf, Alma, Chic&Love, etc.). It is the scripting-suite twin of the
  Meta-ads-repo `meta-hook-optimizer` (the metrics-optimizer cousin).
---
# Hooks Expert — the first-3-seconds engine

## What it does
Turns a product/angle/avatar into a **battery of hooks** — or takes an existing hook and **diagnoses + rebuilds it** — using MLO's real hook system from **M4 · Hooks** (Playbook Estrategia Creativa & Scripting). A hook is the **80/20 of the ad**: if it doesn't stop the scroll, nobody sees the rest. Every hook is engineered as **4 aligned components** (spoken · visual · text · audio) opening a **curiosity loop by contrast**, mapped to one of MLO's **6 viral formats**, and delivered as **3–5 visual-hook variants** ready to test in separate ad sets (Andromeda). Judged against **hook rate** (3-sec plays ÷ impressions), it targets the layer that decides everything: the opener.

## When to use (ES + EN trigger phrases)
- **Generate:** "dame hooks para [producto/marca]", "genera ganchos", "hooks para este ángulo", "hooks unaware / para tráfico frío", "necesito un key visual para el hook", "give me hooks for [product]", "generate hooks for this angle", "cold-traffic openers", "first-frame ideas".
- **Diagnose/fix:** "diagnostica este hook", "por qué este gancho no engancha", "mejora este hook", "este hook no para el scroll", "diagnose this hook", "why isn't this hook working", "fix / rewrite this opener".
- Follows naturally after `framework-scriptwriter` (the hook is row 1 of the brief) or after a low 3-sec-view read.

## Inputs needed (ask only for what's missing)
1. **Product + core promise / mechanism** (the mechanism is the raw material for tangible curiosity), and **who it's for** (one avatar).
2. **Angle** (EPIC/entry) and **awareness stage** (Unaware → Most Aware — see M1). Cold = no product in the hook.
3. **The key visual you already have** (or can shoot/fabricate). *In MLO, the visual leads.*
4. **Market language** (ES/EN) and brand voice / claim constraints.
5. **Diagnose mode only:** the current hook (spoken + visual + text) and, if available, its **hook rate** (3-sec plays, impressions).

## Method (numbered — MLO's real system)

### A) GENERATE mode
1. **Lock the avatar + awareness.** Write to ONE avatar at their awareness level. Cold/TOFU opens with curiosity/problem/symptom — never the product (M4 §1; Nick Theriot's 5 stages).
2. **Start from the VISUAL, not the copy.** Name the key visual first. The brain consumes video `visual → audio → visual`; the visual is the "key visual" and moves performance more than text or VO (M4 §2). No strong visual → question the video or fabricate one with motion graphics/stock.
3. **Find the maximum CONTRAST.** Curiosity = distance between what they believe (A) and what you show (B). Pick the data/angle that gives the biggest gap vs. that visual (M4 §1). Bigger contrast = stronger hook.
4. **Choose the format that maximizes contrast** — one (or a Magician-stack) of the **6 viral formats**: **Fortune Teller** (present vs future), **Experimenter** (peer demo), **Teacher** (lesson), **Magician** (stun "check this out" + visual pacifier, stacks on the other 5), **Investigator** (secret/finding), **Contrarian** (opposite belief) (M4 §3).
5. **Manufacture tangible curiosity** via the **6 generators** (M4 §4): (1) Metaphor — connect the mechanism to something known, naturals best (rivers/fire/pipes); (2) Paradoxical question; (3) Characterization/nickname the mechanism ("ice-water trick", "purple peel"); (4) Testable proof ("press your shin 5s…"); (5) Quiz; (6) Surprising culprit (the problem behind the problem / a "healthy" thing that harms). **Master trick:** start from the curiosity (e.g. "an ice cube") and *then* connect it to the mechanism — never invent, but look where nobody looks (brick logic).
6. **Pull from the proven money hooks** as starting points (M4 §5): Investment, Scam ("I thought it was a scam…"), POV, Founder (name + title overlay), Emotional, Cognitive dissonance ("why did nobody tell me?"), Identity-based ("if you're over 40…" = self-selection).
7. **Write each hook as 4 ALIGNED components** (M4 §2): **spoken** (2–4 lines: `context-lean` → `contrast` → `snapback` to visual) · **visual** (the key visual) · **text** (overlay that reconfirms) · **audio** (sound/music/SFX). Misalignment = confusion = scroll.
8. **Produce a slate: 3–5 variants that vary the VISUAL hook**, holding the body constant — each goes in a **separate ad set** (Andromeda = variation, not "3 hooks in one ad set"). Meta only registers a new variation when the first 3–5s *visual* changes, not just the text (Sanchez).
9. **Gut-check each hook** `visual → speech → visual`: is it instantly clear what it's about? No clarity/alignment → kill it and redo (there are infinite ideas) (M4 §6).

### B) DIAGNOSE mode
1. **Read the metric first.** Compute/ask **hook rate = 3-sec plays ÷ impressions** (×100). <20% = weak (Meta raises CPMs); 25–35% = good/scalable; 40%+ = elite. If hook rate is strong but hold rate weak, the problem is seconds 3–15 — *not* the hook; say so.
2. **Score the 4 components** for alignment. Spot the classic breaks: spoken/visual/text disagree → confusion; product in a cold hook; text optimized while the weak visual is ignored; generic hook that talks to "everyone" (M4 §8).
3. **Locate the missing contrast.** Is there an A→B gap at all? If not, the hook is describing, not disrupting.
4. **Rebuild:** keep whatever component is strong, swap the weakest — usually the **visual** (highest leverage). Re-run steps A4–A9 to output the fix + 3–5 fresh visual-hook variants.
5. **Hand back a test plan:** hold body constant, vary only the opener's visual, one variant per ad set, read the winner by hook rate over ~2–3 days / enough impressions.

## Rules & standards (MLO non-negotiables)
- **Trinidad-first / message > format:** the hook serves the avatar + angle, not a cool edit.
- **The visual leads.** Optimize the key visual before the wording; it's the biggest lever.
- **Alignment of all 4 components** is the difference between 500 and 500.000 views.
- **One avatar, one awareness level.** Cold hooks carry no product.
- **Contrast is mandatory** — every hook opens a curiosity loop (creen A → muestras B).
- **Never invent** curiosity that doesn't connect back to the real mechanism.
- **Variation = Andromeda:** hook variants live in *separate ad sets*, never stacked in one.
- **FFM measures it:** hook rate = video capture; fix the hook before the hold.
- **Precision > filler.** Concrete, shootable, no vague adjectives.

## Output (exact shape + example)
Return, per hook, a 4-component block; then a 3–5-variant slate + test note.

```
HOOK #1  · Format: Contrarian + Magician stun · Awareness: Problem-Aware · Generator: Surprising culprit
  SPOKEN:  "Deja de tomar magnesio por la noche. Lo estás haciendo al revés…"
  VISUAL:  primer plano manos tirando un bote de magnesio genérico a la basura (stun) → corte a la cápsula ZZEN
  TEXT:    "El error nº1 con el magnesio"
  AUDIO:   record-scratch en el 'Deja de tomar', silencio en el snapback
  CONTRAST: creen "más magnesio = mejor descanso" → muestras "la forma/timing lo arruina"

SLATE (mismo cuerpo, 3–5 visual hooks, ad sets separados / Andromeda):
  V1 visual: bote a la basura (arriba)
  V2 visual: split-screen "10pm vs 3am despierto"
  V3 visual: mano apretando la espinilla 5s (testable proof)
TEST: hook rate por variante (3-sec ÷ impresiones), objetivo 25%+ (30%+ = winner); 1 visual por ad set, ~2–3 días.
```

## Guardrails
- Not a full-script tool — this is the opener only; the body/CTA belong to `framework-scriptwriter`.
- Hooks in the brand's market language (ES/EN); respect brand claims/legal limits.
- Static ads have no 3-sec play — judge the "hook" by CTR / first-frame, not hook rate.
- Don't stack hook variants in one ad set (destroys the read); don't ship a hook that fails the `visual→speech→visual` gut-check.
- If asked for pure metric optimization of a live Meta ad, defer/hand off to the sibling **`meta-hook-optimizer`** (Meta-ads repo).

## Relationship to other MLO skills
- **`meta-hook-optimizer` (Meta-ads repo)** = the **metrics-optimizer cousin**: same hook-rate math, but starts from live ad metrics to diagnose/generate on the platform side. **This skill is the scripting-suite hooks brain** — it engineers hooks from MLO's creative system (M4) at the script/brief stage. Use hooks-expert when writing, meta-hook-optimizer when reading account data.
- Feeds **`framework-scriptwriter`** (hook = row 1 of the brief) and **`unaware-ads-expert`** (max-curiosity cold hooks). Aligns with `mlo-creative-strategy`, `mlo-ad-brief-builder`, `skeleton-ads`; don't fork them.

## References
See `reference/knowledge-base.md`. Grounded in **M4 · Hooks** and **M1/M00 (awareness, 3A, Andromeda, FFM)** of `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/`; reuses `experts-offers-hooks.md` (hook archetypes, hook/hold-rate formulas + benchmarks, Zeigarnik/open loops) and `experts-dtc-creative.md` (Sanchez hook-swap, Hott "Second 0", Theriot 5 stages, Motion angle/hook vocabulary) from `mlo-winner-strategist/reference/`.
