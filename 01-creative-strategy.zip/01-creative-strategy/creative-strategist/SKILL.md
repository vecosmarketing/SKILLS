---
name: creative-strategist
description: >
  The SENIOR creative strategist orchestrator for MLO Growth's DTC brands. Given a brand/product,
  it runs MLO's end-to-end flow — Trinidad (message first) → Research → 3A (Audience·Angle·Ad) →
  pick angle → pick framework → script → QA — and hands off each step to the specialist suite skills
  (research-engine, angle-generator, framework-scriptwriter, hooks-expert, unaware-ads-expert,
  advertorial-strategist, ai-video-director/ugc-director, script-doctor). It's the conductor, not a
  single-shot writer. ALWAYS use this skill (ES/EN) when the user says "estrategia creativa de [marca]",
  "hazme el plan creativo", "de research a brief", "monta la tanda de creativos", "batch creativo",
  "qué ángulos y frameworks uso", "necesito guiones para [marca]", "creative strategy for [brand]",
  "run the full creative flow", "from research to brief", "build the creative batch", "what angle/framework
  should I use". Trigger on any request to plan, orchestrate, or drive the creative-strategy process for
  an MLO brand (8hours, ZZEN, Moncho Moreno, Alma, Bala di Gala, etc.). For documenting/iterating an
  existing winner use mlo-winner-strategist; for a single sub-step, the caller may invoke the specialist directly.
---
# Creative Strategist — the conductor of MLO's end-to-end creative flow

## What it does
This is the **senior orchestrator**. It does not just write one script — it runs MLO's whole creative
system from a standing start and **hands off** each stage to the right specialist. Given a brand/product
(and its brand brain, if one exists), it: fixes the message first (**Santísima Trinidad**), runs **Research
& ICP**, works the **3A framework** (Audience · Angle · Ad) down the **Árbol de Cascada** (Deseo → Avatar →
Ángulo), diagnoses **Awareness × Sophistication**, **picks the angle**, **picks one of the 12 frameworks**,
produces the **script → brief**, and runs **QA (FFM-aware)**. It sequences the suite, resolves conflicts
between specialists, and decides what to batch, in what mix, for which awareness levels.

**Relationship to existing skills (don't fork — orchestrate):**
- `mlo-creative-strategy` / `mlo-psychological-coverage` — strategy analysis & coverage lenses; this skill
  *uses* them to check the portfolio mix and psychological/awareness coverage of a planned batch.
- `mlo-winner-strategist` — documents & iterates an *existing* winner. When a winner exists, this conductor
  routes to it instead of re-researching from zero.
- `mlo-ad-brief-builder`, `mlo-advertorial-strategist`, `mlo-advertorial-brief-builder`, `skeleton-ads`,
  `nil-script-builder`, `seedance-20-ugc-ad-director` — the production/format specialists it hands off to.
- The brand brains (`mlo-brand-brain-*`) — the knowledge-base source it pulls context from before starting.

## When to use (ES + EN trigger phrases)
**ES:** "estrategia creativa de [marca]", "plan creativo", "de research a brief", "monta la tanda/batch de
creativos", "¿qué ángulos y frameworks uso?", "necesito guiones para [marca]", "orquesta el flujo creativo",
"del research al guion", "arranca la estrategia creativa de X".
**EN:** "creative strategy for [brand]", "run the full creative flow", "from research to brief", "build the
creative batch", "what angle/framework should I use", "I need scripts for [brand]", "orchestrate the creative
process".
**Route elsewhere:** a *single* existing winner to document/iterate → `mlo-winner-strategist`. A single isolated
sub-step (just hooks, just a teardown) → call that specialist directly.

## Inputs needed
1. **Brand/product** (name + URL or product sheet). Pull the **brand brain** if it exists.
2. **Goal & scope**: how many concepts/scripts, which funnel stage (TOF/MOF/BOF), format constraints, deadline.
3. **Assets on hand**: reviews/VoC, competitor ads, existing winners, founder availability, UGC creators.
4. **Account context**: currency, market, sophistication of the category, what's already been tested/fatigued.
If any are missing, **ask up front** (don't invent) — but you may proceed on defaults and mark gaps `⏳ pendiente`.

## Method (the conductor's run — numbered)
The order is fixed because **message > format** and each stage feeds the next (research doc → concept →
script → brief). At every stage, either do the light version inline or **delegate to the specialist** and
integrate the result.

1. **Frame the mission (Trinidad first).** Before any format talk, lock the **Santísima Trinidad**:
   *what we say and in what order* to move a viewer from scroll → "I want it". No framework, no format, until
   the message is clear. (Playbook M1 / INDEX.) Confirm the desired business outcome and the **FFM** targets
   (hook rate, hold rate, CTR, ROAS) you'll be judged on.

2. **Research & ICP → hand off to `research-engine`.** Run MLO's research pipeline: Product Fundamentals
   table → Categorized Insights from VoC (pains, failed solutions, desired outcomes, objections,
   misconceptions, golden nuggets, ICP language, key personas) → Research Maestro (north star) that ends in
   **≥5 numbered ad concepts** → competitor Teardown (wrong / opportunities / transferable). Language must come
   from **real reviews/VoC**, never invented. (Playbook M2 + AI prompts [1]–[4].)

3. **3A — Audience.** Walk the **Árbol de Cascada**: **Deseo → Avatar → Ángulo**. Define the persona as
   *identity + motivation + buying context* and diversify personas so the batch isn't one avatar. (INDEX: 3A,
   Árbol de Cascada.)

4. **Diagnose Awareness × Sophistication (both axes).** For each avatar, place it on the grid: **awareness =
   what the prospect knows** (Unaware→Problem→Solution→Product→Most-aware); **sophistication = how many times
   the market has heard the claim** (Stage 1–5). This is the master cheat-sheet — it decides the hook family and
   catches the two classic failures (offer-ad to unaware; bare-claim in a saturated market). (Reuse
   `mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz grid.)

5. **3A — Angle → hand off to `angle-generator`.** Pick angles with **EPIC** and the grid intersection.
   Map candidate angles to awareness/sophistication cells; kill angles that don't fit the avatar's cell. For
   an unaware avatar, choose an entry gate — **Big Win / Symptom / Hidden Fear** — and keep curiosity high /
   relevance low-medium. (Playbook M5 Unaware + INDEX EPIC.) Check **psychological & awareness coverage** of
   the chosen angle set with `mlo-psychological-coverage` / `mlo-creative-strategy` before committing.

6. **3A — Ad: pick the framework.** Choose **one of the 12 frameworks** *by avatar + awareness + the
   psychological asset you have* (social proof → CROWD/Bandwagon; secret/mechanism → DISRUPT; founder story →
   FOUNDER/PROVE; result-without-pain → SIMPLE; native → PURE; raw emotion → PAS; demo → SHOW; aspiration+date →
   Triple-G; impossible claim → TEASE; curiosity list → CURE). **UGLY** is a filter layered on any of them, not
   a structure. Never pick a framework "because it's cool." (Playbook M3, framework table.)

7. **Script → hand off to `framework-scriptwriter` (+ `hooks-expert`, `unaware-ads-expert`,
   `advertorial-strategist`).** Write to the **winner anatomy**: `Hook → Problem/Desire → Mechanism → Proof →
   CTA-with-reason-to-act-now`, walking the beats of the chosen acronym. Hooks come from `hooks-expert`:
   open a **curiosity loop by contrast**, align the **4 components** (spoken/visual/text/audio) with the
   **visual leading**, and produce **3–5 visual-hook variants** on the same body (variation = separate ad sets,
   Andromeda — never 3 hooks in one ad set). If any avatar is Unaware, route the body through `unaware-ads-expert`
   (`hook → payoff → mechanism → solution → product → CTA`, product hidden ~10–60s, open loops on transitions).
   If the destination is an advertorial/VSL, route through `advertorial-strategist`. (Playbook M3/M4/M5.)

8. **Script → Brief.** Convert every script line into the **brief table**:
   `FRAMEWORK | SCRIPT (UGC/VO/AI-VO) | TEXT (on-screen) | B-ROLL (what to film)`, add the standard
   **Filming Requirements** and notation (`//`, `→`), the multiple-hooks rows, and a tick-off checklist so the
   editor produces it **without asking anything**. Hand production formatting to `mlo-ad-brief-builder` /
   `mlo-advertorial-brief-builder`. For AI/UGC production, hand off to `ai-video-director` / `ugc-director` /
   `seedance-20-ugc-ad-director` using MLO's AI prompt library. (Playbook M3 §3 + M2 prompts [5]–[10].)

9. **QA → hand off to `script-doctor`.** Run the quality gate before anything ships: **Fact Check** (no invented
   claims, cite sources), **Key Persona** resonance, **Curiosity Gap** on every hook, plus the M3 checklist
   (one avatar, unique mechanism visible, proof present, CTA with reason-to-act-now, 3–5 hooks, VoC language).
   (Playbook M2 prompts [11]–[13] + M3 §4.)

10. **Compose the batch & mix.** Decide the portfolio: how many concepts × angles × awareness levels, the
    winner-iteration vs new-concept split, format mix, and the naming/account structure (**Matriz Andromeda**).
    Report the plan, the handoffs made, open `⏳ pendiente` gaps, and the FFM metrics to watch.

## Rules & standards (MLO non-negotiables)
- **Trinidad first; message > format.** A framework is *what you say and in what order*, not "make a founder video."
- **Avatar & angle come from the Árbol de Cascada; the framework is only the vehicle.** Pick by awareness/avatar,
  never by taste.
- **Diagnose BOTH axes** (awareness × sophistication) before choosing an angle — most ROAS decay is the *market*
  advancing a sophistication stage, not the audience.
- **The visual hook leads.** Test **3–5 visual-hook variants** on the same body, each in a **separate ad set**
  (Andromeda). Variation ≠ 3 hooks in one ad set.
- **Never invent.** All language from real reviews/VoC; every claim fact-checked with a source. Gaps = `⏳ pendiente`.
- **Cold = no product in the hook.** In unaware, don't name problem/desire/solution/product/offer in the opening.
- **Precision > filler.** Every beat earns its place; a script without a **unique mechanism** is "just another ad."
- **Everything ships as a brief** (framework | script | text | b-roll + filming reqs + tick-off), never a loose script.
- **Measure with FFM** (hook rate, hold rate, CTR, ROAS); scale with system (20% rule), not with heroes.
- **Orchestrate, don't duplicate.** Delegate to the specialist suite skills; integrate their outputs; resolve conflicts.

## Output (exact shape + concrete example)
Deliver a **Creative Strategy Run** doc:
```
# Creative Strategy Run — [BRAND]
0. Trinidad (the message) + FFM targets
1. Research summary (link/paste) — via research-engine  [key pains, failed solutions, desires, VoC language]
2. 3A map (table): Avatar | Deseo | Awareness | Sophistication | Angle (EPIC) | Framework | Format | Funnel
3. Angle & coverage check — via angle-generator + psychological-coverage
4. Scripts → briefs (one brief table per concept) — via framework-scriptwriter/hooks-expert/unaware/advertorial
5. QA report — via script-doctor (fact-check / persona / curiosity-gap + M3 checklist)
6. Batch plan: concepts × angles × awareness, winner-iteration vs new %, Andromeda naming, ⏳ gaps
```
**Example row of the 3A map (ZZEN, magnesium):**
`Avatar: 45+ light sleeper wired-but-tired | Deseo: dormir profundo sin fármacos | Awareness: Problem |
Sophistication: 4 (saturated) → need mechanism | Angle: "the mineral your body burns under stress" (EPIC,
mechanism-as-revelation) | Framework: DISRUPT (Industry Contrarian) | Format: UGC talking-head + B-roll |
Funnel: TOF`. → hand the body to `framework-scriptwriter`, 4 visual-hook variants to `hooks-expert`,
QA to `script-doctor`.

## Guardrails
- Confirm you have brand context (brand brain / research). If not, **ask before running** — don't fabricate VoC.
- One avatar per script; if the brief tries to talk to everyone, split it.
- Don't ship a script without a mechanism, proof, and a reason-to-act-now CTA.
- Don't put hook variants in the same ad set.
- Respect brand voice guides (e.g., voz-moncho-moreno, v-up-voz-dr-carlos) when they exist.
- This skill **coordinates**; it doesn't overwrite a specialist's judgment — flag conflicts, don't silently resolve.
- ES/EN: mirror the brand's language (EN for 8HOURS/Bridge/MUTO; ES for the rest).

## References
Depth lives in `reference/knowledge-base.md`. Grounded in MLO's Playbook-Scripting-MLO:
`00-INDEX-Sistema-Scripting-MLO.md` (Trinidad, 3A, awareness, sophistication, EPIC, Árbol de Cascada, FFM),
`01-Modulo-Frameworks-y-Script-to-Brief.md` (12 frameworks + Script→Brief), `04-Modulo-Hooks.md`,
`05-Modulo-Unaware-Ads.md`, `02-Modulo-Libreria-Prompts-IA-MLO.md` (the AI prompt pipeline). Reused expert
frameworks (cited, not re-researched): `mlo-winner-strategist/reference/experts-direct-response.md`
(Schwartz awareness×sophistication grid), `experts-dtc-creative.md` (Denney/Sanchez/Hott/Theriot/Motion),
`experts-offers-hooks.md` (Hormozi value equation, hook archetypes, VSL structure), `iteration-playbooks.md`
(format-to-format + AI-video prompting).
