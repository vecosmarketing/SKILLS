# Creative Strategist — Knowledge Base (the conductor's playbook)

This is the distilled reference for the **senior orchestrator**. It summarizes the MLO system it drives and
the expert frameworks it reuses, and lays out the **handoff map** to the specialist suite. Depth on any single
stage lives in that stage's own skill; this file is about *sequencing and decisions*.

---

## 0. The system in one screen (MLO INDEX)
> *Filosofía MLO:* el **mensaje va primero (Trinidad)**; el avatar/ángulo salen del **Árbol de Cascada + 3A**;
> el **framework es el vehículo**; la **IA es el acelerador**; todo se mide con **FFM** y se escala **con sistema,
> no con héroes**. **Precisión > relleno.** (Source: `00-INDEX-Sistema-Scripting-MLO.md`.)

The 9-module system in 3 blocks:
- **Bloque 1 — Fundamentos & Estrategia (el QUÉ decir):** M1 Fundamentos + 3A (Trinidad, Awareness, Market
  Sophistication, 3A, EPIC, winner anatomy); M2 Research & ICP.
- **Bloque 2 — Scripting (el CÓMO se cuenta) · núcleo:** M3 the 12 frameworks + Script→Brief; M4 Hooks;
  M5 Unaware Ads; M6 Formatos por awareness & demografía.
- **Bloque 3 — Motor:** M7 AI prompt library; M8 IA in the workflow; M9 Testing, Winners & Scaling.

**Cross-references the conductor uses:** ángulos/naming → **Árbol de Cascada** + **Matriz/Taxonomía Andromeda**;
medición → preset **FFM** (hook rate, hold rate, CTR, ROAS).

---

## 1. The run order (why it's fixed)
Message > format, and each stage's output is the next stage's input:
`Trinidad → Research (VoC) → 3A Audience (Árbol de Cascada) → Awareness×Sophistication → 3A Angle (EPIC) →
3A Ad (pick 1 of 12 frameworks) → Script (winner anatomy) → Script→Brief → QA → Batch/Andromeda.`

**Winner anatomy (all 12 frameworks are 12 ways to walk it):**
`Hook → Problema/Deseo → Mecanismo (por qué funciona) → Prueba → CTA con razón para actuar ya.`
(Source: `01-Modulo-Frameworks-y-Script-to-Brief.md` §0.)

---

## 2. Trinidad + FFM (stage 1)
- **Santísima Trinidad** = *what we say and in what order* to move a viewer scroll → "lo quiero." Lock this
  before any format decision. (INDEX + M3 §0 rule 1.)
- **FFM preset** = the measurement contract: **hook rate** (video capture), **hold rate**, **CTR**, **ROAS**.
  Set targets before writing; QA and scaling judge against them.

---

## 3. Research & ICP → `research-engine` (stage 2)
MLO's AI pipeline (from cero → brief). The conductor runs / delegates these prompts, output of one = input of next:
1. **[1] Fundamentos de Producto** → table: `FEATURE | BENEFIT | DESIRE | CORE NEED | PAIN | STRUGGLE | OBJECTION | HANDLING | ICP`.
2. **[2] Research Doc (Categorized Insights from VoC)** → Top Pain Points, Failed Solutions, Desired Outcomes,
   Objections, Misconceptions, Golden Nuggets (verbatim), Strategy Implications, ICP Language, Key Personas.
3. **[3] Research Maestro (north star)** → market research w/ sourced quotes ending in **≥5 numbered ad concepts**
   (avatar, hooks, structure, proof, CTA, "why it'll work") + sophistication read + roadmap.
4. **[4] Teardown Competitivo** → What competitors did wrong / Opportunities to exploit / Transferable ideas.
- **Rule:** language 100% from real reviews/VoC; missing data = `⏳ pendiente`; never invent.
(Source: `02-Modulo-Libreria-Prompts-IA-MLO.md` prompts [1]–[4].)

---

## 4. 3A — Audience & the Árbol de Cascada (stage 3)
- **3A = Audience · Angle · Ad.** (INDEX.)
- **Árbol de Cascada:** **Deseo → Avatar → Ángulo.** The framework is only the *vehicle* that carries them.
- Persona = **identity + motivation + buying context**. **Diversify personas** so one batch isn't one avatar.
(Source: INDEX; M3 §1 "Regla MLO".)

---

## 5. Awareness × Sophistication grid (stage 4) — the master cheat-sheet
Two independent axes; diagnose **both** before an angle. *(Reused from
`mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz grid.)*
- **Awareness (the prospect):** cold/no problem recognition → **Unaware/Problem-Aware**; searching solutions →
  **Solution-Aware**; warm/engagers → **Product-Aware**; cart abandoners/list → **Most-Aware**.
- **Sophistication (the market):** novel category → **1–2**; crowded but claims believed → **3 (need a
  mechanism)**; saturated/skeptical (supplements, skincare, weight-loss) → **4–5 (mechanism or identity)**.
- **Pick the hook from the intersection** (grid): e.g. Problem-Aware × Soph 4–5 → name the pain → **prove with
  data/demo/testimonial, lead with credibility**; Solution-Aware × Soph 3 → **mechanism-vs-alternatives**.
- **Two classic DTC failures the grid catches:** (1) **offer-ad to an unaware audience** ("20% off" to cold
  traffic) → move left to a story/problem hook; (2) **bare claim in a saturated market** → move up to a
  **mechanism** (stage 3) or **identity/reinvention** (stage 5).
- **Angle-decay rule:** when a winner fatigues, first ask *"has the market heard this claim too many times?"* —
  usually ROAS decay = the *market* advanced a sophistication stage, not the audience.

---

## 6. 3A — Angle → `angle-generator` (+ coverage) (stage 5)
- Angles via **EPIC** (INDEX) mapped onto the grid cell of each avatar; kill angles that don't fit the cell.
- **Coverage check** before committing the angle set: run `mlo-psychological-coverage` / `mlo-creative-strategy`
  so the batch spans awareness levels and psychological triggers, not one lever repeated.
- **Unaware avatars** — pick an **entry gate** (from `05-Modulo-Unaware-Ads.md`, delegate to `unaware-ads-expert`):
  - **A) Big Win** — the "benefit of the benefit," ride the chain to a big life result. Watch the **TAM** of the win.
  - **B) Symptom** — call the symptom, not the problem ("si tu perro tiene mal aliento…") — like a doctor
    (symptom → diagnosis → treatment). Pick symptoms with search mass.
  - **C) Hidden Fear** — universal fears (lose money, public embarrassment, being cheated, banned, illness/death).
  - **Golden rule:** high curiosity + low/medium relevance; never name problem/desire/solution/product/offer in
    the opening; product hidden ~10–60s.

---

## 7. 3A — Ad: the 12 frameworks (stage 6)
Choose **by avatar + awareness + the psychological asset you hold** (M3 master table):

| Framework | Acronym | Use when… | Typical awareness |
|---|---|---|---|
| Bandwagon | CROWD | social proof / authorities adopting | Solution/Product |
| Industry Contrarian | DISRUPT | a "secret"/mechanism that breaks status quo | Problem/Solution |
| Listicle | CURE | curiosity retention in list form | Problem |
| Founder | FOUNDER | strong founder story/mission | Unaware/Problem |
| How to X without Y | SIMPLE | result **without** the usual pain | Solution |
| Organic | PURE | must not feel like an ad (native) | Any (cold) |
| PAS | Pain-Agitate-Solution | strong clear emotional pain | Problem |
| Ugly Ads | UGLY | stop scroll with raw/ugly on purpose | Any (cold TOF) |
| Founder Objections | PROVE | crush objections in founder's voice | Product |
| Us vs Them | SHOW | can demonstrate superiority visually | Solution/Product |
| Triple G | Goal-Gap-Gains | aspiration/transformation with a date | Problem |
| TEASE | T·E·A·S·E | impossible claim, max retention | Unaware/Problem |

- **UGLY is a filter, not a structure** — layer it on any framework (3 questions: simpler? cheaper-looking?
  opposite of the competitor?).
- **Never pick a framework "because it's cool."** Pick by awareness/avatar.
(Source: `01-Modulo-Frameworks-y-Script-to-Brief.md` §1–2. Acronym beats live there and in `framework-scriptwriter`.)

---

## 8. Hooks → `hooks-expert` (inside stage 7)
- A hook = first **1–5s**; its job is to open a **curiosity loop by CONTRAST** (viewer believes A → you show B).
- **4 components** received at once: **spoken · visual · text · audio** — *máxima alineación* is the 500 vs
  500,000 views difference. Brain order = `visual → audio → visual`, so **the VISUAL leads** (changing the visual
  hook moves performance more than text/voice).
- **6 viral hook formats:** Fortune Teller, Experimenter, Teacher, Magician (stun + combine with any), Investigator,
  Contrarian.
- **6 tangible-curiosity generators** (usually off the mechanism): metaphor, paradoxical question,
  characterization/nickname, testable proof, quiz, surprising culprit. *Trick: start from the curiosity, then
  connect it to the mechanism — never invent.*
- **Proven money hooks:** Investment, Scam ("pensé que era una estafa"), POV, Founder (name+title overlay),
  Emotional, Cognitive dissonance ("¿por qué nadie me lo dijo?"), Identity-based (self-selection).
- **Test 3–5 visual-hook variants** on the same body, **each in a separate ad set** (Andromeda). Not 3 hooks/ad set.
(Source: `04-Modulo-Hooks.md`.)

---

## 9. Unaware body structure → `unaware-ads-expert` (inside stage 7)
`HOOK (high curiosity, no product) → PAYOFF → MECANISMO (intensify pain) → SOLUCIÓN → PRODUCTO → CTA (razón para
actuar ya)`, with **open loops on transitions** ("esta es la parte que nadie te cuenta"). 10 proven unaware types
(paradox, lost wisdom, conspiracy, warning sign, everyday culprit, story, big win, big horror, symptom callout,
sacred cow) + innate-curiosity triggers (NASA/Harvard/Nobel, exotic cultures, mafia/CIA). Hit rate 1/20–1/50 vs
1/10 aware — compensated by scale (one unaware can be a $443k ad). (Source: `05-Modulo-Unaware-Ads.md`.)

---

## 10. Script → Brief (stage 8)
The brief table is the heart of production — the editor builds it **without asking anything**:

| FRAMEWORK | SCRIPT *(FROM UGC / FOR VO / FOR AI VO)* | TEXT *(on-screen)* | B-ROLL *(what to film)* |
|---|---|---|---|
| framework beat | literal line (mode tag) | punchy overlay | exact visual instruction |

- **Filming Requirements (always):** raw via Drive · iPhone **no HDR** · unedited · talking-head & B-rolls
  separate, no voiceover while filming · **no product in the hooks** · good light · **vertical 9:16** · eye-level ·
  no logos/brands, change clothes between talking-head and B-roll.
- **Notation:** `//` splits on-screen text into two cards; `→` = shot sequence in one cell; **HOOK 1…5** rows for
  multiple hooks on one body; **tick-off checklist** at the end.
- Format specialists: `mlo-ad-brief-builder`, `mlo-advertorial-brief-builder`; AI/UGC production:
  `ai-video-director` / `ugc-director` / `seedance-20-ugc-ad-director` using AI prompts [5]–[10]
  (Script desde Concepto, Script Bulletproof, Banco de Hooks, Banco de Headlines, Shotlist, Guía de Edición).
(Source: `01-Modulo-Frameworks-y-Script-to-Brief.md` §3 + `02-Modulo-Libreria-Prompts-IA-MLO.md`.)

---

## 11. QA → `script-doctor` (stage 9)
Quality gate before ship (AI prompts [11]–[13] + M3 §4 checklist):
- **Fact Check** — everything accurate, cite sources, no invented claims.
- **Key Persona** — resonates with the persona's desires/pains/objections.
- **Curiosity Gap** — rewrite any hook that doesn't open a gap (3 versions), keeping persona relevance.
- **M3 checklist:** hook to ONE avatar & stops scroll 0–3s · unique **mechanism** visible · **proof** present ·
  CTA with **reason to act now** · **3–5 hooks** · language from **real VoC**.

---

## 12. Batch, mix & scale (stage 10)
- **Portfolio mix:** concepts × angles × awareness levels; decide **winner-iteration vs new-concept split** (route
  winners to `mlo-winner-strategist`; see `iteration-playbooks.md` — the "iterate vs new concept" decision, 1-angle→
  20-hooks, 3×3 matrix, static→video, UGC⇄high-production, short→VSL, concept→AI-video).
- **Naming & account structure:** **Matriz Andromeda** (variation = separate ad sets).
- **Scaling:** FFM soft/hard metrics; **20% rule**; scale with system not heroes. (INDEX M9.)

---

## 13. Expert frameworks reused (cited, not re-researched)
From `mlo-winner-strategist/reference/`:
- **`experts-direct-response.md`** — Schwartz **awareness × sophistication grid** (§ used in stage 4/5), Ogilvy,
  Halbert (starving crowd/AIDA), Hopkins, Sugarman, Cialdini (7 principles).
- **`experts-dtc-creative.md`** — Dara Denney (3-phase creative testing), Savannah Sanchez (hooks/cadence), Barry
  Hott, Nick Theriot, Motion (2025 creative-trend data) — use for the batch/testing & coverage decisions.
- **`experts-offers-hooks.md`** — Hormozi **Value Equation** & Grand Slam Offer, hook archetypes, thumb-stop-rate,
  unique mechanism, short-form VSL structure, StoryBrand/Hero's Journey/PAS/AIDA.
- **`iteration-playbooks.md`** — format-to-format playbooks + AI-video tool selection & cinematic prompting
  (Veo/Runway/Kling/Sora/Seedance/ElevenLabs/HeyGen).

---

## 14. Handoff map (who does what)
| Stage | Conductor decision | Hand off to |
|---|---|---|
| 1 Trinidad + FFM | lock message + metric targets | — (inline) |
| 2 Research & ICP | run the pipeline, ensure VoC language | `research-engine` |
| 3 Audience (Árbol de Cascada) | Deseo→Avatar→Ángulo, diversify personas | — (inline) |
| 4 Awareness × Sophistication | place each avatar on the grid | reuse Schwartz grid ref |
| 5 Angle (EPIC) + coverage | pick angles per cell, unaware gate | `angle-generator`, `unaware-ads-expert`, `mlo-psychological-coverage`/`mlo-creative-strategy` |
| 6 Framework | pick 1 of 12 by avatar/awareness/asset | — (decision), then → |
| 7 Script + hooks | winner anatomy + 3–5 visual-hook variants | `framework-scriptwriter`, `hooks-expert`, `unaware-ads-expert`, `advertorial-strategist` |
| 8 Script→Brief | brief table + filming reqs + tick-off | `mlo-ad-brief-builder`, `mlo-advertorial-brief-builder`, `ai-video-director`/`ugc-director`/`seedance-20-ugc-ad-director` |
| 9 QA | fact/persona/curiosity + checklist | `script-doctor` |
| 10 Batch & scale | mix, Andromeda, iteration split | `mlo-winner-strategist`, coverage skills |

*Note:* the AI-video production roles (`ai-video-director`, `ugc-director`) are intended suite roles; until a
dedicated skill exists, the conductor runs that stage via `seedance-20-ugc-ad-director` / `nil-script-builder`
or inline with AI prompts [5]–[10], and marks the handoff `⏳ pendiente`. **Confirmed present at build time:**
`research-engine`, `angle-generator`, `framework-scriptwriter`, `hooks-expert`, `unaware-ads-expert`,
`script-doctor`, `competitor-teardown`, `edit-guide`, `mlo-advertorial-strategist`, `mlo-advertorial-brief-builder`,
`mlo-ad-brief-builder`, `mlo-psychological-coverage`, `mlo-creative-strategy`, `mlo-winner-strategist`,
`seedance-20-ugc-ad-director`, `skeleton-ads`, `nil-script-builder`.

---

## Sources
**MLO Playbook (source of truth) — `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/`:**
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, Sophistication, EPIC, Árbol de Cascada, Andromeda, FFM.
- `01-Modulo-Frameworks-y-Script-to-Brief.md` — the 12 frameworks, winner anatomy, Script→Brief table, filming reqs.
- `04-Modulo-Hooks.md` — 4 components, 6 formats, 6 curiosity generators, proven hooks, hook process.
- `05-Modulo-Unaware-Ads.md` — entry gates, 10 types, unaware structure, launch/test.
- `02-Modulo-Libreria-Prompts-IA-MLO.md` — AI prompt pipeline [1]–[13] (research → brief → QA), ACV worked case.

**Reused expert brain — `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/`:**
- `experts-direct-response.md`, `experts-dtc-creative.md`, `experts-offers-hooks.md`, `iteration-playbooks.md`.

**External sources** (via the reused files): Schwartz *Breakthrough Advertising* (awareness/sophistication);
Hormozi *$100M Offers/$100M Leads*; Cialdini *Influence*; Motion 2025 creative-trend report; format/AI-video
playbooks — full URLs in each `experts-*.md` / `iteration-playbooks.md` "Sources" section.
