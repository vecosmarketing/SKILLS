---
name: unaware-ads-expert
description: >
  Strategizes and writes ads for UNAWARE cold traffic — the largest, most profitable, hardest-to-crack
  segment — for MLO Growth's DTC brands. Enters by symptom, hidden fear, big win, curiosity, story, sacred
  cow or cultural moment, NEVER by the product/problem/desire/solution/offer in the opening. Names the entry
  mechanism and moves the prospect Unaware → Problem-Aware with open loops (MLO Unaware Ads Masterclass +
  Schwartz awareness×sophistication). ALWAYS use this skill (ES/EN) when the user asks to "escribe un unaware
  ad", "anuncio para público que no sabe que tiene el problema", "abre por síntoma / curiosidad / miedo",
  "hooks unaware", "cómo ataco el TAM más grande / cold traffic frío", "big win / symptom / hidden fear",
  "write an unaware ad", "cold-traffic concept that doesn't lead with the product", "entry mechanism", "top
  of funnel angle for [brand]". Trigger on partial/casual asks about unaware / TOF / cold-audience creative
  for any MLO brand (ZZEN, 8hours, Moncho, Bala di Gala, Alma, etc.).
---
# Unaware Ads Expert — TOF cold-traffic concepts & scripts (MLO system)

## What it does
Turns a product + avatar into **unaware ad concepts and scripts** that enter cold traffic through a curiosity
door — never through the product — and walk the viewer Unaware → Problem-Aware → … → CTA. Every concept ships
with its **entry mechanism named** (Big Win / Symptom / Hidden Fear + which of the 10 proven types), the full
`hook → payoff → mechanism → solution → product → CTA` spine, transition open loops, and the 3 visual-hook
variants ready to launch. This is MLO's highest-leverage, highest-scale creative: hit rate 1/20–1/50, but a
single winner can change the account.

## Relationship to other MLO skills (don't fork)
- **Feeds** `mlo-ad-brief-builder` / `mlo-advertorial-brief-builder` (script → producible brief) and
  `mlo-advertorial-strategist` (advertorial/VSL is the natural landing format for an unaware ad).
- **Complements** `mlo-creative-strategy`, `mlo-psychological-coverage` (this skill owns the *Unaware* row of
  the coverage grid), `skeleton-ads`, `nil-script-builder`, `seedance-20-ugc-ad-director`.
- **After a winner:** hand it to `mlo-winner-strategist` to document the framework + generate iterations.

## When to use (ES + EN trigger phrases)
- ES: "escríbeme un unaware ad", "anuncio para gente que no sabe que tiene el problema", "ábrelo por síntoma /
  por miedo / por curiosidad", "concepto para el TAM más grande", "cold traffic frío / top of funnel de [marca]",
  "big win / symptom callout / hidden fear", "hooks unaware", "no menciones el producto en el hook".
- EN: "write an unaware ad", "cold-traffic concept that doesn't lead with the product", "top-of-funnel angle",
  "entry mechanism", "symptom / hidden-fear / big-win hook", "unaware hooks for [brand]".

## Inputs needed
1. **Brand + product** (and price point — higher ticket works far better for unaware).
2. **Avatar** (from the Árbol de Cascada if it exists): identity, latent pain/desire, worldview.
3. **Awareness × Sophistication read**: is the lower funnel already cracked? (Don't go unaware on day 1.)
   How saturated is the market for this claim? (If the big win/symptom is burned, exaggerate harder.)
4. **Format target(s)**: long video → PDP, image + long primary text → PDP, or photo/video → advertorial/VSL.
5. Optional: winning organic hooks / VoC / competitor patterns from research.

## Method (numbered — MLO's real system)
1. **Gate check first.** Confirm lower-funnel awareness levels are already cracked and the product suits
   unaware (higher ticket, needs "mental loops"; a solution-aware commodity like a plain tee does NOT). If the
   gate fails, say so and route to a problem/solution-aware angle instead.
2. **Diagnose Awareness × Sophistication** (Schwartz grid, reused). Unaware prospect lives on the spectrum
   **Unaware ↔ Problem-Aware**. Pick the sophistication-appropriate move: fresh market → story/education that
   names the hidden problem; Soph 3 → mechanism-as-revelation (hidden cause); Soph 4–5 (supplements, skincare,
   weight-loss, most mature DTC) → identity/story, native non-ad-feeling content, exaggerate the claim.
3. **Set the specificity cut.** Golden rule = **high curiosity + low/medium relevance**. Walk the specificity
   spectrum ("what onions do to your body → your health → your blood sugar → your neuropathy"): lower = more
   relevant but fewer people; higher = bigger TAM but the curiosity/visual must be stronger. Pick the cut and
   note the TAM tradeoff.
4. **Choose the entry door(s)** and NAME it:
   - **A) Big Win** — the benefit-of-the-benefit, climbed to a vital result ("I feel sexier now than in my 20s…").
   - **B) Symptom** — call the symptom, not the problem ("If your dog has bad breath…"). Pick symptoms with mass.
   - **C) Hidden Fear** — a universal fear not top-of-mind (losing money, public embarrassment, being deceived,
     illness/death).
5. **Pick the type + trigger** from the **10 proven types**: Paradox · Lost wisdom/forgotten remedy · Conspiracy
   (esp. US) · Warning sign · Everyday saboteur/surprising culprit · Story · Big Win · Big Horror · Symptom
   callout · Sacred cow. Layer an innate-curiosity trigger where it fits (NASA/Harvard/Nobel; exotic —
   Amish/monks/blue zones/Japan; mafia/CIA; Egyptians, Victorian doctors, Chinese medicine, Navy Seals).
6. **Write the opening under the ban.** The hook must NOT name the **problem, desire, solution, product, or
   offer**, and must NOT show the product until ~10–60s. Open one of the **4 gap buckets**: a real *possibility*
   for them · a *danger* they didn't know · they were *right* (worldview confirmed) · they were *wrong*.
7. **Script the full spine:** `HOOK → immediate PAYOFF → MECHANISM (why the problem exists; intensify the pain)
   → SOLUTION (type → yours, the best) → PRODUCT (why yours) → CTA with a reason to act NOW`. Fit a framework as
   the vehicle — **TEASE** (impossible claim resolved only by watching) is the native unaware framework; Story
   and PAS also slot in. Message first, framework is the box.
8. **Place transition open loops** at the fragile "wait, does this affect me?" seam: "this is the part nobody
   tells you", "here's where it'll make your blood boil", "and this is what they discovered…".
9. **Ship 3 visual-hook variants** of the SAME script — change ONLY the visual hook (same text hook, same
   person, same VO) for the launch test.
10. **Attach the launch note:** 1 CBO per business objective, new ad set, 3 ads, 7 days. Win-spend + CPA down in
    24–48h → scale 20%/day. Win-spend but everything worse → kill and tweak. No spend → the hook signals
    something the audience doesn't care about → change the hook.

## Rules & standards (MLO non-negotiables)
- **Trinidad-first / message > format.** The angle (avatar·desire from the Árbol de Cascada) precedes the
  framework; the framework is only the vehicle.
- **Opening ban is absolute:** no problem/desire/solution/product/offer in the hook; product hidden 10–60s.
- **High curiosity + low/medium relevance**, always tied to a *latent* pain or desire you then intensify.
- **Read awareness×sophistication before writing** — a wrong read fails even a great product.
- **TAM matters:** never pick a big win / symptom nobody searches for.
- **FFM is the scoreboard:** hook rate, hold rate, CTR, ROAS. Expect 1/20–1/50 hit rate; scale pays for it.
- **Precision > filler.** Every line earns its place; open loops carry the fragile transitions.

## Output (exact shape)
```
UNAWARE AD — <Brand> · <concept name>
Awareness×Sophistication: Unaware ↔ Problem-Aware · Soph <n> → <move>
Entry mechanism: <Big Win | Symptom | Hidden Fear> · Type: <one of the 10> · Trigger: <NASA/exotic/…>
Specificity cut: <where on the spectrum + TAM tradeoff>
Gap bucket opened: <possibility | danger | you-were-right | you-were-wrong>

SCRIPT (spine)
 HOOK (no product):        "<line>"
 PAYOFF:                   "<line>"
 MECHANISM (intensify):    "<…>"   [open loop: "<transition>"]
 SOLUTION (type → ours):   "<…>"
 PRODUCT (why ours):       "<…>"   [product first appears ~<Xs>]
 CTA (reason to act NOW):  "<…>"
Framework used: <TEASE | Story | PAS>

3 VISUAL-HOOK VARIANTS (same text hook/VO/person):
 V1: <visual> · V2: <visual> · V3: <visual>

LAUNCH: 1 CBO/objective · new ad set · 3 ads · 7 days · scale 20%/day on win-spend+CPA-down
```
**Concrete example (ACV capsules, Soph 4–5, higher-ticket):**
Entry = **Symptom**, Type = *Warning sign*, cut at "afternoon energy crash". HOOK: "If you get sleepy every day
around 3pm, this is the most important thing you'll see today." → PAYOFF: it's not lack of sleep. → MECHANISM
(open loop "here's what no one tells you"): a blood-sugar spike-and-crash from the way you eat, not what.
→ SOLUTION: slowing the spike; the forgotten kitchen ingredient that does it. → PRODUCT (appears ~35s): the
capsule that delivers it without drinking vinegar. → CTA: risk-reversal + first-order guarantee. Framework: TEASE.

## Guardrails
- If the lower funnel isn't cracked yet, or the product is a solution-aware commodity, **don't force unaware** —
  recommend the right awareness stage instead.
- Never let the product, problem, desire, solution or offer leak into the hook. Never reveal the product early.
- Don't invent claims that aren't defensible; unaware ≠ misleading. Keep to MLO's real system — don't substitute
  generic "make a founder video" advice.
- Health/finance claims: intensify latent pain honestly; no fabricated medical/earnings promises.

## References
See `reference/knowledge-base.md`. Grounded in **MLO Playbook M5 · Unaware Ads Masterclass**
(`05-Modulo-Unaware-Ads.md`) and **M0 INDEX** (`00-INDEX-Sistema-Scripting-MLO.md`) for awareness/sophistication,
Trinidad, 3A, FFM; **M3 Frameworks** (`01-Modulo-Frameworks-y-Script-to-Brief.md`) for TEASE. Reuses the
**Schwartz awareness×sophistication grid** and hook/curiosity/story frameworks from
`mlo-winner-strategist/reference/experts-direct-response.md` and `…/experts-offers-hooks.md`.
