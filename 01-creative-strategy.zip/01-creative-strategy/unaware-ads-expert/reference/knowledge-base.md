# Knowledge base — Unaware Ads Expert

Distilled from MLO's own Unaware Ads Masterclass, plus the reused Schwartz / DR expert brain. This is the
source of truth for writing ads to UNAWARE cold traffic. **MLO system first, generic advice never.**

---

## 1. Why unaware is the ad that matters (MLO M5 §1)
- Awareness ladder (M0/M1): `Unaware → Problem → Solution → Product → Most-aware`. **Unaware = the biggest
  segment** — people who don't know they have the problem, don't search, don't think about the category. Biggest
  TAM → most profitable, scales the most.
- **Also the hardest:** hit rate **1/20–1/50** vs ~1/10 for an aware ad. Slower to produce (an aware ad: ~30 in
  2h; an unaware: 1–2 in 4–5h, sometimes 2 weeks). But a single winner can change the account (cases of $443k
  behind one ad).
- **Entry rules:** only go unaware **after** cracking the lower awareness levels (not day 1). **Higher ticket
  works better** (more "mental loops" → you need margin). A solution-aware commodity (a plain tee) does NOT go
  unaware. Some markets never need unaware (enough solution-aware TAM already).

## 2. The golden rule (M5 §2)
An unaware ad leads with **high curiosity + low/medium relevance**. It lives on the spectrum **Unaware ↔
Problem-Aware** and almost always touches a **latent pain or desire** that you then intensify and crystallize.

**Specificity spectrum** — you choose where to cut:
> "What onions do to **your body**" → "to your **health**" → "to your **blood sugar**" → "to your **neuropathy**".
- Lower = more relevant but **fewer people**. Higher = **bigger TAM but you need a stronger curiosity/visual**.

## 3. The opening ban (M5 §3)
In the hook/headline you may NOT call out:
- ❌ the **problem** ("does your head hurt?")
- ❌ the **desire** ("how to make more money")
- ❌ the **solution** ("you need mentoring")
- ❌ the **product** (the brand)
- ❌ the **offer** ("sign up today")

You can say all of that **inside** the ad — never in the opening. And **don't show the product** until ~**10–60s**
(this deliberately breaks "show the product in the first second," which only applies to aware/solution-aware).

## 4. The 3 entry doors — name the mechanism (M5 §4)
- **A) Big Win — the benefit-of-the-benefit.** Climb the chain to a big vital result. *Cayenne → burns calories
  → lose weight → **you look sexier** →* hook: "I feel sexier now than in my 20s, and it started when I tried
  this." Then → problem → solution → product → offer. **Find them:** study the niche on TikTok/YouTube/Reddit,
  note which wins people celebrate; watch the **TAM** of the win (too small a win pays poorly).
- **B) Symptom — call the symptom, not the problem.** "If your dog has bad breath, this is the most important
  thing you'll see" → diagnose the problem (plaque) → solution (seaweed) → product → offer. Doctor logic:
  symptom → diagnosis → treatment. Different symptoms = **different search volume** (dog licking paw ≫ itching
  ear); pick symptoms with mass.
- **C) Hidden Fear — universal fears not top-of-mind.** Losing money, public embarrassment, being deceived, a
  banned account, illness/death. "The most embarrassing thing that happened to me in my 60s…" → relatable story
  → problem → solution → product.

## 5. The 10 proven types + triggers (M5 §5)
On a new account, run the list and test styles:
1. **Paradox** ("why does an adult take longer to learn a language than a child?")
2. **Lost wisdom / forgotten remedy** (what the Amish / the tribes did)
3. **Conspiracy** (esp. US; "what the industry won't tell you", cover-ups)
4. **Warning sign** ("if your dog's ears look like this…")
5. **Everyday threat / surprising culprit** ("the bathroom object sabotaging your weight")
6. **Story** ("my Uber driver told me 5 words that changed how I see men")
7. **Big Win** (§4A)
8. **Big Horror** (the negative version: worst-case, vivid)
9. **Symptom callout** (neutral symptoms painted as a problem)
10. **Sacred cow** (validate or contradict a market belief)

**Innate-curiosity triggers that almost always hook:** NASA / Harvard / Nobel; the exotic (Japanese, Amish,
monks, Switzerland, Norway, blue zones); mafia / CIA / conspiracy; Egyptians, Victorian doctors, Chinese
medicine, Navy Seals.

## 6. Advanced idea machines (M5 §6)
- **Steal organic hooks (cook your algorithm):** spin up a separate IG account, follow high-signal niche
  accounts, engage until your feed = your prospect's feed. When writing, swipe the hooks that pop + read
  comments (pure research).
- **Avatar worldview:** *"people will do anything for someone who encourages their dreams, justifies their
  failures, calms their fears, **confirms their suspicions**, and helps them throw rocks at their enemies."*
  Speak to the worldview (validate or agitate it) → infinite ideas. (Alt-health: throw rocks at "the industry";
  dating: confirm the apps are rigged against them.)
- **Winning-angle vectors:** detect the pattern of what works (yours + organic) and expand it in every direction.

## 7. Structure of the unaware ad (M5 §7)
```
HOOK (high curiosity, no product)
 → immediate PAYOFF (deliver what the hook promised)
   → MECHANISM (why the problem exists; intensify the pain here)
     → SOLUTION (type of solution → yours, the best)
       → PRODUCT (why yours)
         → CTA with a reason to act NOW (scarcity / risk-reversal)
```
**Open loops at the transitions** so they don't bail at the fragile point (moving from "I came for curiosity"
to "does this affect me?"): "this is the part nobody tells you", "here's where your blood will boil", "and this
is what they discovered…".

**The 4 gap buckets every unaware hook opens:** a real **possibility** for you · a **danger** you didn't know ·
you were **right** (worldview confirmed) · you were **wrong** about something.

## 8. Production & test (M5 §8)
**Execution formats (test all 4):** long video (30s–3min) → PDP · photo with very long primary text → PDP ·
photo/video → advertorial/VSL → PDP (lifts conversion) · start with the first two before writing off unaware.
**Launch:** 3 variants of the SAME script changing ONLY the visual hook (same text hook, person, VO) → into your
CBO (1 per business objective), new ad set, 3 ads → **7 days**. Win-spend + campaign CPA down in 24–48h → scale
20%/day. Win-spend but everything worse → kill and tweak. No spend → the text/visual hook signals something the
audience doesn't care about → change it. **Market sophistication applies here too** — if the big win/symptom is
burned, exaggerate harder.

## 9. Quality checklist (M5 §9) & common mistakes (§10)
- [ ] Opening = high curiosity + low/med relevance; NO problem/desire/solution/product/offer.
- [ ] Touches a latent pain/desire and intensifies it.
- [ ] Product doesn't appear until ~10–60s.
- [ ] Runs `hook → payoff → mechanism → solution → product → CTA` with open loops.
- [ ] 3 visual-hook variants on one script to test.
- [ ] Awareness/sophistication read correctly (or it fails even with a great product).
- **Mistakes:** going unaware before cracking lower levels · naming the problem/product in the hook (turns them
  problem/product-aware) · showing the product too early · picking a tiny-TAM win/symptom · expecting aware-level
  hit rates (it's 1/20–1/50; scale compensates).

---

## 10. Reused expert frameworks (cite the winner-strategist reference files)

### Schwartz Awareness × Sophistication grid — the Unaware row
From `mlo-winner-strategist/reference/experts-direct-response.md` §"Awareness × Sophistication grid" [1][3][5].
Diagnose BOTH axes before choosing the hook. **Awareness = what the prospect knows; Sophistication = how much
the whole market has already heard this claim.** The less aware → the longer the runway before the product.

**Unaware row of the grid (the exact intersection this skill lives in):**
| Sophistication 1–2 (fresh) | Sophistication 3 (needs mechanism) | Sophistication 4–5 (saturated/skeptical) |
|---|---|---|
| Story/education hook that names the (hidden) problem, then the plain benefit. | Story/education that reveals the **hidden cause** (mechanism as revelation). | **Identity/story hook** — "for the [identity] who…"; native, non-ad-feeling content. |

- **Common DTC failure this catches:** running a Most-Aware offer ("20% off!") to unaware cold traffic → move
  left to a story/problem hook. In saturated categories (supplements, skincare, weight-loss), a bare benefit
  claim is invisible → add a **mechanism** or shift to **identity**. This maps 1:1 to MLO's "if the big
  win/symptom is burned, exaggerate / add mechanism."
- **Angle-decay rule:** when a top unaware creative fatigues, first ask "has the market heard this claim too
  many times?" → deepen the mechanism or shift to identification; if the drop is audience-side, re-diagnose
  awareness and change runway length, not the claim.

### Curiosity, open loops & the Zeigarnik effect
From `…/experts-offers-hooks.md` §"Curiosity, Open Loops & The Zeigarnik Effect". The curiosity gap = the space
between what we know and what we want to know; open loops (unresolved narratives) hold attention. Neuro basis:
the left caudate (dopamine reward pathway) fires when an information gap appears — curiosity runs on the brain's
reward system. **Apply:** open a specific loop in the hook, resolve it only after the mechanism reveal; never
close the curiosity before the CTA. This is the mechanism behind MLO's "open loops at the transitions."

### Hook archetypes (first 3 seconds)
From `…/experts-offers-hooks.md` §"Hook Archetypes". Winning hooks: **open a gap, are specific enough to feel
credible, and deliver on the promise inside the ad.** Archetypes that fit unaware openings: **Question**
("Did you know…?" / "What if I told you…"), **Curiosity Gap** (give just enough to want the rest — the gap must
be *specific*), **Story**. Script 3–5 hook archetypes for the SAME body and test them — mirrors MLO's 3
visual-hook variants (hook = ~80% of VSL performance).

### Story frameworks + awareness routing
From `…/experts-offers-hooks.md` §"Story Frameworks" and §"VSL structure": Unaware/Problem-unaware → lead with
**story + AIDA** (build the problem and desire before the offer). A 2–2.5min VSL can walk a viewer from problem
to purchase: hook → PAS → mechanism → proof → offer → CTA. Hero's Journey compresses to 60s for a founder /
testimonial unaware ad (Ordinary World = the struggle before → discovers product → skepticism/trials →
transformation → recommends).

---

## 11. MLO system anchors (from M0 INDEX & M3)
- **Trinidad first** (message before format); **3A** = Audience · Angle · Ad; avatar + angle come from the
  **Árbol de Cascada**; naming/account structure from the **Matriz Andromeda**; measurement = **FFM** preset
  (hook rate, hold rate, CTR, ROAS). Source: `00-INDEX-Sistema-Scripting-MLO.md`.
- **TEASE framework** (`01-Modulo-Frameworks-y-Script-to-Brief.md` ⑫) is the native unaware vehicle — an
  impossible/surprising claim that creates dissonance and resolves ONLY by watching the whole ad:
  **T**ease (impossible claim) → **E**ngage (develop the story, introduce product without revealing the link) →
  **A**dvantage (stack benefits + proof in-narrative) → **S**atisfy (clever resolution that makes the claim
  logical) → **E**ncourage (immediate CTA + urgency/bonus). Also usable: Story, PAS.
- **EPIC** angles and the full 12 frameworks live in M3 — this skill picks the vehicle, the Árbol de Cascada
  picks avatar+angle.

---

## Sources
**MLO Playbook modules (source of truth):**
- `05-Modulo-Unaware-Ads.md` — Unaware Ads Masterclass (§§1–11) — primary source for this skill.
- `00-INDEX-Sistema-Scripting-MLO.md` — awareness levels, Trinidad, 3A, Árbol de Cascada, Andromeda, FFM.
- `01-Modulo-Frameworks-y-Script-to-Brief.md` — TEASE framework (⑫), Script→Brief.

**Reused expert brain (mlo-winner-strategist/reference/):**
- `experts-direct-response.md` — Schwartz Awareness × Sophistication grid.
- `experts-offers-hooks.md` — hook archetypes, curiosity/open loops/Zeigarnik, story frameworks, VSL structure.

**External (already cited in the reused files):**
- Schwartz awareness & sophistication — https://www.kingeshop.com/en/customer-awareness-sophistication-eugene-schwartz
- 5 Stages of Awareness — https://www.leadgen-economy.com/blog/five-stages-awareness-lead-generation/
- 5 Levels of Market Awareness — https://copyposse.com/blog/5-levels-of-market-awareness-how-to-speak-to-your-target-audience-part-1/
- Hook archetypes — https://prealgo.com/blog/hook-archetypes-2026
- Zeigarnik effect / curiosity — https://www.leadalchemists.com/marketing-psychology/ziegarnik-effect/
