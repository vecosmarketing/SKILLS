---
name: psychological-coverage
description: >
  Audits a DTC brand's ACTIVE ad portfolio for psychological coverage and surfaces the GAPS. Maps every
  live ad onto the Schwartz Awareness × Sophistication grid + emotional triggers + Cialdini's 7 persuasion
  levers, finds where the portfolio is bunched vs. white space, and outputs a coverage matrix + a prioritized
  gap list + a next-batch recommendation (target cell → MLO framework → concept). Grounds in MLO's Sistema de
  Scripting (Trinidad, 3A, Awareness, Sophistication, EPIC, the 12 frameworks, FFM) and reuses the winner-strategist
  expert brain (Schwartz, Sugarman, Halbert, Cialdini). Complements — does NOT fork — mlo-psychological-coverage
  (Levinger's Valence × Self-Concept × Intensity); cross-references it. ALWAYS use this skill (ES/EN) when the user
  says "audita la cobertura de [marca]", "coverage audit", "mapea mis anuncios en el grid de awareness", "qué
  awareness/emociones/palancas me faltan", "dónde está el hueco psicológico de mi cuenta", "qué produzco esta
  semana según cobertura", "matriz de cobertura", "gap analysis de creativos", "audit my active ads", "map my
  portfolio to awareness × sophistication", "which emotions / Cialdini levers am I missing", "what's the white space".
  Trigger on partial/casual asks about auditing an ad portfolio's psychological coverage for any MLO brand
  (ZZEN, 8hours, Moncho Moreno, Bala di Gala, HobbitAlf, Alma, Chic&Love, V-UP, etc.).
---

# Psychological Coverage — Portfolio Audit & Gap Finder

## What it does
Takes a brand's **current active ad portfolio** and audits it for **psychological coverage** across three
persuasion lenses:
1. **Schwartz Awareness × Sophistication grid** — the master axis (which prospect state × which market stage each ad serves).
2. **Emotional triggers** — which feeling each ad fires (fear, frustration, aspiration, curiosity, belonging, trust, guilt, greed, surprise, humor).
3. **Cialdini's 7 levers** — which persuasion principle each ad pulls (reciprocity, commitment, social proof, authority, liking, scarcity, unity).

It plots every ad, exposes where the account is **bunched vs. white space**, and delivers a **coverage matrix + a prioritized gap list + a next-batch recommendation** (which awareness/emotion/lever to make next, with the MLO framework to deliver it).

**Relationship to `mlo-psychological-coverage` (Sarah Levinger).** That sibling audits the same portfolio on **Valence × Self-Concept × Language Intensity** and drives batch/copy review. This skill audits on the **complementary** awareness-stage / trigger / Cialdini axes. Do not fork — cross-reference. When both run, a *truly* redundant ad repeats on BOTH lens-sets.

## When to use (ES + EN trigger phrases)
- ES: "audita la cobertura de [marca]", "coverage audit", "mapea mis anuncios activos en el grid de awareness × sophistication", "¿qué awareness/emociones/palancas me faltan?", "¿dónde está el hueco psicológico de la cuenta?", "matriz de cobertura", "gap analysis de creativos", "¿qué produzco esta semana según cobertura?", "¿mi cuenta cubre todo el funnel?".
- EN: "audit my active ads", "coverage audit", "map my portfolio to awareness × sophistication", "where's the white space", "which emotions / Cialdini levers am I missing", "coverage matrix", "creative gap analysis", "what should I produce this week based on coverage".
- For any MLO brand (ZZEN, 8hours, Moncho Moreno, Bala di Gala, HobbitAlf, Alma, Chic&Love, V-UP, i-Energy…).
- **Not** for writing a single script (→ framework-scriptwriter), generating angles (→ angle-generator), reviewing one copy on valence/self-concept (→ mlo-psychological-coverage), or documenting one winner (→ mlo-winner-strategist).

## Inputs needed
- The **active-ad list** (last 60–90 days): ad name/id, format, and the hook/opening + key message. If not supplied, ask for it — or the Meta account id + date range so it can be pulled. **Never invent a portfolio.**
- Optional but valued: **FFM metrics** (hook rate, hold rate, CTR, ROAS) + spend per ad — lets recommendations distinguish "untested white space" from "tested and lost."
- Optional: the brand's ICP/awareness context and current funnel focus.

## Method (numbered — the core)
1. **Pull the active ads** (60–90 days). Capture id/name, format, hook/first-3s, key message, and FFM+spend if available.
2. **Classify each ad on all three lenses — reading the HOOK/entry, not the format (Trinidad-first):**
   - **Awareness (1–5)** — where the ad *enters*: Unaware / Problem / Solution / Product / Most-Aware. Offer-led hook = Most-Aware regardless of the body.
   - **Sophistication (S1–2 / S3 / S4–5)** — how many times the market has heard this claim; S3 needs a mechanism, S4–5 needs proof/identity.
   - **Emotional trigger** — the PRIMARY feeling fired (+ any secondary).
   - **Cialdini lever(s)** — which of the 7 principles it pulls.
   - Note the **MLO framework** (one of the 12) and **EPIC family** for context — but score coverage on the lens tags, not the framework (12 frameworks can sit in one cell).
   - Cite the hook line that justifies each classification (precision > filler).
3. **Build the coverage matrix** — a 5-row (Awareness) × 3-column (Sophistication) grid, each ad dropped in its cell. Add two tally tables: emotional-trigger counts and Cialdini-lever counts. Overlay spend/win where FFM exists.
4. **Find clusters & white space** — the 1–2 cells holding 70–90% of ads (usually Problem-Aware/S4 + fear/urgency + social-proof/scarcity), the empty cells, the missing triggers, the unused levers.
5. **Prioritize the gaps** — rank each by: (a) size of the desire pocket it serves, (b) learning value (never-tested > iteration), (c) fit to the brand's funnel stage, (d) FFM signal that an adjacent cell wins. Flag the two classic failures if present: offer-ad-to-Unaware, and bare-claim-in-saturated-market.
6. **Recommend the next batch** — for each top gap: target cell + trigger + lever, the MLO framework that best delivers it (e.g. TEASE for Unaware/curiosity, Founder for liking/authority, Us vs Them for S4 proof, Industry Contrarian for S3 mechanism), and a one-line concept. **Cross-check against `mlo-psychological-coverage`** so the batch also fills valence/self-concept white space.

## Rules & standards (MLO non-negotiables)
- **Trinidad-first:** audit the message, never the format. A cell is defined by what the ad *says and to whom*.
- **Message > format:** two ads in the same cell with different formats are still redundant coverage. Framework variety ≠ coverage.
- **Precision > filler:** every classification cites the hook that justifies it; every gap names a real desire pocket, not "try positive too."
- **Coverage > volume:** recommend the *minimum* set that fills the most valuable white space. Discovery beats 100 iterations.
- **FFM-aware:** with data, never re-recommend a cell that already failed; separate untested white space from tested-and-lost.
- **Align, don't fork:** always note the relationship to Levinger's `mlo-psychological-coverage` and cross-reference when both are run.

## Output (exact shape + example)
**A. Coverage matrix** (Awareness rows × Sophistication columns) with ads in cells, plus emotional-trigger and Cialdini-lever tally tables (white space flagged).
**B. Cluster & white-space summary** (2–4 lines).
**C. Prioritized gap list** — ranked table: `# | Gap (cell / trigger / lever) | Why it matters | Priority | Recommended concept | Framework | EPIC/trigger | Cialdini lever`.
**D. Next-batch recommendation** — 4–8 concepts, each mapped to the cell + lever it fills, with the MLO framework and one-line concept, plus the Levinger cross-check.

**Concrete example (abbreviated, for a supplement brand, 22 active ads):**

*A. Matrix (excerpt):*

| | S1–2 fresh | S3 mechanism | S4–5 saturated/identity |
|---|---|---|---|
| Unaware | — (empty) | — (empty) | — (empty) |
| Problem-Aware | 3 ads | 5 ads | **11 ads ← cluster** |
| Solution-Aware | 1 ad | 1 ad | — |
| Product-Aware | — | — | — |
| Most-Aware | — | — | — |

Trigger tally: Fear ×14, Frustration ×5, Curiosity ×2, Aspiration 0, Belonging 0, Trust 1, Humor 0.
Cialdini tally: Social Proof ×12, Scarcity ×6, Authority ×3, Unity 0, Reciprocity 0, Liking 1.

*B. Summary:* 73% of the portfolio sits in Problem-Aware/S4–5 with fear + social proof. Zero Unaware (no top-of-funnel runway), zero Most-Aware (nothing for the retargeting/list), zero Aspiration/Belonging, zero Unity.

*C. Prioritized gaps (top 2):*

| # | Gap | Why it matters | Priority | Concept | Framework | Trigger | Cialdini |
|---|---|---|---|---|---|---|---|
| 1 | Unaware / S4–5 (identity) | Biggest TAM, totally uncovered; account can't feed cold | HIGH | "For the [ICP] who's stopped noticing they're running on empty" story hook, never mentions product | TEASE / Founder | Belonging + curiosity | Unity |
| 2 | Most-Aware / S4–5 | No offer ad for warm/list → leaving retargeting revenue on the table | HIGH | Offer + risk-reversal + "you've tried the rest" | Founder Objections | Greed/value | Scarcity + reciprocity |

*D. Next batch:* 5 concepts filling Unaware×2 (Belonging/Unity + Curiosity), Aspiration (Ideal-self transformation), Most-Aware offer, and one S3 mechanism revelation. Levinger cross-check: this batch also moves the account out of its High-Negative/Actual-Self/High-Intensity cluster into Low-Positive/Ideal-Self and Ought-Self.

## Guardrails
- If the active-ad list isn't provided, request it (or Meta account + date range) before auditing.
- If FFM/spend is missing, audit anyway but flag recommendations as *unvalidated* (learning-first).
- Never recommend a Most-Aware offer to an Unaware pocket, or a bare claim into an S4–5 saturated market.
- Don't mistake framework variety for coverage; don't recommend exploring a cell that already lost.
- If the grid is genuinely well-covered, say so and pivot to FFM-driven iteration inside winning cells.

## References
- **Full method + lens tables + sources:** `reference/knowledge-base.md`.
- **MLO modules used:** `00-INDEX-Sistema-Scripting-MLO.md` (Trinidad, 3A, Awareness, Sophistication, EPIC, FFM); `01-Modulo-Frameworks-y-Script-to-Brief.md` (the 12 frameworks + winner anatomy).
- **Reused expert brain:** `mlo-winner-strategist/reference/experts-direct-response.md` (Schwartz Awareness × Sophistication grid, Sugarman/Halbert emotional triggers, Cialdini's 7).
- **Sibling to align with (don't fork):** `mlo-psychological-coverage` (Levinger's Valence × Self-Concept × Intensity).
