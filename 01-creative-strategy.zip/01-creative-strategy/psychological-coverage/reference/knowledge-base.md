# Psychological Coverage — Knowledge Base

Distilled knowledge for the `psychological-coverage` skill: auditing a DTC brand's **active ad portfolio** for coverage across three persuasion lenses — **Schwartz Awareness × Sophistication**, **emotional triggers**, and **Cialdini's 7** — then surfacing the GAPS and recommending what to make next.

> **Relationship to `mlo-psychological-coverage` (Levinger).** That sibling skill audits coverage on **Sarah Levinger's 3 dimensions** — Valence Zone × Self-Concept Anchor × Language Intensity — and drives batch distribution/copy review. THIS skill audits the SAME portfolio on a **complementary set of axes** (awareness stage, market sophistication, emotional trigger, Cialdini lever). Use both together for a full coverage picture: Levinger tells you the *neurological/identity* white space; this skill tells you the *awareness-stage / persuasion-lever* white space. Do not fork — cross-reference. When both are run, a truly redundant ad repeats on BOTH lens-sets.

---

## Why coverage matters (the MLO thesis)

- **Volumen sin varianza = wallpaper caro.** A portfolio of 40–100 ads that are the same concept re-skinned reads as *redundant* to Andromeda → CPMr rises, reach shrinks, account stalls. (Shared with the Levinger skill; MLO's core coverage thesis.)
- Coverage isn't "more ads" — it's **more of the map covered**. An account can run 60 ads and only occupy 2 of ~25 grid cells. The job of this skill is to find the empty cells that a starving segment lives in.
- **Message > format (Trinidad).** Two "founder videos" that both open with a Most-Aware offer to cold traffic are the *same* ad psychologically. Coverage is measured on the *message/psychology*, never the format or the B-roll.
- **The market is chosen before the copy (Schwartz/Halbert).** "You do not create desire, you channel existing desire." A gap in the grid = a pocket of existing desire nobody's channeling yet.

---

## LENS 1 — Schwartz Awareness × Sophistication grid (the master axis)

Source: reused verbatim from `mlo-winner-strategist/reference/experts-direct-response.md` (Schwartz *Breakthrough Advertising*, 1966). Read that file for the full grid + sources. Summary for auditing:

### The 5 AWARENESS stages (what the PROSPECT knows) — the rows

| Stage | Prospect knows | The ad should lead with |
|---|---|---|
| **1. Unaware** | Nothing — no problem recognition | NO product. Symptom/story/curiosity/identity hook that triggers realization. Long runway. |
| **2. Problem-Aware** | Feels the pain, not the cause/fix | Validate pain → name it precisely → diagnose root cause. |
| **3. Solution-Aware** | Knows solution *categories*, comparing | Mechanism + USP; "vs." framing; why your approach wins. |
| **4. Product-Aware** | Knows your product, not committed | Objection-handling: proof, guarantees, testimonials, before/after, risk-reversal. |
| **5. Most-Aware** | Trusts it, ready | Offer + CTA + urgency. Remove all friction. Short runway. |

Diagnosis heuristic for auditing an ad: **read the first 3 seconds / the hook.** Where it *enters* = the awareness stage it serves (not where the product sits). An offer-led hook = Most-Aware, regardless of the rest.

### The 5 SOPHISTICATION stages (what the MARKET has heard) — the columns

| Stage | Market condition | The ad must |
|---|---|---|
| **1. First to market** | Fresh claim | State the claim plainly. |
| **2. Second wave** | Claim copied | Enlarge/outbid the claim (bigger/faster/easier). |
| **3. Mechanism** | Claims disbelieved | Introduce a unique mechanism (the *how*). |
| **4. Elaborated mechanism** | Everyone has a mechanism | Out-prove: studies, certs, demos, testimonials. |
| **5. Identification / reinvent** | Total saturation | Sell on identity ("this is you") or reinvent the category. |

For a DTC audit, collapse the columns into three usable buckets: **S1–2 (fresh)**, **S3 (mechanism)**, **S4–5 (saturated/identity)**. Most mature DTC categories (supplements, skincare, weight-loss) sit at S3–5.

### The intersection grid (the cheat-sheet for what each cell's ad looks like)

| | S1–2 (fresh) | S3 (mechanism) | S4–5 (saturated/identity) |
|---|---|---|---|
| **Unaware** | Story/education → plain benefit | Story revealing hidden cause | Identity/story hook, native, non-ad |
| **Problem-Aware** | Name pain → direct promise | Name pain → reveal mechanism | Name pain → prove w/ data/demo |
| **Solution-Aware** | "The category that finally works" | Mechanism-vs-alternatives | Elaborated proof + comparison |
| **Product-Aware** | Direct benefit + why us | Our mechanism + guarantee | Stack proof: reviews, before/after, studies |
| **Most-Aware** | Offer + CTA | Offer + CTA + 1 proof | Offer + urgency + risk-reversal |

**The two failures the audit catches most:**
1. **Whole portfolio bunched in one or two cells** — usually Problem-Aware/S4 with High-Negative urgency. Everything else is white space.
2. **Offer ad to Unaware** (Most-Aware creative aimed at cold) OR **bare claim in a saturated market** (needs a mechanism/identity). The grid names the fix: move the runway or move up a sophistication stage.

**Angle-decay rule:** when a winner fatigues, first ask "has the market heard this claim too many times?" → the market advanced a sophistication column; respond by adding a mechanism (S3) or shifting to identification (S5), not by shouting louder.

---

## LENS 2 — Emotional triggers (which feeling the ad fires)

Source: Sugarman's psychological triggers + Halbert "selling is emotion, justified by logic" (see `experts-direct-response.md`). For coverage auditing we use a compact **emotional-trigger set** — tag each ad with its PRIMARY trigger; a strong ad stacks 2–3.

**Primary emotional triggers (audit checklist):**
1. **Fear / loss aversion** — "your X is quietly failing"; what they'll lose.
2. **Frustration / pain-agitation** — naming the daily annoyance (PAS territory).
3. **Aspiration / hope** — the believable transformation, ideal-self future.
4. **Curiosity** — open loop; "the reason nobody told you."
5. **Belonging / identity / pride** — "for the [identity] who…"; tribe.
6. **Greed / value** — steep, time-boxed deal; cost-per-use math.
7. **Trust / relief / reassurance** — calm, "you're safe here," guarantee-led.
8. **Guilt / duty (ought)** — "do it for them, not you."
9. **Surprise / novelty / shock** — pattern-interrupt, ugly ad, unexpected claim.
10. **Humor / delight** — levity that lowers the sales-defense.

**Coverage rule:** ~90% of DTC accounts over-index on **fear + frustration + urgency** (High-Negative). Aspiration, belonging, trust, curiosity, humor are the usual white space. Fear works on prospects already in an elevated state and ignores everyone else. (Directly parallels the Levinger valence finding — cross-reference the sibling skill's Valence Zone map.)

---

## LENS 3 — Cialdini's 7 persuasion principles (which lever the ad pulls)

Source: reused from `experts-direct-response.md` (Cialdini, *Influence* + *Pre-Suasion*). Tag each ad with the principle(s) it fires; weak ads fire only one.

| Principle | The ad element that fires it |
|---|---|
| **Reciprocity** | Free guide/sample/shipping, genuinely useful content before the ask |
| **Commitment & Consistency** | Micro-yes quiz, free trial, low first step |
| **Social Proof** | Review counts, UGC volume, "50k customers," #1 best-seller, before/after |
| **Authority** | Doctor/founder/expert, credentials, clinical data, "as seen in," certs |
| **Liking** | Relatable creator mirroring the ICP, founder story, humor, similarity |
| **Scarcity** | "Only 12 left," countdowns, limited drops, "ends tonight" |
| **Unity** | "One of us" — tribe/identity/community language, us-vs-them |

**Coverage rule:** Unity > Liking (in-group beats similarity), and it's the most under-used lever in DTC — it coincides with Schwartz Sophistication-5 identification and the belonging trigger. Most portfolios over-rely on **Social Proof + Scarcity** and neglect Reciprocity, Authority, Unity.

---

## Mapping MLO's system onto the three lenses

- **Trinidad first** — the audit reads the MESSAGE, not the format. Classify by hook/entry, not by "it's a UGC."
- **3A (Audience · Angle · Ad)** — the awareness row ≈ Audience state; the trigger/Cialdini tags ≈ Angle lever; the format ≈ Ad. Coverage gaps are almost always **Angle-lever gaps**, not Ad-format gaps.
- **EPIC angles** (Emotion · Problem · Identity · Curiosity — MLO's angle families, M1/angle-generator) map cleanly onto the emotional-trigger lens: Emotion→aspiration/fear/pride, Problem→frustration/fear, Identity→belonging/Unity, Curiosity→curiosity/surprise. A portfolio missing an EPIC family = a trigger-column gap.
- **The 12 frameworks are vehicles, not coverage.** Bandwagon→Social Proof, Founder→Liking/Authority, PAS→frustration/fear, Us vs Them→Authority/proof (S4), TEASE→curiosity (Unaware), Industry Contrarian→curiosity+mechanism (S3), Ugly Ads→surprise (cold). Note WHICH framework each ad uses, but score coverage on the lens tags — two different frameworks can occupy the same cell.
- **FFM** (hook rate, hold rate, CTR, ROAS) — overlay performance onto the grid so recommendations are *validated-zone-aware*: double down where a covered cell wins, explore true white space for learning, retire fatigued cells (angle-decay).

---

## The audit method (encoded in SKILL.md, expanded here)

1. **Pull active ads** (last 60–90 days) — id/name, format, and if available FFM metrics + spend.
2. **Classify each ad on all three lenses** by reading the hook/first 3s + body:
   - Awareness stage (1–5) × Sophistication stage (S1–2 / S3 / S4–5) → grid cell.
   - Primary emotional trigger (+ any secondary).
   - Cialdini principle(s) fired.
   - (Note framework + EPIC family for context.)
3. **Build the coverage matrix** — a 5×3 Awareness×Sophistication grid with each ad dropped in its cell; plus two tally rows: emotional-trigger counts and Cialdini-lever counts. Mark spend/win where known.
4. **Find the clusters & the white space** — the 1–2 cells holding 70–90% of ads; the empty cells; the missing triggers; the missing levers.
5. **Prioritize the gaps** — rank each gap by (a) size of the desire pocket it serves, (b) learning value (never-tested > iteration), (c) strategic fit to the brand's funnel stage, (d) FFM signal that an adjacent cell is winning. High priority = big, untested, funnel-relevant.
6. **Recommend the next batch** — for each top gap, name the target cell + trigger + lever, the MLO framework that best delivers it, and a one-line concept. Cross-check against the Levinger sibling so the new batch also fills valence/self-concept white space.

---

## Output shape (matrix + prioritized gap list)

**A. Coverage matrix** (Awareness rows × Sophistication columns), each cell listing the ads in it (or empty). Below it, two tally tables: emotional triggers (count per trigger) and Cialdini levers (count per principle), with white space flagged.

**B. Cluster & white-space summary** — 2–4 lines: where the portfolio is bunched, what's empty, over/under-used triggers and levers.

**C. Prioritized gap list** — a ranked table: `# | Gap (cell / trigger / lever) | Why it matters | Priority | Recommended concept | Framework | EPIC/trigger | Cialdini lever`.

**D. Next-batch recommendation** — 4–8 concrete ad concepts to produce, each mapped to the exact cell + lever it fills, with the MLO framework and a one-line concept. Note the Levinger cross-check.

---

## Rules & standards (MLO non-negotiables)

- **Trinidad-first:** audit the message, never the format. A cell is defined by what the ad *says and to whom*, not by UGC/VSL/static.
- **Message > format:** two ads in the same cell with different formats are still redundant coverage.
- **Precision > filler:** every classification cites the hook line that justifies it; every gap names a real desire pocket, not "we should try positive too."
- **Coverage is the goal, not volume:** recommend the minimum set of concepts that fills the most valuable white space. Discovery > 100 iterations.
- **FFM-aware:** when performance data exists, don't recommend exploring a cell that already failed; distinguish "untested white space" from "tested and lost."
- **Align, don't fork:** always note the relationship to Levinger's `mlo-psychological-coverage` and cross-reference when both are run.

---

## Guardrails

- If the brand's active-ad list isn't provided, ask for it (or the Meta account + date range) before auditing — don't invent a portfolio.
- If FFM/spend data is missing, do the coverage audit anyway but flag recommendations as *unvalidated* (learning-first, not scale-first).
- Never recommend a Most-Aware offer ad to a cold/Unaware pocket, or a bare claim into an S4–5 saturated market — those are the two grid failures.
- Don't confuse *framework variety* with *coverage*. 12 different frameworks can all sit in one cell.
- Keep the audit honest: if the portfolio genuinely covers the grid, say so and pivot the recommendation to FFM-driven iteration within winning cells.

---

## Sources

### MLO modules
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A (Audience·Angle·Ad), Awareness levels, Market Sophistication, EPIC angles, Árbol de Cascada, Matriz Andromeda, FFM.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/01-Modulo-Frameworks-y-Script-to-Brief.md` — the 12 frameworks (Bandwagon, Industry Contrarian, Listicle, Founder, How to X without Y, Organic, PAS, Ugly Ads, Founder Objections, Us vs Them, Triple G, TEASE) and the winner anatomy (Hook → Problema/Deseo → Mecanismo → Prueba → CTA).

### Reused expert brain (do not re-research)
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz Awareness × Sophistication grid (Lens 1), Sugarman triggers + Halbert emotion (Lens 2), Cialdini's 7 (Lens 3), with primary-source URLs.

### Sibling skill to align with
- `mlo-psychological-coverage` (Sarah Levinger: Valence Zone × Self-Concept Anchor × Language Intensity) — complementary lens-set; cross-reference, don't duplicate.
