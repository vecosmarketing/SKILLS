# Research Engine — Knowledge Base

Distilled research knowledge for MLO's Research Engine skill. This is the *depth* behind SKILL.md.
It pulls the relevant MLO Sistema de Scripting content (summarized + cited to the module file),
reuses the pre-built MLO expert brain (cited to the winner-strategist reference files), and adds
fresh, cited web research where the MLO material has gaps (clearly separated). MLO frameworks come
first; external frameworks are named and attributed; web findings carry source URLs.

The through-line (all masters agree): **you channel existing desire, you don't create it.** Research
exists to *find and name* the desire, the words, and the market's noise level — before a word of script.

---

## 0. Where this sits in MLO's system (the map)

MLO's Sistema de Scripting has 3 blocks; this skill IS **Bloque 1 → M2 · Research & ICP** — "research
interno→audiencia→competencia, persona (identidad+motivación+buying context), VoC, Grok/Google Trends,
persona diversification." (cite: `00-INDEX-Sistema-Scripting-MLO.md`)

Its output feeds, in order:
- **Trinidad** (el mensaje va primero) — research decides the *message*, never the format.
- **Árbol de Cascada** — deseo → avatar → ángulo. Research supplies deseo, avatar, and candidate ángulos.
- **3A Framework** — Audience · Angle · Ad. Research produces Audience(s) + Angle candidates.
- **Awareness levels × Market Sophistication** — research diagnoses both axes per persona.
- **EPIC angles** — research surfaces the raw angle territory EPIC organizes.
- **Andromeda** — personas/angles get named for account structure downstream.
- **FFM** — the measurement preset that later grades what research proposed.

Rule from the playbook: research feeds *inputs*; scripting (M3/M4/M5) turns them into scripts. Don't
cross the line. (cite: `00-INDEX-Sistema-Scripting-MLO.md`, `01-Modulo-Frameworks-y-Script-to-Brief.md`)

---

## 1. PHASE A — Internal research (product truth + mechanism)

Before touching the audience, establish what's *true* about the product, because every downstream angle
and every VoC claim must attach to a real mechanism.

- **Product truth sheet:** ingredients/components, the honest **mechanism** (the *how* that makes the
  benefit credible), guarantee/risk-reversal, price/AOV, hero SKU, format.
- **Mechanism = reason-why.** Claude Hopkins' *reason-why* copy and Schwartz's *stage-3 mechanism* are the
  same lever: "because it's made with X, it does Y" beats "it's the best." The mechanism is what re-earns
  belief in a saturated market. (cite: `experts-direct-response.md` — Hopkins; Schwartz sophistication 3)
- **Reuse the Brand Brain.** If the brand has an `mlo-brand-brain-*` skill, pull its documented winners,
  losers, angles, and account context instead of re-deriving. Research adds the *audience/VoC/competition/
  trend* layers on top.
- **Anatomy of a winner** (the target research must eventually serve): `Hook → Problema/Deseo → Mecanismo
  → Prueba → CTA con razón para actuar ya`. Research must produce raw material for every one of those beats.
  (cite: `01-Modulo-Frameworks-y-Script-to-Brief.md` §0)

---

## 2. PHASE B — Persona along MLO's three lenses

MLO builds the persona on **identity + motivation + buying context** (cite: `00-INDEX` M2). Fill each:

**Identity — who they are and who they think they are.**
- Demographics (age, gender, geo, income proxy from AOV) + psychographics (values, fears, aspirations).
- The **self-image/identity they defend** — this is the Schwartz stage-5 / Cialdini *Unity* lever
  ("this is *you*, one of us"). Identity angles win when claims and mechanisms are exhausted.
  (cite: `experts-direct-response.md` — Schwartz stage 5; Cialdini Unity)

**Motivation — the existing desire you will channel.**
- Name the **core desire** (Schwartz: "copy cannot create desire… it can only channel it"). Find the
  *starving crowd* — the group demonstrably hungry for this outcome (Halbert). If the crowd isn't hungry,
  no creative saves it. (cite: `experts-direct-response.md` — Schwartz, Halbert starving crowd)
- Separate surface benefit from deep desire (weight-loss → confidence; supplement → control over aging).

**Buying context — when/where/why they buy.**
- Trigger events, purchase occasion, budget/price sensitivity, the **objections** that stall the sale,
  and the **alternatives already tried** (this list becomes competitor + "without Y" angle territory).
- This is Nick Theriot's brief thinking: Desire, Feature, Benefit, and Persona are isolated variables you
  fill so wins/losses attribute to one thing. (cite: `experts-dtc-creative.md` — Theriot 7-variable brief)

**Denney's Persona dimension** integrates all five content axes (Format, Creator, Messaging, Imagery,
Persona) — Persona is the axis that ties research to casting and message. (cite: `experts-dtc-creative.md`
— Dara Denney content-level data)

---

## 3. PHASE C — Voice of Customer mining (the highest-leverage phase)

The goal: **your prospect's exact words** become the hooks and headlines. Ogilvy's rule — mine reviews,
support tickets, and comments for the real language customers use; that's your headline bank.
(cite: `experts-direct-response.md` — Ogilvy research-led) MLO's own rule: *"el lenguaje sale de reviews/
VoC reales, no inventado."* (cite: `01-Modulo-Frameworks-y-Script-to-Brief.md` §4 checklist)

### Data sources (priority order + what each is best for)
1. **Product reviews — Shopify apps (Loox, Judge.me, Okendo, Yotpo) + Amazon reviews.** Best for
   before/after language, objections that survived purchase, and the "moment it clicked." Amazon reviews
   (esp. 3-star) are gold for balanced pros/cons. Note: pull verbatim, keep the star rating + date.
2. **Support tickets / DMs / Gorgias-Zendesk logs.** Best for the sharpest objections and pre-purchase doubts.
3. **Organic comments** on the brand's + competitors' posts (Meta/TikTok/YouTube). Best for spontaneous
   reactions and skepticism.
4. **Reddit / niche forums.** Best for unfiltered problem language and "alternatives I've tried." MLO's
   Unaware masterclass explicitly says: study the niche on **Reddit/TikTok/YouTube**, note the wins they
   celebrate, and read comments as pure research; "swipe the hooks that pop + read the comments."
   (cite: `05-Modulo-Unaware-Ads.md`)
5. **Niche TikTok/YouTube comment sections.** Cook your own algorithm (a fresh IG/TikTok account following
   high-signal niche accounts) so your feed = the prospect's feed. (cite: `05-Modulo-Unaware-Ads.md`)

### Language-bank buckets (tag every quote)
Collect verbatim quotes into these buckets; tag each with **source + date + awareness stage**:
- **Pain / before-state** — how they describe the problem in their words.
- **Dream / after-state** — the outcome they celebrate.
- **Objection / doubt** — why they hesitated (price, taste, trust, "tried everything").
- **Click-moment** — what finally convinced them.
- **Phrases & metaphors** — the exact idioms/images they reuse (these become hooks).
- **Alternatives tried** — competitor products and DIY fixes (feeds competition + "without Y" angles).

### The 4 "gap" buckets an unaware hook opens (use to interrogate VoC)
Every strong unaware angle opens one of these gaps: a **good possibility** they didn't know about, a
**danger** they didn't know, a place they were **right** in their worldview, or something they were
**wrong** about. Scan VoC for evidence feeding each. (cite: `05-Modulo-Unaware-Ads.md`)

---

## 4. PHASE E — Trend research (Google Trends + Grok-style social pass)

Two jobs: (a) is the desire **rising or falling**, and (b) how is it **phrased right now**.

### Google Trends (structured)
- Compare category term vs. symptom terms vs. competitor brand terms → **rising/falling** and relative interest.
- **Seasonality** (does demand spike — e.g. New Year, summer) → informs offer timing, not just angles.
- **Breakout / rising queries** → emerging language and sub-desires to test.
- **Set the correct region + language** to the brand's real market (Trends is geo-specific).
- **Related queries** reveal adjacent problems that hint at persona diversification.

### Grok-style / social-search pass (freshness the algorithms won't show in reviews)
- A recent-window sweep of X/Reddit/TikTok ("how are people talking about [desire/category] this month")
  surfaces new objections, memes, and cultural moments before they reach reviews. This is MLO's
  "Grok/Google Trends" input in the M2 scope. (cite: `00-INDEX-Sistema-Scripting-MLO.md`)
- **Cultural moment** is a legitimate unaware entry point — a timely event the prospect already cares about.
  (cite: `05-Modulo-Unaware-Ads.md`)
- Always date-stamp trend findings; they decay fast.

*(External method note: Google Trends is a directional/relative tool, not absolute volume — treat spikes
as signal to investigate, not proof. Pair with the VoC/language bank for the actual wording.)*

---

## 5. Awareness × Sophistication — the diagnostic every persona runs through

This is the **master cheat-sheet**, reused verbatim from the MLO expert brain. Diagnose BOTH axes per
persona before proposing angles. (cite: `experts-direct-response.md` — Awareness × Sophistication grid)

**Awareness (the prospect — what THEY know):** Unaware → Problem-Aware → Solution-Aware → Product-Aware →
Most-Aware. Rule: *the less aware, the longer the runway before the product; the more aware, the faster to
the offer.* Cold/broad Meta ≈ Unaware→Solution-aware; warm/site ≈ Product-aware; cart/list ≈ Most-aware.
(cite: `experts-direct-response.md`; also `experts-dtc-creative.md` — Theriot's 5 stages applied to Meta)

**Sophistication (the market — what it has already HEARD):** 1 first-to-market (state the claim plainly)
→ 2 enlarge the claim → 3 introduce a **mechanism** → 4 elaborate/out-prove the mechanism → 5
**identity/reinvent**. Mature DTC categories (supplements, skincare, weight-loss) sit at **4–5** → a bare
benefit claim is invisible; you need a mechanism or an identity angle. Angle decay usually = the market
advanced a sophistication stage, not that the creative got worse. (cite: `experts-direct-response.md`)

**The intersection picks the angle.** E.g. Problem-Aware × Sophistication-4/5 → "name the pain → prove
with data/demo/testimonial, lead with credibility." Two classic failures the grid catches: (1) an *offer
ad to an unaware audience*; (2) a *bare claim in a saturated market*. (cite: `experts-direct-response.md`)

**Target by the bait, not the audience** (Theriot): keep targeting broad and let the *creative* (angle +
awareness stage) self-select the audience — so research must produce stage-specific angles, not interest
lists. (cite: `experts-dtc-creative.md` — Nick Theriot)

---

## 6. PHASE D — Competition research (sets sophistication + finds the gap)

- **Meta Ad Library teardown** of the top 3–5 competitors: what **claims, mechanisms, angles, formats**
  are they running (and which are long-lived = winning)? This tells you the market's current sophistication
  stage — how many times your prospect has heard this claim. (cite: `experts-direct-response.md` —
  sophistication; `experts-dtc-creative.md` — Motion angle vocabulary: Angle/Concept/Hook/Format)
- **Competitor reviews (esp. 1–3 star):** their complaints are your **openings** — the unmet need no rival
  answers. Barry Hott's problem-first lens: lead with the problem the viewer feels. (cite:
  `experts-dtc-creative.md` — Barry Hott)
- **Find the gap:** the mechanism nobody claims, the identity nobody owns, the objection nobody resolves.
  That gap is a persona/angle candidate.

---

## 7. PHASE F — Persona diversification (more than one buyer)

Split one persona into **2–4** that differ on a **strategic axis**, so the creative slate covers real
territory rather than five edits of the same idea:
- **Identity/demographic axis** (e.g. the disciplined 34F vs. the skeptical 55M).
- **Core-desire axis** (confidence vs. convenience vs. health-control from the same product).
- **Awareness axis** (an Unaware persona needing a story runway vs. a Most-aware persona needing the offer)
  — Theriot & Denney: the same product needs different creative per stage, and most brands over-index on the
  Most-aware discount ad. (cite: `experts-dtc-creative.md`)
- **Use-case/occasion axis** (gift vs. daily-use vs. travel).

Each diversified persona ships with: **primary desire · dominant awareness stage · sophistication response
(claim vs. mechanism vs. identity) · 1–2 candidate angles (EPIC-style)** — so it drops straight into a
distinct branch of the Árbol de Cascada and a distinct Audience in 3A. Diversification that doesn't change
one of these axes is one persona in two hats — reject it.

Denney's Messaging Strategy Buckets (Human desires / Demographics / Strategy angles / User journey) are a
useful cross-check that your personas span different *psychological* territory. (cite: `experts-dtc-creative.md`)

---

## 8. Output contract (what a strategist receives)

A **Research Brief / persona deck** with: Snapshot · Audience Map · Persona(s) (Identity/Motivation/Buying
context/Awareness/Sophistication/angles) · Voice of Customer language bank (verbatim + source + stage) ·
Competition (claims + gap) · Trends (Google Trends + social, dated) · Diversification (2–4 personas on a
strategic axis) · **So-what for scripting** (the 3–5 highest-conviction angles to hand to Árbol de Cascada /
3A next). Every claim is sourced; MLO frameworks named as MLO's; external frameworks attributed; web/trend
findings carry URL + date.

Handoff targets: `framework-scriptwriter` (angle → script), `unaware-ads-expert` (cold/unaware personas),
`mlo-ad-brief-builder` / `mlo-advertorial-strategist` (brief), `mlo-psychological-coverage` (coverage check).

---

## Sources

### MLO playbook modules (source of truth)
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — system map; **M2 ·
  Research & ICP** scope (internal→audiencia→competencia, persona identidad+motivación+buying context, VoC,
  Grok/Google Trends, persona diversification); Trinidad, 3A, Árbol de Cascada, EPIC, Andromeda, FFM.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/01-Modulo-Frameworks-y-Script-to-Brief.md` — anatomy of a
  winner (Hook→Problema/Deseo→Mecanismo→Prueba→CTA); "el lenguaje sale de reviews/VoC reales, no inventado."
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/05-Modulo-Unaware-Ads.md` — Reddit/TikTok/YouTube + comment
  mining, "cook your algorithm," the 4 gap buckets, cultural-moment entry.

### Reused MLO expert brain (do not re-research)
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz Awareness ×
  Sophistication grid, Halbert starving crowd, Ogilvy mine-the-reviews, Hopkins reason-why/mechanism, Cialdini
  (Unity/Social Proof/Authority).
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/experts-dtc-creative.md` — Dara Denney (Persona +
  content-level data, Messaging buckets), Barry Hott (problem-first), Nick Theriot (5 stages applied to Meta,
  target-by-bait, 7-variable brief), Motion (Angle/Concept/Hook/Format vocabulary, angle > execution).

### External method references (fresh, cited — for the trend/VoC phases)
- Eugene Schwartz — Awareness & Sophistication (kingeshop): https://www.kingeshop.com/en/customer-awareness-sophistication-eugene-schwartz
- Gary Halbert — "Direct Marketing to a Starving Crowd": https://www.thegaryhalbertletter.com/newsletters/direct_marketing_to_a_starving_crowd.htm
- Nick Theriot — 5 Stages of Market Awareness (LinkedIn): https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk
- Google Trends (methodology — relative, geo-specific interest): https://support.google.com/trends/answer/4365533
- Hook/hold benchmarks (to grade what research later proposes): https://www.exposure.com.au/blog/what-is-a-good-hook-rate
