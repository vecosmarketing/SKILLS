---
name: research-engine
description: >
  MLO Growth's research brain for DTC creative strategy. Runs MLO's full research flow —
  internal → audience → competition — then builds the ICP persona (identity + motivation + buying
  context), mines Voice of Customer (reviews on Shopify/Amazon, Reddit, comments, support tickets),
  runs trend research (Google Trends / Grok-style), and produces persona diversification so the
  creative slate covers more than one buyer. Output = a structured Research Brief / persona deck a
  strategist can act on today. Grounds in MLO's Sistema de Scripting (M2 Research & ICP, Trinidad, 3A,
  Árbol de Cascada, awareness × sophistication) and reuses the MLO expert brain (Schwartz, Ogilvy,
  Halbert, Cialdini; Dara Denney, Barry Hott, Nick Theriot, Motion). ALWAYS use this skill (ES/EN)
  when the user asks to: "haz el research de [marca]", "monta el persona / avatar de [marca]",
  "sácame el ICP", "investiga a la audiencia / competencia", "mina reviews / VoC / Voice of Customer",
  "qué dice la gente en Reddit/comentarios", "research brief", "persona deck", "diversifica el avatar",
  "build the persona/ICP", "do audience/competitor research", "mine reviews", "research brief for [brand]".
  Trigger on partial/casual asks about researching a brand's audience, persona, VoC or angles before scripting.
---
# Research Engine — MLO's research brain (research → persona → VoC → trends → diversification)

## What it does
Turns a brand into a **decision-ready Research Brief + persona deck** that feeds the rest of MLO's
scripting system. It runs MLO's real research flow (internal → audience → competition), builds the
ICP persona along three lenses (**identity + motivation + buying context**), mines **Voice of Customer**
for the exact words customers use, layers in **trend research** (Google Trends / Grok-style), and ends
with **persona diversification** so the creative slate hits several buyers, not one.

This is the **QUÉ decir** upstream of everything: its output is the raw material for the Árbol de
Cascada (deseo → avatar → ángulo), the 3A framework (Audience·Angle·Ad), the 12 scripting frameworks,
and awareness/sophistication diagnosis. It is grounded in **M2 · Research & ICP** of the Sistema de
Scripting M.L.O. Precisión > relleno: every claim ships with the source it came from.

## When to use (ES + EN triggers)
- **ES:** "haz el research de [marca]", "monta el avatar / persona / ICP de [marca]", "investiga la
  audiencia", "análisis de competencia", "mina las reviews / el VoC", "qué dicen en Reddit / en los
  comentarios", "research brief", "persona deck", "diversifica el avatar", "qué ángulos hay aquí",
  "prepara el research antes de escribir guiones".
- **EN:** "do the research for [brand]", "build the persona / ICP / avatar", "audience research",
  "competitor research / teardown", "mine the reviews / VoC / Voice of Customer", "what are people
  saying on Reddit / in comments", "research brief", "persona deck", "diversify the persona",
  "find the angles", "research before we script".
- Also fires on partial/casual asks about researching a brand's audience, persona, VoC, or angles
  **before** any script or brief is written.

## Inputs needed
1. **Brand + product** (what it is, price, hero SKU, category).
2. **Data access** — Shopify store handle (reviews/order data), Amazon listing URL if any, ad account,
   any existing brand brain / KPI panel. (Use the brand's MLO Brand Brain skill if one exists.)
3. **VoC sources** — review apps (Loox/Judge.me/Okendo on Shopify, Amazon reviews), support tickets/DMs,
   organic comments, relevant subreddits/forums, TikTok/YouTube comment sections in the niche.
4. **Market/geo + language** (ES/EN and country — affects VoC sources and Google Trends region).
5. **Goal** — full research brief, quick persona, VoC pull, or diversification pass.

## Method (numbered — MLO's system + the expert frameworks)

**PHASE A — INTERNAL research (what the brand already knows).**
1. Pull the brand's own assets: product truth (ingredients, mechanism, guarantee, price/AOV), current
   winners & losers, existing angles, and any prior persona work. Reuse the brand's **MLO Brand Brain**
   if it exists — don't re-derive what's already documented.
2. State the **product's inherent mechanism** and the honest reason-why it works (Hopkins reason-why /
   Schwartz stage-3 mechanism). This anchors every later angle. → knowledge-base §1.

**PHASE B — AUDIENCE research (who buys and why).**
3. Segment who is actually buying (order data, repeat buyers, high-AOV). Draft the persona along MLO's
   three lenses — **Identity** (who they are: demo + psychographic + self-image/identity they defend),
   **Motivation** (the deep desire being channeled — Schwartz: you channel desire, you don't create it;
   Halbert's starving crowd), **Buying context** (when/where/why they buy, triggers, objections,
   alternatives tried, budget). → knowledge-base §2.
4. **Diagnose awareness (the prospect)** and **sophistication (the market)** using the reused
   Awareness × Sophistication grid. Most cold Meta traffic = Unaware→Solution-aware; mature DTC
   categories (supplements, skincare, weight-loss) = sophistication 4–5 → need a mechanism or identity
   angle, not a bare claim. → knowledge-base §5.

**PHASE C — VOICE OF CUSTOMER mining (their words, not ours).**
5. Mine VoC systematically. Sources in priority order: **product reviews (Shopify apps + Amazon),
   support tickets/DMs, organic comments, Reddit/forums, niche TikTok/YouTube comments**. Pull verbatim
   language for each bucket: *pain/before-state, dream/after-state, objections/doubts, the moment it
   clicked, exact phrases & metaphors, alternatives they'd tried*. → knowledge-base §3.
6. Build the **language bank / swipe** — the literal customer phrases become hook and headline copy
   (Ogilvy: mine reviews/tickets for the real language; MLO rule: "el lenguaje sale de reviews/VoC
   reales, no inventado"). Tag each phrase with its source and awareness stage.

**PHASE D — COMPETITION research (the noise the prospect already heard).**
7. Teardown the top competitors' active ads (Meta Ad Library) and reviews: what claims/mechanisms/angles
   they run, what their reviews complain about (= your opening). This sets **market sophistication** —
   how many times the prospect has heard this claim → whether you need to enlarge, add a mechanism, or
   shift to identity. → knowledge-base §5.
8. Find the **gap**: the angle/mechanism/identity no competitor owns, and the complaint no competitor
   answers. That gap is a persona/angle candidate.

**PHASE E — TREND research (is the desire rising, and how do people phrase it now).**
9. Run **Google Trends** for the category, symptoms, and competitor terms (rising vs. falling, seasonality,
   breakout queries, region). Run a **Grok-style / social-search pass** (X/Reddit/TikTok in the last
   weeks) for how the desire is talked about *right now* and any emerging objection or meme. → knowledge-base §4.

**PHASE F — PERSONA DIVERSIFICATION (more than one buyer).**
10. From the internal+audience+VoC data, split the single persona into **2–4 distinct personas** that
    differ on a strategic axis: identity/demographic, core desire, awareness stage, or use-case/occasion
    (Denney's Persona dimension; Theriot: the same product needs different creative per stage). Each
    diversified persona = a distinct **Audience** input for 3A and a distinct branch of the Árbol de Cascada.
11. For each persona, name its **primary desire, dominant awareness stage, likely sophistication response
    (claim vs. mechanism vs. identity), and 1–2 candidate angles (EPIC-style)** — handing the strategist
    ready-to-script territory, not just a portrait.

**PHASE G — ASSEMBLE the Research Brief / persona deck** (see Output).

## Rules & standards (MLO non-negotiables)
- **Trinidad first, message > format.** Research feeds the *message*; format is chosen later. Never let a
  format decision (UGC/VSL/static) leak into the research.
- **You channel desire, you don't create it** (Schwartz/Halbert). The research job is to find the existing
  starving-crowd desire, not to invent one.
- **VoC verbatim, always sourced.** Customer language is quoted literally with its source; never paraphrase
  a review into a claim and never invent quotes. Precisión > relleno.
- **Diagnose awareness AND sophistication before angles.** Both axes, every time (reused grid).
- **Feed the system, don't fork it.** Output must map cleanly onto Árbol de Cascada (deseo→avatar→ángulo),
  3A, awareness levels, and Andromeda naming — this skill produces *inputs*, not final scripts.
- **Diversify, don't clone.** Personas must differ on a strategic axis, or they're one persona in two hats.
- **Cite sources, separate MLO from external.** MLO frameworks are named as MLO's; borrowed expert
  frameworks are named and attributed; fresh web/trend findings carry their URL/date.

## Output (exact shape + concrete example)
Deliver a **Research Brief / persona deck** with these sections:
```
1. SNAPSHOT — brand, product, mechanism, price/AOV, market, geo, goal, date.
2. AUDIENCE MAP — segments + which is the primary buyer (with evidence).
3. PERSONA(S) — for each: Identity · Motivation (core desire) · Buying context (triggers/objections/
   alternatives) · Awareness stage · Sophistication response · candidate angles.
4. VOICE OF CUSTOMER — language bank by bucket (pain / dream / objection / click-moment / phrases),
   every line quoted verbatim + source + awareness stage.
5. COMPETITION — top competitors' claims/mechanisms/angles + the unowned gap.
6. TRENDS — Google Trends read (rising/falling, seasonality, breakout terms) + social/Grok pass, with dates.
7. DIVERSIFICATION — the 2–4 personas on their strategic axis, each with desire + stage + angle candidates.
8. SO-WHAT FOR SCRIPTING — the 3–5 highest-conviction angles to feed Árbol de Cascada / 3A next.
```
**Concrete example (VoC → persona → angle, ACV capsules):**
- VoC verbatim (Shopify review): *"I hate the taste of liquid ACV, I'd gag every morning"* — bucket: objection/pain; awareness: Solution-aware; source: Loox review 12-mar.
- Persona: **"The disciplined-but-disgusted"** — Identity: 34F, wellness routine already, values consistency;
  Motivation: keep her healthy habit without the daily dread; Buying context: quit the liquid, searching
  "ACV without the taste"; Awareness: Solution-aware; Sophistication: 4 (heard "ACV benefits" a thousand
  times → needs mechanism/format angle, not a benefit claim).
- Angle candidate (EPIC): **"How you get every ACV benefit without the gag"** → maps to the SIMPLE
  ("How you can X without Y") framework downstream.

## Guardrails
- **Don't script here.** This skill stops at angles/personas; scripting is M3/M4 (framework-scriptwriter,
  hooks). Hand off, don't overreach.
- **Don't invent MLO frameworks.** Use the real ones (3A, Trinidad, Árbol de Cascada, EPIC, awareness ×
  sophistication, Andromeda, FFM). If MLO material has a gap, fill with a *named, cited* external framework
  and mark it as external.
- **No fabricated VoC or data.** If a review/trend can't be verified, label it as an assumption to validate,
  not a finding.
- **Respect access limits.** If Shopify/Amazon/ad-account data isn't available, say what's missing and
  proceed with what can be sourced (organic comments, Reddit, Ad Library, Google Trends) rather than guessing.
- **Geo/language aware.** Pull VoC and Google Trends in the brand's real market/language.

## References
- **MLO playbook:** `00-INDEX-Sistema-Scripting-MLO.md` (M2 · Research & ICP scope; Trinidad, 3A, Árbol de
  Cascada, EPIC, Andromeda, FFM); `01-Modulo-Frameworks-y-Script-to-Brief.md` (anatomy of a winner; "el
  lenguaje sale de reviews/VoC reales"); `05-Modulo-Unaware-Ads.md` (Reddit/comment mining, gap buckets).
- **Reused expert brain:** `mlo-winner-strategist/reference/experts-direct-response.md` (Schwartz awareness ×
  sophistication grid, Halbert starving crowd, Ogilvy mine-the-reviews, Hopkins reason-why, Cialdini);
  `mlo-winner-strategist/reference/experts-dtc-creative.md` (Denney Persona/content dimensions, Hott problem-first,
  Theriot 5 stages + 7-variable brief, Motion angle>execution).
- **Full detail + sources:** `reference/knowledge-base.md`.
- **Aligns with (don't fork):** `mlo-creative-strategy`, `mlo-psychological-coverage`, `mlo-winner-strategist`,
  `mlo-advertorial-strategist`, `mlo-ad-brief-builder`, and each brand's `mlo-brand-brain-*`. This skill is the
  **research upstream**; those consume its Research Brief.
