---
name: mlo-ad-brief-builder
description: "Universal ad brief builder for Meta Ads (static, carousel, video/VSSL). Generates production-ready briefs with copy, visual direction, awareness mapping, and psychological coverage for any DTC brand managed by MLO Growth. ALWAYS use (ES/EN) when Marcel or the team asks to: create ad briefs, write ad copy, generate static ads, build carousels, write VSSL scripts, brief creatives, 'hazme un brief', 'brief para [marca]', 'crea los copies', 'dame las versiones', 'brief de estáticos', 'carrusel para [marca]', 'guion de video', 'script para video', 'VSSL de [marca]', 'ad copy para [marca]', or any request to produce structured creative briefs for Meta Ads across any brand. Trigger also for: 'dame los briefs listos para copiar', 'crea las variaciones', 'adapta este formato a [marca]', 'brief con este diseño', or when the user passes a reference image/design and asks to generate copy for it. This skill is brand-agnostic — it adapts to any DTC brand by requiring brand context upfront."
---

# SKILL: Ad Brief Builder — Meta Ads (Static / Carousel / Video)
## MLO Growth | Universal for any DTC brand

---

## CUÁNDO USAR ESTE SKILL

Activar SIEMPRE (ES/EN) cuando Marcel o el equipo:

- Pidan crear briefs de ads para cualquier marca
- Pasen una imagen/diseño de referencia y pidan copy
- Quieran generar estáticos, carruseles o guiones de video
- Digan "hazme un brief", "crea los copies", "dame las versiones"
- Pidan adaptar un formato visual a otra marca o ángulo
- Necesiten variaciones de copy para un mismo diseño
- Quieran briefs listos para copiar y pegar a diseño o Notion

---

## ANTES DE ESCRIBIR CUALQUIER BRIEF

### 1. CONTEXTO DE MARCA (obligatorio)

Si no está en memoria o en el proyecto, preguntar:

- Marca:
- Producto:
- Mercado/país:
- Idioma y dialecto (ej: español Colombia, español España):
- Buyer personas activos (nombre + edad + dolor principal):
- Deseo central que atacamos:
- Ángulo activo:
- Subángulo activo:
- Posicionamiento (transformación vs preservación):
- Autoridad/experto (si aplica):
- Villano tangible (lo que la persona usa hoy y no funciona):
- Landing/destino:

### 2. REGLAS DE COPY QUE NUNCA SE ROMPEN

1. Habla como habla la persona, no como habla un copywriter.
   - Usa las palabras exactas del mercado (ej: Colombia = "tinto", no "café"; "fundido", no "agotado"; "malgenio", no "irritable")
   - Si el copy suena a IA, está mal. Si suena a lo que alguien diría por WhatsApp, está bien.

2. Hablarle directamente al buyer persona.
   - No "hay muchas personas que..." sino "usted se levanta a las 5..."
   - Usar "usted" o "tú" según el mercado y la edad del buyer persona.

3. Menos palabras = mejor.
   - Si una slide necesita más de 4 líneas, está mal.
   - Si un headline tiene más de 8 palabras, probablemente sobran 3.
   - Cada palabra tiene que ganarse su puesto.

4. Nunca usar estas palabras en copy de ad:
   - "Solución", "complemento nutricional", "neurotransmisores" (a menos que sea brief educacional avanzado)
   - "Descubre", "transforma", "revolucionario", "único en el mercado"
   - Cualquier palabra que suene a folleto de farmacia o landing page genérica

5. Todo copy debe justificarse con research.
   - Cada frase debe rastrearse a: encuestas, foros, reviews, transcripciones, research de mercado, o frases reales del buyer persona.
   - Si no viene del research, probablemente es genérico.

6. El producto NO aparece en el hook.
   - Slides 1-2 (o primeros 3 segundos de video) = 100% sobre la persona y su dolor.
   - El producto entra al final, como descubrimiento natural.

---

## FORMATO 1: BRIEF DE ESTÁTICO

### Estructura de entrega

🎴 BRIEF — [NOMBRE DEL CONCEPTO]

Visual: [Descripción del diseño / referencia]
Subángulo: [Subángulo específico]
Buyer Persona: [Nombre + descripción corta]
Awareness: [Unaware / Problem Aware / Solution Aware / Product Aware]
Valence: [High/Low] [Pos/Neg] / [Actual/Ideal/Ought Self] / [Alta/Baja intensidad]
Ad Framework: [Educational / Pain-point / Villain / Before-After / etc.]

V1
Copy on image:
[HEADLINE]
[SUBHEADLINE si aplica]

V2
Copy on image:
[HEADLINE]
[SUBHEADLINE si aplica]

V3
Copy on image:
[HEADLINE]
[SUBHEADLINE si aplica]

📋 NOTAS
- Justificación de copy (de dónde sale cada frase)
- Lenguaje específico del mercado usado
- Lo que NO hace este creativo

### Reglas de estático

- Mínimo 2 versiones, máximo 4 por diseño
- Cada versión debe estar en una zona psicológica distinta (Sarah Levinger)
- Incluir siempre la clasificación psicológica:

| V | Valence | Self | Intensidad |
|---|---|---|---|
| V1 | [zona] | [self] | [alta/baja] |
| V2 | [zona] | [self] | [alta/baja] |

---

## FORMATO 2: BRIEF DE CARRUSEL

### Estructura de entrega

🎴 CARRUSEL — [NOMBRE DEL CONCEPTO]

Visual: [Estilo visual / referencia]
Subángulo: [Subángulo específico]
Buyer Persona: [Nombre]
Awareness: [Recorrido: ej. Unaware → Solution Aware]
Slides: [Número total]

Slide 1 (hook):
[COPY — máximo 3 líneas]

Slide 2 (identificación o reframe