---
name: framework-scriptwriter
description: >
  MLO Growth's core scripting skill. Given a brand + angle + awareness stage, it picks the RIGHT
  framework from MLO's real 12 (Bandwagon, Industry Contrarian, Listicle, Founder, How to X without Y,
  Organic, PAS, Ugly Ads, Founder Objections, Us vs Them, Triple G, TEASE), writes a full production-ready
  ad script following the winner anatomy (Hook → Problema/Deseo → Mecanismo → Prueba → CTA), then converts
  Script→Brief in MLO's exact table (FRAMEWORK | SCRIPT | TEXT | B-ROLL) with 3-5 hooks, filming reqs and
  tick-off list. ALWAYS use this skill (ES/EN) when the user says "escríbeme un guion", "haz el script de
  este anuncio", "qué framework uso para [marca/ángulo]", "pásalo a brief", "script para UGC/VSL/estático",
  "guion + brief", "write me a script", "which framework should I use", "turn this into a brief", "script this
  angle for [brand]". Trigger for any MLO brand (ZZEN, 8hours, Moncho Moreno, Bala di Gala, HobbitAlf, Alma,
  Chic&Love, etc.) and for media buyers/strategists who need a shootable script.
---
# Framework Scriptwriter — MLO's core scripting engine

## What it does
Turns a **brand + angle + awareness stage** into (1) the correct framework choice from **MLO's 12**, (2) a full
**production-ready script** built on the winner anatomy, and (3) the **Script→Brief** table an editor/UGC creator/
designer can shoot with **zero questions**. This is the flagship scripting skill of MLO's Creative Strategy &
Scripting suite. It encodes Módulo 1 (the 12 Frameworks + Script→Brief) and Módulo 4 (Hooks), and reuses the
direct-response + offers/VSL expert brains.

**Alignment (don't fork):** upstream of this skill the **avatar + angle** come from `angle-generator` / Árbol de
Cascada, and `creative-strategist`; the **hook system** lives in `hooks-expert` (this skill embeds the essentials
but defers deep hook work to it); `unaware-ads-expert` / `advertorial-strategist` own the unaware/advertorial
long-forms; `ai-video-director` / `ugc-director` / `seedance-20-ugc-ad-director` take the finished brief into
production; `script-doctor` critiques an existing script. This skill is the **write-from-scratch → brief** engine.

## When to use (ES + EN trigger phrases)
- **ES:** "escríbeme un guion para [marca]", "haz el script de este ángulo", "qué framework uso aquí",
  "pásame esto a brief", "guion + brief para UGC/VSL/estático", "script para el ángulo X de ZZEN/8hours/Moncho…",
  "necesito 5 hooks y el cuerpo", "conviértelo en tabla de brief".
- **EN:** "write me a script for [brand]", "which framework fits this angle", "script this angle", "turn this
  into a brief", "give me the brief table", "5 hooks + body for this creative".

## Inputs needed (ask only for what's missing — never block)
1. **Brand** + product (and the one thing it does). Pull VoC/reviews language if available.
2. **Angle** (the EPIC angle / promise). If absent, ask or derive one with `angle-generator`.
3. **Awareness stage** of the target avatar (Unaware / Problem / Solution / Product / Most-aware).
4. **Market sophistication** (1–5) — how many times the market already heard this claim.
5. **Format** (UGC / VSL / advertorial / static) and **language** (ES/EN per brand).
6. **Psychological asset** you actually have: social proof, founder story, unique mechanism, demo, etc.
If awareness/sophistication are unknown, diagnose them from the audience (cold broad → Unaware/Problem; retargeting
→ Product/Most-aware) before choosing a framework.

## Method (the core)
**Step 0 — Trinidad first (message > format).** A framework is NOT "make a founder video" — it's *what you say and in
what order*. Lock **Deseo → Avatar → Ángulo** before touching a framework. Never show the product in a cold hook.

**Step 1 — Pick the framework by avatar + awareness + asset** (not by taste). Use the master table below. The
framework is only the *vehicle* that carries the angle; the winner anatomy is the same for all 12:
`Hook → Problema/Deseo → Mecanismo (por qué funciona) → Prueba → CTA con razón para actuar ya`.

**MLO's 12 Frameworks — acronym + when-to-use + typical awareness:**

| # | Framework | Acronym (beats) | Use when… | Typical awareness |
|---|---|---|---|---|
| 1 | **Bandwagon** | CROWD | You have social proof / authorities adopting it | Solution / Product |
| 2 | **Industry Contrarian** | DISRUPT | You have a "secret"/mechanism that breaks the status quo | Problem / Solution |
| 3 | **Listicle** | CURE | You want curiosity-driven retention in a list format | Problem |
| 4 | **Founder** | FOUNDER | There's a strong founder story/mission | Unaware / Problem |
| 5 | **How to X without Y** | SIMPLE | Product delivers the result **without** the usual pain | Solution |
| 6 | **Organic** | PURE | You want native, "doesn't-feel-like-an-ad" content | Any (cold) |
| 7 | **PAS** | Pain-Agitate-Solution | There's a strong, clear emotional pain | Problem |
| 8 | **Ugly Ads** | UGLY | You want a raw/ugly scroll-stopper (a *filter*, not a structure) | Any (cold TOFU) |
| 9 | **Founder Objections** | PROVE | You must crush objections in the founder's voice | Product |
| 10 | **Us vs Them** | SHOW | You can demonstrate superiority in a visual challenge | Solution / Product |
| 11 | **Triple G** | Goal-Gap-Gains | You sell an aspiration/transformation with a date | Problem |
| 12 | **TEASE** | T·E·A·S·E | You want max retention via an impossible claim (curiosity loop) | Unaware / Problem |

**Beat maps (write 1–2 sentences per letter — that's your script):**
- **CROWD** — Call out the movement · Reject the old way · Onboard the new way · Wave the proof · Direct (benefit-in-CTA).
- **DISRUPT** — Declassify the secret · Industry failure · Solution · Reinforce w/ evidence · Upstage competition · Provide proof · Trigger the movement (risk reversal).
- **CURE** — Curiosity (list hook + reason for the number) · Uncover failures · Remedy (product) · Evidence · Engage (CTA w/ risk reversal).
- **FOUNDER** — Feature the founder · Opposing force · Unlocking the idea · Numbers (3–4 results) · Destiny · Engage the movement.
- **SIMPLE** — State the escape (identity+pain, 1 line) · Identify pain · Minimal solution · Prove (because→so) · Lifestyle win · Escape CTA.
- **PURE** — Problem uncovered · Unfiltered chaos (day-diary 7am/10am/4pm) · Real evidence · Effortless freedom.
- **PAS** — Problem (their words) · Agitate (loss aversion + social-proof gap) · Solution (unique mechanism + fast relief + identity shift).
- **UGLY** — *Filter over any framework, 3 questions:* make it simpler (≤5 words, text cards) · show it cheap (vertical, natural light, Paint graphics) · do the opposite of the competitor.
- **PROVE** — Problem (raw truth) · Reframe (critics vs your identity) · Objection (the doubt you beat) · Victory (results crush it) · Expand (bigger vision).
- **SHOW** — Set the challenge · Head-to-head showdown (split-screen) · Outcome & why (the feature that wins) · Win & CTA (tie win to viewer benefit).
- **Triple G** — Goal (with concrete year) · Gap (missing piece / why they failed) · Gains (product = bridge + proof).
- **TEASE** — Tease (impossible claim) · Engage (build story, introduce product) · Advantage (stack benefits+proof) · Satisfy (clever resolution) · Encourage (urgent CTA + bonus).

**Step 2 — Write 3–5 hooks (the 80/20).** Hooks share the body; each is its own ad set (variation = Andromeda, not
"3 hooks in one ad set"). Align the **4 hook components** (spoken · visual · text · audio) — **the visual leads**
(brain consumes visual→audio→visual). Pick the hook **format** that gives most *contrast* with your key visual:
Fortune Teller · Experimenter · Teacher · Magician · Investigator · Contrarian. Build **tangible curiosity** from the
mechanism (metaphor · paradox question · nickname · testable proof · quiz · surprising culprit). Proven money hooks to
draw from: Investment, Scam ("thought it was a scam"), POV, Founder (name+title overlay), Emotional, Cognitive
dissonance ("why did nobody tell me?"), Identity ("if you're over 40…"). Gut-check comprehension `visual→speech→visual`.

**Step 3 — Write the full body** on the winner anatomy, sequenced by the awareness×sophistication grid (reuse
`experts-direct-response.md`): unaware/problem-aware → longer runway (story/PAS); solution/product-aware → mechanism +
proof + offer fast. In saturated markets (soph. 3–5) a bare claim is invisible → **name a unique mechanism** or shift
to **identity**. Load the offer with the value equation / risk-reversal (reuse `experts-offers-hooks.md`). For a VSL,
follow the compressed VSL skeleton (Hook 0–5s → Problem → Agitate → Mechanism → Proof stack → Offer → CTA).

**Step 4 — Convert Script→Brief** into MLO's exact table so it's shootable with zero questions.

**Step 5 — Attach Filming Requirements + notation + tick-off list.** Run the Módulo-1 quality checklist before delivering.

## Rules & standards (MLO non-negotiables)
- **Trinidad first, message > format.** Avatar + angle come from Árbol de Cascada; the framework is only the vehicle.
- **No product in a cold hook.** Cold = open with curiosity/problem.
- **Every script needs a unique mechanism** (why it works when nothing else did) + **proof** + **CTA with a reason to act now**.
- **Language from real VoC/reviews**, never invented.
- **3–5 hooks per brief**, each a *distinct visual hook*, tested in separate ad sets (Andromeda) — never stacked in one ad set.
- **Precision > filler.** Specifics (numbers, ingredient, timeframe) beat adjectives (Ogilvy/Hopkins).
- **A loose script is not deliverable** — it MUST ship as the brief table + filming reqs + tick-off.
- Measure with the **FFM** preset (hook rate, hold rate, CTR, ROAS); language conventions per brand (ES = coma decimal).

## Output (exact shape + example)
Deliver in this order: **(A) Diagnosis** (avatar · awareness · sophistication · chosen framework + why) → **(B) Hooks 1–5**
→ **(C) Full script** (beats labeled) → **(D) Script→Brief table** → **(E) Filming Requirements + tick-off list**.

**The brief table (the heart of the system):**

| FRAMEWORK | SCRIPT *(FROM UGC / FOR VO / FOR AI VO)* | TEXT *(on-screen)* | B-ROLL *(what to shoot)* |
|---|---|---|---|
| Beat name (e.g. "Declassify the secret") | The literal line the creator/VO says | Short punchy overlay version | Exact visual instruction |

**Notation:** `//` in TEXT = split into 2 separate on-screen cards · `→` in B-ROLL = shot sequence in one cell ·
first rows = HOOK 1…5 over one shared body · end with a **tick-off list**.

**Mini worked example** — Brand: ZZEN (magnesium), Angle: "you're not stressed, you're magnesium-depleted",
Avatar: 40+ ES, Problem-aware, Soph. 4 → **Framework: PAS** (+ Ugly filter on hooks).
- HOOK 3 (Investigator/Contrarian): SCRIPT (FROM UGC) "No estás estresado. Te falta magnesio y nadie te lo dijo." — TEXT "No es estrés // es déficit de magnesio" — B-ROLL: selfie vertical luz natural, mano en el pecho → señala frasco solo al final.
- Body beats: Problem (despiertas cansado, tenso) → Agitate (loss aversion: "y seguirá así cada noche") → Solution (mecanismo: glicinato de magnesio absorbible → relaja en X noches) → Proof ("87% durmió más profundo en 2 semanas") → CTA ("30 noches o te devolvemos el dinero").

## Guardrails
- Don't invent MLO's frameworks or rename the 12 — they are fixed (list above, from Módulo 1). Don't add a "13th".
- Don't pick a framework "because it's cool" — justify by avatar + awareness + asset.
- Don't deliver a bare script — always the brief table + filming reqs + tick-off.
- Don't stack hook variants in one ad set. Don't show product in a cold hook. Don't fabricate proof or VoC.
- If awareness/sophistication/asset are missing, diagnose or ask — don't guess silently.

## References
See `reference/knowledge-base.md`. MLO playbook modules used: **Módulo 1 — Los 12 Frameworks + Script→Brief**
(`01-Modulo-Frameworks-y-Script-to-Brief.md`) and **Módulo 4 — Hooks** (`04-Modulo-Hooks.md`), grounded by
**Módulo 0 — INDEX** (Trinidad, 3A, Awareness, EPIC, Árbol de Cascada, Andromeda, FFM). Reused expert brains:
`mlo-winner-strategist/reference/experts-offers-hooks.md` (VSL/story structure, value equation, hook archetypes) and
`.../experts-direct-response.md` (Schwartz awareness×sophistication grid, Ogilvy/Halbert/Hopkins/Sugarman/Cialdini).
