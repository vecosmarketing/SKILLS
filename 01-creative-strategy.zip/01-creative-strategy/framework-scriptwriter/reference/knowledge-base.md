# Knowledge Base — framework-scriptwriter

Distilled knowledge for MLO's core scripting skill: pick the right framework from MLO's **12**, write a
production-ready script on the winner anatomy, and convert Script→Brief. Grounded in the MLO Playbook (Módulos 0, 1, 4)
and the reused expert brains from `mlo-winner-strategist/reference/`.

---

## 1. The 3 rules that govern everything (Módulo 1 §0)
1. **Message first, format is just the box.** A framework is *what you say and in what order*, not "make a founder video" (Trinidad → Módulo 0).
2. **The hook speaks to ONE person.** The viewer doesn't know or care about your brand — only their problem. A good hook stops the *right* scroll even if it repels everyone else.
3. **Winner anatomy (true for all 12 frameworks):** `Hook → Problema/Deseo → Mecanismo (why it works) → Prueba → CTA con razón para actuar ya`. The 12 frameworks are **12 ways to walk that same anatomy**.

**Choose framework by:** avatar + awareness level, and the psychological asset you actually hold (social proof, founder, unique mechanism, demo…). The **avatar + angle come from the Árbol de Cascada**; the framework is only the vehicle. Naming/account structure = Matriz Andromeda. Measurement = FFM preset (hook rate, hold rate, CTR, ROAS).

---

## 2. MLO's 12 Frameworks — full beat maps (Módulo 1 §1–2)

Master selection table:

| # | Framework | Acronym | Use when… | Awareness |
|---|---|---|---|---|
| 1 | Bandwagon | CROWD | social proof / authorities adopting | Solution / Product |
| 2 | Industry Contrarian | DISRUPT | a "secret"/mechanism that breaks status quo | Problem / Solution |
| 3 | Listicle | CURE | curiosity retention in a list | Problem |
| 4 | Founder | FOUNDER | strong founder story/mission | Unaware / Problem |
| 5 | How to X without Y | SIMPLE | result **without** the usual pain | Solution |
| 6 | Organic | PURE | native, non-ad content | Any (cold) |
| 7 | PAS | Pain-Agitate-Solution | strong clear emotional pain | Problem |
| 8 | Ugly Ads | UGLY | raw/ugly scroll-stopper (a *filter*) | Any (cold TOFU) |
| 9 | Founder Objections | PROVE | crush objections in founder's voice | Product |
| 10 | Us vs Them | SHOW | visual superiority challenge | Solution / Product |
| 11 | Triple G | Goal-Gap-Gains | aspiration/transformation with a date | Problem |
| 12 | TEASE | T·E·A·S·E | impossible claim for max retention | Unaware / Problem |

**① Bandwagon — CROWD:** Call out the movement (name the group/experts/celebs already using it) · Reject the old way · Onboard the new way (product as the superior new way) · Wave the proof (studies/cases/social proof) · Direct the viewer (CTA with the **benefit inside the CTA**). *Ex: "12 fine-dining chefs switched to this oven last quarter… watch the salmon in 47s."*

**② Industry Contrarian — DISRUPT:** Declassify the secret (reveal suppressed knowledge / bust a myth) · Industry failure (why mainstream fails) · Solution (product) · Reinforce with evidence · Upstage the competition (what makes you unique) · Provide proof (measurable social proof) · Trigger the movement (CTA + risk reversal). *Ex: "This anti-aging compound sat on the shelf 30 years because the industry preferred cheaper synthetics."*

**③ Listicle — CURE:** Curiosity/list hook **+ the reason for the number** (bad: "5 hidden mistakes"; good: "If you sleep 8h and still wake tired, here are 5 mistakes wrecking your sleep") · Uncover failures (why standard fixes fail — melatonin, white noise…) · Remedy (product) · Evidence ("87% slept deeper in 2 weeks") · Engage/CTA + risk reversal ("30 nights or refund").

**④ Founder — FOUNDER:** Feature the founder (human with a mission) · Opposing force (the customer's enemy/problem) · Unlocking the idea (the eureka/turn) · Numbers (3–4 tangible results) · Destiny (current wins are just the start) · Engage the movement (CTA with "join"/identity language).

**⑤ How You Can X Without Y — SIMPLE** (the "one-thing fix"): State the escape (identity + pain in one line: "Eat healthy without Sunday cooking marathons") · Identify pain (concrete scenarios) · Minimal solution (product = "the only thing you need") · Prove (feature→benefit with because→so logic: "guayusa → focus without jitters") · Lifestyle win (old effort vs new ease) · Escape CTA (fit the avatar's identity).

**⑥ Organic — PURE:** Problem uncovered (raw relatable frustration hook) · Unfiltered chaos (2–3 real scenes, day-diary format 7am/10am/4pm) · Real evidence (genuine "aha" moments in natural setting) · Effortless freedom (anti-friction payoff).

**⑦ PAS — Pain · Agitate · Solution:** Problem (core pain in their words — "I can't get air", "chest panic") · Agitate to the emotional (levers: *loss aversion* "this will always be your reality" + *social-proof gap* "others handle it, why can't you?") · Solution (unique mechanism "dual resistance trains inhale + exhale" + fast relief "in 10 breaths" + social backing; close with *identity shift* "from victim to prepared warrior").

**⑧ Ugly Ads — UGLY** (a **filter over any framework**, not a structure). 3 questions: (1) *Simpler?* say it in ≤5 words, delete 70% of words, would a 10-year-old get it? → lines become text cards. (2) *Cheaper-looking?* vertical mobile, natural light, Paint-style graphics, real selfie not HD. (3) *Opposite of the competitor?* if everyone says "find your dream job!", you: "HATE YOUR BOSS? STEAL HIS JOB."

**⑨ Founder Objections — PROVE:** Problem (undeniable painful truth, raw-reality hook) · Reframe (critics vs your identity: "but we're farmers, we know…") · Objection (verbalize the doubt you beat: "regulators said: they'll never approve it") · Victory (crush the doubt with results: "in 11 weeks, 300 villages powered") · Expand (pivot to the bigger vision).

**⑩ Us vs Them — SHOW** (challenge video, usually split-screen): Set the challenge (high-stakes: product vs alternative/task) · Head-to-head showdown (simultaneous visual clash) · Outcome & why (who wins **+ the feature that enables it**: "solid-state tech → 2× density") · Win & CTA (tie the win to the viewer's benefit: "if buffering frustrates you → instant streaming now").

**⑪ Triple G — Goal · Gap · Gains** (use a **concrete year** for urgency): Goal (the result they want: "make hydration a habit in 2026") · Gap (why they failed before / the missing piece: "current drinks are loaded with sugar") · Gains (product = the bridge + stack proof). *5 template hooks:* "Want [goal]? Let's fix it for 2026" · "You keep failing at [goal] because you're missing this" · "The BEST tool for [goal]" · "Make [goal] a habit with [missing piece]" · "Your 2026 [goal] starts by fixing this gap".

**⑫ TEASE — T·E·A·S·E** (curiosity loop; an impossible claim resolved only by watching the whole ad): Tease (impossible/surprising claim creating dissonance: "I got my boyfriend a Valentine's gift for free") · Engage (build the story, introduce the product without revealing the link) · Advantage (stack benefits + proof inside the narrative) · Satisfy (clever resolution that makes the opening claim logical) · Encourage (immediate CTA + urgency + bonus).

---

## 3. The Hook system (Módulo 4) — the 80/20

- **A hook opens a curiosity loop by CONTRAST:** viewer believes A → you show B; the gap *is* the curiosity. Bigger contrast = stronger hook. Cold (TOFU) hook = curiosity/problem, **never product**.
- **4 components received simultaneously — align all 4:** Spoken (what's said) · Visual (what's shown) · Text (overlay) · Audio (sound). 500 vs 500,000 views = alignment. The brain consumes `visual → audio → visual`; eyes are 10–100× faster than ears → **the VISUAL leads** ("key visual"). Changing the visual hook moves performance more than text/voice. That's why you test **3 visual-hook variants**, same everything else.
- **6 viral hook formats** (pick the one giving most contrast with your visual): **Fortune Teller** (present vs future) · **Experimenter** (peer-to-peer demo) · **Teacher** (teacher-to-student lesson) · **Magician** (visual/verbal stun + visual pacifier; combines with the other 5) · **Investigator** (a secret/finding) · **Contrarian** (opposite of convention, direct).
- **6 tangible-curiosity generators** (take the **mechanism**, make it concrete/visual): Metaphor (natural best — river/fire/pipes) · Paradox question · Characterization/nickname (*ice-water trick, purple peel, white-napkin effect*) · Testable proof ("press your shin 5s; if it's slow to bounce back, that's water retention") · Quiz · Surprising culprit (the problem behind the problem). Master trick: start from the **curiosity**, then connect it back to the mechanism — never invent, but explore where nobody looks (*brick logic*).
- **Proven money hooks:** Investment ("I tried X for 3 years before…") · Scam ("thought it was a scam") · POV · Founder (name + title overlay) · Emotional ("why did this make me cry?") · Cognitive dissonance ("why did nobody tell me?") · Identity-based ("if you're over 40…" = self-selection).
- **5-step process:** (1) What VISUAL do I have? (2) Which fact/angle gives most contrast? → picks the format. (3) Write spoken hook: context-lean → contrast → snapback to visual. (4) Add text hook that reconfirms. (5) Gut-check `visual→speech→visual`; if not crystal-clear, throw the hook and redo — ideas are infinite.

---

## 4. Script → Brief (Módulo 1 §3) — the heart of the system

A loose script can't be shot. Deliver the **table**: every line maps to a framework beat, what's said, on-screen text, and exactly what to film.

| FRAMEWORK | SCRIPT *(FROM UGC / FOR VO / FOR AI VO)* | TEXT *(on-screen)* | B-ROLL *(what to shoot)* |
|---|---|---|---|
| Beat name (e.g. "Declassify the secret") | Literal line the creator/VO says (label = mode: UGC creator / VO human / AI VO) | Short punchy overlay version | Exact visual instruction ("point at the key ingredient on the label", "throw the makeup remover in the trash") |

**Notation conventions (teach the team):**
- `//` in TEXT = split into 2 separate on-screen cards shown one after another ("Why they fail // What works").
- `→` in B-ROLL = shot sequence within one cell.
- **Multiple HOOKS per brief** (HOOK 1…5) in the first rows over **one shared body** → this is variation to test (Andromeda), NOT "3 headlines in one ad set".
- **Tick-off list** at the end: checklist to confirm everything was filmed before closing.

**Filming Requirements (always in the brief):** raw via Google Drive · iPhone **no HDR** · **unedited** (no subtitles/transitions) · talking-head and B-rolls **separate**, **no voiceover** while filming · natural, some improv OK · **don't show product in hooks** (only where script says) · good light · **vertical 9:16** · don't speak glued to camera (leave margin for crops/text) · no background noise · camera at eye level · comfortable clothes **no logos** · **change clothes** between talking-head and B-rolls.

**Plug into MLO system:** avatar + angle ← Árbol de Cascada · naming/structure ← Matriz Andromeda · brief templates + Quality Gate ← SOP "Creación Brief" · measurement ← FFM preset. The framework only decides *how it's told*.

**Quality checklist ("is the script ready?"):** hook speaks to ONE avatar & stops scroll in 0–3s · unique mechanism visible · proof present · CTA has a reason to act now (scarcity / risk reversal) · passed to brief table + filming reqs + tick-off · 3–5 alt hooks to test · language from real reviews/VoC.

**Common mistakes:** picking a framework "because it's cool" instead of by awareness/avatar · showing product in the hook · script with no mechanism · delivering without the brief table · putting hook variants in the same ad set.

---

## 5. Reused expert frameworks (cite the source file)

From **`mlo-winner-strategist/reference/experts-direct-response.md`**:
- **Schwartz — 5 Awareness stages** (Unaware → Problem → Solution → Product → Most-aware): *less aware = longer runway before product; more aware = go to offer faster.* Routes framework choice (see Módulo 1 awareness column).
- **Schwartz — 5 Sophistication stages** (plain claim → enlarge claim → mechanism → elaborate/prove mechanism → identification/reinvent): in saturated markets (soph. 3–5) a bare claim is invisible → **name a unique mechanism** or shift to **identity**. This is why winners decay — the *market* advanced a stage.
- **Awareness × Sophistication grid** — the master cheat-sheet for picking the hook at the intersection. Two most common DTC failures it catches: offer-ad to an unaware audience; bare claim in a saturated market.
- **Ogilvy / Hopkins** — specifics > adjectives (reason-why copy; the number, ingredient, timeframe). **Halbert** — starving crowd (market > copy); AIDA in order; sell on emotion, justify with logic. **Sugarman** — slippery slide (each element's only job is to earn the next); 24 triggers as an audit checklist. **Cialdini** — 7 principles (reciprocity, commitment, social proof, authority, liking, scarcity, unity); Unity/identity = Schwartz stage-5 identification.

From **`mlo-winner-strategist/reference/experts-offers-hooks.md`**:
- **Hormozi Value Equation** = (Dream Outcome × Perceived Likelihood) / (Time Delay × Effort). Diagnose which lever a weak creative fails to move and rebuild the angle around it.
- **Grand Slam Offer / value stack** (10× price + risk-reversal guarantee) → the CTA/offer beat.
- **Short-form VSL skeleton (2–2.5 min):** Hook 0–5s (≈80% of performance) → Problem → Agitate → Unique Mechanism → Proof stack (multi-angle) → Offer/stack → CTA. Time budget ~2:15: 0:00–0:05 hook · 0:05–0:30 problem+agitate · 0:30–1:00 mechanism · 1:00–1:40 proof · 1:40–2:05 offer · 2:05–2:15 CTA. Use this as the body skeleton when the format is VSL/founder-story/explainer.
- **Story frameworks:** StoryBrand SB7 (customer = hero, brand = guide), compressed Hero's Journey (founder/testimonial ads), PAS (problem-aware), AIDA (unaware — build desire). Diagnose failures with hook rate (fails 0–5s) vs hold rate (fails 5–15s).
- **Hook rate = 3s plays / impressions**; **Hold rate = ThruPlays / 3s plays**. Table stakes hook ~20–25%, good >30%, elite >40%. Fix hook rate before hold rate.

---

## Sources
**MLO Playbook (source of truth):** `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/`
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, Market Sophistication, EPIC angles, Árbol de Cascada, Matriz Andromeda, FFM.
- `01-Modulo-Frameworks-y-Script-to-Brief.md` — **the 12 frameworks + Script→Brief** (primary grounding).
- `04-Modulo-Hooks.md` — the full hook system (4 components, 6 formats, 6 curiosity generators, money hooks, 5-step process).

**Reused expert brains:** `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/`
- `experts-direct-response.md` — Schwartz awareness×sophistication grid; Ogilvy, Halbert, Hopkins, Sugarman, Cialdini.
- `experts-offers-hooks.md` — Hormozi value equation & Grand Slam Offer; short-form VSL structure; StoryBrand/Hero's Journey/PAS/AIDA; hook-rate/hold-rate formulas.

**Aligned MLO skills (don't fork):** `angle-generator`, `creative-strategist`, `hooks-expert`, `unaware-ads-expert`, `advertorial-strategist`, `ai-video-director`, `ugc-director`, `seedance-20-ugc-ad-director`, `script-doctor`, `mlo-winner-strategist`.
