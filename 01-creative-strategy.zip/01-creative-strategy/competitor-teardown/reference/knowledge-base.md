# Competitor Teardown — Knowledge Base

Distilled knowledge for the `competitor-teardown` skill. It teaches how to pull competitors' running ads, decode *each winner* (angle, hook, framework, awareness stage, why it works), and turn the read into **steal-worthy insights + gaps to exploit** for MLO Growth's DTC brands. Everything below is grounded in MLO's real playbook + the winner-strategist expert brains; fresh external facts carry a source URL.

This is the *offense* counterpart to `mlo-winner-strategist` (which decodes MLO's *own* winners). Same taxonomy, same expert brains, opposite direction: we read the enemy's board, not ours.

---

## 1. Where to pull competitor ads (sources & how)

### A) Meta Ad Library — the primary, always-on source
The Meta Ad Library shows *every* ad a Page is currently running (all placements), how many creative variations sit under one ad, and — for EU-targeted ads — reach/demographics. It is the field's default competitor-recon tool because "still running after weeks" is a free proxy for "profitable." (https://www.facebook.com/ads/library/)

- **MCP tool:** `ads_library_search` (Meta Marketing MCP, server prefix `mcp__59c1dc50-...__ads_library_search`). Use it first when available — search by advertiser Page / keyword / country, pull active creatives + copy. Load its schema via ToolSearch before calling.
- **Read signals (proxies for a winner, since you can't see spend):**
  - **Longevity** — ad live for many weeks = it's paying. This is the single strongest public signal.
  - **Variation count** — many "This ad has multiple versions" = the advertiser is actively iterating a *concept that works* (they don't iterate losers).
  - **Concept repetition** — the same angle re-shot across many creators/formats = a proven concept they're scaling.
  - **Recency of new launches** — a burst of new ads on one angle = a fresh winner they just found.
- **Gotcha:** the Library shows *what's running*, not *what's converting*. Longevity + variation volume are inferences, not truth. Say so in the output. Spend/ROAS are never visible for competitors.

### B) Atria — creative intelligence layer (via Chrome)
Atria (used across MLO brands, accessed through the Chrome session) adds a decode/grade layer on top of Ad Library scraping: hook/hold estimates, creative tagging, angle/format labels, and searchable competitor libraries. Use it to (a) surface which competitor creatives look highest-quality, (b) get a first-pass hook/format tag you then verify by hand. Treat Atria's auto-tags as a *draft* to correct with the MLO taxonomy below, not gospel.

### C) Secondary sources (name them, use if the above is thin)
- **TikTok Creative Center / TikTok Ad Library** — for TikTok-native competitors; shows top ads by region/industry.
- **Foreplay / Motion / Sensor Tower / SocialPeta** — third-party swipe/intel tools some brands license; if the brand has one, mine it.
- **Organic feeds** — the competitor's own IG/TikTok best-performing organic often previews the angle before it becomes a paid winner.

---

## 2. The teardown decode — what to extract per ad (the core)

For **every** competitor ad you tear down, produce this 8-field decode. This mirrors the winner-strategist's "Creative Framework Extractor v2" logic, aimed outward. Be surgical and specific — **no generic language.**

1. **Creative format** — UGC · Static · High-Prod · UGC Video · Founder-Led · Mashup · Carousel. (Same options as MLO's Best-Performing Frameworks `Ad Format`.)
2. **The hook (first 3s), verbatim** — transcribe the exact opening line + describe the opening *visual*. Classify the hook archetype (see §5). Barry Hott's rule: judge "Second 0" first — does this first frame stop the *right* scroller? (experts-dtc-creative.md)
3. **The angle** — the perspective/argument that sustains interest toward conversion (Motion's Angle ≠ Hook ≠ Concept ≠ Format vocabulary). Name the EPIC angle bucket if it fits (Emotional / Practical / Identity / Curiosity — MLO 00-INDEX). Angle > execution: the argument beats the polish. (experts-dtc-creative.md)
4. **Framework** — map to MLO's **12 Scripting frameworks** AND the **Best-Performing Frameworks 19-option taxonomy** (see §3). Give both labels.
5. **Awareness stage (Schwartz)** — Unaware · Problem-Aware · Solution-Aware · Product-Aware · Most-Aware. Diagnose from the *runway*: does it educate before naming the product (low awareness) or lead with offer/CTA (high awareness)? (experts-direct-response.md)
6. **Market sophistication stage (Schwartz)** — 1 plain claim · 2 enlarged claim · 3 mechanism · 4 elaborated mechanism · 5 identity/reinvention. This is what tells you whether the competitor is riding a *fresh* claim or has been forced up to a mechanism/identity play — and where an MLO brand in the same category must land. (experts-direct-response.md)
7. **Emotional triggers / persuasion levers fired** — FOMO, transformation, status, curiosity, resolved frustration, authority, social proof… Audit against **Cialdini's 7** (Reciprocity, Commitment, Social Proof, Authority, Liking, Scarcity, Unity) and **Sugarman's triggers**. Weak ads fire one; strong ads stack 3–5. (experts-direct-response.md)
8. **Why it works (3–5 lines) + what's replicable** — the mechanism of the win in plain language, then explicitly: what an MLO brand can *steal* vs. what is competitor-specific and non-transferable.

Optional performance proxies (never present as real numbers): estimated longevity (weeks live), variation count, Atria hook/hold estimate. Label them "inferred."

---

## 3. Framework mapping — competitor ad → MLO taxonomy

Every torn-down ad gets **two** framework labels so it plugs into MLO's whole system.

### (a) MLO's 12 Scripting Frameworks (source: playbook `01-Modulo-Frameworks-y-Script-to-Brief.md`)
The vehicle that carries the message. Anatomy of every winner: `Hook → Problem/Desire → Mechanism (why it works) → Proof → CTA with a reason to act now`. The 12 are 12 ways to walk that anatomy:

| Framework | Acronym | Spot it when the ad… | Typical awareness |
|---|---|---|---|
| **Bandwagon** | CROWD | leads with a group/experts/celebs already switching | Solution / Product |
| **Industry Contrarian** | DISRUPT | reveals a "suppressed secret" / breaks the status quo | Problem / Solution |
| **Listicle** | CURE | is "X reasons / X mistakes…" retention-by-curiosity | Problem |
| **Founder** | FOUNDER | tells the founder-hero mission story | Unaware / Problem |
| **How to X without Y** | SIMPLE | promises the result *without* the usual pain | Solution |
| **Organic** | PURE | is built to not look like an ad (native) | Any (cold) |
| **PAS** | Pain·Agitate·Solution | leads with a sharp emotional pain | Problem |
| **Ugly Ads** | UGLY | is deliberately crude/lo-fi to stop the scroll (a *filter* over any framework, not a structure) | Any (cold TOFU) |
| **Founder Objections** | PROVE | has the founder crushing objections one by one | Product |
| **Us vs Them** | SHOW | is a head-to-head/split-screen demo | Solution / Product |
| **Triple G** | Goal·Gap·Gains | sells a dated aspiration/transformation | Problem |
| **TEASE** | T·E·A·S·E | runs an impossible claim resolved only by watching to the end | Unaware / Problem |

### (b) Best-Performing Frameworks — the 19-option Notion taxonomy (source: mlo-winner-strategist SKILL.md, DB `collection://2356c997-7eb7-80b3-9ae0-000b61bd9fc8`)
The label the win gets filed under in MLO's Creative HUB, so a competitor teardown can seed MLO's own library:

`Us Vs Them · Investigation Arc · Testimonial · Benefits Timeline · Problem/Solution · Offer / Scarcity · Founder-led · Expert-led · Social Proof · Friction Removal · Status / Identity · Before & After · Transformation · Myth Busting · Pain-Point Based · Trust / Authority · Life Aspiration · Curiosity / Open Loop · Lifestyle Aspirational`

If the exact option doesn't fit, pick the closest and note the nuance — never invent a new option silently (same rule as winner-strategist).

**Cross-walk (12 → 19), so you can label both fast:**
- Bandwagon → Social Proof / Status·Identity
- Industry Contrarian → Myth Busting
- Listicle → Curiosity / Open Loop
- Founder → Founder-led
- How to X without Y → Friction Removal
- Organic → (format-native; label by underlying angle, e.g. Problem/Solution)
- PAS → Pain-Point Based / Problem·Solution
- Ugly Ads → (filter, not a framework; label the underlying angle)
- Founder Objections → Founder-led / Trust·Authority
- Us vs Them → Us Vs Them / Before & After
- Triple G → Life Aspiration / Transformation
- TEASE → Curiosity / Open Loop

---

## 4. The master diagnostic — Awareness × Sophistication (apply first)

The single most important tool (source: experts-direct-response.md, Schwartz grid). Diagnose **both** axes for each competitor ad, then for the MLO brand's own position in the category.

- **Awareness = what one prospect knows** (Unaware → Most-Aware). Read from runway length: education-first = low; offer-first = high.
- **Sophistication = how much the whole *market* has already heard this claim** (1 plain → 5 identity/reinvent). Read from whether the ad states a bare benefit (fresh market) or is forced into a mechanism / identity play (saturated market).

**Why this is the teardown's power move:** it turns "here's a nice ad" into strategy.
- If every competitor is running **Most-Aware offer ads** → the top of the funnel is *wide open*; an MLO brand wins by owning Unaware/Problem-Aware story creative. (Theriot: most brands over-index on the discount ad — experts-dtc-creative.md.)
- If the category is **sophistication 4–5** (supplements, skincare, weight-loss) and a competitor is still shouting a **bare claim** → they're about to fatigue; MLO leaps ahead with a **mechanism** or **identity** angle.
- If a competitor just moved to a **unique mechanism** and it's clearly scaling (many variations, long life) → the market has advanced a stage; MLO must match/out-prove the mechanism, not shout the old claim louder.

**Angle-decay read:** a competitor ad that *was* everywhere and vanished usually died because the market advanced a sophistication stage — note it as a gap MLO can enter with the *next* stage's angle.

---

## 5. Hook & persuasion reference (for the decode)

- **Hook = ~90% of the job / "Second 0" first.** Transcribe and classify the opening; the body is comparatively cheap. Common archetypes to tag: Problem/Callout · Curiosity/Open-Loop · Bold-Claim/Contrarian · Testimonial/Result · Question · Negative/"stop doing X" · Visual pattern-interrupt · Us-vs-Them tease. (experts-dtc-creative.md, experts-offers-hooks.md)
- **Native / lo-fi beats polished.** Motion data: 42% of top-spend ads are lo-fi. If a competitor's whole library is over-produced, that's a **gap** — MLO enters with ugly/native. If the competitor already runs native UGC well, match the register. (experts-dtc-creative.md — Hott "Ugly Ads," Sanchez native-first, Motion trends.)
- **Cialdini's 7 / Sugarman triggers** — audit which levers each ad fires; MLO's counter-angle should fire the levers the competitor *ignores* (e.g. everyone fires Scarcity, nobody fires Unity/identity → build the tribe angle). (experts-direct-response.md)
- **Hormozi Value Equation** — read the competitor's *offer*: Dream Outcome × Perceived Likelihood ÷ (Time Delay × Effort). If their offer is weak on likelihood (no proof/guarantee) or high on effort, that's the wedge for an MLO Grand-Slam-Offer counter. (experts-offers-hooks.md)
- **Benchmarks for grading inferred hooks:** hook rate <20% weak, 25–35% good, 40%+ elite; hold ~25%+. Only ever "inferred" for competitors (you don't have their data). (experts-dtc-creative.md)

---

## 6. Pattern & gap synthesis — the deliverable's payoff

After decoding the individual ads, zoom out. This is where a teardown earns its keep — patterns and gaps, not a pile of summaries.

**Patterns to surface (what the category is doing):**
- **Dominant framework(s)** — which of the 12/19 shows up most across the set → the category's default vehicle.
- **Awareness concentration** — where the whole competitor set clusters on the ladder (usually bottom-funnel).
- **Sophistication level** — plain-claim vs. mechanism vs. identity — is the category climbing?
- **Format/register consensus** — all polished? all UGC? all founder? (a shared blind spot is a gap.)
- **Repeated hooks/angles** — the same claim everyone copies (sophistication is rising; it's decaying).
- **Persuasion levers everyone fires** (and the ones nobody does).

**Gaps to exploit (the steal-worthy output — the point of the whole doc):**
- **Uncovered awareness stage** — the funnel level no competitor addresses (typically Unaware/Problem-Aware). → MLO owns it.
- **Uncovered framework** — a proven MLO framework nobody in the category runs (e.g. all Testimonial, none Us-vs-Them demo).
- **Uncovered register** — everyone polished → go Ugly/native; everyone UGC → a High-Prod founder film stands out.
- **Uncovered lever** — nobody fires Unity/identity, or nobody shows a mechanism → next sophistication stage.
- **Offer wedge** — competitors' weak Value-Equation link (no guarantee, slow result) → MLO's Grand Slam Offer.
- **Fatigue window** — an angle that was everywhere and died → re-enter with the next stage's angle.

Each gap must ship with a **steal-worthy insight**: a concrete, one-line "so MLO should ___" that a strategist can brief tomorrow (name the MLO framework + awareness stage + hook direction). Where useful, these are exactly the seeds `mlo-winner-strategist` / `mlo-creative-strategy` / `angle-generator` turn into briefs and Notion entries.

---

## 7. Rules & standards (MLO non-negotiables)
- **Trinidad-first, message > format** — decode *what is said and in what order*, never "it's a founder video." (00-INDEX)
- **Ground every judgment** in the 12 frameworks + the two expert brains; **never invent** MLO frameworks or fake competitor metrics. (build guide)
- **Precision > filler** — verbatim hooks, named frameworks, specific angles. No "great engaging creative."
- **Inference honesty** — Ad Library shows *what's running*, not *what converts*; label longevity/variation/Atria reads as inferred proxies.
- **FFM lens** — grade with the FFM preset vocabulary (hook rate, hold rate, CTR, ROAS) but flag competitor numbers as estimates.
- **Every teardown ends in action** — patterns + gaps + steal-worthy one-liners, or it's just a scrapbook.

---

## Sources

**MLO playbook & skills (source of truth):**
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, Sophistication, EPIC angles, FFM, Árbol de Cascada, Matriz Andromeda.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/01-Modulo-Frameworks-y-Script-to-Brief.md` — the 12 Scripting frameworks + winner anatomy + Script→Brief.
- `mlo-winner-strategist/SKILL.md` — Best-Performing Frameworks 19-option taxonomy, winner criteria, Creative Framework Extractor v2 logic, Notion DB IDs.

**Reused expert brains (winner-strategist `reference/`):**
- `experts-direct-response.md` — Schwartz Awareness × Sophistication grid (the master tool), Ogilvy, Halbert (starving crowd), Hopkins, Sugarman triggers, Cialdini's 7.
- `experts-dtc-creative.md` — Dara Denney (content > metrics), Savannah Sanchez (hook = 90%, native-first), Barry Hott (Ugly Ads, Second-0), Nick Theriot (5 awareness stages, bait-targeting), Motion (Angle/Concept/Hook/Format, lo-fi 42%, volume).
- `experts-offers-hooks.md` — Hormozi Value Equation & Grand Slam Offer, hook archetypes, unique mechanism, VSL structure.

**External (for the pull sources):**
- Meta Ad Library — https://www.facebook.com/ads/library/
- (MCP) `ads_library_search` — Meta Marketing MCP tool for programmatic Ad Library search.
- Atria — creative-intelligence layer (accessed via the MLO Chrome session).
- TikTok Creative Center — https://ads.tiktok.com/business/creativecenter
