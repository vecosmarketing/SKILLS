# Direct-Response Legends — Frameworks for the Modern Creative Strategist

A cited knowledge base distilling the six foundational direct-response / advertising masters into tools a DTC creative strategist applies to ads (static, video, UGC, VSL, landing) **today**. Every claim carries a source URL. The single most important tool is the **Awareness × Sophistication grid** at the bottom — read that section last, apply it first.

Core through-line all six share: **you do not create desire, you channel existing desire.** The market is chosen before the copy is written. Product and creative quality lose to a hungry, correctly-diagnosed audience.

---

## Eugene Schwartz — *Breakthrough Advertising* (1966)

Schwartz is THE core model. Two frameworks that stack on top of each other: **Awareness** (what the *prospect* knows) and **Sophistication** (what the *market* has already heard). You diagnose both before choosing a hook.

> "The power, the force, the overwhelming urge to own that makes advertising work, comes from the market itself, and not from the copy. Copy cannot create desire for a product. It can only take the hopes, dreams, fears and desires that already exist in the hearts of millions of people, and focus those already existing desires onto a particular product." — Eugene Schwartz. Your job is to *channel* mass desire, not manufacture it. [1][2]

### The 5 Stages of AWARENESS — how much your prospect already knows

The awareness level determines everything downstream: the headline, the opening hook, the proof, and the CTA. The rule: **the less aware, the longer the runway you must build before the product; the more aware, the faster you go to the offer.** [3]

| Stage | What the prospect knows | Lead the ad with… (hook/angle) |
|---|---|---|
| **1. Unaware** | Nothing — doesn't even recognize the problem. | Do NOT mention the product. Lead with symptom recognition, a story, a curiosity/education hook, or an identity call-out that makes them realize something is wrong. Ex: "10 signs your [X] is quietly failing you." Content triggers the realization. [3][4] |
| **2. Problem-Aware** | Feels the pain / sees the symptoms, but doesn't know the cause or that a fix exists. | Validate the frustration, name the pain precisely, then diagnose the root cause. Establish expertise *before* naming a solution category. Ex: "Why is [your problem] happening — and the real reason nobody told you." [3][4] |
| **3. Solution-Aware** | Knows solution categories exist; comparing types/approaches, not yet a specific brand. | Emphasize your **mechanism** and USP — why *your* approach beats the alternatives they're weighing. Comparison angles, "vs." framing, "the [category] everyone else gets wrong." [3][4] |
| **4. Product-Aware** | Knows your product exists; hasn't committed (price, trust, competitor, timing doubts). | Handle specific objections. Proof, guarantees, testimonials, before/afters, FAQs, risk-reversal, ROI. Ex: "Still deciding? Here's what 4,000 buyers said." [3][4] |
| **5. Most-Aware** | Knows the product, trusts the claims, ready — just needs the right offer/moment. | Remove all friction. Lead with the **offer + CTA + urgency**: price, bundle, discount, deadline, free shipping. "Start free trial," "Get 30% off before midnight." [3][4] |

**How to apply to a DTC ad:** Most cold Meta traffic sits at stages 1–3; your retargeting sits at 4–5. A common failure is running a stage-5 offer ad ("20% off!") to a stage-1 cold audience that has no idea they need the product. Match the creative's *runway length* to the stage: unaware = story/education/native-feeling content; most-aware = direct offer. Build a **creative portfolio that covers every stage**, not five variants of the same stage.

### The 5 Stages of Market SOPHISTICATION — how much your MARKET has already heard

Sophistication is about the *competitive noise* your prospect has already been exposed to for this type of claim. As a market matures, the same claim stops working and you must escalate. This is why "winning angles" decay. [1][5]

| Stage | Market condition | What the ad must do |
|---|---|---|
| **1. First to market** | Brand-new claim, no competitors. | State the claim **plainly and directly.** Just name the desire/benefit. "Lose weight." "The first watch that monitors your health in real time." Nothing fancy needed — the claim alone is fresh. [5] |
| **2. Second wave** | Competitors copy the claim; the market has heard it. | **Enlarge / outbid the claim.** Make it bigger, faster, easier, more. "Lose weight in half the time." "20% more accurate thanks to patented tech." [5] |
| **3. Mechanism** | Enlarged claims stop being believed. | Introduce a **unique mechanism** — the *how* that makes the claim credible again. "Lose weight by blocking the enzyme that stores fat." The mechanism becomes the new hook. [5] |
| **4. Elaborated mechanism** | Everyone now has a mechanism; the market is saturated & skeptical. | **Out-prove and elaborate** the mechanism — more specific, more scientific, more evidence: studies, certifications, testimonials, demonstrations. "Approved by 10 of 10 cardiologists." [5] |
| **5. Identification / reinvent** | Total saturation; nobody believes claims or mechanisms anymore. | Stop selling on claim/mechanism. Sell on **identity and identification** with the prospect ("this is *you*, this is who you are"), OR **reinvent** the product/category entirely. "A simple watch. Reliable. Essential." [5] |

**How to apply to a DTC ad:** Before writing a hook, ask *"How many times has my prospect already heard this exact promise?"* In a fresh category (stage 1–2), a direct benefit hook wins. In a saturated DTC category — supplements, skincare, weight loss (stage 3–5) — a bare benefit claim is invisible; you **need a mechanism** ("the reason it works is X") or an **identity angle** ("for the woman who…"). When a top ad's ROAS decays, it's usually because the market moved up a sophistication stage — respond by adding a mechanism or shifting to identification, not by shouting the same claim louder.

---

## David Ogilvy — headlines, research, "the consumer isn't a moron"

Ogilvy bridged brand and direct response: creative that is *tested* and *sells*, but respects the audience.

- **The consumer isn't a moron.** "The consumer isn't a moron; she is your wife. You insult her intelligence if you assume that a mere slogan and a few vapid adjectives will persuade her to buy anything." (*Confessions of an Advertising Man*, 1963, p.96) [6][7] — **Apply:** don't hype with empty adjectives; give real information. She wants all the information you can give her.
- **Headlines carry 80% of the spend.** "On the average, five times as many people read the headline as read the body copy. When you have written your headline, you have spent eighty cents out of your dollar." [7] — **Apply:** on a Meta static/thumbnail, the hook line + first frame *is* the ad. Test hooks separately from bodies.
- **The headline must promise a benefit.** "Your headline should promise a benefit, or deliver news, or offer a service, or tell a significant story, or recognize a problem, or quote a satisfied customer." Ads that promise no benefit don't sell. [7][8] — **Apply:** every hook must telegraph WIIFM (what's in it for me), not be clever. Avoid puns/double meanings; "readers travel fast through this jungle." [7]
- **Specifics over adjectives.** "Good ad: all facts, no adjectives, specific." The Rolls-Royce ad ("At 60 miles an hour the loudest noise… comes from the electric clock") ran 607 words of fact. [8] — **Apply:** replace "amazing results" with the number, the ingredient, the timeframe.
- **Long copy sells.** "Long copy sells more than short copy, particularly when you are asking the reader to spend a lot of money. Only amateurs use short copy." [7][8] — **Apply:** for higher AOV / considered purchases, the long-form VSL or advertorial beats a one-liner. Give the reader the full case.
- **Research-led.** Ogilvy insisted on studying the product and the customer before writing. — **Apply:** mine reviews, support tickets and comments for the actual language customers use; that's your headline bank.

---

## Gary Halbert — the "starving crowd," AIDA, emotional selling

- **The Starving Crowd (the #1 lesson).** Halbert asked his students: *"If you and I both owned a hamburger stand and we were in a contest to see who could sell the most hamburgers, what advantages would you most like to have?"* Students named better meat, buns, location, price. His answer: *"The only advantage I want is… A Starving Crowd!"* [9] — **Apply:** the *market* beats the product, the copy, and the price. Before optimizing creative, ask whether you're aiming at a hungry audience. In DTC: audience/offer selection > ad polish. A mediocre ad to a starving crowd outsells a brilliant ad to an indifferent one. "Constantly be on the lookout for groups of people (markets) who have demonstrated they are starving for some product or service." [9]
- **AIDA, in order, no skipping.** Attention (sharp headline) → Interest (fascinating facts) → Desire (show it solves *their* specific pain) → Action (explicitly tell them what to do). It's a funnel; you can't skip a step. [10] — **Apply:** map every video ad to AIDA — hook (A), demonstration/facts (I), transformation/benefit (D), CTA (A).
- **Selling is emotion, justified by logic.** "Selling is pure emotion." Use specific details and vivid, emotional description to build the connection; then give logical reasons to justify the buy. [10] — **Apply:** open on the emotional pain/desire, close with specifics and proof.
- **The Halbert method / voice.** Write like a personal letter to one person, in plain, conversational language (the *Boron Letters* voice). Grab attention with pattern-interrupts and story. — **Apply:** UGC and founder-story ads that read like one human talking to another outperform corporate polish.

---

## Claude Hopkins — *Scientific Advertising* (1923)

The origin of testing culture. "Advertising is salesmanship." [11]

- **Salesmanship in print.** "Salesmanship-in-print, in principle, is just the same as salesmanship-in-person." Judge every ad as you'd judge a salesperson: does it *sell*? [11] — **Apply:** an ad's job is a conversion, not applause. Kill "brand awareness" excuses for ads that don't sell.
- **Test everything with measured response.** Hopkins used keyed/coded coupons to track results and tested headlines, offers and propositions against one another, keeping winners and killing losers. [11] — **Apply:** this is the ancestor of Meta A/B testing. Isolate one variable (hook, angle, offer), measure by real response (ROAS/CPA), let data decide. Never argue about creative — test it.
- **Reason-why copy.** Don't just claim — give the *reason why* it's true/better. Research the product deeply first. [11] — **Apply:** "Because it's made with X, it does Y" beats "it's the best." Mechanism = reason-why (ties directly to Schwartz stage 3).
- **Specifics beat generalities.** "Specific claims when made in print are taken at their value." State exact figures and facts, not vague superlatives. (Hopkins famously advertised that Schlitz beer bottles were "washed with live steam" — a process every brewer used, but *no one had said it.*) [11] — **Apply:** find the concrete, demonstrable specific about your product that competitors do but never state, and claim it first.
- **Offer + incentive to act.** Use coupons, samples, guarantees and specific offers to drive and measure action. [11] — **Apply:** always give a reason to act now; make response measurable.

---

## Joe Sugarman — *The Adweek Copywriting Handbook*

- **The Slippery Slide.** Every element of the ad has ONE job: to get the reader to read the next element. The headline sells the first sentence; the first sentence (kept short and punchy) sells the second; and so on — the reader slides down, unable to stop. [12][13] — **Apply:** the ONLY purpose of a video hook is to earn the next 3 seconds. Structure ads so each line/scene creates a reason to keep watching. Open loops, curiosity, short opening sentences.
- **Make the slide slippery.** Paint mental images with specific sensory detail (touch, taste, smell, sound, sight); open with a personal story, tie to a current trend/news, or open a curiosity loop. [12] — **Apply:** sensory-specific UGC ("you feel the cooling the second it hits") holds attention better than feature lists.
- **Sell on emotion, justify with logic.** "You sell on emotion, but you justify a purchase with logic." Also: every product has an inherent drama — find it and dramatize it. [12]
- **Psychological triggers (24, per the published list).** Selected triggers most useful for DTC creative: [13][14]
  1. **Involvement / ownership** — get them mentally using it ("imagine waking up without…").
  2. **Honesty** — admit a flaw; it makes every other claim believable. (Sugarman: the most powerful trigger.)
  3. **Integrity / Credibility** — honesty + consistency = believability.
  4. **Value & proof of value** — show it vs. alternatives / cost-per-use.
  5. **Justify the purchase** — give the logical reason for the emotional buy.
  6. **Greed** — steep, time-boxed discounts trigger impulse.
  7. **Authority** — logos, credentials, "as seen in," expert endorsement.
  8. **Satisfaction conviction** — a bold guarantee (365-day returns) signals confidence.
  9. **Curiosity** — open loops; tease what they can't get by scrolling past.
  10. **Sense of urgency / scarcity** — deadlines and limited stock force decisions.
  11. **Instant gratification** — fast shipping/access raises conversion.
  12. **Exclusivity / rarity / uniqueness** — limited availability raises perceived value.
  13. **Simplicity** — one clear offer, clear layout; confusion kills conversion.
  14. **Specificity** — concrete numbers ("30,847 sold") out-credible vague claims.
  15. **Hope** — sell the believable transformation.
  (Others in the list: proof, desire to belong, desire to collect, timing, current fads, nature of product, human relationships, guilt, familiarity, mental engagement.) [13][14]
  — **Apply:** treat these as a checklist when auditing an ad — which triggers is it firing? A strong ad usually stacks 3–5.

---

## Robert Cialdini — *Influence* + *Pre-Suasion*: the 7 principles

Universal persuasion levers. Each maps directly to an ad element. [15][16]

| Principle | Definition | Evidence | Apply to a DTC ad |
|---|---|---|---|
| **Reciprocity** | People feel obligated to repay favors/gifts. | Restaurant mints study: a mint with the check raised tips 3%; a second, "just for you" mint raised them ~21%. [16] | Lead magnet, free sample, free guide, free shipping, genuinely useful content before the ask. |
| **Commitment & Consistency** | People align with prior actions/small commitments. | Foot-in-the-door: homeowners who put up a small sign later accepted a large billboard. [16] | Micro-yes quizzes ("what's your skin type?"), free trials, low first step; small commitment → purchase. |
| **Social Proof** | People copy others when uncertain. | Hotel towel-reuse cards citing what other guests did lifted reuse; bystander effect. [16] | Review counts, UGC volume, "50,000+ customers," ratings, before/afters, "#1 best-seller." |
| **Authority** | People defer to credible experts. | Milgram obedience experiments (authority attire drives compliance). [16] | Expert/doctor/founder endorsement, credentials, clinical data, "as seen in," certifications. |
| **Liking** | People say yes to those they like / who are similar / who compliment them. | Peer-model dog-fear study; similarity & rapport increase compliance. [16] | Relatable UGC creators who mirror the ICP; founder story; shared identity/values; humor. |
| **Scarcity** | Limited/decreasing availability raises desire (loss aversion). | Scarcity works via loss aversion — fear of missing out beats promise of gain. [16] | Limited drops, "only 12 left," countdowns, "ends tonight," limited-edition bundles. |
| **Unity** | Shared identity / "we" — same in-group, not just similar. | Framing a request as helping "your child" / your group sharply raised response. [15][16] | "For [specific identity]…" targeting; community/tribe language ("join 30k [group]"); us-vs-them positioning. |

**How to apply:** Unity > Liking — Liking is "you're like me," Unity is "you're one of us." The strongest DTC angles build a tribe/identity (Schwartz stage-5 identification + Cialdini unity are the same move). Audit any ad by which principles it fires; weak ads usually fire only one.

---

## The Awareness × Sophistication grid — the master cheat-sheet

This is the most important operational tool. Two independent axes; you diagnose BOTH before choosing an angle. **Awareness = what one prospect knows about their problem/your product. Sophistication = how much the whole market has already heard this type of claim.** [1][3][5]

**Step 1 — Diagnose awareness (the prospect):**
- Cold/broad Meta audience, no problem recognition → **Unaware / Problem-Aware**
- Cold audience actively searching solutions → **Solution-Aware**
- Warm / site visitors / engagers → **Product-Aware**
- Cart abandoners / past buyers / email list → **Most-Aware**

**Step 2 — Diagnose sophistication (the market):**
- New/novel category, few competitors → **Stage 1–2**
- Crowded but claims still believed → **Stage 3** (need a mechanism)
- Saturated, skeptical (supplements, skincare, weight-loss, most mature DTC) → **Stage 4–5**

**Step 3 — Pick the hook from the intersection:**

| | **Sophistication 1–2** (fresh claim) | **Sophistication 3** (needs mechanism) | **Sophistication 4–5** (saturated / skeptical) |
|---|---|---|---|
| **Unaware** | Story / education hook that names the problem, then the plain benefit. | Story/education that reveals the *hidden cause* (mechanism as revelation). | Identity/story hook — "for the [identity] who…"; native, non-ad-feeling content. |
| **Problem-Aware** | Name the pain → state the direct benefit/promise. | Name the pain → reveal the mechanism behind it ("the real reason you can't…"). | Name the pain → prove with data/demo/testimonial; lead with credibility. |
| **Solution-Aware** | "The [category] that finally works." | Mechanism-vs-alternatives ("why X beats the pills/creams you've tried"). | Elaborated proof + comparison + demonstration; out-prove the category. |
| **Product-Aware** | Direct benefit + why us. | Our unique mechanism + guarantee. | Stack proof: reviews, before/afters, studies, risk-reversal, FAQ. |
| **Most-Aware** | Offer + CTA. | Offer + CTA + one proof point. | Offer + urgency + risk-reversal (they've heard it all — just make it easy & safe). |

**The two most common DTC failures the grid catches:**
1. **Offer ad to an unaware audience** — running "20% off!" (built for Most-Aware) to cold traffic that doesn't know it has the problem. Fix: move left to a story/problem hook.
2. **Bare claim in a saturated market** — shouting the benefit louder ("lose weight fast!") in a stage-4/5 category where nobody believes claims. Fix: move up to a **mechanism** (stage 3) or **identity/reinvention** (stage 5). This is usually why a proven winner's ROAS decays — the *market* advanced a sophistication stage.

**Angle-decay rule of thumb:** when a top creative fatigues, first ask *"has the market heard this claim too many times?"* If yes → add/deepen a mechanism, or shift to identification. If the ROAS drop is audience-side, re-diagnose awareness and change the runway length, not the claim.

---

## Sources

1. Eugene Schwartz — Awareness & Sophistication Levels (kingeshop): https://www.kingeshop.com/en/customer-awareness-sophistication-eugene-schwartz
2. Breakthrough Advertising summary (solidgrowth): https://www.solidgrowth.com/book/breakthrough-advertising
3. Eugene Schwartz's 5 Stages of Awareness (leadgen-economy): https://www.leadgen-economy.com/blog/five-stages-awareness-lead-generation/
4. 5 Levels of Market Awareness (Copyposse): https://copyposse.com/blog/5-levels-of-market-awareness-how-to-speak-to-your-target-audience-part-1/
5. Five Levels of Market Sophistication (kingeshop): https://www.kingeshop.com/en/customer-awareness-sophistication-eugene-schwartz
6. "The customer is not a moron" (Grokipedia): https://grokipedia.com/page/The_customer_is_not_a_moron
7. David Ogilvy quotes on copywriting (Goodreads / Carmine Mastropierro): https://carminemastropierro.com/david-ogilvy-quotes/
8. 9 Copywriting Lessons from David Ogilvy (Reads to Leads): https://www.readstoleads.com/blog-article/what-copywriters-can-learn-from-david-ogilvy
9. Gary Halbert — "Direct Marketing to a Starving Crowd" (original newsletter): https://www.thegaryhalbertletter.com/newsletters/direct_marketing_to_a_starving_crowd.htm
10. Gary Halbert / The Boron Letters — AIDA & emotional selling (dropdeadcopy): https://www.dropdeadcopy.com/the-boron-letters/
11. Claude Hopkins — *Scientific Advertising* (full text PDF, Castlewood): https://castlewoodstudios.com/downloads/scientific_advertising.pdf
12. The Adweek Copywriting Handbook — slippery slide (jeremymac): https://www.jeremymac.com/blogs/news/5-timeless-copywriting-secrets-from-the-adweek-copywriting-handbook-that-will-transform-your-copywriting-skills
13. Joe Sugarman Triggers (Copywriting Course): https://copywritingcourse.com/joe-sugarman-triggers/
14. Joe Sugarman's psychological triggers list (SwipeFile): https://swipefile.com/joe-sugarman-triggers/
15. Cialdini's 7 Principles — Unity (W. P. Carey / ASU): https://news.wpcarey.asu.edu/20250422-gentle-science-persuasion-part-seven-unity
16. Cialdini's 7 Principles of Persuasion — definitions & evidence (Cognitigence): https://www.cognitigence.com/blog/cialdini-7-principles-of-persuasion
