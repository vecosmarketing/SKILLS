# Experts: Modern DTC Creative Strategy — Cited Frameworks

A distilled, cited knowledge base of the leading modern DTC performance-creative strategists and their *specific, named* frameworks. Use this as the mental-model library for the MLO Winner Strategist skill. Every claim below is followed by its source URL. Where a person's material was thin or not directly retrievable, it is flagged honestly.

Scope note: this focuses on Meta + TikTok performance creative (hooks, testing, angles, native vs. polished, awareness stages). It is opinionated on purpose — these are the operators the field actually cites.

---

## Dara Denney

**Who she is:** Performance-creative consultant, partner at Point Guard Media, and Motion's Chief Evangelist. Has managed 100M+ USD in ad spend and is best known for teaching creative *analysis* as content analysis rather than metrics analysis. Author of the widely-used "Performance Creative Master Course." (https://motionapp.com/library/expert/dara-denney/)

### Signature frameworks / mental models

- **The 4-Step Creative Analysis Process — Metrics → Content → Comparison → Feedback.** Her core belief: "It's actually the metrics that are the least important part of this process." Content is the most important step. How to apply: when auditing a winner/loser, do not start in Ads Manager — start by describing the *content* (format, creator, messaging, imagery, persona), then use metrics only to confirm the story. (https://motionapp.com/library/expert/dara-denney/)
- **Content-Level Data — 5 dimensions: Format, Creator, Messaging, Imagery, Persona.** How to apply: tag every ad on these 5 axes so you can isolate *why* it won and reproduce it. Her line: "Your creator and the talent that you work with is more important candidly than the script." Persona/intended-audience is the integrating dimension she pushes for the Andromeda/2026 era. (https://motionapp.com/library/expert/dara-denney/)
- **Primary KPIs vs. Storytelling KPIs.** Primary KPIs (spend, results, CPA, ROAS) tell you *if* it worked; Storytelling KPIs (CPM, CTR, frequency, video plays, shares, comments) tell you *why*. How to apply: never diagnose a creative from primary KPIs alone — pair every performance read with a storytelling metric that explains the mechanism. (https://motionapp.com/blog/facebook-ad-creative-kpis)
- **Messaging Strategy Buckets — Human desires / Demographics / Strategy angles / User journey.** How to apply: classify each ad's message into one of these four so your test slate covers different *psychological* territory, not just different edits. (https://motionapp.com/library/expert/dara-denney/)

### Concrete testing rules — the 3-Phase Creative Testing Framework

- **Phase 1 — Pre-Flight Testing: "which new creative is the best?"** Rule: test new creatives only against *other new creatives* — never against a historically-optimized ad, because that comparison is unfair. How to apply: isolate new concepts in their own ad set/campaign to find the internal winner first. (https://motionapp.com/blog/ultimate-guide-creative-testing-2025)
- **Phase 2 — New vs. BAU (business-as-usual): "is your new creative better than what's already working?"** Rule: a new creative must beat or match your existing winner to earn a place. How to apply: only promote a pre-flight winner if it clears your current control. (https://motionapp.com/blog/ultimate-guide-creative-testing-2025)
- **Phase 3 — Scaling.** Rules: scale immediately on validation; inject the new winner into fatigued ad sets; keep old winners running alongside; give CBO/ASC+ campaigns time to adjust. (https://motionapp.com/blog/ultimate-guide-creative-testing-2025)
- **Match the test structure to account size.** ASC+ or CBO for smaller accounts (cost-efficiency), ABO for medium accounts (accuracy), and cost-cap testing reserved for accounts spending 500K+/month. How to apply: don't run cost-cap tests on a small account — you won't get signal. (https://motionapp.com/blog/ultimate-guide-creative-testing-2025)
- **Benchmark against yourself, not the industry.** Compare new creative to your own top ads, not universal thresholds. (https://motionapp.com/blog/facebook-ad-creative-kpis)

---

## Savannah Sanchez (The Social Savannah)

**Who she is:** Founder of The Social Savannah, a paid-social/UGC agency shipping 200+ Meta and TikTok ads per week for ~50 brands with an internal team of creators and editors. Known for high-volume authentic UGC and for publicly rejecting AI-generated ads in favor of native creator content. (https://motionapp.com/library/expert/savannah-sanchez/) (https://tydo.com/blog/deepdive-savannah)

### Signature frameworks / mental models

- **The hook is ~90% of the job.** "The hook is the most important part of the ad in that first three seconds." How to apply: put nearly all creative effort into the first 3 seconds; the body is comparatively cheap to keep constant. (https://motionapp.com/library/expert/savannah-sanchez/)
- **Native-first: "TikTok ads have to look like they belong and are made on TikTok."** What works on other platforms doesn't work on TikTok. Use native transitions, animations, fonts, voice effects, greenscreen, and the comment-question overlay. How to apply: build ads inside the platform's own visual language, not a repurposed brand film. (https://tydo.com/blog/deepdive-savannah)
- **Strict role separation — Strategist → Creator → Editor.** "Don't leave strategy to the creators/editors, and don't force your strategist to star in the ad and edit on CapCut." Strategist owns research/scripts/QC; creator shoots raw footage only; editor finishes. How to apply: don't collapse these three roles into one person or you lose quality on all three. (https://motionapp.com/library/expert/savannah-sanchez/)

### Concrete rules — hooks, testing cadence, checklist

- **Hook-swap testing: hold the body constant, swap only the opening.** "If you're just changing the text on top, Facebook doesn't really see it as a different variation." Meta requires *visual* distinctness in the first 3–5 seconds to register a new variation. How to apply: to test a new hook, change the first 3–5 seconds' *visual*, not just the on-screen text. (https://motionapp.com/library/expert/savannah-sanchez/)
- **Weekly testing structure (for 30k–100k/month budgets): 2 inspirations × 2 written hooks × 2 opening visuals.** Two overarching ad inspirations per week, each with two written hook variations, each with two opening-visual variations. How to apply: a disciplined 2×2×2 slate per week gives structured hook coverage without chaos. (https://motionapp.com/library/expert/savannah-sanchez/)
- **Keep ads under 15 seconds; always include a clear CTA.** "TikTok ads that are under 15 seconds are performing best." How to apply: default to sub-15s with an explicit spoken/on-screen CTA. (https://tydo.com/blog/deepdive-savannah)
- **Pre-delivery checklist:** hook engagement (first 3s), pacing (~3s minimum between frames), storyline (hook → story → CTA), a human desire addressed, clear visual focus, and the "Take Pride" gut-check — "Is this ad better than the inspiration?" (https://motionapp.com/library/expert/savannah-sanchez/)
- **Brief creators richly, then get out of the way.** Give creators benefits, must-say / must-not-say, and dos/don'ts — "then let the creator do their thing." (https://tydo.com/blog/deepdive-savannah)

---

## Barry Hott

**Who he is:** Longtime paid-social growth consultant, the "Make Ugly Ads" guy. Has managed 600M+ USD in social ad spend across AT&T, Toyota, Kraft, Microsoft, and DTC brands like True Classic, AG1, Lumin, and Harry's. Runs "Building Ads with Barry." (https://www.buildingadswithbarry.com/) (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)

### Signature frameworks / mental models

- **"Ugly Ads" — if your marketing is too pretty, it probably won't work on paid social.** An effective ugly ad doesn't look expensive to produce but has a strong story and hook. How to apply: intentionally strip polish (shaky camera, natural light, phone-shot, imperfect audio, delayed/minimal branding) so the ad reads as native content, not an ad. (https://www.practicalecommerce.com/ugly-ads-perform-best-marketer-says) (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)
- **The "Sniff Test" — over-polished red flags viewers reject:** heavy branding in the first frame (logo/brand fonts/colors), obviously artificial lighting, white/blank backgrounds, high video quality clearly not shot on a phone, heavily scripted dialogue. How to apply: run any creative through these five red flags before launch; each one present makes it read as "an ad." (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)
- **Problem-first, not production-first.** Focus on "getting people to pay attention to the problem" rather than production quality. He's not anti-brand — "deep down, I care a lot about brand" — but the problem/hook comes first. How to apply: lead the ad with the problem the viewer feels, before any product or brand reveal. (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)

### Concrete rules

- **Judge Second 0 first.** Look at imagery and messaging at second 0 and ask if it's genuinely enough to stop the scroll for the *right* people (increasing hook and hold rate). How to apply: if the first frame doesn't stop the target scroller, nothing downstream matters. (https://www.buildingadswithbarry.com/)
- **Match the platform's content conventions even if "off-brand"** — e.g. Impact meme font. How to apply: mimic the format users already consume in that feed. (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)
- **Six actionable tips:** start with small budgets to prove ROI; prioritize authenticity over salesiness; match content-format conventions; crowdsource UGC from employees; release imperfect work faster; balance relatability with marketing fundamentals. (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)
- **Proof point:** ugly ads have shown ~30% lift in action intent vs. polished versions, and in one case ~3x click rate and 3–5x higher conversion rate over polished content. How to apply: use this to justify shipping lo-fi tests to skeptical clients. (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads) (https://www.practicalecommerce.com/ugly-ads-perform-best-marketer-says)

---

## Nick Theriot (The Direct Response Podcast)

**Who he is:** Media buyer and founder of Theriot Solutions; host-adjacent voice in the Direct Response ecosystem, runs the Nick Theriot Inner Circle. His awareness-stage system is credited with 60M+ USD in client revenue. (https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk) (https://www.youtube.com/watch?v=IBVgPnCPXb4)

### Signature frameworks / mental models

- **The 5 Stages of Market Awareness (from Eugene Schwartz, applied to Meta ads): Unaware → Problem Aware → Solution Aware → Product Aware → Most Aware.** Build a distinct ad for each stage; each ad is self-contained. How to apply: map every concept to a stage and make sure your slate covers the full ladder — most brands over-index on the "Most Aware" discount ad. His examples:
  - **Unaware (largest audience):** appeal to a mindset, no problem/solution named — e.g. "I go to work in tears everyday because I hate my job."
  - **Problem Aware:** name the pain — "I'm broke… what should I do?"
  - **Solution Aware:** connect the desired outcome without the product — "Laziest way to make money online for beginners."
  - **Product Aware:** establish superiority/trust — "The only forex trading strategy you'll ever need."
  - **Most Aware:** price/offer incentive; he calls this "the lowest level of marketing IQ" — "Forex Trading Mastery now 50% off."
  (https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk)
- **Target by the bait, not the audience — "BROAD TARGETING but target audiences by the bait (our ad) we put out."** The creative does the targeting; the audience stays broad. How to apply: stop building interest stacks — build stage-specific creative and let broad + the ad self-select the audience. (https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk)
- **The Hook Formula Matrix — an opener-engineering system (13 hook formulas) for a repeatable concept pipeline.** How to apply: instead of guessing openers, run each angle through a fixed set of hook formulas to mass-produce variations. (Detail is gated inside his Inner Circle; the *existence and shape* of the matrix is public, the 13 formulas themselves are not fully published.) (https://udcourse.com/product/nick-theriot-inner-circle-april-2026/) (https://x.com/nicktheriot_/status/1922683951249752444)

### Concrete rules

- **Every ad brief isolates 7 variables: Desire, Feature, Benefit, Market Awareness, Market Sophistication, Hook Pattern, Persona.** How to apply: fill all 7 fields per brief so you can attribute wins/losses to a single changed variable. (https://udcourse.com/product/nick-theriot-inner-circle-april-2026/)
- **Unaware ads run longer and can walk the full ladder in one ad** ("start with unaware and go through all the stages in that one ad"); higher-awareness ads warrant more spend. How to apply: give unaware/cold creative room (longer runtime, more education); concentrate budget on higher-stage winners. (https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk)
- **System over random testing:** "The fastest way to scale to 1M/month isn't random testing, it's a repeatable, research-driven creative system" — and most brands skip the research step. (https://x.com/nicktheriot_/status/1922683951249752444)

---

## Motion / Alex Cooper (creative analytics + trends)

**Who they are:** Motion is the creative-analytics platform used by DTC teams; its data covers 14B+ USD in annual media spend. Alex Cooper runs AdCrate, working with 8–9 figure DTC brands (Huel, The Perfect Jean, Caraway, Harry's), 3,000+ ads shipped, and is a frequent Motion collaborator on live ad-building and AI workflows. (https://motionapp.com/) (https://motionapp.com/blog/ai-ad-creative-alex-cooper)

### Signature frameworks / mental models

- **The 7 Steps of Creative Strategy — Research → Ideation → Briefing → Content Creation → Evaluation → Launch → Creative Analysis (cyclical).** How to apply: run creative as a closed loop where analysis feeds the next research cycle, not as one-off asset production. (https://motionapp.com/blog/creative-strategy)
- **The vocabulary — Angle vs. Concept vs. Hook vs. Format.** Hook = the initial attention-grabber (first seconds); Angle = the perspective/argument that sustains interest toward conversion; Concept = the bigger idea combining hook + angle; Format = the delivery structure (video/static/carousel). How to apply: when you say "let's test a new ad," specify which layer you're changing — testing a new *hook* on the same angle is a different experiment than testing a new *angle*. (https://motionapp.com/blog/creative-strategy)
- **Angle > execution:** the perspective/argument matters more than the polish. This underpins Motion's whole analysis stack. How to apply: exhaust angles before you re-shoot; a fresh angle beats a prettier version of a tired one. (https://motionapp.com/blog/creative-strategy)

### Concrete data rules — 2025 Creative Trends (100M+ in spend, 500+ advertisers surveyed)

- **Humor: 25% of 1M+ spend ads used humor** (vs. only 14% of social ads overall). How to apply: budget for at least one humor concept in every serious test slate. (https://motionapp.com/creative-trends)
- **Lo-fi wins: 42% of top-spending ads were lo-fi (minimal editing); 53% of advertisers plan to invest more in lo-fi vs. hi-fi.** How to apply: default new tests to lo-fi/native; reserve hi-fi for validated winners. (https://motionapp.com/creative-trends)
- **Long-form education: top ads now introduce the product at 40–50 seconds** rather than early — education-first. How to apply: for considered purchases, delay the product reveal and lead with value/education. (https://motionapp.com/creative-trends)
- **Volume: top DTC brands ship 50–70 new ads per week.** How to apply: your throughput ceiling, not your idea quality, is usually the constraint. (https://motionapp.com/creative-trends)
- **AI: 86% plan to increase AI use for research/ideation, 79% for production — but 55% remain unconvinced of the promise.** How to apply: use AI to accelerate research/ideation/variation, keep a human on strategy and QC. (https://motionapp.com/creative-trends) (https://motionapp.com/blog/ai-ad-creative-alex-cooper)

---

## Taylor Lagace / Kynship (creator-led) — brief

**Who he is:** Co-CEO/co-founder of Kynship, an influencer agency that pioneered seeding + whitelisting as a paid-creative engine for DTC. (https://www.kynship.co/blog/whitelisting-an-influencer-strategy-you-cant-ignore)

- **Seeding ≠ gifting.** "Influencer gifting is a one-time, transactional experience. Influencer seeding is a long-term, relationship-building exercise" — seeded product goes out with no strings attached (no required post). How to apply: send product for genuine adoption, not in exchange for a guaranteed post. (https://www.kynship.co/blog/best-practice-guide-to-product-seeding-how-to-launch-your-own-influencer-seeding-campaign)
- **The seeding funnel math:** seed ~500 influencers/month → expect ~20% opt-in (100) → ~30% organic post rate (~30 posting 2–3 assets) → 60–90 earned posts at cost-of-goods. How to apply: treat seeding as a content-acquisition engine priced at COGS, not a PR gift. (https://www.kynship.co/blog/best-practice-guide-to-product-seeding-how-to-launch-your-own-influencer-seeding-campaign)
- **Whitelisting = run creators' organic content as ads from the creator's handle**, tested via Dynamic Creative (DCT) so the algorithm — not the brand — picks winners; then contractualize top performers into affiliate/ambassador deals at ~half market rates. How to apply: license IGC, DCT-test all of it, and only pay premium for proven winners. (https://www.kynship.co/blog/whitelisting-an-influencer-strategy-you-cant-ignore) (https://www.kynship.co/blog/best-practice-guide-to-product-seeding-how-to-launch-your-own-influencer-seeding-campaign)

---

## Benchmark reference (industry, for calibration)

These are general Meta/TikTok video benchmarks the field uses to grade creative. They are calibration defaults — every expert above says to benchmark against *your own account's trailing average* first. (https://motionapp.com/blog/facebook-ad-creative-kpis)

- **Hook rate (a.k.a. thumbstop / 3-second view rate) = 3-second video plays ÷ impressions × 100.** Below 20% = weak; 25–35% = good/scalable; 30%+ = strong; 40%+ = elite scroll-stopper. (https://www.exposure.com.au/blog/what-is-a-good-hook-rate)
- **Hold rate** tracks 3–15s retention (does the story stay interesting); target ~25%+ alongside a 30–40% hook rate. The cheapest fix for a weak hook is to swap the opening (keep the winning body, test 5–15 new openers) — the same hook-swap lever Sanchez teaches. (https://billo.app/blog/hook-rate-to-hold-rate/)

---

## Synthesis: the shared playbook

Where these operators converge — the through-lines to encode into the Winner Strategist skill:

1. **Win or lose in the first 3 seconds.** Hook is the single highest-leverage variable. Sanchez puts ~90% of effort there; Hott judges "Second 0" first; Motion/Denney define the hook as the layer to test first; industry hook-rate benchmarks (25–35% good, 40%+ elite) exist precisely because this window decides everything. (https://motionapp.com/library/expert/savannah-sanchez/) (https://www.buildingadswithbarry.com/) (https://www.exposure.com.au/blog/what-is-a-good-hook-rate)
2. **Test at the concept/hook level, isolating one variable.** Denney's pre-flight (new vs. new), Sanchez's hold-body-swap-hook, and Theriot's 7-variable brief all say the same thing: change one thing so you learn something. (https://motionapp.com/blog/ultimate-guide-creative-testing-2025) (https://motionapp.com/library/expert/savannah-sanchez/) (https://udcourse.com/product/nick-theriot-inner-circle-april-2026/)
3. **Angle > execution.** The argument/perspective beats polish. Motion codifies Angle vs. Concept vs. Hook vs. Format; Denney ranks Content above Metrics; Theriot builds around awareness stage and desire. Exhaust angles before re-shooting. (https://motionapp.com/blog/creative-strategy) (https://motionapp.com/library/expert/dara-denney/)
4. **Native/lo-fi > polished.** Hott's "ugly ads," Sanchez's "must look made on the platform," and Motion's data (42% of top-spend ads lo-fi; 53% investing more in lo-fi) all point the same way: polish signals "ad" and gets skipped. (https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads) (https://tydo.com/blog/deepdive-savannah) (https://motionapp.com/creative-trends)
5. **Map creative to awareness stages / personas.** Theriot's 5 Stages and Denney's Persona dimension both insist the *same product* needs different creative for unaware vs. most-aware buyers — and most brands over-index on bottom-funnel discount ads. (https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk) (https://motionapp.com/library/expert/dara-denney/)
6. **The creator/talent matters more than the script.** Denney says it outright; Sanchez separates strategist/creator/editor roles; Kynship builds an entire earned-content engine on this. Casting is a strategic decision, not a logistics one. (https://motionapp.com/library/expert/dara-denney/) (https://motionapp.com/library/expert/savannah-sanchez/)
7. **Content analysis > metrics analysis; benchmark against yourself.** Metrics confirm the story but don't tell it. Read the content first, then use storytelling KPIs to explain the primary KPIs — and compare to your own top ads, not universal numbers. (https://motionapp.com/library/expert/dara-denney/) (https://motionapp.com/blog/facebook-ad-creative-kpis)
8. **Volume + a repeatable system beats random genius.** Top brands ship 50–70 ads/week; Theriot: scaling "isn't random testing, it's a repeatable, research-driven creative system." Throughput and process are the real constraints. (https://motionapp.com/creative-trends) (https://x.com/nicktheriot_/status/1922683951249752444)

---

## Sources

- Dara Denney — Motion Library expert page: https://motionapp.com/library/expert/dara-denney/
- Motion — Ultimate guide to Facebook ad creative testing (2025), Denney's 3-phase framework: https://motionapp.com/blog/ultimate-guide-creative-testing-2025
- Motion — Facebook Ad Creative KPIs (Primary vs. Storytelling KPIs): https://motionapp.com/blog/facebook-ad-creative-kpis
- Savannah Sanchez — Motion Library expert page: https://motionapp.com/library/expert/savannah-sanchez/
- Tydo — How to Create Quality TikTok Ads with Savannah Sanchez: https://tydo.com/blog/deepdive-savannah
- The Social Savannah — site: https://thesocialsavannah.com/
- Barry Hott — Building Ads with Barry: https://www.buildingadswithbarry.com/
- Barry Hott — "Ugly ads don't mean bad ads": https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads
- Practical Ecommerce — "Ugly Ads Perform Best, Marketer Says" (Barry Hott): https://www.practicalecommerce.com/ugly-ads-perform-best-marketer-says
- Nick Theriot — 5 Stages of Market Awareness (LinkedIn): https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk
- Nick Theriot — "The BIGGEST Facebook Ads Myth in 2025," The Direct Response Podcast (YouTube): https://www.youtube.com/watch?v=IBVgPnCPXb4
- Nick Theriot — research-driven creative system (X): https://x.com/nicktheriot_/status/1922683951249752444
- Nick Theriot Inner Circle (Hook Formula Matrix, 7-variable brief): https://udcourse.com/product/nick-theriot-inner-circle-april-2026/
- Motion — What is Creative Strategy? 7 Steps (Angle/Concept/Hook/Format): https://motionapp.com/blog/creative-strategy
- Motion — 2025 Ad Creative & Creative Strategy Trends: https://motionapp.com/creative-trends
- Motion — AI tools for more winning ads ft. Alex Cooper: https://motionapp.com/blog/ai-ad-creative-alex-cooper
- Motion — platform / creative analytics: https://motionapp.com/
- Kynship — Whitelisting: an influencer strategy you can't ignore (Taylor Lagace): https://www.kynship.co/blog/whitelisting-an-influencer-strategy-you-cant-ignore
- Kynship — Best-practice guide to product seeding (seeding vs. gifting, funnel math): https://www.kynship.co/blog/best-practice-guide-to-product-seeding-how-to-launch-your-own-influencer-seeding-campaign
- Exposure — What is a good hook rate (benchmark tiers + formula): https://www.exposure.com.au/blog/what-is-a-good-hook-rate
- Billo — From Hook Rate to Hold Rate: https://billo.app/blog/hook-rate-to-hold-rate/

---

### Retrievability notes (honesty)

- **Nick Theriot's Hook Formula Matrix:** the *existence and structure* (13 hook formulas, opener-engineering, 7-variable brief) are documented publicly, but the full list of the 13 formulas is gated inside his paid Inner Circle and was not directly retrievable. Treat the matrix as a known mental model, not a fully-published list.
- **Savannah Sanchez's "3 things top TikTok ads have in common"** (first-frame face/selfie, cliffhanger-not-product, native elements) surfaced in search summaries and aligns with her published native-first rules, but her own primary page (social-savannah.com) did not resolve; the substantiated rules above come from her Motion Library page and the Tydo interview.
- **Exact hook/hold benchmark numbers** attributed to individuals were sparse in primary sources; the numeric tiers in the Benchmark section are industry-standard calibration figures, not a specific quote from any one expert. Every expert here says to benchmark against your own account first.
