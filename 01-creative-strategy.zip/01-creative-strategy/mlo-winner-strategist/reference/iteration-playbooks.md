# Iteration Playbooks — Format-to-Format & AI-Video Production

> Cited knowledge base for the `mlo-winner-strategist` skill. Purpose: take a **proven WINNING ad** and iterate it into new formats, vehicles, and awareness levels for DTC ecommerce — without killing what already works. Every claim is sourced inline; full list under **## Sources**.

**Core doctrine that runs through everything below:** a winner is a *signal, not an endpoint*. You are scaling a **concept/pattern**, not a single asset — clone the winner into 10+ variants and scale the whole set ([Metalla](https://metalla.digital/creative-iteration-to-scale-winning-ads/); [Motion](https://motionapp.com/blog/creative-iterations-for-winning-ads)). At the same budget, brands that ship more creative get roughly **2× the winners** — top large accounts ship ~31 ads/week and produce ~5.99 winners/month vs ~1.75 for the average account on identical spend ([Sepia](https://sepia-lab.com/en/blog/ad-creative-volume-benchmarks); [Purposeful Profits](https://www.purposefulprofits.co/blog/creative-testing-velocity-dtc-brands)).

---

## The "Iterate vs New Concept" Decision

Decide this FIRST, before touching any tool. It sets everything downstream.

**Definitions** ([Motion](https://motionapp.com/blog/creative-iterations-for-winning-ads)):
- **Iteration** = slight tweaks to an *existing* winning asset (hook, thumbnail, offer framing, CTA, format).
- **Net-new concept** = an entirely different creative idea (e.g. a "Gordon Ramsay" character ad vs a straight product promo).

### Playbook — the decision

1. **Confirm you actually have a winner worth iterating.** A winner is a validated *pattern*, not luck. Validate on early signals: 3-second hold rate, thumb-stop rate, then CTR→CVR alignment ([Billo](https://billo.app/blog/ad-hooks-variations/)). If it only "won" for a day on tiny spend, treat it as a hypothesis, not a winner.
2. **Diagnose WHERE the ad is strong vs weak** using Motion's three funnel analyses — this tells you *what* to iterate ([Motion](https://motionapp.com/blog/creative-iterations-for-winning-ads)):
   - **Thumbstop vs CTR:** low thumbstop + high CTR → test a new thumbnail/hook. High thumbstop + low CTR → rewrite the offer; extend the problem before the solution.
   - **CTR vs video play rate:** high plays + low CTR → add scarcity, urgency, social proof, credibility.
   - **CTR vs CVR:** high CTR + low CVR → build a cohesive custom landing page matching the ad. Low CTR + high CVR → test demographic-specific tone/language by age/gender.
3. **Pick the iteration lever with the least risk to what works.** Ways to iterate WITHOUT killing the winner (change ONE variable at a time):
   - **Change the hook only** — keep body, proof, CTA. Highest-leverage, lowest-risk ([Metalla](https://metalla.digital/creative-iteration-to-scale-winning-ads/)).
   - **Change the format** — same script/angle → static, carousel, UGC video, VSL (see format sections below).
   - **Change the awareness level** — re-target the same offer at Problem-Aware or Solution-Aware instead of Most-Aware (see VSL section).
   - **Change the ICP/persona** — a single product usually solves 3–5 distinct problems for different segments; isolate one per variation ([Motion creative strategy](https://motionapp.com/blog/creative-strategy)).
   - **Change the proof** — swap testimonial, demo, data point, or objection handled ([Elevarus](https://elevarus.com/high-intent-creative-strategy-hooks-angles-proof/)).
   - **Change the creator / re-cut the first 3 seconds / change the CTA** ([Metalla](https://metalla.digital/creative-iteration-to-scale-winning-ads/)).
4. **Apply the volume split.** Two credible schools — pick per account maturity:
   - **90/10 rule (Barry Hott):** 90% net-new concepts, 10% iteration, to escape "iteration paralysis."
   - **Motion's stance:** most brands need *multiple* iterations of a concept to land a winner ([Motion](https://motionapp.com/blog/creative-iterations-for-winning-ads)).
   - MLO practical read: once you HAVE a winner, mine it hard (this skill's job); keep a parallel net-new pipeline so you're not one fatigue cycle from zero.
5. **Refresh cadence.** Refresh winning ideas *before* performance drops sharply. Rotate hooks every **7–10 days** or when early metrics decline (rising CPM, falling CTR); new hooks weekly, new angles monthly, new proof as results accumulate ([Billo](https://billo.app/blog/ad-hooks-variations/); [Elevarus](https://elevarus.com/high-intent-creative-strategy-hooks-angles-proof/)).

**When to go NET-NEW instead:** when all three funnel analyses are healthy AND you've exhausted the cheap iteration levers, or the concept has fatigued across multiple refreshes. A proven angle with 10 hook variants will out-carry 10 unrelated new angles — so iterate the winner *until* diminishing returns, then diversify ([Metalla](https://metalla.digital/creative-iteration-to-scale-winning-ads/)).

---

## Angle → N Variations Frameworks (hook / ICP / objection / format)

The engine that turns 1 winner into 20 assets. **First principle:** separate the *angle* from the *hook*. The **angle** is the strategic idea + emotional tension (the *what/why*); the **hook** is one of many ways to open with that angle in the first 1–3 seconds (the *how*). Separating them lets you produce dozens of variations without changing the underlying story ([Billo](https://billo.app/blog/ad-hooks-variations/); [MHI](https://mhigrowthengine.com/blog/best-dtc-ad-hooks-2026/)).

### Playbook A — 1 angle → 20 hooks ([Billo six-step](https://billo.app/blog/ad-hooks-variations/))

1. Identify the **psychological promise** behind the winner (e.g. "better for less," "effortless upgrade").
2. Validate the promise on early metrics (3-sec hold, thumb-stop).
3. Deconstruct into components: **claim, tension, proof, resolution.**
4. Pair with **visual proof** (UGC-style assets build trust).
5. Convert into multiple **hook types** across structural formats.
6. Run a **hook system**: keep the angle constant, diversify the expression.

**The 20-hook menu** (categories to fill) ([Billo](https://billo.app/blog/ad-hooks-variations/)):
- **Short punchy statements** (×5): claim compression ("X costs $200… Y costs $32"), better-results, price-value contradiction.
- **Question hooks** (×3): raise unresolved tension, challenge an assumption, curiosity.
- **POV formats** (×2): personal narrative, relatable journey.
- **Testimonials** (×2): social proof, authority.
- **Visual pattern interrupts** (×5): texture macro, split screen, price overlay, unboxing, ingredient comparison.
- **CTA-led** (×3): behavioral reframe ("Stop overpaying," "Upgrade your routine"), intent-level adaptation.

### Playbook B — the 3×3 matrix (9 concepts from one brief)

Cross **3 hooks × 3 formats**. Hooks = bold claim / relatable problem / social proof. Formats = UGC video / static carousel / founder talking-head. That's 9 distinct concepts from a single brief ([Motion](https://motionapp.com/blog/creative-strategy); see also Pilothouse's 3-3-3 testing structure — [Pilothouse](https://www.pilothouse.co/post/meta-creative-testing-framework-the-3-3-3-approach-to-finding-winners)).

### Playbook C — vary by ICP / objection / proof
- **ICP:** isolate the 3–5 distinct problems the product solves; one variation per segment rather than cramming all into one ad ([Motion](https://motionapp.com/blog/creative-strategy)).
- **Objection:** build objection-specific proof for every objection (price, shipping, quality, guarantee), assemble into modular ads/landing sections — ideal for retargeting ([Elevarus](https://elevarus.com/high-intent-creative-strategy-hooks-angles-proof/); [Motion](https://motionapp.com/blog/creative-strategy)).
- Note the distinction: **changing persona/objection/emotional driver = variation** (a new asset); **changing a headline = iteration** (a tweak) ([Motion](https://motionapp.com/blog/creative-strategy)).

**PROMPT TEMPLATE — variation generator (paste into an LLM):**
```
You are a DTC creative strategist. Here is a WINNING ad:
[paste hook + script + offer + the ONE proof point + the metric that won]

The winning ANGLE (strategic promise) is: [e.g. "salon-quality color at 1/6 the price"]

Generate a variation matrix that keeps this angle CONSTANT:
1) 20 HOOKS spread across: 5 punchy statements, 3 questions, 2 POV,
   2 testimonial, 5 visual pattern-interrupts, 3 CTA-led.
2) 3 ICP re-cuts — same offer aimed at 3 different personas/pain points.
3) 3 OBJECTION re-cuts — each opens by handling one objection (price,
   quality, "will it work for me").
Keep the body, proof, and CTA structure of the winner intact unless the
variation type requires changing it. Label each with the single variable changed.
```

---

## Static → Video

Goal: add motion + sound, animate a static, and turn a static *claim* into a *demo*. Converted video ads have shown **~133% higher CTR and ~24% lower CPM** vs their static equivalents; broader reports cite 2–5× higher CTR, ~3× dwell time, and lower CPMs by repositioning spend to a video-native format ([Increditors](https://increditors.com/static-to-video-ads-conversion/); [BrandMov/Eilan context](https://eilandigital.com/newsletter/why-businesses-are-switching/)).

### Playbook — static → video ([Increditors 6-phase](https://increditors.com/static-to-video-ads-conversion/))

1. **Audit the library.** Prioritize statics with *layered* compositions (not flat single-layer) and *proven* static performance. Get source files (PSD/AI/vector), not flat exports.
2. **Pick a motion technique:**
   - **Parallax & depth** — move layers at different speeds; best for product photography.
   - **Kinetic typography** — animate copy sequentially; best for copy-driven statics, cheapest to produce at volume ([Increditors](https://increditors.com/static-to-video-ads-conversion/); [BrandMov](https://brandmov.com/blog/dtc-static-meta-ads/)).
   - **Progressive data reveal** — build infographics element-by-element; animated infographics can lift retention up to **~40%** vs static ([Increditors](https://increditors.com/static-to-video-ads-conversion/)).
   - **Cinemagraphs** — one moving element in an otherwise still frame; subtle/premium.
   - **Vector path animation** — choreograph illustration into a narrative.
3. **Format for every placement** by *extending* the composition, not re-animating: extend 4:5 vertically, 16:9 horizontally, keep the core animation identical.
4. **Sequence with AIDA timing:** 0–2s Attention (visual hook) · 2–7s Interest (problem/context) · 7–12s Desire (solution/proof) · 12–15s Action (CTA). Must work **sound-off AND sound-on** via on-screen text ([Increditors](https://increditors.com/static-to-video-ads-conversion/)).
5. **Template the 80/20:** custom ground-up production for the top ~20% of creative; After Effects templates with variable asset slots for the other ~80%.
6. **Measure video-native metrics:** hook rate (past 2s), hold rate (to midpoint), completion — then update the template's opener if hook rate underperforms.

**Turning a static CLAIM into a DEMO:** don't just pan-and-zoom a JPEG. Apply purposeful motion to assets that already hold brand equity — animate the product, show the mechanism, let a data point build on screen ([Eilan](https://eilandigital.com/newsletter/why-businesses-are-switching/); [Increditors](https://increditors.com/static-to-video-ads-conversion/)). For a claim like "absorbs in 10 seconds," the video demos the absorption; the static only asserted it.

**PROMPT TEMPLATE — static-to-video brief (paste into editor brief or AI tool):**
```
Convert this winning STATIC into a 15s vertical (9:16) video ad.
Static claim: [claim]  |  Proven because it won on: [metric]
Motion technique: [parallax / kinetic type / data reveal / cinemagraph]
Beat sheet (AIDA): 0-2s hook = animate [element]; 2-7s = show the problem;
7-12s = DEMO the claim (show the mechanism, not the text); 12-15s = CTA [CTA].
Must read fully with SOUND OFF (burned-in captions). Sound-on layer: [SFX/VO].
Keep brand colors/logo lockup from the source PSD identical.
```

---

## UGC → High-Production (and vice-versa)

Same angle, opposite production values. Choose by **audience, objective, funnel position** — not by dogma ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)).

**What the data says:**
- UGC beats polished studio creative on **cold-prospecting CPA by ~22–38%** in most DTC categories, and generates higher engagement signals up-funnel ([Stackmatix](https://www.stackmatix.com/blog/ugc-ads-strategy-for-brands); [ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)).
- Polished wins on **perceived premium positioning**; the exception where UGC *undercuts* the brand is luxury/aspirational (premium fashion, jewelry, luxury home) and high-consideration/technical products that need authority first ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)).
- Typical mix: run **both in parallel** — UGC for cold, polished for retargeting/higher-funnel awareness. Budget guides: DTC/ecom **60–80% UGC**, premium/luxury **30–40%**, B2B SaaS **40–50%** ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)).

### Playbook — UGC ⇄ high-production
1. **Keep the angle + proof fixed.** Only the production register changes.
2. **Winner is UGC, going high-production (for retargeting/premium):** shoot the same script studio-lit; replace phone-selfie framing with clean product hero shots; keep the raw testimonial *words* but upgrade the visuals. Use polished when the brand promise is "premium" ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)).
3. **Winner is polished, going UGC (for cold prospecting):** re-shoot handheld, single talking creator, natural light, iPhone aesthetic; lead with a relatable problem, not the logo. UGC excels for lifestyle, beauty, fashion, emotional-resonance products ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/); [GoMarble](https://www.gomarble.ai/library/guides/ugc-ad-examples/)).
4. **Scale the register without reshooting** via AI avatars/VO (next section) — deploy many persona variations by mixing faces/voices/tones and A/B test ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).

---

## Short Ad → Long-Form VSL (2–2.5 min, through awareness stages)

A short ad usually targets **Most-Aware** (ready to buy). A VSL unlocks the *much larger* **Problem-Aware / Solution-Aware** pools by walking them from "here's the real root cause" to "here's why this specific product is the only fix" ([AdLibrary](https://adlibrary.com/guides/vsl-ads-ecommerce-guide); [Adcrafty](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026)).

**Length reality check:** modern best practice is **60–120s top-of-funnel** and 2–5 min for high-intent landing pages — long VSLs underperform on paid social. The 2026 winners run **30–90s VSL-style ads (micro-VSLs)** that *feel* like UGC (shot-on-phone, native) but are *structured* like a sales letter, driving 3–5× ROAS on TikTok/Meta/Shorts. Every second advances the buy decision ([Adcrafty](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026)). A 2–2.5 min MLO VSL sits at the upper end of the ad range / entry of the landing range.

### Playbook — short ad → 2–2.5 min VSL

Map the winning short ad's hook to Phase 1, then build out. **4-phase structure** ([AdLibrary](https://adlibrary.com/guides/vsl-ads-ecommerce-guide)), scaled to ~2:15:

1. **Hook (0:00–0:12):** call out the *specific* audience + a bold claim (pattern interrupt that stops the scroll). Reuse the proven short-ad hook here.
2. **Lead (0:12–0:40):** acknowledge current pain; *widen the gap* between their reality and desired outcome to build tension and promise a revelation.
3. **Body + Mechanism (0:40–1:45):** this is the heart. Introduce the **Problem Mechanism** (real root cause — "why everything else fails") and the **Solution Mechanism** (the antidote), then position the product as the *delivery mechanism*, backed by a **proof stack** (testimonials, data, demo). The "mechanism click" — the moment the buyer *gets it* — is the core persuasion event ([AdLibrary](https://adlibrary.com/guides/vsl-ads-ecommerce-guide); [Adcrafty](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026)).
4. **Close (1:45–2:15):** offer stack + value/bonuses, remove risk (guarantee), apply urgency, single CTA.

(The longer 7-stage variant — Hook · Problem Agitation · Credibility Bridge · Mechanism · Proof Stack · Offer Stack · Close — is the same skeleton with the middle expanded; use for landing-page VSLs, not feed ads ([Adcrafty](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026)).)

**Awareness pass-through rule:** open Problem-Aware (name the pain), transit through Solution-Aware (name the mechanism/category), land Most-Aware (name *your* product + offer). The mechanism is what separates a VSL from a generic product pitch ([AdLibrary](https://adlibrary.com/guides/vsl-ads-ecommerce-guide)).

**PROMPT TEMPLATE — short ad → VSL script:**
```
Turn this winning SHORT AD into a 2:15 VSL script that passes through
awareness stages. Winning short ad hook: [hook]. Product: [product].
Root-cause the customer misunderstands: [problem mechanism].
Our unique reason-why it works: [solution mechanism].
Proof available: [testimonial / data / demo].
Offer: [offer + guarantee + urgency].

Write it in 4 phases with timestamps:
Hook 0:00-0:12 (reuse the winning hook, call out [ICP] + bold claim)
Lead 0:12-0:40 (agitate pain, widen the gap)
Body+Mechanism 0:40-1:45 (problem mechanism -> why past fixes fail ->
   solution mechanism -> product as delivery -> proof stack)
Close 1:45-2:15 (offer stack, guarantee, urgency, ONE CTA)
Tone: native/UGC, shot-on-phone feel, every line earns the next second.
```

---

## Concept → AI Video (tool selection + prompting)

### Which tool for what (2025–2026)

| Tool | Best for | Notes |
|---|---|---|
| **Google Veo 3 / 3.1** | Cinematic look + **native audio/dialogue** in one gen; controllable camera & lighting | Strongest prompt-to-cinematography control ([DeepMind](https://deepmind.google/models/veo/prompt-guide/); [Google Cloud](https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-veo-3-1)) |
| **Runway Gen-4 / 4.5** | **Marketers' pick** — reference-image control, brand-friendly **character consistency**, motion brush, fast Turbo gens, built-in editor | Pro benchmark for image-to-video ([invideo](https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/); [Masonry](https://masonry.so/blog/best-ai-video-generator-2025-comparison)) |
| **Kling 3.0** | **High-volume social output**, fast motion, best value; can generate **minutes-long clips in one pass** | Common "daily driver" ([invideo](https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/)) |
| **Sora 2** | Photoreal realism + narrative coherence | **Caveat:** OpenAI announced Sora web/app discontinued **Apr 26, 2026**, API **Sep 24, 2026** — not safe for long-running projects ([Medium/Coburger](https://medium.com/@renecoburger/ai-video-in-2025-a-creators-guide-to-ray2-runway-gen-2-kling-sora-veo-and-nova-reel-d207b1323e2b)) |
| **Seedance** | Photoreal UGC-style ad clips | See MLO `seedance-20-ugc-ad-director` skill for MLO's tested workflow |
| **Midjourney / DALL-E** | **Stills** — hero frames, image-to-video start frames, thumbnails | Feed the still into Runway/Kling for I2V consistency |
| **ElevenLabs** | **Voiceover / voice clone** | Drives the avatar; record it first ([ElevenLabs](https://elevenlabs.io/blog/how-to-create-ai-characters-with-heygen-avatar-iv-and-elevenlabs-voice-changer)) |
| **HeyGen** | **AI avatars / UGC-style talking-head** at scale | Avatar IV (Aug 2025): full-body motion, micro-expressions, gestures ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)) |

Practical pattern: **Kling as daily driver, switch to Runway or Veo when a specific look or brand consistency is required** ([invideo](https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/)).

### Cinematic prompting — the 5-part formula (Veo, transfers to all)

`[Cinematography] + [Subject] + [Action] + [Context] + [Style & Ambiance]` ([fal](https://fal.ai/learn/devs/veo3-prompt-guide-master-google-video-generation); [DeepMind](https://deepmind.google/models/veo/prompt-guide/)).

Best-practice detail per component:
- **Cinematography (most powerful lever for tone):** name the shot + camera move explicitly — *dolly, tracking, crane, aerial, slow pan, POV*; composition *wide / close-up / extreme close-up / low angle / two-shot*; lens *shallow DoF / wide-angle / macro / deep focus*. **If you want the camera to move, say so — Veo defaults to static/subtle handheld otherwise** ([fal](https://fal.ai/learn/devs/veo3-prompt-guide-master-google-video-generation)).
- **Subject:** hyper-specific. "A woman in her twenties with wavy brown hair and light freckles" > "a brown-haired woman" ([DeepMind](https://deepmind.google/models/veo/prompt-guide/)).
- **Action:** what the subject does, concretely.
- **Context:** thorough scene. "A smoky jazz club at night" > "a jazz club."
- **Lighting:** precise — "golden hour backlighting," "harsh overhead fluorescents," "dappled forest light," "volumetric fog rays."
- **Style & ambiance:** aesthetic + mood (realistic / claymation / film noir / VHS).
- **Audio (Veo native):** explicitly define SFX/ambience/dialogue, in a separate line, to match sound to visuals ([DeepMind](https://deepmind.google/models/veo/prompt-guide/)).
- **Method:** start simple, then **layer detail incrementally — more detail = more control**; use Gemini/an LLM to expand a rough prompt ([DeepMind](https://deepmind.google/models/veo/prompt-guide/)).

**Character consistency across shots:** use **Runway's reference-image / Gen-4 character controls** (or a fixed Midjourney/DALL-E start frame fed into I2V) to hold the same face/product across a multi-shot ad ([invideo](https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/); [Masonry](https://masonry.so/blog/best-ai-video-generator-2025-comparison)).

**PROMPT TEMPLATE — cinematic AI-video shot (Veo/Runway/Kling):**
```
[Cinematography] Slow dolly-in, low angle, shallow depth of field, macro on the product label.
[Subject] A woman in her late 20s, wavy auburn hair, light freckles, wearing a cream linen shirt.
[Action] She uncaps the bottle and applies a single drop to the back of her hand; it absorbs instantly.
[Context] Bright minimalist bathroom, morning, soft window light from camera-left.
[Style & Ambiance] Photoreal, warm golden-hour tone, calm premium mood.
[Audio] Gentle ambient room tone; a soft satisfying "click" as the cap opens; no music.
Camera: hold the same character face and bottle label across all shots (reference image attached).
```

### AI UGC / avatar workflow (ElevenLabs + HeyGen)

1. **Voice first (ElevenLabs):** record a clean 1–3 min sample, quiet room, no noise. Tune **stability & similarity** until it reads natural — the voice drives the avatar ([ElevenLabs](https://elevenlabs.io/blog/how-to-create-ai-characters-with-heygen-avatar-iv-and-elevenlabs-voice-changer); [vidau](https://www.vidau.ai/how-to-use-elevenlabs-heygen-make-reels-workflow/)).
2. **Avatar (HeyGen):** train on **2–5 min of footage in good, even lighting** — footage quality decides avatar realism. Avatar IV adds full-body motion, micro-expressions, gestures ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).
3. **Keep it raw:** best UGC "sounds like an iPhone recording" — raw/personal beats studio-polished for cold ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).
4. **Batch to scale:** write 5–10 scripts in one sitting → generate all VOs → render all avatar clips in one HeyGen session ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).
5. **Cut + B-roll:** cut frequently, overlay B-roll — AI B-roll from Kling/Runway or in-house footage ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).
6. **Persona-multiply:** one avatar → hundreds of persona variants by mixing faces/voices/tones; A/B test scripts to the highest converter without reshoots — the fastest way to run Playbooks A–C above at volume ([HeyGen](https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15)).

---

## Sources

- Motion — Creative Iterations Guide (when/how to tweak, three funnel analyses, iteration levers): https://motionapp.com/blog/creative-iterations-for-winning-ads
- Metalla — 8 Creative Iteration Strategies to scale winning ads (clone winner into 10+ variants, hook/creator/CTA swaps, 90/10): https://metalla.digital/creative-iteration-to-scale-winning-ads/
- Sepia — Ad Creative Volume Benchmarks 2026 (ships/week, winners/month): https://sepia-lab.com/en/blog/ad-creative-volume-benchmarks
- Purposeful Profits — Creative Testing Velocity (more creative → ~2× winners): https://www.purposefulprofits.co/blog/creative-testing-velocity-dtc-brands
- Billo — Ad Hooks That Scale: 1 angle → 20 variations (six-step, 20-hook menu, angle vs hook, refresh cadence): https://billo.app/blog/ad-hooks-variations/
- Motion — What is Creative Strategy (3×3 matrix, ICP isolation, variation vs iteration): https://motionapp.com/blog/creative-strategy
- Elevarus — High-Intent Creative Strategy: Hooks, Angles, Proof (objection-specific proof): https://elevarus.com/high-intent-creative-strategy-hooks-angles-proof/
- Pilothouse — Meta 3-3-3 creative testing framework: https://www.pilothouse.co/post/meta-creative-testing-framework-the-3-3-3-approach-to-finding-winners
- MHI Growth Engine — Best DTC Ad Hooks 2026: https://mhigrowthengine.com/blog/best-dtc-ad-hooks-2026/
- Increditors — Static to Video conversion (6-phase process, motion techniques, AIDA timing, 133% CTR / −24% CPM): https://increditors.com/static-to-video-ads-conversion/
- Eilan Digital — Why Animated Ads Are Replacing Static (purposeful motion, performance lift): https://eilandigital.com/newsletter/why-businesses-are-switching/
- BrandMov — DTC Static Meta Ads (kinetic typography, static's role): https://brandmov.com/blog/dtc-static-meta-ads/
- ROASPIG — Ideal mix of UGC vs Produced Content (CPA deltas, budget splits, when each wins): https://roaspig.com/blog/ugc-vs-produced-content/
- Stackmatix — UGC Ads Strategy (UGC vs polished cold-prospecting): https://www.stackmatix.com/blog/ugc-ads-strategy-for-brands
- GoMarble — UGC Ad Examples 2026: https://www.gomarble.ai/library/guides/ugc-ad-examples/
- AdLibrary — VSL Ads for E-commerce guide (4-phase structure, awareness stages, mechanism, timing): https://adlibrary.com/guides/vsl-ads-ecommerce-guide
- Adcrafty — Short-Form VSL / micro-VSL ads (30–90s, 3–5× ROAS, 7-stage structure): https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026
- Google DeepMind — Veo 3 prompt guide (components, subject specificity, lighting, audio, incremental detail): https://deepmind.google/models/veo/prompt-guide/
- Google Cloud — Ultimate prompting guide for Veo 3.1: https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-veo-3-1
- fal — Veo 3 prompt guide (5-part formula, explicit camera movement default): https://fal.ai/learn/devs/veo3-prompt-guide-master-google-video-generation
- invideo — Kling vs Sora vs Veo vs Runway (tool selection, character consistency, daily-driver pattern): https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/
- Masonry — Best AI Video Generators 2026 comparison: https://masonry.so/blog/best-ai-video-generator-2025-comparison
- Medium / René Coburger — AI Video 2025 creators' guide (Sora discontinuation dates, model roundup): https://medium.com/@renecoburger/ai-video-in-2025-a-creators-guide-to-ray2-runway-gen-2-kling-sora-veo-and-nova-reel-d207b1323e2b
- HeyGen Community — Scale realistic UGC video ads with AI avatars (Avatar IV, batching, raw-feel, persona-multiply): https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15
- ElevenLabs — Create AI characters with HeyGen Avatar IV + ElevenLabs (voice-first, stability/similarity): https://elevenlabs.io/blog/how-to-create-ai-characters-with-heygen-avatar-iv-and-elevenlabs-voice-changer
- vidau — ElevenLabs + HeyGen + Make reels workflow: https://www.vidau.ai/how-to-use-elevenlabs-heygen-make-reels-workflow/
