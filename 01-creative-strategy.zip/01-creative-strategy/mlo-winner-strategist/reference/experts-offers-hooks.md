# Experts, Offers & Hooks — Cited Knowledge Base

Reference library for the MLO Winner Strategist skill. Every framework below is captured with its exact formula and a source URL. Use it to build offers, hooks, and 2–2.5 minute short-form VSL ads for DTC ecommerce brands.

---

## Alex Hormozi — The Value Equation ($100M Offers)

The core mental model for why anyone buys. Hormozi defines perceived value as a single equation. The goal of any offer is to push the two top variables up and the two bottom variables toward zero.

**Exact formula:**

```
              Dream Outcome  ×  Perceived Likelihood of Achievement
Value  =  ───────────────────────────────────────────────────────────
                   Time Delay  ×  Effort & Sacrifice
```

The four variables ([source](https://thepowermoves.com/100-million-offers-summary-review/), [source](https://medium.com/@anferneeck/alex-hormozis-value-equation-the-secret-behind-what-people-actually-pay-for-56f84bd5ce84)):

1. **Dream Outcome** (maximize) — the gap between the prospect's current reality and the desired result; the feelings and experiences they've envisioned. The stronger and more emotional the outcome, the higher the perceived value.
2. **Perceived Likelihood of Achievement** (maximize) — "How likely do I believe it is that I'll get the result if I buy this?" *Perceived* is the operative word: belief, not reality, drives the number.
3. **Time Delay** (minimize) — the time between purchase and receiving the promised benefit. Shorter = more valuable.
4. **Effort & Sacrifice** (minimize) — the work, discipline, and things the customer must give up to get the result. The fastest way to make an offer exponentially more valuable is to drive the denominator toward zero.

**How to apply to a DTC ad:** Every winning creative maps to one of the four levers. A skincare ad that shows a dramatic before/after sells the *Dream Outcome*; a "clinically tested, 4.9★ from 12,000 reviews" ad sells *Perceived Likelihood*; a "results in 7 days" ad kills *Time Delay*; a "one scoop, no blender, no routine change" ad kills *Effort & Sacrifice*. When a creative underperforms, diagnose which variable it's failing to move and rebuild the angle around it.
Sources: [thepowermoves.com](https://thepowermoves.com/100-million-offers-summary-review/) · [medium.com](https://medium.com/@anferneeck/alex-hormozis-value-equation-the-secret-behind-what-people-actually-pay-for-56f84bd5ce84) · [YouTube — The Value Equation](https://www.youtube.com/watch?v=wdkdO-8aLio)

---

## Alex Hormozi — The Grand Slam Offer & Value Stacking ($100M Offers)

**Grand Slam Offer, exact definition:** "An offer you present to the marketplace that cannot be compared to any other product or service available, combining an attractive promotion, an unmatchable value proposition, a premium price, and an unbeatable guarantee with a money model that allows you to get paid to get new customers." ([source](https://thepowermoves.com/100-million-offers-summary-review/))

Core principle: position the offer in a category of its own so you compete on **value, not price**. The total value stack should be **10× the price or higher** ([source](https://loxie.app/learnwithloxie/100m-offers)).

**The 7 Steps to a Grand Slam Offer** ([source](https://thepowermoves.com/100-million-offers-summary-review/)):

1. **Identify the Dream Outcome** — the end result the customer truly wants.
2. **List the Problems** — every obstacle between them and that outcome, in detail.
3. **Turn Problems into Solutions** — rewrite each problem as a "how to" statement.
4. **Create Delivery Vehicles** — decide *how* you'll solve each problem (product, bonus, content, service).
5. **Trim & Stack** — keep only the **low-cost/high-value** and **high-cost/high-value** items; cut high-cost/low-value first, then low-cost/low-value.
6. **Bundle Together** — combine the survivors into one irresistible package and name it.
7. **Enhance** — layer on guarantees, scarcity, urgency, and bonuses.

**Value stacking process** ([source](https://thepowermoves.com/100-million-offers-summary-review/), [source](https://www.theghgn.com/blog/grandslamoffer)): identify each problem → create a specific named solution for each → stack all solutions → present the *cumulative* value (often 5–10× the price) against a single price. Example structure: $4,351 of stacked value presented for a $599 price.

**Enhancers** ([source](https://thepowermoves.com/100-million-offers-summary-review/)):
- **Bonuses** — sum of bonus value should exceed the offer price; give each a catchy name.
- **Guarantees** — reverse the customer's single biggest fear into the guarantee (risk reversal).
- **Scarcity** — "lots of demand, very little supply or perceived supply"; cap availability.
- **Urgency** — time-limited windows create pressure to act now.
- **Naming** — use rhyme/alliteration. Headline formula: **Avatar + Action + Goal + Time Interval + Container Word**.

**How to apply to a DTC ad:** The offer *is* the ad's payload. Build the on-page/landing offer as a stack ("Product + free gift + guide + fast shipping + money-back guarantee = $X value, yours for $Y"), then have the creative sell the transformation and drop the risk-reversal guarantee as the CTA. On product pages, the "value stack" reads as bundled bonuses; in ads it reads as "and it comes with…" right before the close.
Sources: [thepowermoves.com](https://thepowermoves.com/100-million-offers-summary-review/) · [loxie.app](https://loxie.app/learnwithloxie/100m-offers) · [theghgn.com](https://www.theghgn.com/blog/grandslamoffer)

---

## Alex Hormozi — Hook-Retain-Reward & Lead Magnets ($100M Leads)

**The Hook–Retain–Reward content system** — every piece of content (an ad, a reel, an email) must do three jobs ([source](https://www.shortform.com/blog/100m-leads-alex-hormozi/), [source](https://blog.vidtao.com/alex-hormozi-lead-magnet-framework/)):

1. **Hook** — grab attention. Use a topic the audience already cares about and tailor the format to the platform (video for YouTube/TikTok, text for LinkedIn).
2. **Retain** — keep attention. Use unresolved questions, cliffhangers, and storytelling so they don't scroll away (this is the open-loop mechanic — see below).
3. **Reward** — satisfy the interest. Deliver on the promise the hook made; give real, usable value so the next piece of content earns trust.

**The Lead Magnet framework — 7 steps** ([source](https://blog.vidtao.com/alex-hormozi-lead-magnet-framework/)):

1. **Define the Problem** — pick one narrow, specific problem.
2. **Solve It** — give a real, actionable solution, no fluff.
3. **Decide the Format** — PDF, checklist, free trial, sample, video, software, etc.
4. **Test the Name** — make the title attention-grabbing (e.g. "5 Steps to Double Your Ad ROI in 30 Days").
5. **Make It Easy** — frictionless to access and consume.
6. **Overdeliver** — give more than expected.
7. **Include a CTA** — tell them the next step, with urgency.

A lead magnet must: (a) be valuable enough that someone *would pay for it*, (b) solve a problem that naturally connects to the core offer, and (c) be easy to consume so leads quickly experience its value. Guiding philosophy: **"give until they ask"** — flood the audience with value so they request the sale (reciprocity), rather than pushing.

**How to apply to a DTC ad:** For DTC, the lead magnet is usually a free sample, a first-order discount code, a quiz ("find your shade/formula"), or a genuinely useful guide gating an email/SMS opt-in. Structure the creative as Hook (call out the problem) → Retain (agitate + tease the fix) → Reward (offer the free thing). This is the paid-social front end that feeds the email/SMS flows.
Sources: [shortform.com](https://www.shortform.com/blog/100m-leads-alex-hormozi/) · [blog.vidtao.com](https://blog.vidtao.com/alex-hormozi-lead-magnet-framework/)

---

## Hook Rate / Thumb-Stop Rate — The Metric

**Hook Rate (a.k.a. thumb-stop rate), exact formula** ([source](https://insights.vaizle.com/hook-rate-hold-rate/), [source](https://sovran.ai/blog/hook-rate-for-meta-ads-ultimate-guide)):

```
Hook Rate = 3-second video plays ÷ Impressions   (× 100 for %)
```

**Hold Rate, exact formula** ([source](https://insights.vaizle.com/hook-rate-hold-rate/)):

```
Hold Rate = ThruPlays ÷ 3-second video plays   (× 100 for %)
```

Meta's exact metric names: **3-second video plays**, **ThruPlays** (15s or completion), **Impressions**. Hold rate measures the share of scroll-stoppers who continue to ~15 seconds.

**Benchmarks** ([source](https://insights.vaizle.com/hook-rate-hold-rate/), [source](https://sovran.ai/blog/hook-rate-for-meta-ads-ultimate-guide)):

| Metric | Table stakes | Good | Elite |
|---|---|---|---|
| Hook Rate | ~20–25% | >30% | >40% |
| Hold Rate | ~40–50% | >50% | — |

Below ~20% hook rate, Meta treats the creative as low quality and raises CPMs; a 35%+ hook rate is rewarded with cheaper distribution and broader reach. **Fix hook rate before hold rate** — nobody sees your message if they don't stop.

**How to apply to a DTC ad:** Track hook rate per creative as the first gate. If hook rate is weak, the problem is the first 3 seconds (visual/opening line), not the offer — re-test hooks. If hook rate is strong but hold rate is weak, the problem is seconds 3–15 (the retain/agitation section). This diagnostic tells you *which second of the ad to rebuild*.
Sources: [insights.vaizle.com](https://insights.vaizle.com/hook-rate-hold-rate/) · [sovran.ai](https://sovran.ai/blog/hook-rate-for-meta-ads-ultimate-guide) · [motionapp.com](https://motionapp.com/blog/key-creative-performance-metrics)

---

## Hook Archetypes (The First 3 Seconds)

The opening must be a **pattern interrupt** — the brain is wired to notice anything that breaks expected flow, so something visually or verbally unexpected forces a pause ([source](https://prealgo.com/blog/hook-archetypes-2026)). Winning hooks share three traits: they **open a gap** the viewer needs to close, they're **specific enough to feel credible**, and they **deliver on the promise** inside the video ([source](https://www.trendtrack.io/blog-post/best-performing-ad-hooks)).

Core archetypes ([source](https://prealgo.com/blog/hook-archetypes-2026), [source](https://www.gethookd.ai/learn/8-best-facebook-ad-hook-examples-for-2026/)):

- **Question** — "Did you know…?" / "What if I told you…?" Opens an information gap the brain wants closed.
- **Bold Claim** — a declarative statement that challenges conventional wisdom; creates cognitive dissonance ("This $12 serum outperforms the $120 one").
- **Negativity / Mistake Callout** — loss aversion; "Stop doing X" / "The mistake ruining your Y" beats positive "here's how to win" framing.
- **Curiosity Gap** — give just enough to make them want the rest; open a loop and don't close it immediately (the gap must be *specific*).
- **Callout** — name the audience directly ("If you're over 40 and…") so the right person self-selects.
- **Social Proof** — borrow credibility from numbers/behavior; strongest = a specific number + a specific behavioral outcome ("47,000 women switched to this").
- **Visual Break / Pattern Interrupt** — an unexpected visual, motion, or "before" state shown instantly; large animated center-screen text, not just bottom subtitles.

**Timeline:** 0–3s = hook (pattern interrupt / bold claim / visual surprise); 3–15s = value delivery (demo, benefit, proof) ([source](https://prealgo.com/blog/hook-archetypes-2026)).

**How to apply to a DTC ad:** Script 3–5 different hook archetypes for the *same* body and test them as separate creatives (hook = ~80% of performance in a VSL — see below). Show the "before" state or product-in-use in the first frame; open a specific loop in the first line. The hook is the single highest-leverage variable to iterate.
Sources: [prealgo.com](https://prealgo.com/blog/hook-archetypes-2026) · [gethookd.ai](https://www.gethookd.ai/learn/8-best-facebook-ad-hook-examples-for-2026/) · [trendtrack.io](https://www.trendtrack.io/blog-post/best-performing-ad-hooks)

---

## Curiosity, Open Loops & The Zeigarnik Effect

**Zeigarnik Effect:** people remember and fixate on unfinished tasks/information more than completed ones. Incomplete information creates **cognitive tension** — the brain actively seeks closure ([source](https://marketingagency.sg/zeigarnik-effect-marketing/)).

**Curiosity gap:** the space between what we know and what we want to know. Strategically placed **open loops** (unresolved narratives, teased answers) hold attention in ways linear content can't ([source](https://www.leadalchemists.com/marketing-psychology/ziegarnik-effect/)).

**Neurological basis:** fMRI shows the left caudate (tied to the dopamine reward pathway) fires when an information gap appears — curiosity runs on the brain's primal reward system ([source](https://marketingagency.sg/zeigarnik-effect-marketing/)).

**In copywriting:** teaser headlines and "fascinations" (a.k.a. "can't-do-it" bullets) make a claim so intriguing the reader wonders "How is that possible?" and must find out ([source](https://donnie-bryant.com/blog/tag/zeigarnik-effect/)).

**How to apply to a DTC ad:** Open a loop in the hook ("The reason your moisturizer stops working after 2 weeks isn't what you think…") and only close it after the mechanism reveal. Use fascinations in the ad body and in email subject lines. Never resolve the curiosity before the CTA — the unclosed loop is what carries the viewer through the retain phase.
Sources: [marketingagency.sg](https://marketingagency.sg/zeigarnik-effect-marketing/) · [leadalchemists.com](https://www.leadalchemists.com/marketing-psychology/ziegarnik-effect/) · [donnie-bryant.com](https://donnie-bryant.com/blog/tag/zeigarnik-effect/)

---

## The Unique Mechanism

The **unique mechanism** is the specific, named reason *why* your product works that competitors don't have — it reframes the prospect's problem so your solution feels like the *only* logical answer. A generic "our product works because it's high quality" does not differentiate; the mechanism must give the viewer a **new way of understanding their problem** ([source](https://thrivethemes.com/video-sales-letter-script/), [source](https://robpalmer.com/blog/what-is-a-vsl)).

Two layers often used together:
- **Unique Mechanism of the Problem** — the hidden root cause the prospect didn't know about ("It's not your diet, it's cortisol-driven inflammation").
- **Unique Mechanism of the Solution** — the proprietary way your product fixes that root cause ("Our triple-extraction process delivers X the others can't").

**How to apply to a DTC ad:** Give the mechanism a proprietary name (e.g. "Cold-Pressed Micellar Complex," "3-Phase Time-Release"). This is what lets a commodity product escape price comparison — it's the ad-level twin of Hormozi's "category of one." Place it right after problem agitation and right before proof.
Sources: [thrivethemes.com](https://thrivethemes.com/video-sales-letter-script/) · [robpalmer.com](https://robpalmer.com/blog/what-is-a-vsl)

---

## Short-Form VSL Structure (2–2.5 min DTC Ad)

The classic VSL persuasion flow, compressed for a short social video ([source](https://thrivethemes.com/video-sales-letter-script/), [source](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026), [source](https://adlibrary.com/guides/vsl-ads-ecommerce-guide)):

1. **Hook / Pattern Interrupt (0–5s)** — stop the scroll. If the VSL doesn't stop the scroll in the first 5–15 seconds, the conversion rate never recovers. Hooks carry **~80% of a VSL's performance** — invest disproportionately here.
2. **Problem (identify)** — name the pain the viewer feels.
3. **Agitate** — make the problem feel worse; spend real time here. "The more deeply you agitate the problem, the more powerfully the solution lands."
4. **Unique Mechanism** — reveal the hidden cause + your proprietary fix (the reframe).
5. **Proof Stack** — stack proof from multiple angles: customer results, before/after data, expert endorsements, research, media, reviews. Two or three testimonials is not enough.
6. **Offer** — present the Grand Slam Offer / value stack + risk-reversal guarantee.
7. **CTA** — clear, direct, unmissable. CTAs that describe the next step ("Start your 14-day free trial") beat generic ones ("Get started") by ~28% (VWO analysis of 3,200 landing pages).

**Budget for a ~2:15 ad:** ~0:00–0:05 hook · 0:05–0:30 problem + agitate · 0:30–1:00 mechanism · 1:00–1:40 proof · 1:40–2:05 offer/stack · 2:05–2:15 CTA.

**How to apply to a DTC ad:** This is the master skeleton for a UGC/founder-story/explainer video ad. Every second maps to a job; if the ad underperforms, use hook rate (fails 0–5s) and hold rate (fails 5–15s) to locate the broken segment, then rebuild only that segment.
Sources: [thrivethemes.com](https://thrivethemes.com/video-sales-letter-script/) · [adcrafty.ai](https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026) · [adlibrary.com](https://adlibrary.com/guides/vsl-ads-ecommerce-guide) · [robpalmer.com](https://robpalmer.com/blog/what-is-a-vsl)

---

## Story Frameworks for Ads

### StoryBrand (SB7) — Donald Miller
The customer is the **hero**, the brand is the **guide**. Seven elements ([source](https://www.innatemarketinggenius.com/storybrand-framework/), [source](https://www.shortform.com/blog/donald-miller-building-a-storybrand/)):

> A **Character** (the customer/hero) has a **Problem** and meets a **Guide** (your brand) who gives them a **Plan** and **Calls them to Action**, which helps them avoid **Failure** and ends in **Success**.

1. **Character** — position the *customer* as the hero, not the brand.
2. **Problem** — external, internal, and philosophical pain points.
3. **Guide** — the brand shows empathy + authority.
4. **Plan** — a clear, simple path (e.g. "1. Take the quiz 2. Get your kit 3. See results").
5. **Call to Action** — direct ask.
6. **Failure / Stakes** — what they lose by not acting.
7. **Success** — the transformed after-state.

**Apply to DTC:** Never make the brand the hero. The ad says "*You* want clear skin (hero), the mystery breakouts are stealing your confidence (problem), we've helped 40k people (guide), here's the 3-step plan (plan), start today (CTA), or keep guessing (stakes), and wake up confident (success)."

### Compressed Hero's Journey
The monomyth — Ordinary World → Call to Adventure → transformation → return changed — can be **compressed into 60 seconds** for short-form ([source](https://en.wikipedia.org/wiki/Hero's_journey), [source](http://www.thearetical.com/blog/the-heros-journey-in-advertising)). For DTC: Ordinary World (the struggle before) → Call to Adventure (discovers the product) → Trials (tries it, skepticism) → Transformation (the after) → Return (recommends it). This is the backbone of a founder-story or customer-testimonial ad.

### PAS — Problem, Agitate, Solution
Push people *away from a negative* ([source](https://www.crazyegg.com/blog/aida-vs-pas/), [source](https://www.saasfunnellab.com/essay/pas-copywriting-framework/)): **Problem** (name it) → **Agitate** (make it feel worse) → **Solution** (present the fix). Best when the audience is *problem-aware* — you don't need to build attention, you leverage pain they already feel. This maps directly onto steps 2–4 of the VSL flow.

### AIDA — Attention, Interest, Desire, Action
Coined by E. St. Elmo Lewis, 1898 ([source](https://www.canellacamaiora.com/writing-to-persuade-aida-and-the-copywriters-shortcuts/)): **Attention** (stand out) → **Interest** (fresh, relevant info) → **Desire** (benefits + proof) → **Action** (the ask). AIDA *pulls toward a positive outcome*; PAS *pushes away from a negative*. Best for a more **unaware** audience where desire must be built from scratch.

**Awareness-stage routing (Schwartz logic, applied):** Unaware/Problem-unaware → lead with story + AIDA (build the problem and desire). Problem-aware → PAS (agitate the known pain). Solution/Product-aware → lead with the unique mechanism + proof + Grand Slam Offer. A 2–2.5 min VSL can walk a viewer from problem-aware to purchase in one video by sequencing: hook → PAS → mechanism → proof → offer → CTA.
Sources: [innatemarketinggenius.com](https://www.innatemarketinggenius.com/storybrand-framework/) · [shortform.com](https://www.shortform.com/blog/donald-miller-building-a-storybrand/) · [en.wikipedia.org — Hero's journey](https://en.wikipedia.org/wiki/Hero's_journey) · [thearetical.com](http://www.thearetical.com/blog/the-heros-journey-in-advertising) · [crazyegg.com](https://www.crazyegg.com/blog/aida-vs-pas/) · [saasfunnellab.com](https://www.saasfunnellab.com/essay/pas-copywriting-framework/) · [canellacamaiora.com](https://www.canellacamaiora.com/writing-to-persuade-aida-and-the-copywriters-shortcuts/)

---

## Quick-Reference: The Winner Ad Stack

Putting it together for a DTC short-form VSL:

1. **Hook** (archetype + open loop, pattern interrupt) → wins hook rate.
2. **Problem + Agitate** (PAS) → wins hold rate.
3. **Unique Mechanism** (named reframe) → escapes price comparison.
4. **Proof Stack** (multi-angle) → raises Perceived Likelihood.
5. **Grand Slam Offer** (value stack 10× price + risk-reversal guarantee) → maximizes the Value Equation.
6. **CTA** (specific next step) → converts.

Diagnose failures with the metrics: weak hook rate = fix step 1; weak hold rate = fix step 2; strong watch-through but no sales = fix steps 3–5 (mechanism/proof/offer).

---

## Sources

- Alex Hormozi $100M Offers summary — thepowermoves.com — https://thepowermoves.com/100-million-offers-summary-review/
- Value Equation explainer — medium.com — https://medium.com/@anferneeck/alex-hormozis-value-equation-the-secret-behind-what-people-actually-pay-for-56f84bd5ce84
- Value Equation (video) — YouTube — https://www.youtube.com/watch?v=wdkdO-8aLio
- $100M Offers key insights (10× value stack) — loxie.app — https://loxie.app/learnwithloxie/100m-offers
- Grand Slam Offer how-to — theghgn.com — https://www.theghgn.com/blog/grandslamoffer
- $100M Leads overview (Hook-Retain-Reward) — shortform.com — https://www.shortform.com/blog/100m-leads-alex-hormozi/
- $100M lead magnet framework — blog.vidtao.com — https://blog.vidtao.com/alex-hormozi-lead-magnet-framework/
- Hook rate & hold rate formulas + benchmarks — insights.vaizle.com — https://insights.vaizle.com/hook-rate-hold-rate/
- Hook rate ultimate guide — sovran.ai — https://sovran.ai/blog/hook-rate-for-meta-ads-ultimate-guide
- Creative performance metrics — motionapp.com — https://motionapp.com/blog/key-creative-performance-metrics
- Hook archetypes — prealgo.com — https://prealgo.com/blog/hook-archetypes-2026
- Facebook ad hook examples — gethookd.ai — https://www.gethookd.ai/learn/8-best-facebook-ad-hook-examples-for-2026/
- Best-performing ad hooks — trendtrack.io — https://www.trendtrack.io/blog-post/best-performing-ad-hooks
- Zeigarnik effect / curiosity gaps — marketingagency.sg — https://marketingagency.sg/zeigarnik-effect-marketing/
- Zeigarnik effect explained — leadalchemists.com — https://www.leadalchemists.com/marketing-psychology/ziegarnik-effect/
- Open loops / fascinations — donnie-bryant.com — https://donnie-bryant.com/blog/tag/zeigarnik-effect/
- VSL scripting (hook = 80%, mechanism, proof) — thrivethemes.com — https://thrivethemes.com/video-sales-letter-script/
- What is a VSL — robpalmer.com — https://robpalmer.com/blog/what-is-a-vsl
- Short-form VSL ads — adcrafty.ai — https://adcrafty.ai/blog/short-form-vsl-ads-social-media-2026
- VSL ads for ecommerce — adlibrary.com — https://adlibrary.com/guides/vsl-ads-ecommerce-guide
- StoryBrand SB7 framework — innatemarketinggenius.com — https://www.innatemarketinggenius.com/storybrand-framework/
- Building a StoryBrand summary — shortform.com — https://www.shortform.com/blog/donald-miller-building-a-storybrand/
- Hero's journey — en.wikipedia.org — https://en.wikipedia.org/wiki/Hero's_journey
- Hero's journey in advertising — thearetical.com — http://www.thearetical.com/blog/the-heros-journey-in-advertising
- AIDA vs PAS — crazyegg.com — https://www.crazyegg.com/blog/aida-vs-pas/
- PAS framework — saasfunnellab.com — https://www.saasfunnellab.com/essay/pas-copywriting-framework/
- AIDA framework history — canellacamaiora.com — https://www.canellacamaiora.com/writing-to-persuade-aida-and-the-copywriters-shortcuts/
