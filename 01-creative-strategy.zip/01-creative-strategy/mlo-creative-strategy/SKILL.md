---
name: mlo-creative-strategy
description: "Expert creative strategy framework for Meta Ads (2026 playbook). Covers concept architecture (persona → angle → offer → format), Andromeda algorithm, hook strategy, testing frameworks, creative fatigue, portfolio management, and production systems. ALWAYS use (ES/EN) when asked about: creative strategy, ad concepts, hooks, angles, personas for ads, UGC, static, VSSL, carrusel, creative testing, ad fatigue, scaling winners, ad briefs, similarity score, pain vs desire mix, awareness stages, \"cuántos ads necesito\", \"qué testear primero\", \"por qué no escala el creativo\", \"cómo hacer el brief\", \"ángulo vs persona\", \"hook testing\", \"static vs video\", \"fatiga creativa\", \"estrategia creativa\", \"concepto creativo\", \"diversidad de creativos\", or any request related to building, briefing, or analyzing Meta ad creatives for any DTC brand managed by MLO."
---

# SKILL: Creative Strategy Expert — Meta Ads (2026 Playbook)
## MLO Growth | Based on Nathan's 2026 Creative Strategy Framework

---

## CUÁNDO USAR ESTE SKILL

Activar SIEMPRE (ES/EN) cuando Marcel o el equipo mencionen:
- Estrategia creativa / creative strategy
- Cómo conceptualizar un ad / ad concept / concepto creativo
- Hook, gancho, hook strategy, hook testing
- Ángulo / angle / messaging / argumento creativo
- Persona / ICP / buyer persona para creativos
- Formato de ad (UGC, static, VSSL, carrusel, etc.)
- Testing de creativos / framework de testeo
- Fatiga creativa / creative fatigue / ad fatigue
- Portfolio de ads / ad portfolio / gestión de creativos
- Volumen de producción / cuántos ads necesito
- Andromeda / algoritmo de Meta 2026
- Cómo escalar creativos / scaling winners
- Briefing de creativos / ad brief
- "cómo mejorar mis ads", "qué hacer con el creativo", "qué testear primero"
- Concept architecture, concepto → ángulo → oferta
- Similarity score / diversidad creativa

---

## CONTEXTO CLAVE: POR QUÉ EL CREATIVO ES EL LEVER EN 2026

El media buying ya no da ventaja competitiva en Meta. El targeting está automatizado (broad), Andromeda distribuye el creativo automáticamente, y todas las palancas técnicas históricas (duplicar adsets, bidding tricks) fueron comprimidas. **La única arbitrage opportunity real en 2026 es el creativo.**

El argumento: la mayoría de equipos son malos en creative strategy → existe una brecha enorme → quien domina esto tiene ventaja estructural de mercado.

**Los 3 errores más comunes:**
1. Confundir actividad con estrategia (lanzar volumen sin calidad ni concepto)
2. Diagnosticar mal el bottleneck (pensar que el problema es la cantidad, no el ángulo)
3. Ver el creativo como un cost center en vez de un revenue driver

---

## CÓMO FUNCIONA ANDROMEDA (Meta 2026)

**Principio central: el creativo ES el targeting.**

Pre-Andromeda: tú elegías la audiencia y cargabas los ads.
Post-Andromeda: cargas los ads y Meta decide a quién servirlos basado en el contenido del creativo (transcript, copy, palabras, contexto visual, historial de conversión).

**Implicaciones críticas:**

- Si todos tus ads son similares → Meta los agrupa (bundling) → los sirve al mismo pool de audiencia → frecuencia sube, reach baja, ROAS cae.
- Si los ads hablan a personas distintas → Meta abre audiencias distintas → frecuencia baja, reach aumenta, eficiencia sube.
- **Diversity Score / Similarity Score:** a mayor similitud entre ads, peor desempeño sistémico.
- Ads con alta frecuencia en cold (>2x) = señal de alerta: falta diversidad de concepto en cuenta.
- Meta optimiza en multiclick/view, no last-click. No apagar ads que están en KPI aunque su ROAS individual parezca bajo.

**Concepto de secuencia:**
Meta prueba combinaciones de secuencias de ads para llegar a conversión. Cada ad en la cuenta puede funcionar como "warm-up" o "closer". Apagar un ad con ROAS bajo pero que está en KPI como adset puede romper una secuencia que funciona.

---

## CONCEPT ARCHITECTURE: EL SISTEMA DE 4 CAPAS

Antes de pensar en formato, se construye el concepto en este orden:

### 1. PERSONA (prioridad más alta en testing)
No es demografía. Es un arquetipo definido por **problema + deseo + trigger de compra**.

**Regla de oro:** Personas demasiado amplias = creativos olvidables. Personas específicas = ads que resuenan y escalan.

| ❌ Malo (demasiado amplio) | ✅ Bueno (específico) |
|---|---|
| "Profesional ocupado" | "Consultora que viaja 2x/semana y necesita un guardarropa carry-on que funcione en boardrooms y bares" |
| "Papá consciente de la salud" | "Mamá que ha probado 6 suplementos porque su hijo de 2 años no come verduras" |
| "Adulto mayor activo" | "Don Luis, 62 años, gerente retirado que nota que tarda más en recordar nombres y quiere seguir siendo el mismo en conversaciones de negocios" |

**Cómo construir personas con LLM:**
1. Primero construir 20–30 personas manualmente con contexto real (reviews, encuestas, testimonios).
2. Darle esa lista completa + todo el contexto de marca al LLM.
3. Pedirle 20–30 más → filtrar a 4–5 → refinar → ampliar de nuevo.
4. El LLM solo da promedios si le das poco contexto. Basura in, basura out.

### 2. ÁNGULO (segunda prioridad en testing — debería ser la primera en la práctica)
El ángulo es el argumento específico o perspectiva que usas para resonar con la persona. **No son features del producto.** Es la historia, el argumento, el porqué.

**Componentes tácticos de un ángulo poderoso:**

| Componente | Descripción |
|---|---|
| **Problem agitation** | Hacer que el espectador sienta el dolor antes de ofrecer solución |
| **Contrarian truth** | Desafiar una creencia común → "Todo lo que te dijeron sobre X está mal" |
| **Social proof** | Evidencia externa que valida el claim |
| **Authority / expertise** | Alguien con credibilidad en el dominio (doctor, marathonista, experto) |
| **Curiosity gap** | Abrir una pregunta que no se responde de inmediato, pull hacia adelante |
| **Objection handling** | Anticipar lo que el usuario ya probó y por qué no funcionó |
| **Transformation (before/after)** | Visualmente o narrativamente. Meta no lo permite explícito pero es de lo más efectivo |

**El ángulo en una frase:**
`"Si nuestra persona es [X] con [problema Y], el ángulo es que [producto] soluciona [Y] porque [razón Z con evidencia/historia]"`

### 3. OFERTA (importante, pero con límites rápidos)
- Qué estás ofreciendo y cómo estás enmarcando el valor.
- Testing de oferta: bundles, gift with purchase, subscripción, descuento por volumen, cost-per-use framing.
- **El límite:** con 1–2 productos, el testing de oferta se agota rápido. No hay que dependeer de descuento agresivo para escalar → erosiona margen y crea dependencia.

### 4. FORMATO (última prioridad — nunca empezar por aquí)
El formato amplifica el concepto, no lo reemplaza. UGC vacío no escala. Una foto de producto linda tampoco. Lo que funciona es el concepto que vive dentro del formato.

**Formatos principales y cuándo usarlos:**

| Formato | Cuándo usarlo |
|---|---|
| **Static / imagen** | Concepto que puede comunicarse en 1 frame. Barato, rápido, subestimado. Ideal para testear ángulos. Se puede escalar a cientos de miles/día con buen copy. |
| **UGC (User Generated Content)** | Persona → ángulo → oferta primero. El talento y la naturalidad amplifican, no crean el concepto. |
| **VSSL (Video Sales Letter)** | Audiencias 50+, productos que requieren educación, stages de awareness bajos. Muy efectivo con AI. |
| **Carrusel** | Comparaciones, listados, educación por pasos |
| **DPA (Dynamic Product Ads)** | Bottom of funnel / retargeting. Bueno pero tienden a overspend y el ROAS se infla. |
| **Long-form copy static** | Audiencias mayores en Facebook feed. Requiere copywriting experto. Lleva al usuario a través de todos los stages de awareness. |
| **Avitorial / Twitter-native** | Formato orgánico que no parece ad. Muy efectivo para problem agitation amplia (ej: síntomas de deficiencias). |

**5 preguntas antes de elegir formato:**
1. ¿Cuál es el concepto? (persona → ángulo → oferta primero)
2. ¿Este concepto requiere educación? → video largo
3. ¿El value prop puede comunicarse en un solo frame? → static
4. ¿El producto necesita una demo?
5. ¿En qué stage de awareness está la persona?

---

## HOOK STRATEGY: EL 80% DEL RENDIMIENTO ESTÁ AQUÍ

El hook es el primer segundo (visual + copy + audio) del ad. Determina si el usuario sigue viendo o no.

**3 variables del hook (cambiar cualquiera puede cambiar el rendimiento):**
- Visual (qué se ve en el primer frame)
- Copy (qué dice el texto/subtítulo)
- Audio (qué se escucha, tono, ritmo)

**Cómo testear hooks:**
- Tomar un ad con buen body y rotar 10–50 hooks distintos.
- Usar Trial Reels en Instagram (orgánico) para validar hooks antes de pagarlos en ads. Datos: views comparativos + retention graph.
- Hook rate = % de personas que pasan los primeros 3 segundos. Hold rate = % que pasa los 15 segundos.
- Hook rate y hold rate NO predicen conversión directamente, pero son herramientas de diagnóstico para iterar.

**Tipos de hooks que funcionan:**
- Callout directo de persona: "Si tienes X problema..."
- Contrarian opener: "Todo lo que te dijeron sobre X está mal"
- Stat impactante: "El 40% de las personas tiene esto sin saberlo"
- Curiosity gap puro: "Aquí está lo que el top 1% sabe que no te van a decir"
- Demostración visual inmediata (show don't tell)

**Post-Andromeda:** hook testing sigue siendo altamente efectivo. Puede extender la vida de un winner al rotar hooks en el mismo body.

---

## TESTING FRAMEWORK

### Orden de prioridad para testear (de mayor a menor impacto):
1. **Ángulo** → El mensaje. Si los ads no funcionan, el problema es el argumento, no el formato.
2. **Oferta** → Cómo se enmarca el valor. Limitado en variaciones posibles.
3. **Persona** → Cambiar persona = cambiar a quien hablas. Segunda prioridad real en táctica.
4. **Formato** → Último. No es lo que funciona, sino lo que contiene.

### Estructura de cuenta para aprendizaje real:
- **Un adset = un concepto** (misma persona, mismo ángulo, misma oferta).
- Mezclar conceptos en un adset confunde a Andromeda Y borra los learnings → no sabes qué funcionó.
- El ROAS a nivel de ad individual no es confiable. El nivel de adset es el indicador correcto.

### Métricas de evaluación (en orden de fiabilidad):
1. **Amount spent** → mejor proxy de performance (Meta asigna gasto a lo que funciona)
2. **ROAS** → segunda. Mirar en ventana 7-day click.
3. **CPC** → leading indicator (si CPC está consistentemente sobre benchmark, el ad nunca será rentable)
4. **Hook rate / Hold rate** → diagnóstico de video, no de conversión
5. **Frecuencia** → alerta de fatiga. Cold ads con frecuencia >2 = problema de diversidad

### Regla: no apagar ads que están en KPI
Si el adset está en KPI, no intervenir aunque un ad tenga ROAS bajo individualmente. Meta está secuenciando creativos a propósito. Interferir rompe el learning y la secuencia.

### CBO vs ABO:
- **CBO:** mayor ROI, mayor riesgo. Pareto's principle: el 4% de ads captura el 64% del gasto → sobrexposición.
- **ABO:** menor ROI, menor riesgo. Mejor para portfolio management y control de sell-through por producto.
- Usar CBO cuando necesitas eficiencia rápida (spike). Usar ABO en estado estable para diversificar riesgo.

---

## PORTFOLIO MANAGEMENT: LA MENTALIDAD CORRECTA

**El error fatal:** construir un negocio sobre 1–3 creativos que aguantan todo el spend → cuando fatigan, el negocio colapsa y es "demasiado tarde".

**La posición correcta:** múltiples ads aguantando el spend distribuido. Si uno fatiga, los otros absorben.

**Principio:** Todo creativo tiene una capacidad máxima de gasto de por vida (lifetime spend capacity). Cada creativo va a fatigar. Sin excepciones.

**Opciones al escalar un winner:**
- Squeezing agresivo → mayor spend diario, fatiga más rápida
- Portfolio pacing → bajo spend diario, vida útil de 6+ meses
La decisión depende de: inventario disponible, cash conversion cycle, target de revenue del mes.

**Regla de volumen básica:**
Por cada $1.000 USD/mes en ad spend → 1 ad nuevo al mes.
(Ej: $30K/mes = 30 ads nuevos/mes mínimo)

---

## FATIGA CREATIVA: CAUSAS Y SEÑALES

**2 razones por las que fatigan los ads:**
1. El ad llegó a su lifetime spend capacity → naturaleza del ciclo. Solución: rotar nuevos creativos con mismo ángulo/persona.
2. La audiencia es demasiado pequeña → el spend máximo diario que puede aguantar ese segmento es bajo. Solución: ampliar persona O rotar creativos para mantener relevancia con la misma audiencia.

**Señales de fatiga:**
- Frecuencia >2 en cold
- CPC subiendo sin cambio en la cuenta
- ROAS cayendo con mismo budget
- Meta dejando de distribuir spend al ad

---

## VOLUMEN vs. CALIDAD: EL BALANCE CORRECTO

**La jerarquía real de lo que importa:**
1. Volumen (de ads con calidad mínima aceptable)
2. Calidad del concepto
3. Fuerza del hook
4. Calidad de edición
5. Talento UGC
6. Storytelling

**El umbral de calidad (7/10 rule):**
Define qué es un "buen ad" en tu contexto. Si un ad está por encima de ese umbral, nadie puede predecir cuál ganará → ponlo en cuenta. El juego es maximizar volumen sobre ese umbral, no intentar predecir el winner.

**Volumen basura ≠ ventaja.** Miles de ads malos sin concepto = actividad sin estrategia.

**El modelo financiero:**
- Revenue por ad = avg spend por ad × ROAS
- Costo de producción por ad (imágenes vs video vs UGC)
- Contribution margin por ad = (revenue × gross margin) − costo de producción
- Si el costo de producción > contribution margin → ese tipo de content no es rentable a ese volumen

---

## RETARGETING / BOTTOM OF FUNNEL

**Objetivo: manejar objeciones.**

Si el 95% no compró, ¿por qué?
- 20% → precio alto → mostrar descuento, cost-per-use angle, value anchoring
- 20% → no confían en la marca → social proof, reviews, UGC real
- 20% → dudan de la calidad → demos, before/after, producto en uso
- 20% → no están listos aún → educational content, lifestyle content, top of mind

Cada segmento de objeción = un tipo diferente de creativo de retargeting.

---

## PRODUCCIÓN: ESTRUCTURA DE EQUIPO POR NIVEL DE SPEND

| Nivel | Equipo recomendado | Ads/mes | Budget en producción |
|---|---|---|---|
| $4K–$30K/mes | Founder hace el contenido. iPhone. Todo el leverage en el script. | 3 conceptos core | 60–80% testing |
| $30K–$100K/mes | 2–3 creadores UGC, designer | 30–100 ads/mes | 25% del ad spend |
| $100K+/mes | Equipo completo: scriptwriter, editor, 4–6 creators, designer | 100+ assets/mes | 10% mínimo del ad spend |

**Allocación recomendada de producción:**
- 70–80% en iteración de conceptos existentes (hook variants, nuevos cuerpos de un ángulo ganador)
- 20–30% en conceptos net new

**Trial Reels como hack de validación:**
Subir V1 de un video como Reel orgánico (sin CTA). Datos de retención en 24h → identificar problemas de hook o bridge → corregir antes de pagar por testing en cuenta. Especialmente útil para hook variants en bulk.

---

## AWARENESS STAGES (aplicados a creativos)

| Stage | Descripción | Formato recomendado |
|---|---|---|
| Unaware | No sabe que tiene el problema | Largo, educativo, contrarian hook |
| Problem Aware | Sabe el problema, no la solución | Problem agitation → curiosity gap |
| Solution Aware | Sabe que existe una solución, no tu producto | Comparación, por qué tú |
| Product Aware | Conoce tu producto, no ha comprado | Objeciones, social proof, oferta |
| Most Aware | Listo para comprar | CTA directo, descuento, urgencia |

---

## PAIN vs. DESIRE MIX

La mayoría de cuentas están sobreinvertidas en creativos de DESIRE (campaing shoots, lifestyle, aspiracional). Los mejores assets de performance marketing viven en PAIN.

**Ratio recomendado:**
- 60–70% pain-led (problem agitation, solución de problema concreto)
- 30–40% desire-led (lifestyle, aspiracional, branding)

---

## LIBROS RECOMENDADOS (copywriting & persuasión)

1. *Breakthrough Advertising* — Eugene Schwartz
2. *Scientific Advertising* — Claude Hopkins
3. *Ogilvy on Advertising* — David Ogilvy
4. *Influence: The Psychology of Persuasion* — Robert Cialdini

---

## REFERENCIAS DE FORMATOS GANADORES (para V-UP y otras marcas DTC)

| Formato | Referencia | Por qué funciona |
|---|---|---|
| Twitter/X native static | IM8 (síntomas de deficiencias vitamínicas) | Orgánico, amplia TAM, problem agitation inmediata, autoridad del creator |
| Avitorial / Doctor review | GLP-1 hair loss ad | Authority + curiosity + funnel propio (quiz) |
| Long-form copy static | Audiencias 50+ en Facebook feed | Lleva por todos los stages de awareness sin video |
| VSSL con AI | IM8 gut supplement | Educación profunda, hooks de contrarian truth, secuencia completa de awareness |
| UGC testimonial | Objection handling + before/after sutil | Identificación con la persona + prueba social |

---

## APLICACIÓN PARA V-UP

**Posicionamiento relevante:** V-UP es un producto de **preservación del status quo** (seguir siendo yo), no de transformación. Los formatos y ángulos deben:
- Hablar del dolor de perder quién eres (Don Luis, Jorge) o del miedo de que le pase a alguien que amas (Paola)
- Del agotamiento normalizado que no debería ser normal (Diana)
- Usar autoridad del Dr. Canencio (36 años en medicina integrativa) como anchor de credibilidad
- Evitar el lenguaje de "transformarte" o "volverte mejor" → preservar, mantener, seguir siendo

**Personas activas:**
- **Don Luis** (60+): preservación de identidad cognitiva
- **Paola** (35–50): hija cuidadora, miedo por su papá
- **Diana** (35–50): fatiga mental, saturación profesional
- **Jorge** (50–65): ha normalizado la lentitud cognitiva como "así es la vejez"

**Ángulos activos:**
- Identidad cognitiva: "seguir siendo yo" → K002–K011
- Fatiga mental: "fatiga mental" → K031–K041

**Regla crítica:** el ángulo gobierna el brief, no la persona. Todos los briefs de fatiga mental deben permanecer 100% en fatiga mental sin importar la persona.

---

## MODO DE USO DE ESTE SKILL

Cuando Marcel o el equipo traigan una pregunta de estrategia creativa:

1. **Identificar la capa del problema** (¿es de persona, ángulo, oferta, o formato?)
2. **Diagnosticar el bottleneck real** (¿es volumen, diversidad de concepto, o calidad del ángulo?)
3. **Recomendar en el orden correcto** (siempre ángulo primero, formato último)
4. **Conectar con el contexto de la marca** (V-UP: preservación, no transformación; autoridad del Dr. Canencio; personas específicas)
5. **Entregar outputs listos para ejecutar** (briefs, scripts, hooks, nombres de ads según convención MLO)