---
name: mlo-unique-mechanism-builder
description: >
  MLO Growth's builder of a product's UNIQUE MECHANISM — the 3-layer logical bridge that makes a product
  believable, logical and different, and becomes the spine of advertorials, VSLs, PDPs and ads. Given a
  brand/product (+ its VoC/reviews) it answers, IN ORDER, the 4 questions every mechanism must answer
  (why everything they tried failed → the true root cause → the simple theoretical solution [not the product yet]
  → how the product implements it), and outputs the two named layers — UMP (Unique Mechanism of the Problem =
  root cause) and UMS (Unique Mechanism of the Solution = the theory + how the product enables it, no pitch) —
  then the product layer. It runs the "keep asking WHY until it's explainable in 2–3 sentences AND non-obvious
  to a beginner" drill and a logic-gap validator (does the SM hit the exact PM, or only a symptom?). ALWAYS use
  this skill (ES/EN) when the user says "mecanismo único de [producto/marca]", "UMP/UMS de [marca]",
  "por qué es diferente/creíble el producto", "cuál es la causa raíz", "ángulo de causa raíz",
  "por qué no le funcionó nada de lo que probó", "constrúyeme el mecanismo", "unique mechanism",
  "build the mechanism", "root cause angle", "why nothing else worked", "problem/solution mechanism (PM/SM)".
  Works for any MLO brand. It COMPLEMENTS advertorial-strategist, mlo-vsl-writer, framework-scriptwriter,
  angle-generator, hooks-expert and the brand-brains (which store each brand's UM) — it feeds them, it does not
  replace them. It is the still upstream artifact: build the mechanism here, then hand it to the format skill.
---
# Unique Mechanism Builder

## What it does
Turns a **brand + product (+ its VoC/reviews)** into a product's **Unique Mechanism** — the single most leveraged direct-response concept, and the one thing no other MLO skill produces standalone. The Unique Mechanism is a **3-layer logical bridge** that makes the product feel **believable, logical and different**: it explains why the buyer's problem persists, names a root cause they never knew about, offers a simple theoretical fix, and only then reveals the product as the thing that delivers that fix.

**The mechanism is the hero, not the product.** You never lead with the product. You lead with the problem's hidden cause, and you let the logic pull the reader to the only conclusion left: "so THAT's why nothing worked, and THIS is the only thing that addresses it." When the bridge is airtight, skepticism collapses and the sale becomes the obvious next step. When there's a gap, skepticism survives — and skepticism that survives means no sale.

This is the **upstream artifact**. It is not an ad, a script or a page. It is the spine you build once and then hand to the format skills (advertorial, VSL, PDP, static, hooks) so every asset tells the same believable story.

## When to use (ES + EN trigger phrases)
- **ES:** "mecanismo único de [producto/marca]", "constrúyeme el mecanismo", "UMP y UMS de [marca]", "cuál es la causa raíz de [problema]", "ángulo de causa raíz", "por qué es diferente / por qué es creíble este producto", "por qué no le funcionó nada de lo que probó", "haz que el producto tenga sentido lógico", "la teoría detrás del producto", "PM/SM de [marca]", "el porqué funciona [producto]".
- **EN:** "unique mechanism for [product/brand]", "build the mechanism", "UMP/UMS of [brand]", "root cause angle", "why nothing else worked", "why this product is different/credible", "problem mechanism / solution mechanism (PM/SM)", "the theory behind the product", "make the product make sense".
- **Do NOT use it to WRITE the asset.** Once the mechanism is built, hand it off: full advertorial → `advertorial-strategist` / `mlo-advertorial-strategist`; VSL → `mlo-vsl-writer`; video/UGC script → `framework-scriptwriter`; raw promise/angles → `angle-generator`; the first 3 seconds → `hooks-expert`; landing/listicle → `mlo-page-cooker`. This skill builds the **mechanism they all reuse**, not the final copy.

## Inputs needed
1. **Brand / product** (and, if an MLO brand, its Brand Brain — it may already store the UM; check first, don't rebuild blindly).
2. **The problem** the product solves, in the buyer's words.
3. **What the buyer already tried and why it failed** — this is the raw material for the whole bridge. Pull from **reviews / VoC / Reddit / forums / surveys**, not imagination (per `angle-generator` + Module 06 pains-mining). If missing, ask for it or mine it; do not invent a root cause.
4. **What the product actually does** (its real physical/biological/functional mechanism) — so the product layer is true, not a fabricated stat.
5. Optional: market sophistication (how many times the market heard this claim → decides how novel the UMP must sound), skepticism level, ES/EN.

## Method — the 4 questions, IN ORDER
The Unique Mechanism answers **4 questions, and the order is non-negotiable** — swap the order or skip one and performance drops. (Module 06.12 + Module 08.6.)

1. **Why did everything they tried fail?** Open by validating the buyer's frustration: list the alternatives they've already tried and burned money/hope on. This isn't the product's enemy — it's the reader's lived experience, and naming it earns trust and auto-generates frustration with the old solutions. (Do NOT attack the buyer's present; frame the failure as "not your fault — you were sold the wrong fix.")
2. **What is the true root cause of the problem?** → this becomes the **UMP**. Name the hidden mechanism *behind* the problem — the thing under the symptom they've been fighting. This is the reframe that makes the reader think "nobody ever told me that." Landing the root cause is what makes step 1's failures suddenly make sense ("of course nothing worked — they were all treating the symptom").
3. **What is the simple theoretical solution?** (NOT the product yet) → this is the first half of the **UMS**. State the fix *in principle* — the theory of what would actually have to happen to address the root cause. Still no product. The reader should be nodding "yes, THAT is what I'd need" before the product is named.
4. **How does the product implement that theory?** → the second half of the **UMS** flows into the **product layer**. Only now reveal the product as the vehicle that delivers the theoretical solution — how it enables Y, still described as mechanism, not pitch.

## The two named layers (+ the product layer)
Build and label these explicitly — they are the deliverable:

- **UMP — Unique Mechanism of the Problem** = the **root cause** behind the symptom (answer to Q2). *"Your [problem] isn't [what you think] — it's actually caused by X."*
- **UMS — Unique Mechanism of the Solution** = the **simple theory** that addresses X + **how the product enables it, with NO pitch** (answers Q3 + Q4). *"X is fixed by Y — and [product] is what delivers Y."*
- **Product layer** = the product's real, concrete mechanism that makes Y happen (the ingredient / material / design / technology). This is where you get specific and provable.

**Mother sentence** (Module 13.3, the part that prints): *"Your [problem] is caused by X (the Problem Mechanism), X is fixed by Y (the Solution Mechanism), and our product delivers Y → result Z."* **PM > SM in weight** — landing the Problem Mechanism does most of the persuasive work (it generates the frustration, the hope, and the willingness); the SM just has to be the clean answer to it.

## The WHY drill (how to FIND the root cause)
To find the UMP, **keep asking "why" until the cause is BOTH:**
- **explainable in 2–3 sentences**, AND
- **non-obvious to a beginner** (a newcomer to the category shouldn't already know it).

If it's still obvious/generic ("you're not sleeping because you're stressed"), you haven't drilled deep enough — ask why again. If it takes a paragraph to explain, it's too complex to carry an ad — simplify. The sweet spot is the "of course!" reframe: simple once you hear it, but the reader didn't know it before. That is what makes it *unique*.

## Logic-gap validator (run before shipping)
The bridge only sells if it's airtight. Check every link:
- **Does the SM hit the EXACT PM — or only a symptom?** If the Solution Mechanism addresses a symptom rather than the named root cause, the logic has a gap → the reader's skepticism survives → **no sale.** Realign the SM to the exact UMP.
- **Chain integrity:** failure of alternatives → root cause → theory → product must be a single unbroken "therefore." If a reader can ask "…but why does that follow?" at any link, the bridge leaks.
- **Order intact:** the 4 questions appear in order; the product does not appear before the theory.
- **Believable & true:** the product layer is real (no fabricated stat/ingredient); if proof is missing, flag it, don't invent it.
- **2–3-sentence test:** the whole mechanism can be told in a few plain sentences to a beginner and still land as non-obvious.
- **Beginner-skeptic test:** would someone who's tried everything say "huh, that actually explains it"? If not, the UMP isn't sharp enough.

## Output (exact shape)
```
UNIQUE MECHANISM — [Brand / Product]  ·  Problem: [in buyer's words]  ·  [ES/EN]

Q1 · Why everything failed: [the alternatives tried + why each treated a symptom, not the cause]
Q2 · Root cause (→ UMP): [the hidden mechanism behind the problem]
Q3 · Theoretical solution (→ UMS, no product): [what would actually have to happen]
Q4 · How the product implements it (→ product layer): [product as the vehicle for Y]

── LAYERS ──
UMP (Problem Mechanism): [1–2 sentences]
UMS (Solution Mechanism = theory + how product enables it, no pitch): [1–2 sentences]
Product layer (real concrete mechanism): [ingredient / material / design / tech]

Mother sentence: "Your [problem] is caused by [X], [X] is fixed by [Y], and [product] delivers [Y] → [result Z]."

WHY-drill note: [depth reached — is the cause 2–3 sentences AND non-obvious? if not, keep drilling]
Logic-gap check: [PASS/FAIL per link — does SM hit the exact PM? chain unbroken? order intact? proof real?]
Sophistication fit: [why this UMP is novel enough for the market's saturation level]
Hand-off: [which skill takes it next — advertorial / VSL / scriptwriter / hooks / page-cooker]
```

## Worked examples
**1 · Weighted blanket (sleep) — the canonical one:**
```
Q1 · Why everything failed: melatonin, sleep hygiene, apps — all treat the surface (falling asleep), not why the body stays wired.
Q2 · Root cause (UMP): chronically elevated cortisol keeps the nervous system in fight-or-flight and SUPPRESSES melatonin — so the body can't drop into deep sleep no matter what pill you take.
Q3 · Theoretical solution (UMS): calm the nervous system itself — sustained gentle pressure triggers the "held/hugged" parasympathetic response, lowering cortisol so melatonin can rise naturally.
Q4 · Product layer: the blanket's DPS (Deep Pressure Stimulation) microbeads distribute exactly that even, gentle pressure across the body.
Mother sentence: "Your broken sleep is caused by cortisol suppressing melatonin (X), that's fixed by calming the nervous system with gentle pressure (Y), and our DPS microbead blanket delivers Y → you sleep through the night."
```
**2 · Skincare / collagen (anti-aging):**
```
UMP: topical creams sit on the skin's surface; the wrinkles form because dermal collagen production collapses with age — a depth the cream never reaches.
UMS: you have to trigger the skin to REBUILD its own collagen from within, not coat it from outside — and [product]'s [peptide/actives + delivery] penetrates to the dermal layer to switch that production back on.
Product layer: [specific actives + delivery system].
(Note the reframe: "creams fail because the problem isn't on the surface — it's underneath.")
```
**3 · Back pain (supplement/device):**
```
UMP: painkillers and stretches fail because the pain isn't a "tight muscle" — it's a specific pinched/compressed nerve, and masking or loosening the wrong tissue never releases it.
UMS: you have to decompress and take pressure off that exact nerve — [product] does Y by [mechanism].
Product layer: [device geometry / ingredient action].
(Skepticism-heavy market → pair with the Doctor/Expert story shell per mlo-vsl-writer.)
```

## Rules & standards (MLO non-negotiables)
- **The mechanism is the hero, not the product.** Never lead with the product; lead with the hidden cause and let logic pull the reader.
- **4 questions, always in order.** Failure → root cause → theory → product. Product never appears before the theory.
- **PM > SM.** Spend the persuasion budget landing the Problem Mechanism; the SM is just its clean answer.
- **Root cause must pass the WHY drill:** 2–3 sentences AND non-obvious to a beginner. Not generic, not a paragraph.
- **SM must hit the exact PM.** If it only addresses a symptom, fix it — a surviving gap = surviving skepticism = no sale.
- **Ground in VoC, never fabricate.** Failures, causes and the product layer come from reviews/Brand Brain/reality; flag missing proof, don't invent a stat.
- **This is the spine, not the copy.** Build the mechanism, then hand off to the format skill — don't write the full asset here.
- **ES/EN:** write in the brand's language; no literal translation (rewrite the idea, not the sentence — MLO voice).

## Guardrails
- Don't hand back a product feature list dressed up as a "mechanism" — a UM is UMP → UMS → product layer, all three, in order, with the logic-gap check passed.
- Don't skip Q1: without the "why everything failed" beat the root cause lands flat.
- Don't fabricate a root cause or a proof point to make the bridge close; if the product's real mechanism doesn't actually address the named cause, say so — that's a positioning problem, not a copy problem.
- If the brand already has a UM in its Brand Brain, refine/reuse it rather than inventing a competing one; then store the result back (see references).
- Deep framework, examples and the swipe-file method live in `reference/unique-mechanism.md`.

## References
- **Full framework + examples + swipe-file:** `reference/unique-mechanism.md`.
- **Grounded in the course (Accelerated Advisory):** `~/Documents/CODEX/accelerated-advisory/modules/06-customer-profiling.md` (§6.12 Unique Mechanism UMP/UMS), `08-copywriting.md` (§8.6 Unique Mechanism in copy — the 3-layer bridge, most leveraged DR concept), `13-vsl.md` (§13.3 Mechanism — mother sentence, PM>SM, the WHY drill).
- **Suite relationship — it FEEDS these, doesn't fork them:** `advertorial-strategist` / `mlo-advertorial-strategist` (UM = the spine/hero-story engine), `mlo-vsl-writer` (UM = obligatory pre-write artifact + story-shell choice by skepticism×complexity), `framework-scriptwriter` (UM drops into the Mechanism beat of the 12 frameworks), `angle-generator` (root-cause angle = a UMP turned into a promise), `hooks-expert` (the UMP reframe is a hook engine — "the real reason nothing worked"), `static-ads-expert` (mechanism-led headline for soph-3+ markets). The **brand-brains** store each brand's UM — read it before building, write the built UM back after.
