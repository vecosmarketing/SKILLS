# Unique Mechanism — Knowledge Base

The deep reference for `mlo-unique-mechanism-builder`. Grounded in the Accelerated Advisory course: Module 06.12 (Customer Profiling — UMP/UMS), Module 08.6 (Copywriting — Unique Mechanism in copy), Module 13.3 (VSL — Mechanism, "the part that prints"). Everything here reconciles those three into one MLO artifact.

---

## 1. What the Unique Mechanism IS (and why it's the highest-leverage DR concept)

The Unique Mechanism makes a product **believable, logical and different**. It is the reason a skeptical buyer — one who has "tried everything" — moves from "yeah right, another one" to "oh… that actually explains why nothing worked, and this is the only thing that addresses it."

Nothing else in the MLO skill library produces this standalone. Hooks grab attention, angles frame a promise, frameworks sequence a script, advertorials/VSLs house the story — but the **mechanism is the load-bearing spine underneath all of them.** Build it once, correctly, and every downstream asset inherits its credibility. Get it wrong and every asset inherits the same leak.

**The mechanism is the hero, not the product.** The single biggest mistake is leading with the product ("our blanket is amazing, here's why"). Instead you lead with the buyer's problem and its hidden cause, and you let the logic walk them to the product as the *only remaining conclusion*. The product should feel discovered, not sold.

---

## 2. The 4 questions — IN ORDER (the order is the mechanism)

The whole thing is 4 questions answered in a fixed sequence. The order isn't stylistic — it's what makes the logic compound. Skip one or reorder and you lose performance (Module 06.12: "the 3 layers in order or you lose performance").

1. **Why did everything they've tried fail?**
   - Validate the frustration first. List the alternatives the buyer already burned money and hope on.
   - Frame the failures as "not your fault — all of those treated the *symptom*." This does two jobs: earns trust, and pre-loads the reader to accept a new cause.
   - Do NOT attack their present or blame them (Module 13.4, Rock Bottom rule: consequences framed in the future, never an attack on where they are now).

2. **What is the true root cause?** → **UMP**
   - The hidden mechanism *behind* the problem — under the symptom they've been fighting.
   - This is the reframe. "You think the problem is X, but the real cause is Y — and nobody told you." Landing this is what retroactively explains step 1 ("of course the pills failed — they never touched the actual cause").

3. **What is the simple theoretical solution?** (NOT the product) → first half of **UMS**
   - State, in principle, what would actually have to happen to fix the root cause.
   - Still no product. The reader nods "yes, THAT's what I'd need" *before* the product is named. If you name the product here you collapse the logic and it reads as a pitch.

4. **How does the product implement that theory?** → second half of **UMS** + the **product layer**
   - Now, and only now, the product appears — as the vehicle that delivers the theoretical solution.
   - Still described as mechanism ("it does Y by…"), not as a sales pitch ("buy now, limited stock").

---

## 3. The two named layers + the product layer

| Layer | = | Answers | Example (weighted blanket) |
|---|---|---|---|
| **UMP** — Unique Mechanism of the Problem | the **root cause** behind the symptom | Q2 | high cortisol suppresses melatonin, keeping the body wired |
| **UMS** — Unique Mechanism of the Solution | the **theory** that fixes the cause **+ how the product enables it, no pitch** | Q3 + Q4 | calm the nervous system with sustained gentle pressure |
| **Product layer** | the real, concrete mechanism that delivers the theory | Q4 detail | DPS microbeads distribute even gentle pressure |

**Mother sentence** (Module 13.3): *"Your [problem] is caused by X (Problem Mechanism), X is fixed by Y (Solution Mechanism), and our product delivers Y → result Z."*

**PM > SM.** The Problem Mechanism carries most of the persuasive weight. Landing the PM auto-generates three things at once: frustration with the old solutions, hope (a new cause means a new path), and willingness to try. The SM only has to be the clean, obvious answer to the PM you just installed. So spend your research and your word-count on nailing the PM.

---

## 4. The WHY drill — how to FIND the root cause

The UMP is found by interrogation, not invention. **Keep asking "why" until the cause is BOTH:**
- **explainable in 2–3 sentences**, AND
- **non-obvious to a beginner** (a newcomer to the category shouldn't already know it).

Worked drill (sleep):
- "Why can't they sleep?" → they're stressed. *(too obvious — keep going)*
- "Why does stress stop sleep?" → the body stays in fight-or-flight. *(warmer)*
- "Why does that block sleep specifically?" → elevated cortisol suppresses melatonin, so the body physically can't drop into deep sleep. *(2–3 sentences ✓, non-obvious ✓ → this is the UMP)*

Failure modes:
- **Too shallow / generic** ("you're tired because you're busy") → not unique, ask why again.
- **Too complex** (needs a paragraph and a diagram) → won't carry an ad, simplify to the essential causal step.
- **Sweet spot** = the "of course!" reframe: simple once said, but the reader didn't know it before.

---

## 5. Logic-gap validator (the credibility gate)

The bridge sells only if every link is airtight. Run this before shipping:

- **Does the SM hit the EXACT PM — or only a symptom?** This is the #1 gap. If the Solution Mechanism addresses a symptom instead of the named root cause, the reader's skepticism survives → **no sale.** Realign the SM to the exact UMP.
- **Chain integrity:** failed alternatives → root cause → theory → product must read as one unbroken "therefore." If a reader can insert "…but why does that follow?" at any joint, the bridge leaks. Patch or re-derive.
- **Order intact:** the 4 questions appear in order; the product does not surface before the theory.
- **Real & true:** the product layer is the product's actual mechanism (real ingredient/material/design/tech). No fabricated stat, study or testimonial — if proof is missing, flag it (it's a positioning/proof problem, not something to invent).
- **2–3-sentence test:** you can tell the whole mechanism to a beginner in a few plain sentences and it still lands as non-obvious.
- **Beginner-skeptic test:** would someone who's "tried everything" say "huh, that actually explains it"? If not, sharpen the UMP.
- **Sophistication fit:** in a saturated market (soph 4–5) the bare claim is dead; the UMP has to *sound new*. Check the root cause is novel enough for how many times this market has heard the category's promise.

---

## 6. Worked examples (full)

### 6.1 Weighted blanket (sleep) — canonical
- **Q1:** melatonin, sleep hygiene, apps all target *falling asleep* (the symptom), not why the body stays wired.
- **Q2 / UMP:** chronically elevated cortisol keeps the nervous system in fight-or-flight and suppresses melatonin — the body can't reach deep sleep regardless of any pill.
- **Q3 / UMS theory:** calm the nervous system itself; sustained gentle pressure triggers the parasympathetic "held/hugged" response, lowering cortisol so melatonin rises naturally.
- **Q4 / product:** DPS (Deep Pressure Stimulation) microbeads distribute that even, gentle pressure across the whole body.
- **Mother sentence:** "Your broken sleep is caused by cortisol suppressing melatonin, that's fixed by calming the nervous system with gentle pressure, and our DPS microbead blanket delivers that → you sleep through the night."

### 6.2 Skincare / collagen (anti-aging)
- **Q1:** creams and serums fail because they sit on the surface.
- **Q2 / UMP:** wrinkles form because dermal collagen production collapses with age — a depth topical products never reach.
- **Q3 / UMS theory:** you must trigger the skin to *rebuild its own* collagen from within, not coat it from outside.
- **Q4 / product:** [peptide/active + delivery system] penetrates to the dermal layer and switches collagen production back on.
- Reframe line: "creams fail because the problem isn't on the surface — it's underneath."

### 6.3 Back pain (device/supplement)
- **Q1:** painkillers mask, stretches loosen the wrong tissue — neither releases the pain.
- **Q2 / UMP:** the pain isn't a "tight muscle," it's a specific pinched/compressed nerve.
- **Q3 / UMS theory:** decompress and take pressure off that exact nerve.
- **Q4 / product:** [device geometry / ingredient action] does exactly that.
- Skepticism-heavy health market → pair with the **Doctor/Expert story shell** (see `mlo-vsl-writer`, Module 13.5 shell matrix: high skepticism × complex mechanism).

---

## 7. Swipe-file method

The fastest way to build and pressure-test mechanisms is to study proven ones and copy the **sequence/logic, never the wording** (Module 13.5 writing recipe). Sources:
- **swiped.co** — annotated classic DR breakdowns.
- **ClickBank** — high-volume VSLs/advertorials in supplement/health/finance where the mechanism does all the work.
- **Facebook / Meta Ad Library** — search a competitor or an adjacent market, find long-running ads (longevity = winner), transcribe the mechanism section.
- **Billy Gene, and other DR swipe archives** (Module 08.6).
- **VoC for the raw material:** reviews, Trustpilot/Amazon/G2, post-purchase surveys, forums and **Reddit** (anonymity → people confess the raw emotion and the "why nothing worked") — this is where Q1 and the UMP come from (Module 06.10/06.11 mining + `angle-generator`).

**Method:** transcribe 3–5 winning mechanisms in your category and adjacents → break each into ≤10 sections → copy the causal *sequence* → then **differentiate with a NEW mechanism** (a different root cause or a different theory). Never lift the competitor's exact UMP — that's how you become one more undifferentiated claim in a soph-4 market.

---

## 8. Hand-off map (where the built mechanism goes)

The UM is the upstream artifact. After building and validating it, hand it to the format skill — and store it in the brand's Brain so every future asset reuses the same spine.

| Downstream skill | How it consumes the UM |
|---|---|
| `advertorial-strategist` / `mlo-advertorial-strategist` | UM = the spine / hero-story engine; the advertorial *is* the 4 questions dramatized. |
| `mlo-vsl-writer` | UM is the obligatory pre-write artifact (mother sentence); drives Building Block 5 (Mechanism) and the story-shell choice by skepticism × complexity. |
| `framework-scriptwriter` | UM drops into the Mechanism beat of the 12 frameworks (Hook → Problem → **Mechanism** → Proof → CTA). |
| `angle-generator` | a root-cause angle = a UMP turned into a promise ("the real reason nothing worked"). |
| `hooks-expert` | the UMP reframe is itself a hook engine — "the hidden cause of [problem] nobody told you." |
| `static-ads-expert` | mechanism-led headline for soph-3+ markets (bare claim is dead → lead with the mechanism). |
| `mlo-page-cooker` / `cro-2026` | UM structures the presell/listicle/PDP narrative. |
| **brand-brains** (`mlo-brand-brain-*`) | **store the built UM here** (root cause + theory + product mechanism + mother sentence). Read it before building; write it back after. |

**Rule:** this skill builds the mechanism; it does not write the final asset. If the request is "write the VSL/advertorial/ad," build/confirm the UM here, then invoke the format skill with it.
