# Knowledge base — advertorial-strategist

Distilled knowledge for conceptualizing cold-traffic advertorials (Unaware / Problem-Aware) in the MLO system.
Sources: MLO Playbook modules (cited inline), the mlo-winner-strategist expert brains, the legacy MLO
advertorial pair, and external DR research. See **Sources** at the end.

---

## 0. Where this sits (relationships — don't fork)
- **This is the consolidated entry point** for *conceptualizing* advertorials. It absorbs the legacy
  `mlo-advertorial-strategist` (same 5-beat skeleton, same 9-winner Based Supplies system, same two-piece
  funnel) so there is one door for the concept step. Reference the legacy skill; never contradict it.
- **Concept → brief handoff:** `mlo-advertorial-brief-builder` FORMATS an approved angle into a production
  brief (an **ad brief** OR an **advertorial-landing "5 razones"** brief). This skill stops at the concept.
- **Video cousin:** `unaware-ads-expert` writes the shootable unaware *video/VSL script*. An advertorial/VSL
  landing is the natural destination of an unaware video ad — the two chain together.
- **Coverage:** owns the Unaware / Problem-Aware rows of `mlo-psychological-coverage`.

---

## 1. MLO fundamentals that govern every advertorial
*(Source: `00-INDEX-Sistema-Scripting-MLO.md`, `05-Modulo-Unaware-Ads.md`)*

- **Trinidad — message first.** The message (avatar + angle) precedes format. The advertorial wrapper
  (editorial/native/breaking-news) is only the vehicle. Never pick the format before the awareness + angle.
- **3A (Audience · Angle · Ad).** Audience & angle come from the Árbol de Cascada; the Ad (this advertorial)
  is last.
- **5 Awareness levels:** Unaware → Problem-Aware → Solution-Aware → Product-Aware → Most-Aware. Advertorials
  live in the **Unaware ↔ Problem-Aware** band. Beyond that (Solution/Product-Aware) is not this cold terrain.
- **Market Sophistication (Schwartz):** how many times the market has heard this exact claim. Decides whether a
  plain benefit still works (fresh) or you must escalate to a **mechanism** (Soph 3) or **identity/story**
  (Soph 4–5). Advertorials thrive in saturated DTC (Soph 4–5) precisely because native + mechanism + identity
  beats the "shout the benefit louder" ad everyone else runs.
- **FFM** (Framework de Fórmula de Medición) is the scoreboard: hook rate, hold rate, CTR, ROAS.
- **Precision > filler.** Every line earns its place; open loops carry the fragile "wait, does this affect me?"
  transition.

---

## 2. Why advertorials, and the Unaware/Problem-Aware entry logic
*(Source: `05-Modulo-Unaware-Ads.md` §1–4; legacy `mlo-advertorial-strategist`)*

- Unaware = the biggest TAM and the most scalable, but the hardest to crack (hit rate ~1/20–1/50 vs ~1/10 for
  aware). A single winner can change an account and run 100–480+ days. Advertorials/VSLs are the format that
  best carries the long runway an Unaware/Problem-Aware prospect needs.
- **Golden rule:** lead with **high curiosity + low/medium relevance**, tied to a **latent pain or desire** you
  then intensify and crystallize.
- **Specificity spectrum** (choose where to cut): "what onions do to *your body* → *your health* → *your blood
  sugar* → *your neuropathy*". Lower = more relevant, fewer people; higher = bigger TAM, needs stronger
  curiosity. Note the TAM tradeoff explicitly.
- **Opening ban** (in the hook/headline you may NOT name): the **problem**, the **desire**, the **solution**,
  the **product/brand**, or the **offer**. All of that lives *inside* the piece. And **don't show the product**
  early — Beat 4, not before.
- **Break ad-blindness:** the piece must read like content — useful, educational, entertaining, or a
  public-interest alert. Not like an ad.

### The 3 entry doors (name one)
- **A) Symptom** — call the *symptom*, not the problem ("If your dog has bad breath…"). Doctor logic: symptom →
  diagnosis → treatment. Pick symptoms with **search mass** (different symptoms = very different volume).
- **B) Cognitive bias / worldview** — speak to the avatar's worldview: *"people will do anything for who
  confirms their suspicions and helps them throw stones at their enemies."* Confirm suspicions / throw stones at
  "the industry". This is where the **villain** is born.
- **C) Curiosity** — the pure curiosity door, using the 10 proven types + innate triggers (below).

### The 10 proven unaware types (sweep these on a new account)
Paradox · Lost wisdom / forgotten remedy · Conspiracy (esp. US) · Warning sign · Everyday saboteur / surprising
culprit · Story · Big Win · Big Horror · Symptom callout · Sacred cow.
**Innate-curiosity triggers:** NASA / Harvard / Nobel; the exotic (Amish, monks, blue zones, Japan, Norway);
mafia / CIA / conspiracy; Egyptians, Victorian doctors, Chinese medicine, Navy Seals.

### 4 gap buckets every unaware hook opens
A real **possibility** for you · a **danger** you didn't know · you were **right** (worldview confirmed) · you
were **wrong**.

---

## 3. The 5-beat master skeleton
*(Source: legacy `mlo-advertorial-strategist`; aligned with `05-Modulo-Unaware-Ads.md` §7 spine)*

Product NOT before Beat 4.
1. **Hook / Titular** — breaks ad-blindness, reads like a media headline; names NO product/category. Springs:
   pattern alert · myth debunked · discovery (medical/scientific) · hyper-relatable story.
2. **Beat 1 · Symptom / Agitation** — names the felt pain, escalates the cost of not resolving it. Zero product.
3. **Beat 2 · Myth / Common Error** — why what they tried failed, and it's **not their fault** (kills self-blame).
4. **Beat 3 · New Mechanism** — the true root: **villain named + root named + vivid metaphor** ("seeds in
   cement"). Converts Unaware → Problem-Aware → Solution-Aware. Without a credible mechanism it's an ad in
   disguise.
5. **Beat 4 · Organic Introduction** — the product appears ONLY now, as the sole logical consequence of the root
   ("this does X the others didn't"), then a **soft CTA** — bridge, not door: read on / try the method / take
   the test. Conversion happens on the landing.

The Unaware-module spine maps 1:1:
`HOOK → immediate PAYOFF → MECHANISM (intensify) → SOLUTION (type → ours) → PRODUCT → CTA (act now)`.
Place **open loops** at the transitions: "this is the part nobody tells you", "here's where it'll make your
blood boil", "and this is what they discovered…".

---

## 4. The two-piece funnel (HARD RULE)
*(Source: legacy `mlo-advertorial-strategist` + `mlo-advertorial-brief-builder`; `05-Modulo-Unaware-Ads.md` §8)*

Advertorials are **two pieces**, not one:
- **The ad (Meta creative) = the tip.** Its ONLY job is to sell the **click** — hook + one brush of the symptom
  + native social proof + CTA. It does NOT close the sale.
- **The advertorial (landing/article) = where the 4 beats breathe fully** and the sale closes.

**The 4 beats are NOT crammed into the ad.** Compression by format:
- **Video UGC/VSL 30–60s** → the 4 beats express (2–3 sentences each).
- **Static / screenshot / native comment** → hook + native social proof + CTA only.
- **Carousel** → ~1 beat per card + CTA close.

Mnemonic: **the ad seals the click, the advertorial closes.** Execution formats to test (from the module): long
video → PDP · photo + very long primary text → PDP · photo/video → advertorial/VSL → PDP (lifts conversion).

---

## 5. The clone-a-winner system (9 Based Supplies winners)
*(Source: legacy `mlo-advertorial-strategist` — page-ref +1100 ads; validated across 3 products, 100–480+ days)*

Pattern from 9 winners of ONE advertiser (tallow & honey balm, onion shampoo) across many problems (anti-aging,
hands, eczema, hair loss). **This is MLO's scalable advertorial system — the spine we clone.**

**The spine (constants in ALL):**
1. **Villain = the industry / synthetic / "what they don't tell you"** — foreign ingredients wreck your
   microbiome; sulfates kill follicles; Botox/retinol/serums; "12 products, zero results". Always a side:
   natural/simple vs synthetic/expensive/complicated. Strong variant: **"the treatment you use makes you
   *worse* / creates dependence."**
2. **Hook enters by symptom, curiosity or benefit — never product.**
3. **Mechanism delivered as education** — why the traditional thing fails + why this works, with the **root
   named** (collagen layer, DHT, Staph aureus, sulfur/keratin).
4. **Product = natural/bioidentical**, the logical consequence, that **replaces or rebuilds** (doesn't compete).
5. **Specific result + timeline**, often **escalated** (week 1 / 6 / 12 → "10 years younger").
6. **Scarcity + guarantee** (limited stock + 30-day money-back).
7. **Native/UGC format**, zero ad look.

**The 6 archetypes (pick or fuse):**
1. **Static + native comment** — alert/fear hook + proof in an FB comment (real photo, timestamp, reactions).
2. **UGC "the secret / how-to education"** — curiosity/benefit hook + ingredient listicle + creator-as-proof
   ("Age: X" on screen) + ritual demo.
3. **VSL "avoid these 2 errors / the real root"** — Problem-Aware symptom hook + kills the obvious alternatives
   (Botox, retinol) + pseudo-scientific mechanism with root named + escalated timeline + guarantee + authority POV.
4. **Testimonial / transformation** — emotional first-person hook + low point (identity, motherhood) +
   skepticism-overcome arc + live proof ("no makeup").
5. **Founder / origin story** — founder narrator ("I started this for my son") + origin arc + borrowed
   authority ("hospitals use it") + proof by volume ("50k jars") + brand/community trust.
6. **Long editorial article** — first-person editorial (structure below).

**Hook menu:** alert/fear · secret/benefit · symptom+hope ("it's not permanent, good news") · emotional
first-person · "what happens if you use [X] for [time]?" · "the real root of [problem]".

**Proof-type menu:** native comment · creator-as-proof ("Age:X" / no makeup) · transformation testimonial ·
stacked testimonials (emotional, parent) · study + stat ("2002, 73%") · authority/expert POV (dermatologist) ·
mentor (character who reframes) · volume ("50k sold").

**Long-advertorial editorial structure (the article script):**
1. Relatable confessional lead (personal, vulnerable, specific — "$800 in 14 months, nothing worked").
2. The symptom moment (the exact scene it became undeniable — brutal specificity).
3. The spiral of failures / myth (everything tried + the industry's wrong belief).
4. Turning point / mentor (expert/hairdresser/dermatologist delivers the reframe via a question or line).
5. Mechanism / root (true cause + villain named + vivid metaphor).
6. Product introduced natively (inside the story, not as a pitch).
7. Honest journey with realistic timeline (include the ugly — "I almost quit"; honesty = credibility).
8. Reflection + explicit product + action-CTA ("turn your jar around and read it" / "try the method") + guarantee.

**How to clone:** pick archetype → swap **villain**, **named root**, **result/proof** to the brand's avatar;
the spine is untouched. One product → N advertorials, re-angled by problem/avatar.

**Cross-brand example (English-Path):** villain = streak-app academies; named root = "speaking is reflex, not
knowledge — at your pace, without exposing yourself"; differentiation = structured books vs Open English/academy;
authority = results/testimonials/creator; scarcity = launch price.

---

## 6. The advertorial-landing "5 razones" molde (for the landing handoff)
*(Source: `mlo-advertorial-brief-builder` MODO LANDING — validated on 6 Based Supplies landings)*

When the deliverable is the landing (not the ad), the architecture is fixed; what changes per variant is the
angle/problem, headline, testimonial and mechanism framing (same villain, different named root):
1. **Editorial header** — discreet logo + angle headline + testimonial subtitle (name + age + specific result)
   + editorial date/hero image ("Note: you'll love it so much it becomes part of your routine").
2. **Lead that matches awareness** — "You know what [pain] is… but here's what nobody tells you: [root reframe]"
   → "Here are the 5 reasons thousands switch to [product]:".
3. **The 5 reasons (listicle body):** ① real root / villain · ② why traditional fails + mechanism · ③ why OURS
   (differentiation) · ④ results + real testimonials + timeline + cost reframe · ⑤ scarcity + identity.
4. **How to get it (steps 1-2-3)** + bundle/gift + limited inventory.
5. **Conversion close** — CTA to PDP/checkout + "as seen in" + reviews + woven guarantee.

The **named root** in Reason 1 can go by lack ("your skin/scalp is starving for X") OR by sabotage ("what you
use makes you worse / suppresses instead of feeding"). Both valid. One product → N landings (skincare-N), one
per angle, message-matched to the ad.

---

## 7. Schwartz Awareness × Sophistication — the master cheat-sheet (reused)
*(Source: `mlo-winner-strategist/reference/experts-direct-response.md`)*

Diagnose BOTH axes before choosing the angle. **Awareness = what the prospect knows. Sophistication = how much
the market has heard this claim.** For advertorials the relevant cells:

| | Soph 1–2 (fresh claim) | Soph 3 (needs mechanism) | Soph 4–5 (saturated/skeptical) |
|---|---|---|---|
| **Unaware** | Story/education that names the problem, then plain benefit | Story/education revealing the *hidden cause* (mechanism-as-revelation) | Identity/story hook, native non-ad content |
| **Problem-Aware** | "The symptom you feel has a name — and a fix" | Mechanism naming the root cause | Reframe + mechanism + native proof; disarm self-blame |

- **Match runway length to awareness:** the less aware, the longer the runway before the product — which is why
  advertorials/VSLs exist for cold traffic.
- **Angle-decay rule:** when a winner fatigues, first ask *"has the market heard this claim too many times?"* If
  yes → deepen the **mechanism** or shift to **identity**, don't shout the same claim louder.
- **Ogilvy:** long copy sells more when the ask is big — the long advertorial beats a one-liner for considered
  purchases.
- **Hopkins:** salesmanship-in-print — judge every advertorial as a salesperson; its job is a conversion.

---

## 8. Compliance & the disclaimer component
*(Source: legacy `mlo-advertorial-strategist`)*

Cold advertorials usually need a **discreet disclaimer/label**: "Advertorial" / "Sponsored content", results
disclaimers for health/finance, "individual results vary". It buys editorial credibility and covers compliance
without breaking the native look. **Never use claims the client can't back** — especially health, supplements,
income, guaranteed results. Advertorial ≠ misleading; intensify *latent* pain honestly.

---

## 9. Launch & measurement note (from the Unaware module)
- Ask for **3 variants of the SAME piece changing only the visual hook** (same text hook, same person, same VO).
- 1 CBO per business objective · new ad set · 3 ads · 7 days. Win-spend + campaign CPA down in 24–48h → scale
  20%/day. Win-spend but everything worse → kill and tweak. No spend → the hook signals something the audience
  doesn't care about → change the hook.
- Sophistication applies here too: if the big win/symptom is burned, **exaggerate more**. Higher ticket performs
  better; some markets don't need unaware (already enough Solution-Aware TAM).

---

## Sources
**MLO Playbook (source of truth):**
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, awareness,
  sophistication, EPIC, FFM.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/05-Modulo-Unaware-Ads.md` — Unaware Ads Masterclass (golden
  rule, opening ban, 3 doors, 10 types, spine, launch/test).

**Existing MLO skills reused / aligned (do not contradict):**
- Legacy `mlo-advertorial-strategist` (5-beat skeleton, 9-winner Based Supplies system, 6 archetypes, two-piece
  funnel, long-editorial structure) — this skill consolidates it.
- `mlo-advertorial-brief-builder` (production brief templates + "5 razones" landing molde) — the handoff target.
- `unaware-ads-expert` (video/VSL cousin), `mlo-winner-strategist` (post-winner documentation/iteration).
- `mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz Awareness×Sophistication grid, Ogilvy,
  Hopkins.
- `mlo-winner-strategist/reference/experts-offers-hooks.md` — hook archetypes, VSL/story structure.

**External DR research (via the reused expert brain, source URLs there):**
- Eugene Schwartz — 5 Stages of Awareness & Market Sophistication
  (https://www.kingeshop.com/en/customer-awareness-sophistication-eugene-schwartz).
- 5 Levels of Market Awareness (Copyposse: https://copyposse.com/blog/5-levels-of-market-awareness-...).
