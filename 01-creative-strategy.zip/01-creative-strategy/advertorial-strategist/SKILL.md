---
name: advertorial-strategist
description: >
  Conceptualizes ADVERTORIALS for cold traffic (Unaware / Problem-Aware) for MLO Growth's DTC brands —
  editorial / native / breaking-news pieces that enter by symptom, cognitive bias or curiosity, NEVER by
  the product. Designs the two-piece funnel (light ad sells the click → long advertorial closes) and clones
  winner skeletons to any brand. Output = advertorial angles + a filled skeleton, with handoff to the
  advertorial brief builder. ALWAYS use this skill (ES/EN) when the user says "dame ángulos de advertorial",
  "conceptualiza advertorials para [marca]", "estrategia de advertorial", "ángulos Unaware/Problem Aware",
  "clona/adapta este winner a [marca]", "piensa 3 advertorials", "advertorial nativo / breaking-news /
  editorial", "cómo entro en frío a [avatar]", "advertorial angles", "conceptualize advertorials for
  [brand]", "clone this winner as an advertorial", "native/editorial/breaking-news concept". Trigger on
  partial asks like "ideas para vender X sin que parezca ad", "destrípame este winner". For any MLO brand
  (8hours, ZZEN, Moncho Moreno, Bala di Gala, Alma, English-Path, HobbitAlf, Chic&Love, etc.).
---
# Advertorial Strategist — cold-traffic advertorial concepts (MLO system)

## What it does
Turns a product + avatar into **advertorial concepts**: editorial articles, native testimonials, "how-to"
educations, or breaking-news pieces that break ad-blindness and enter cold traffic (Unaware / Problem-Aware)
through a **symptom, cognitive bias or curiosity door — never the product**. Every concept ships with its
**awareness read, entry mechanism, the 5-beat master skeleton filled, the two-piece funnel split** (what goes
in the light ad vs. the long advertorial), and a **native proof asset**. Then it hands off to the brief builder
for production. This is the highest-scale cold-traffic format: one skeleton → N variants by swapping only
hook + villain + named root, and one winner runs 100–480+ days.

## Relationship to other MLO skills (don't fork — this is the consolidated entry point)
- **Consolidated advertorial entry point.** This is the suite's single door for *conceptualizing* advertorials.
  It **supersedes and consolidates** the legacy `mlo-advertorial-strategist` (same 5-beat skeleton, same
  9-winner Based Supplies system, same two-piece funnel) — reference it, do not contradict it.
- **Handoff → `mlo-advertorial-brief-builder`** to FORMAT any approved angle into a production brief (ad brief
  or advertorial-landing "5 razones" brief). This skill produces the *concept*; the brief builder produces the
  *producible template*.
- **Complements `unaware-ads-expert`** (the video/script cousin: an advertorial/VSL is the natural *landing*
  format for an unaware video ad). If the deliverable is a shootable video script, route there.
- **Complements** `mlo-creative-strategy`, `mlo-psychological-coverage` (owns Unaware/Problem-Aware rows),
  `angle-generator`, `research-engine`, `skeleton-ads`, `nil-script-builder`, `seedance-20-ugc-ad-director`.
- **After a winner:** hand it to `mlo-winner-strategist` to document the framework + generate iterations.

## When to use (ES + EN trigger phrases)
- ES: "dame ángulos de advertorial", "conceptualiza advertorials para [marca]", "estrategia de advertorial",
  "qué ángulos Unaware/Problem Aware", "advertorial nativo / editorial / breaking-news", "clona/adapta este
  winner a [marca]", "piensa 3 advertorials", "cómo entro en frío a [avatar]", "destrípame este winner",
  "ideas para vender X sin que parezca un anuncio".
- EN: "advertorial angles for [brand]", "conceptualize advertorials", "advertorial strategy", "native /
  editorial / breaking-news concept", "clone this winner as an advertorial", "how do I enter [avatar] cold".

## Inputs needed
1. **Brand + product** (and price point — higher ticket / considered purchases suit advertorials best).
2. **Avatar / ICP** (from the Árbol de Cascada if it exists): identity, latent pain/desire, worldview, VoC.
3. **Mechanism** — the real, client-defensible reason the product works (the *named root* that arms Beat 3).
4. **Offer / CTA** — price hook or action (test / read on / check availability).
5. **Awareness read** — Unaware vs. Problem-Aware; and market **sophistication** (if the claim is burned,
   escalate to mechanism or identity).
6. Optional but recommended: **a winner to clone** (hook + first lines + format + days active); winning organic
   hooks / competitor patterns.

If **avatar**, **mechanism** or **offer/CTA** is missing, ask before conceptualizing — without them the angle
comes out generic.

## Method (numbered — MLO's real system)
1. **Diagnose awareness first (Trinidad: message before format).** Declare the target level and change the lead:
   - **Unaware** — doesn't know they have the problem. Enter through an adjacent life/desire/fear (money,
     status, health, curiosity) and *reveal* the problem.
   - **Problem-Aware** — feels the symptom, doesn't know the cause, usually self-blames. Enter by the **symptom**
     and **disarm the self-blame**.
   - Solution/Product-Aware → NOT this skill's cold terrain; route to direct formats.
2. **Diagnose sophistication (Schwartz grid, reused).** How many times has the market heard this claim? Fresh →
   story/education that names the hidden problem; Soph 3 → mechanism-as-revelation (hidden cause); Soph 4–5
   (supplements, skincare, weight-loss, most mature DTC) → identity/story + native, non-ad-feeling content +
   exaggerate the claim. A wrong read fails even a great product.
3. **Pick the entry door and NAME it** (never the product): **Symptom** (call the symptom, not the problem —
   pick symptoms with search mass) · **Cognitive bias / worldview** (confirm suspicions, throw stones at "the
   industry") · **Curiosity** (paradox, lost wisdom, conspiracy, warning sign, surprising culprit, big win,
   story, sacred cow). Layer an innate-curiosity trigger where it fits (NASA/Harvard/Nobel, exotic —
   Amish/monks/blue zones, mafia/CIA, Victorian doctors, Chinese medicine).
4. **Choose the native format wrapper.** Editorial article · native testimonial · "how-to / the secret"
   education · breaking-news / warning · fake-native comment · founder origin story. It must read like content
   (useful, entertaining, or a public-interest alert), never like an ad.
5. **Fill the 5-beat master skeleton** (product NOT before Beat 4):
   1. **Hook / Titular** — breaks ad-blindness, reads like a media headline; names NO product/category.
   2. **Beat 1 · Symptom / Agitation** — names the felt pain, escalates the cost of not fixing it. Zero product.
   3. **Beat 2 · Myth / Common Error** — why what they tried failed, and it's not their fault (kills self-blame).
   4. **Beat 3 · New Mechanism** — the true root (villain + named root + vivid metaphor). Converts
      Unaware→Problem-Aware→Solution-Aware.
   5. **Beat 4 · Organic Introduction** — the product appears ONLY now, as the sole logical consequence of the
      root → **soft CTA** (bridge, not door: read on / try the method / take the test).
6. **Split the two-piece funnel (HARD RULE).** The **ad** = the tip; its only job is to sell the **click**
   (hook + one brush of the symptom + native social proof + CTA). The **advertorial** (landing/article) = where
   the 4 beats breathe fully and close. **The 4 beats are NOT crammed into the ad.** Compress by format:
   - Video UGC/VSL 30–60s → runs the 4 beats express (2–3 sentences each).
   - Static / screenshot / native comment → hook + native social proof + CTA only.
   - Carousel → ~1 beat per card + CTA close.
   Mnemonic: **the ad seals the click, the advertorial closes.**
7. **Attach a native proof asset** (the highest ad-blindness-breaking element): native FB/IG comment (real photo,
   timestamp, reactions) · creator-as-proof ("Age: X", no makeup) · stacked testimonials · study + stat ·
   authority POV · volume ("50k jars sold").
8. **Clone the winner skeleton to the brand** (when a reference is given): keep the SPINE fixed, swap only
   **villain**, **named root** and **result/proof** to the brand's avatar. Re-angle one product by problem/avatar
   → N advertorials.
9. **Add the disclaimer component** (discreet "Advertorial" / "results vary" label) — buys editorial credibility
   and covers compliance without breaking the native look. Never use claims the client can't back.
10. **Handoff.** If they ask for a production brief, do NOT format by hand — **hand off to
    `mlo-advertorial-brief-builder`** passing brand, product, angle, awareness level, mechanism, offer/CTA,
    leveraged reference and format.

## The clone-a-winner system (9 Based Supplies winners — validated)
Pattern extracted from 9 winners of ONE advertiser across 3 products and multiple problems, ads live 100–480+
days. **This is MLO's scalable advertorial system — the spine we clone.**
- **The spine (constants in ALL):** villain = the industry / synthetic / "what they don't tell you" (strong
  variant: "the treatment you use makes you *worse* / creates dependence") · hook enters by symptom/curiosity/
  benefit, never product · mechanism delivered as education with the **root named** (collagen layer, DHT,
  Staph aureus, sulfates) · product = natural/bioidentical, the logical consequence, that **replaces or rebuilds**
  · specific result + timeline (escalated: week 1 / 6 / 12) · scarcity + guarantee · native/UGC format.
- **6 archetypes (pick or fuse):** ① Static + native comment · ② UGC "the secret / how-to" · ③ VSL "avoid these
  2 errors / the real root" · ④ Testimonial / transformation · ⑤ Founder / origin story · ⑥ Long editorial article.
- **Hook menu:** alert/fear · secret/benefit · symptom+hope ("it's not permanent, good news") · emotional
  first-person · "what happens if you use [X] for [time]?" · "the real root of [problem]".

## Rules & standards (MLO non-negotiables)
- **Trinidad-first / message > format** — awareness + angle decide the piece; the format wrapper is the vehicle.
- **Break ad-blindness:** it must NOT look like an ad — useful, editorial, entertaining, or a public alert.
- **Opening ban:** the hook names NO product / category / offer. **Product does NOT appear before Beat 4.**
- **True, defensible mechanism** — a real *named root*; no claims the client can't back (esp. health/finance).
- **Native, credible proof** — specific result + short timeline + aspirational; native comment is the core asset.
- **Two-piece funnel is a hard rule** — the ad sells the click, never the whole sale.
- **Scalable skeleton** — one spine → N variants swapping only hook + villain + named root + proof.
- **FFM is the scoreboard** (hook rate / hold rate / CTR / ROAS). Expect a low cold hit rate; scale pays for it.
- **Precision > filler** — every line earns its place; open loops carry the fragile "does this affect me?" seam.

## Output (exact shape + example)
Deliver, per angle:
```
ADVERTORIAL — <Brand> · <concept name>
Awareness: <Unaware | Problem-Aware> · Sophistication: Soph <n> → <move>
Entry door: <Symptom | Cognitive bias | Curiosity> · Native format: <editorial | testimonial | how-to | breaking-news | native comment | founder>
Leveraged reference: <winner: hook + days active — or "generic +1100 skeleton">

HOOK / TITULAR (headline, no product):  "<line>"  · psych spring: <alert | myth | discovery | relatable story>
Beat 1 · Symptom/Agitation:              "<…>"
Beat 2 · Myth / Common Error:            "<… not your fault>"
Beat 3 · New Mechanism (villain+root):   "<… named root + vivid metaphor>"
Beat 4 · Organic Introduction + soft CTA:"<product as sole logical consequence>"

Native proof asset: <native comment | creator "Age:X" | study+stat | authority | volume>
Disclaimer: <discreet label / "results vary">

TWO-PIECE SPLIT
 AD (sells the click):        hook + one symptom brush + native proof + CTA   [format: <…>]
 ADVERTORIAL (closes):        the 4 beats breathe fully → PDP/checkout

CLONE MAP (if cloning): villain → <…> · named root → <…> · result/proof → <…>  (spine unchanged)
→ Handoff to mlo-advertorial-brief-builder for the production brief.
```
**Concrete example (8hours sleep supplement · Problem-Aware · Soph 4–5):**
Entry = **Symptom** ("you wake at 3am and can't fall back asleep"), native format = **breaking-news / warning**.
HOOK: "Doctors are quietly warning about the 3am wake-up — and it's not stress." → Beat 1: the exhausting cycle
of broken nights and foggy mornings. → Beat 2 (kills self-blame): melatonin gummies fail because they knock you
out but don't keep you under — not your fault. → Beat 3 (villain = the sedation myth; named root = a night-time
cortisol/blood-sugar dip): your brain wakes to correct it. → Beat 4: the deep-sleep protocol that steadies the
dip, product appears here. Native proof: stacked testimonials + "doctor-approved" authority POV. Two-piece:
static + native comment sells the click → long editorial closes → PDP.

## Guardrails
- If the market is already Solution/Product-Aware, or the product is a solution-aware commodity, **don't force
  an advertorial** — recommend the right awareness stage/format instead.
- Never leak product/category/offer into the hook; never introduce the product before Beat 4.
- Advertorial ≠ misleading. No fabricated medical/earnings claims; the mechanism must be client-defensible.
- Don't hand-format production briefs — that's `mlo-advertorial-brief-builder`. Don't substitute generic
  "write a landing page" advice for MLO's real 5-beat + two-piece + clone system.

## References
See `reference/knowledge-base.md`. Grounded in **MLO Playbook M5 · Unaware Ads Masterclass**
(`05-Modulo-Unaware-Ads.md`) and **M0 INDEX** (`00-INDEX-Sistema-Scripting-MLO.md`) for Trinidad, awareness,
sophistication, 3A, FFM. Consolidates the legacy **`mlo-advertorial-strategist`** (5-beat skeleton, 9-winner
Based Supplies system, two-piece funnel) and hands off to **`mlo-advertorial-brief-builder`**. Reuses the
**Schwartz awareness×sophistication grid** and hook/story frameworks from
`mlo-winner-strategist/reference/experts-direct-response.md` and `…/experts-offers-hooks.md`.
