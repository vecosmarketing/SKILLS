---
name: "linkedin-voice-guardrails"
description: "Filtro obligatorio anti-IA y reglas de voz para TODOS los posts de LinkedIn de Marcel López Olivas. Biblioteca acumulada de errores corregidos, patrones prohibidos, y reglas de tono extraídas de feedback directo de Marcel. ALWAYS load this skill BEFORE writing any LinkedIn post, carousel, comment, DM template, engagement plan, or any content for Marcel's LinkedIn — even when linkedin-content-strategist is already active. This is a mandatory compliance layer: load it, apply every rule, then write. Trigger on: any LinkedIn content creation, \"post de LinkedIn\", \"redactar post\", \"escribe un post\", \"contenido LinkedIn\", or whenever generating text that will publicarse en LinkedIn de Marcel. Also trigger when linkedin-content-strategist skill is active."
---

# LinkedIn Voice Guardrails — Marcel López Olivas

Este skill es un filtro obligatorio. Se carga ANTES de escribir cualquier contenido de LinkedIn para Marcel. Cada regla viene de feedback directo de Marcel — no son sugerencias, son correcciones reales sobre errores que ya se cometieron.

## Regla madre

> "Todo lo que suene a IA, quiero que le pase siempre un filtro de: esto lo diría un humano con estas palabras."

Antes de dar por bueno cualquier texto, léelo en voz alta mentalmente. Si suena a newsletter de Silicon Valley traducida al español, reescríbelo. Si suena a alguien explicándote algo en una terraza con autoridad, está bien.

## Patrones prohibidos — NO usar nunca

### Anglicismos y jerga técnica innecesaria
Marcel no dice "typo", "insight", "game-changer", "take", "hot take" en medio de una frase en español. Si hay una palabra normal en español, usa esa.

| ❌ Prohibido | ✅ Alternativa |
|---|---|
| "No es un typo" | "Sí, suena a burrada. Te lo desgloso." o simplemente no comentar la cifra |
| "Insight" | "dato", "aprendizaje", "lo que vimos" |
| "Game-changer" | "lo que cambió todo", "lo que marcó la diferencia" |
| "Framework" en el cuerpo del post | "sistema", "proceso", "método" (OK en primer comentario técnico) |
| "Approach" | "enfoque", "forma de hacerlo" |
| "Deliverable" | "entregable" o mejor, describir qué es |
| "Benchmark" en el cuerpo del post | "referencia", "punto de comparación" |

**Excepción:** Términos técnicos de la industria que TODOS los media buyers usan en inglés están OK: ROAS, CPA, CTR, LTV, CAC, CPM, hook, ad set, Meta Ads, DTC. Estos no se traducen.

### Frases que delatan IA
| ❌ Nunca escribir | Por qué |
|---|---|
| "No es un typo" | Nadie dice esto en español. Es un patrón de posts de LinkedIn en inglés. |
| "Spoiler alert:" | Mismo problema — calco del inglés |
| "Plot twist:" | Ídem |
| "Let me break it down" / "Te lo desgloso" (si suena forzado) | Patrón de IA |
| "Here's the thing" / "La cuestión es esta" | Patrón de IA |
| "Me emociona compartir" | Corporativo + IA |
| "Estoy encantado de anunciar" | Corporativo + IA |
| "En el panorama actual" | IA pura |
| "Sin más preámbulos" | IA pura |
| "Déjame contarte" | IA — nadie pide permiso para contar algo |
| "¿Quieres saber cómo?" | Clickbait de IA |
| "La respuesta te sorprenderá" | Clickbait basura |
| Cualquier frase que suene a "10 things you won't believe" traducida | Basura |

### Estructura y formato
| ❌ No hacer | ✅ Hacer |
|---|---|
| Posts superficiales sin datos concretos | Posts con profundidad, ejemplos reales, números específicos |
| Usar "yo/he/envío" | SIEMPRE "nosotros/hemos/enviamos" — voz de agencia |
| Poner "24 marcas" como número exacto | "decenas de marcas" o el número que Marcel indique expresamente |
| Poner [NOMBRE] en templates de DM | Escribir DMs sin personalización con placeholder |
| Emojis decorativos | Solo 📊 para separación estructural, ningún otro emoji decorativo |
| Posts que son listas sin sustancia | Listas solo si cada punto tiene profundidad y contexto |
| CTA agresivos tipo "DM me NOW" | CTA como invitación: "Si te suena, está en el primer comentario" |

### Acentos y ortografía
SIEMPRE usar acentos correctos en español. Esto incluye widgets HTML, no solo texto plano.

| ❌ Error | ✅ Correcto |
|---|---|
| campana | campaña |
| distribucion | distribución |
| optimizacion | optimización |
| mas | más (cuando es adverbio) |
| informacion | información |
| tambien | también |
| numero | número |

Si el output va a un widget HTML, los caracteres especiales (á, é, í, ó, ú, ñ, ¿, ¡) deben aparecer correctos — no usar entidades HTML ni omitirlos.

## Tono correcto

### Cómo suena Marcel
- **Directo pero cercano.** No es agresivo, no es bro-marketing, no es Gary Vee en español. Es un tío que sabe mucho, gestiona muchas marcas, y te lo cuenta normal.
- **Autoridad sin pedantería.** Los datos hablan solos. No necesita decir "soy experto en X". Muestra el trabajo.
- **Mundano.** Usa palabras que usaría cualquier persona normal. Si una frase suena a que la escribió un copywriter de LinkedIn americano y la pasó por Google Translate, está mal.
- **Agencia, no individuo.** "Nosotros", "hemos visto", "en las cuentas que gestionamos". Nunca "yo descubrí".

### Test rápido de calidad
Antes de entregar cualquier post, pasa este filtro:

1. ¿Podría Marcel leer esto en voz alta sin sentirse ridículo? → Si no, reescribir.
2. ¿Hay alguna frase que suene a post viral de LinkedIn gringo traducido? → Eliminar.
3. ¿Los datos son concretos o son genéricos tipo "aumentamos los resultados"? → Si genéricos, añadir números reales.
4. ¿Dice "yo" en algún sitio? → Cambiar a "nosotros".
5. ¿Tiene profundidad o es una lista superficial de tips? → Si superficial, añadir el "por qué" y un ejemplo real.
6. ¿Los acentos están correctos en TODO el texto, incluidos widgets? → Revisar.

## Procedimiento obligatorio por post

Cada post de LinkedIn debe incluir:
- 2 opciones de copy (A y B)
- Puntuación F1 Viral Benchmark (hook/estructura/CTA/reach killers/AI tells, sobre 50, target 40+)
- Primer comentario (auto-respuesta que añade valor)
- Plan de engagement (cómo responder a comentarios)
- Template de DM (sin [NOMBRE], sin placeholders)
- Cross-sell (conexión con otros posts o contenidos)

## Actualizaciones

Este skill se actualiza con cada corrección de Marcel. Si Marcel da feedback nuevo sobre tono, palabras prohibidas, o patrones a evitar, añadirlo aquí inmediatamente.

---
*Última actualización: 8 agosto 2026*
*Fuente: Feedback directo acumulado de Marcel López Olivas across múltiples sesiones*
