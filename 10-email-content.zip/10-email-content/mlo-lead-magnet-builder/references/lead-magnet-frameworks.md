# Lead Magnet Frameworks — esqueletos canónicos por tipo de asset

Frameworks para usar como base estructural. NO copiar literal — adaptar al tema concreto.

## 1. Lead Magnet de hook (6-12 páginas) — el formato LinkedIn

**Cuándo usarlo:** captar leads en LinkedIn con promesa concreta. Foco en autoridad rápida + take-aways accionables.

### Estructura

**Página 1 — Cover hero**
- Title XL (un solo concepto, 4-7 palabras).
- Subtitle con la promesa concreta ("De €0 a €100k/mes en Meta Ads sin quemar presupuesto").
- Autoridad MLO (1 línea: "Por M.L.O Growth — 35+ marcas DTC escaladas").
- Logo discreto abajo.

**Página 2 — El problema**
- 1 dato impactante en grande ("87% de las marcas DTC quiebran en el primer año por mala gestión de paid").
- 3 síntomas que el lector reconoce (ej: "ROAS volátil", "CPM imparables", "creativos que duran 3 días").
- Cierre: "Esto pasa porque..." → conecta con la solución.

**Página 3-8 — El framework / los pasos / los principios**
- 1 idea por página.
- Estructura: title de la idea + dato/quote/visual + take-away ("aplícalo así:").
- Si es un framework, una página de overview visual (matriz, funnel, timeline).
- Cada idea con ejemplo real (con métrica si se puede).

**Página penúltima — Síntesis**
- Una sola página con todos los puntos resumidos en una infografía o lista.
- "Si solo te llevas una cosa: ..."

**Última página — CTA**
- Pregunta para el lector ("¿Quieres aplicar esto a tu marca?").
- CTA al Calendly o LinkedIn de Marcel.
- Logo grande.

## 2. Ebook (20-40 páginas) — formato profundo

**Cuándo usarlo:** lead nurture, autoridad de profundidad, "regalar valor" pre-cierre.

### Estructura

**Portada + intro (3-4 págs)**
- Cover + página de copyright/créditos + intro 1-2 págs ("para quién es este ebook, qué no es").

**Capítulos (3-6 capítulos de 4-6 páginas)**
- Cada capítulo: hook de capítulo + 3-5 secciones + recap.
- Cada sección: idea + ejemplo + take-away.
- Caso real al final de cada capítulo (1 página dedicada a un cliente, con números reales).

**Capítulo final: el playbook accionable (5-8 páginas)**
- Pasa de teoría a "cómo aplicarlo esta semana".
- Plantilla rellenable + checklist.

**Cierre**
- 1 página con quote del autor (Marcel) — visión.
- 1 página CTA con Calendly + LinkedIn.

## 3. Playbook operativo (15-30 páginas)

**Cuándo usarlo:** documento operativo paso a paso — un sistema replicable.

### Estructura

**Cover + objetivo (2 págs)**
- Cover + "Qué vas a poder hacer al terminar este playbook".

**Diagnóstico (2-3 págs)**
- Cómo saber si necesitas este playbook (3 preguntas o un test rápido).

**Sistema (10-20 págs)**
- **Step 1:** título + qué hacer + cómo hacerlo + ejemplo + check de salida.
- **Step 2:** igual.
- ... (continuar hasta cerrar el sistema).
- Cada step en 1-2 páginas máximo. Si es más, subdividir.

**Checklist de implementación (1-2 págs)**
- Lista accionable que el lector puede marcar.

**Errores comunes (1-2 págs)**
- "Lo que NO hacer" — 3-5 pitfalls con consejo.

**Recursos + CTA**
- Links a herramientas / templates / Calendly.

## 4. Checklist accionable (1-3 páginas)

**Cuándo usarlo:** asset corto para LinkedIn post directo o regalar pre-call.

### Estructura

**Página 1**
- Title: "Checklist: [Tarea específica]"
- Subtítulo: contexto (1 línea).
- 8-15 items checkeables en columnas.
- Cada item: acción concreta + frase de aclaración (1 línea).

**Página 2 (opcional)**
- "Cómo usar este checklist" — instrucciones de aplicación.
- "Si fallas en X items, deberías..." — diagnóstico rápido.

**Página 3 (opcional)**
- CTA.

## 5. Infografía one-screen

**Cuándo usarlo:** post LinkedIn nativo, slide única, share-friendly.

### Estructura — Patrón Funnel
```
TÍTULO XL (concepto)
─────────────────────
[ETAPA 1: TOP] → datos / %
[ETAPA 2: MID] → datos / %
[ETAPA 3: BOT] → datos / %
─────────────────────
KEY INSIGHT (1 frase)
LOGO MLO
```

### Estructura — Patrón Matriz 2×2
```
TÍTULO + EJES
              EJE Y →
    ┌─────────┬─────────┐
    │ Cuad 1  │ Cuad 2  │
    │ "Name"  │ "Name"  │
    ├─────────┼─────────┤
    │ Cuad 3  │ Cuad 4  │
    │ "Name"  │ "Name"  │
    └─────────┴─────────┘
              EJE X →
KEY INSIGHT
LOGO MLO
```

### Estructura — Patrón Timeline
```
TÍTULO
2026 ──● Evento 1 (data)
       │
       ●─ Evento 2 (data)
       │
       ●─ Evento 3 (data)
KEY INSIGHT
LOGO MLO
```

### Reglas de infografía

- Una sola idea por infografía.
- Datos concretos en cada nodo (no genéricos).
- Tipografía como elemento principal (números enormes).
- Iconos solo si refuerzan, nunca decorativos.

## Frameworks DTC populares para construir lead magnets

(Usar como esqueletos cuando aplique al tema.)

- **Pirámide AIDA** (Awareness → Interest → Desire → Action)
- **Funnel ToFu / MoFu / BoFu**
- **Awareness stages (Schwartz)**: Unaware → Problem aware → Solution aware → Product aware → Most aware
- **Jobs to be done**
- **4U headline** (Useful, Urgent, Unique, Ultra-specific)
- **PAS** (Problem, Agitation, Solution)
- **Funnel paid → discovery → propuesta → firma** (sales asset)
- **Breakeven ROAS / unit economics** (KPI panel framework de MLO)
- **Andromeda creative coverage** (psychological coverage de Levinger)
- **Net new concepts** (creative strategy de MLO)

Si el lead magnet usa uno de estos frameworks, citar la fuente al final.
