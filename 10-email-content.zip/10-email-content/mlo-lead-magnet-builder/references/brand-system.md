# MLO Growth — Brand System

Referencia de identidad visual para usar en todos los documentos generados por este skill. Si algún parámetro está marcado como "pendiente de confirmar con Marcel", preguntárselo antes de la versión final.

## Logo

- **Nombre:** M.L.O Growth
- **Variantes esperadas:** isotipo (M iconográfica) + wordmark.
- **Uso:** logo en header (esquina sup. izquierda) o footer (centro inferior) — nunca en mitad de párrafo.
- **Pendiente de confirmar:** SVG/PNG oficial del logo y variantes color (light/dark).

## Paleta de color (sistema base)

Hasta que Marcel confirme la paleta oficial desde el Manual de Marca PDF, usar este sistema editorial neutro tipo Linear / Stripe:

```
--bg-primary:    #0A0A0B   (negro casi puro — para hero pages, headers)
--bg-secondary:  #111114   (fondo de cards y bloques)
--bg-light:      #FAFAF9   (fondo blanco roto — body en modo claro)
--text-primary:  #0A0A0B   (sobre fondo claro)
--text-inverse:  #FAFAF9   (sobre fondo oscuro)
--text-muted:    #6B7280   (subtítulos, captions, references)
--accent-primary:#17E885   (verde lima — acento principal, CTAs, highlights)
--accent-hover:  #0CA86A   (estado hover del verde)
--border:        #E5E7EB   (líneas separadoras)
--border-dark:   #1F2937   (líneas sobre fondo oscuro)
```

**Reglas de uso:**
- Una página puede ser fondo oscuro (`bg-primary`) o claro (`bg-light`) — nunca mezclar dentro de la misma página.
- El verde lima (`accent-primary`) solo para: número grande, CTA principal, un quote destacado por página. NO usar como fondo de párrafo.
- Texto muted (`text-muted`) para captions, footers, numeración de página.

## Tipografía

```
--font-display:  "Inter", "Helvetica Now Display", system-ui, sans-serif
--font-body:     "Inter", "Helvetica Now Text", system-ui, sans-serif
--font-mono:     "JetBrains Mono", "SF Mono", Monaco, monospace
```

**Escala:**
- `h1` 56-72px / weight 700 / line-height 1.05 / letter-spacing -0.02em
- `h2` 32-40px / weight 600 / line-height 1.15
- `h3` 22-26px / weight 600 / line-height 1.2
- `body` 16-18px / weight 400 / line-height 1.55
- `caption` 13-14px / weight 500 / muted

**Reglas:**
- Display weight nunca debajo de 600 (que pese).
- Body siempre regular (400) — bold solo para destacar palabras clave, no frases enteras.
- Mono solo para código, valores numéricos o tags ("CPM €18.50", "M017.1").

## Estilos editoriales clave

### Card / Callout
```css
background: var(--bg-secondary);  /* o blanco si fondo claro */
border-radius: 12px;
padding: 24px 32px;
border: 1px solid var(--border);
```

### Quote
- Comillas grandes (verde lima).
- Italic NO — mejor un block-quote con border-left de 3px verde.

### Datos numéricos hero
```html
<div style="font-size: 96px; font-weight: 700; color: var(--accent-primary); letter-spacing: -0.04em;">
  +52%
</div>
<div style="font-size: 18px; color: var(--text-muted);">
  growth web en mayo 2026 — Moncho Moreno
</div>
```

### CTA final
```html
<a href="https://calendly.com/mlo-growth/audit-call"
   style="display: inline-block;
          background: var(--accent-primary);
          color: var(--bg-primary);
          padding: 16px 32px;
          border-radius: 8px;
          font-weight: 600;
          text-decoration: none;">
  Agenda tu auditoría →
</a>
```

## Do / Don't de diseño

✅ **Do:**
- Mucho white space — los founders escanean.
- Una idea por página/slide.
- Datos en gráfico simple, no en tablas enormes.
- Logo discreto pero presente.
- Tipografía como elemento de diseño (números enormes, headlines grandes).

❌ **Don't:**
- Stock images de "team trabajando" — nunca.
- Iconos genéricos de Font Awesome — solo si refuerzan dato.
- 3 colores acento en la misma página.
- Body text en bold de párrafos enteros.
- Logos de clientes sin permiso.

## Para el footer de cada página

```
M.L.O Growth · Growth Partner for DTC Brands · mlo-growth.com
```

(Tipografía muted, tamaño 11-12px, centrado.)

## Cuando faltan inputs de branding

Si Marcel no ha confirmado paleta/tipografía oficial, generar el documento con el sistema neutro de arriba y al final dejar un bloque:

> ⚠️ Branding: este documento usa la paleta editorial neutra de MLO (Inter + negro/verde lima). Si tenéis paleta oficial diferente en el Manual de Marca PDF, decidme los hex codes y la tipografía y lo regenero.
