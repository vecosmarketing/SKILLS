# Examples Pool — referencias de lead magnets DTC top

Pool de referencias de assets que funcionan en LinkedIn / Twitter para founders DTC y agency owners. Usar como inspiración estructural, **NUNCA copiar copy literal**.

## Lead magnets que rompen en LinkedIn (DTC/Marketing space)

### Pattern 1 — "El playbook que usé para escalar X a Y"
- Hook: caso real con número.
- Ejemplo de estructura: "Cómo escalamos [marca] de €X a €Y en N meses — el playbook completo".
- Por qué funciona: autoridad inmediata + promesa específica.

### Pattern 2 — "X cosas que [audiencia] hace mal"
- Hook: contraintuitivo / problema reconocible.
- Ejemplo: "7 errores que matan tu ROAS antes del día 14".
- Por qué funciona: el lector se siente identificado, busca validación o aprende qué evitar.

### Pattern 3 — Framework propio con nombre
- Hook: framework con acrónimo o nombre marca.
- Ejemplo: "El framework PROFIT — cómo conseguir breakeven en mes 2 con paid".
- Por qué funciona: posicionamiento como creador de método. Marcel puede crear frameworks propios MLO.

### Pattern 4 — Benchmark / data report
- Hook: dato exclusivo.
- Ejemplo: "Benchmark MLO Q1 2026 — CPMs, CPAs y ROAS reales de 35 marcas DTC".
- Por qué funciona: información que el lector no puede sacar en otro sitio.

### Pattern 5 — Checklist accionable
- Hook: lista que el lector puede usar HOY.
- Ejemplo: "Checklist: 17 cosas que revisar antes de lanzar tu siguiente campaña".
- Por qué funciona: utilidad inmediata sin tener que leer mucho.

### Pattern 6 — Swipe file / templates
- Hook: copia las plantillas que usamos.
- Ejemplo: "15 hooks de UGC que llevamos probados y funcionan — copia y adapta".
- Por qué funciona: ahorro de tiempo + autoridad.

### Pattern 7 — Behind the scenes / case study
- Hook: cuento cómo lo hicimos.
- Ejemplo: "Cómo conseguimos un mes de €100k con Bridge — el behind the scenes".
- Por qué funciona: storytelling + datos reales + nombre real.

## Estructura de un post LinkedIn que lleva al lead magnet

```
[HOOK línea 1 — provocadora o contraintuitiva]

[Contexto 2-3 líneas]

[Problema / pregunta]

[Promesa del lead magnet en 1 línea]

Lo he metido todo en un PDF de [N páginas]:

→ [Bullet 1 — lo que aprenderá]
→ [Bullet 2]
→ [Bullet 3]
→ [Bullet 4]
→ [Bullet 5]

Es gratis. Lo descargas en mi web (link en bio) o me lo pides por DM.

P.D. [extra hook / personal note]
```

## Cosas que se rompen y NO hacer

- **Lead magnet de 60 páginas** — nadie lo lee. Máximo 12-15 págs para LinkedIn.
- **Cover con stock photo** — pierde credibilidad. Mejor cover tipográfico fuerte.
- **Solo teoría** — sin un dato/caso/quote concreto cada 2-3 páginas, se desconecta.
- **CTA difuso** — "espero que te haya servido" no es CTA. Que el lector sepa qué hacer en la última página.
- **Branding inconsistente** — si cada página tiene un color distinto, el lector no confía.

## Referencias de creadores que dominan este formato

- **Marketing Operators** (podcast) — frameworks claros con datos.
- **Carl Weische** — creative strategy didáctica.
- **Dara Denney** — playbook content.
- **D2C Diaries** — case studies bien narrados.
- **Motion** (app + content) — visuales editoriales top.
- **Northbeam** — data reports DTC.
- **Triple Whale** — benchmarks + reports.
- **Manel Gomez** — formato LinkedIn español, contenido DTC.

(Estudiar sus PDFs de LinkedIn para coger estructura, **no copy**.)
