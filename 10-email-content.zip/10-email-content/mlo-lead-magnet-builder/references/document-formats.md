# Document Formats — qué formato técnico usar según el caso

Guía rápida para elegir el formato de output óptimo según el tipo de asset y su uso final.

## Decisión rápida

| Caso de uso | Formato recomendado | Por qué |
|---|---|---|
| Lead magnet PDF para LinkedIn (carousel-style) | **HTML self-contained → export PDF** | Control total de diseño, exporta perfecto a PDF desde Chrome |
| Ebook >20 páginas | **HTML self-contained → PDF** o `docx` | HTML si peso visual, docx si lectura larga + edición posterior |
| Playbook operativo | **HTML self-contained → PDF** | Misma razón: design control + descargable |
| Checklist 1-3 pág | **HTML self-contained → PDF** | Quick + clean |
| Infografía one-screen | **SVG inline en HTML** o **PPTX 1 slide** | SVG si va a LinkedIn como imagen, PPTX si forma parte de deck |
| Deck para call con cliente | **PPTX** (`pptx` skill) | Necesita ser editable + presentable |
| Template editable que el lector rellena | **`docx`** o **Google Doc** | Para que el lector escriba dentro |
| Asset que el diseñador implementará en Figma | **Markdown con specs** | Copy + medidas + colores hex |

## HTML self-contained — patrón

```html
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>[Nombre Asset]</title>
<style>
  :root {
    --bg-primary: #0A0A0B;
    --bg-light: #FAFAF9;
    --text-primary: #0A0A0B;
    --text-inverse: #FAFAF9;
    --text-muted: #6B7280;
    --accent: #17E885;
    --border: #E5E7EB;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: "Inter", system-ui, sans-serif;
    color: var(--text-primary);
    background: var(--bg-light);
    line-height: 1.55;
  }
  .page {
    width: 100%;
    max-width: 210mm;       /* A4 width */
    min-height: 297mm;      /* A4 height */
    margin: 0 auto;
    padding: 40mm 30mm;
    page-break-after: always;
    position: relative;
  }
  .page.dark { background: var(--bg-primary); color: var(--text-inverse); }
  h1 { font-size: 64px; font-weight: 700; line-height: 1.05; letter-spacing: -0.02em; }
  h2 { font-size: 36px; font-weight: 600; line-height: 1.15; margin-top: 32px; }
  h3 { font-size: 24px; font-weight: 600; line-height: 1.2; margin-top: 24px; }
  p { font-size: 17px; margin-top: 16px; }
  .caption { font-size: 13px; color: var(--text-muted); }
  .stat { font-size: 96px; font-weight: 700; color: var(--accent); letter-spacing: -0.04em; line-height: 1; }
  .cta {
    display: inline-block;
    background: var(--accent);
    color: var(--bg-primary);
    padding: 16px 32px;
    border-radius: 8px;
    font-weight: 600;
    text-decoration: none;
    margin-top: 24px;
  }
  .footer {
    position: absolute;
    bottom: 20mm;
    left: 30mm;
    right: 30mm;
    text-align: center;
    font-size: 11px;
    color: var(--text-muted);
  }
  @media print {
    .page { margin: 0; padding: 25mm 20mm; }
  }
</style>
</head>
<body>

  <!-- Page 1: Hero -->
  <div class="page dark">
    <h1>[Title del lead magnet]</h1>
    <p class="caption" style="margin-top: 24px; color: var(--accent);">M.L.O Growth · Lead Magnet</p>
    <p style="margin-top: 64px; font-size: 20px;">[Subtítulo / promesa concreta]</p>
    <div class="footer" style="color: var(--text-muted);">M.L.O Growth · mlo-growth.com</div>
  </div>

  <!-- Page 2: Problema -->
  <div class="page">
    <p class="caption">El problema</p>
    <div class="stat" style="margin-top: 24px;">87%</div>
    <p style="margin-top: 16px; font-size: 20px;">de las marcas DTC no pasan de los €100k/mes por una mala gestión de paid.</p>
    <!-- ... -->
    <div class="footer">M.L.O Growth · 02</div>
  </div>

  <!-- ... más páginas ... -->

  <!-- Página CTA final -->
  <div class="page dark" style="display: flex; flex-direction: column; justify-content: center;">
    <h2 style="color: var(--accent);">¿Te encaja aplicar esto a tu marca?</h2>
    <p style="margin-top: 24px; font-size: 18px;">Pásate por una auditoría estratégica de 45 min. Sin compromiso, sin venta.</p>
    <a href="https://calendly.com/mlo-growth/audit-call" class="cta">Agenda la auditoría →</a>
    <div class="footer" style="color: var(--text-muted);">M.L.O Growth · mlo-growth.com</div>
  </div>

</body>
</html>
```

## Cómo exportar a PDF desde HTML

1. Abrir el HTML en Chrome.
2. Cmd+P → Destino: "Guardar como PDF".
3. Layout: Vertical / Portrait.
4. Margins: None (las páginas ya tienen padding interno).
5. Background graphics: ON.
6. Save.

## Para PPTX (decks)

Usar el skill `pptx` cuando:
- Es un deck para presentar en call.
- Marcel va a editar antes de mandar.
- Hay >5 slides con peso visual fuerte.

Specs por defecto:
- 16:9 (1920×1080) — formato moderno.
- Cada slide con 1 idea.
- Tipografía Inter.
- Paleta MLO (ver brand-system.md).

## Para SVG inline (infografías)

```html
<svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg" style="width: 100%; max-width: 800px;">
  <!-- background -->
  <rect width="800" height="600" fill="#0A0A0B"/>
  <!-- contenido -->
  <text x="400" y="60" text-anchor="middle" fill="#FAFAF9"
        font-family="Inter, sans-serif" font-size="36" font-weight="700">
    Funnel de captación 2026
  </text>
  <!-- ...resto del SVG... -->
</svg>
```

Después se puede:
- Embed en HTML.
- Exportar a PNG con screenshot.
- Subir a Figma para customizar.
- Mandar como adjunto en LinkedIn.

## Cuándo entregar specs en Markdown (para Figma)

Si Marcel pide que el diseñador implemente en Figma, entregar un `.md` con:

```
# [Nombre del Asset] — Specs para Figma

## Dimensiones
- A4 vertical (1240 × 1754 px @ 150dpi) por página

## Paleta
[hex codes con uso]

## Tipografía
- Display: Inter Bold 64px
- Body: Inter Regular 17px
- Caption: Inter Medium 13px

## Página 1 — Hero
- Background: #0A0A0B
- Title: "[copy]"
- Subtitle: "[copy]"
- ...

## Página 2 — ...
...
```

Sin diseñar — solo specs limpios que el diseñador implementa.
