# Voz de Marcel — biblia operativa

Marcel escribe como habla. Esto es lo que define su voz.

## Cadencia y ritmo

- **Frase media: 8-14 palabras.**
- **Frases cortas seguidas** crean ritmo y le dan a la idea el espacio que necesita.
- Si una frase pasa de 25 palabras, córtala. Punto, mayúscula, sigue.
- Párrafos de 1-3 líneas. Si llegas a 4 líneas, separar.

## Vocabulario natural de Marcel

### Conectores que usa
- "Mira", "vale", "lo que pasa", "el tema", "fíjate", "ojo", "vamos", "y aquí está la cosa".
- "Total que", "al final", "en realidad", "honestamente" (poco).
- "A tope con", "de cabeza", "menudo", "vaya", "menudo lío".

### Tacos (usa muy poco — 1 por email como mucho)
- "Cojonudo", "joder", "puto/a" (como intensificador, no insulto).
- Nunca en hook ni en CTA. Solo en el cuerpo, en momentos de énfasis genuino.

### Tics y muletillas legítimas
- "El cliente nos pide X. Y nosotros le decimos Y. Y aquí está el matiz."
- "Esto no es opinión, es lo que vemos cada semana en las 24 marcas."
- "Y no, no es magia. Es esto:" → seguido de explicación.
- "Lo más importante de todo esto es:" → reframing al final.

### Lo que evita
- "Asimismo", "no obstante", "en efecto", "por consiguiente".
- "Innovador", "disruptivo", "estratégico" (vacíos).
- "Compartir contigo" → "decirte".
- "Espero que sirva" → ❌ (parece disculpa).

## Estructuras retóricas favoritas

### El "no es X, es Y"
> "Esto no es un problema de creatividades. Es un problema de oferta."

### El "lista corta con peso"
> "Hay 3 razones. La primera es la importante. Las otras dos también."

### La pregunta como pivote
> "¿Sabes qué pasa cuando le bajas el budget a una campaña con poco aprendizaje? Esto:"

### El dato seguido de la consecuencia
> "1.62x. Por debajo de ahí, pierdes dinero. Punto."

### El "spoiler arriba"
> Primer párrafo dice la conclusión. El cuerpo la justifica. El cierre la resuelve en acción.

## Cómo se posiciona Marcel

- **No es un guru.** No vende cursos genéricos. No vende "10x your revenue".
- **Es operador.** Tiene 24 marcas en marcha. Sabe lo que duele.
- **Está del lado del founder.** Habla de presupuesto real, de equipos reales, de errores reales.
- **No vende la agencia en todos los emails.** Construye autoridad con consistencia.

## Ejemplo: cómo NO sonar
```
Hola Marcel,

Espero que estés genial. Hoy quiero compartirte algo súper potente que hemos descubierto en MLO Growth y que va a cambiar tu forma de ver el marketing.

Como sabes, en el mundo del e-commerce todo evoluciona muy rápido. Por eso es fundamental adaptarse con agilidad y estrategia.

En este email te traigo 5 tips infalibles para…
```
**Por qué falla:** saludo plano, "espero que estés", "súper potente", "como sabes", "fundamental adaptarse", "5 tips infalibles". Todo es humo.

## Ejemplo: cómo SÍ sonar
```
Esta semana hemos cerrado una marca por un problema de stock.

Sin stock no hay campañas. Sin campañas no hay datos. Sin datos no hay decisiones.

Te cuento qué hemos aprendido para que no te pase a ti.
```
**Por qué funciona:** abre con dato concreto, escala la consecuencia en cascada de frases cortas, promete utilidad sin disculparse.
