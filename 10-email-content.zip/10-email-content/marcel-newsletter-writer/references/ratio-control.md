# Control del ratio 80/20 (valor / venta)

## La regla

De cada **5 emails consecutivos**:
- **4 = valor puro** (deep dive, framework, caso, hot take, recap).
- **1 = venta** (auditoría, programa, llamada, recurso de pago).

## Cómo identificar si un email es de "valor" o de "venta"

### Valor puro (cuenta como 1 de los 4)
- ✅ La intención principal es enseñar, opinar, compartir caso.
- ✅ CTA inexistente o muy suave: "responde y dime", "lee este post", "guarda este thread".
- ✅ Si hay mención a MLO, es contextual (caso de cliente) no comercial.

### Venta (cuenta como el 1 de cada 5)
- ✅ Hay una oferta clara en el email.
- ✅ El CTA principal es accionar la oferta: "agenda llamada", "apuntate", "compra".
- ✅ Estructura: storytelling → problema → solución (MLO) → oferta → CTA.

### Casos ambiguos (se decide por el peso)
- Email mayormente educativo + PD breve con oferta → cuenta como **valor**.
- Email que es 70% caso de cliente y 30% mensaje "podemos hacerlo contigo" → cuenta como **venta**.
- Email que abre slot pero solo a quien responda → es venta suave, cuenta como **venta**.

## Cómo llevar la cuenta

Marcel debe tener un tracker simple (Notion o doc) con:

| # | Fecha | Tema | Tipo (V / $) |
|---|---|---|---|
| 1 | 16-jun | Frameworks de testing creativo | V |
| 2 | 18-jun | Caso ZZEN: cómo bajamos CAC -40% | V |
| 3 | 20-jun | Por qué la mitad de los CRO no funcionan | V |
| 4 | 23-jun | Recap LinkedIn semana | V |
| 5 | 25-jun | Abro 3 slots de auditoría Jump Start | **$** |
| 6 | 27-jun | Cómo construir el banco de copys | V |

Al empezar email 6, reseteo: ya hicimos el ciclo de 5. Sigo con valor hasta que toque el siguiente $.

## Excepciones (cuándo romper la regla)

1. **Lanzamiento mayor** (programa nuevo, evento) → 2 emails seguidos de venta justificados. Avisa antes en un email de valor.
2. **Caso de éxito con permiso del cliente** → puede ser híbrido valor+venta sin romper ratio.
3. **Newsletter aniversario, hitos de marca** → emails personales que no entran en el conteo.

## Señales de alarma

Si en las últimas 4 semanas (12 emails) tienes más de 3 de venta → estás quemando la lista. Compensa con 1-2 semanas extra de solo valor.

Si en las últimas 4 semanas tienes 0 de venta → estás dejando dinero encima de la mesa. Mete el siguiente.
