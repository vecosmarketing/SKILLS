# Anti-patterns — qué NO hacer nunca

Reglas que matan la newsletter de Marcel. Lista vivida.

## (1) Apertura plana
**❌** `Hola, espero que estés genial.`
**✅** `Esta semana cerramos una marca por stock.`

El primer 1.5 segundos de lectura debe enganchar. Saludos sociales en email = fricción.

## (2) "Hoy te traigo…" / "Hoy quiero compartirte…"
**❌** `Hoy te traigo 5 frameworks para…`
**✅** `Hay 3 frameworks de creative testing. Solo 1 funciona en B2C nicho.`

Si lo "traes" el lector aún no sabe por qué le importa. Dale la apuesta primero.

## (3) Disculpas y minimización
**❌** `Quizá esto no aplique a tu caso, pero…`
**❌** `Espero que te sirva.`
**✅** `Si tienes >50k de spend mensual, esto te aplica. Si no, archívalo.`

Mojarte. Filtra al lector, no le pidas perdón.

## (4) Buzzwords y vacíos
**❌** `engagement holístico`, `growth hacking`, `disrupción`, `narrativa 360`, `customer-centric`, `data-driven` (sin datos).
**✅** `cómo bajamos CPM de 18€ a 11€` (concreto).

Reemplaza buzzwords por mecánica. Si no puedes describir el qué, no existe.

## (5) Listas de tips sin contexto
**❌**
```
Tips para email marketing:
1. Segmenta
2. Personaliza
3. Testea
4. Automatiza
5. Analiza
```
**✅**
```
Lo que sí mueve la aguja en email B2C:
1. Segmentar por engagement de 30 días, no por tags antiguas.
   → Si abres este punto: el 80% del open viene del 20% que abrió la semana pasada.
2. Personalizar el primer name SOLO si lo capturaste limpio.
   → Si tienes "marcellopezolivas" como first name → vergüenza ajena.
```
Cada punto: razón + ejemplo + por qué la alternativa falla.

## (6) Cierres de relleno
**❌** `Espero que este email te haya aportado valor. Nos vemos pronto.`
**❌** `Un abrazo y a por la semana.`
**✅** Una frase que cierre el tema en seco:
```
Eso es todo.

Si lo pruebas, contéstame cómo te va.
```
O si no hay CTA: ninguna línea de cierre. Que termine el cuerpo y firma.

## (7) PD comercial pegada a todo

**❌**
```
[email de valor sobre Klaviyo]

PD: ¿quieres que MLO te audite tu Klaviyo? Agenda aquí.
```
Mata el 80/20. Si todos los emails llevan PD comercial = lista cabreada en 4 semanas.

**✅** Solo el email de venta del ciclo lleva CTA comercial. Los otros 4 sin.

## (8) Emojis cada 2 líneas
**❌**
```
🔥 Esto es lo que pasó esta semana 🔥
✅ Vendimos +30%
🎯 Cambiamos la oferta
🚀 Ahora a por más
```
**✅** Cero emojis en el cuerpo. Máximo 1, al final de un punto fuerte si encaja.

## (9) Citar a "los gurús"
**❌** `Como dice Alex Hormozi en su libro…`
**✅** `Esto lo aprendí en el bombazo de Hot Sale con BALA DI GALA.`

Tu autoridad viene de OPERAR, no de citar a otros operadores. Excepción: cita data o estudios (no gurús).

## (10) Llamadas a la acción ambiguas
**❌** `Si te interesa, dime.`
**❌** `Dale una vuelta y me cuentas.`
**✅** `Responde a este email con 1 línea: ¿lo aplicas tú o no?`
**✅** `Si quieres slot esta semana, agenda aquí: [link]. Tengo 3 disponibles.`

CTA = acción concreta + criterio claro de cuándo hacerlo.

## (11) Repetir el asunto en el cuerpo
**❌**
```
ASUNTO: 3 errores en email marketing

CUERPO: Hoy quiero hablarte de 3 errores en email marketing…
```
El cuerpo NO repite el asunto. Empieza por el caso, el hook, el dato.

## (12) Plurales reverenciales / academicismos
**❌** `En MLO Growth llevamos a cabo una estrategia…`
**✅** `Hicimos esto:`

## (13) Predecir el futuro sin base
**❌** `El email marketing en 2027 será radicalmente diferente.`
**✅** `Lo que hacíamos en Klaviyo hace 6 meses ya no funciona. Esto sí.`

Habla del presente que has medido, no del futuro que imaginas.

## (14) Mostrar el SaaS de Marcel sin pedir
**❌** Listar 5 herramientas que usas en cada email.
**✅** Mencionar la herramienta SOLO cuando aporta al punto:
```
Para esto usamos Atria. Es lo que nos permite hacer X.
```

## (15) Conclusiones tipo "¡Y eso es todo!"
**❌** `¡Y eso es todo por hoy! Espero que te haya gustado.`
**✅** No conclusión cursi. La idea cierra sola, o con la CTA o con la pregunta abierta.
