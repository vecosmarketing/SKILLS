# Subject lines — patrones que abren

El asunto es el 90% del juego. Si no se abre, el resto no existe.

## Métricas de referencia

- **Open rate objetivo en lista nicho B2B:** 40-55%.
- **Lista de prospects fríos:** 25-35%.
- Si bajas del 30% en cualquier escenario → asunto malo, revisar.

## Reglas generales

- **Longitud: 30-50 caracteres** (lo que ves en mobile).
- **Una idea por asunto.** Si necesita dos cláusulas, separa con `→` o `:`.
- **Sin emojis al inicio** (la app de mail los corta a veces). Si emoji → al final, 1 solo.
- **Sin spam triggers:** "GRATIS", "URGENTE", "$$$", todo en mayúsculas.
- **Pre-header complementa, no repite.** Si el asunto es la pregunta, el pre-header es el adelanto.

## Patrones que funcionan

### (1) Número específico + dolor
- `1.62x: por debajo, pierdes`
- `60 días testando creativos: 3 que funcionan, 27 que no`
- `Bajamos el CAC -40% sin tocar la oferta`

### (2) Hot take / contraintuitivo
- `El ROAS está mintiendo`
- `Por qué pausamos la mitad de las campañas`
- `Tu media buyer no es el problema`

### (3) Pregunta directa al lector
- `¿Tu Klaviyo está generando 30% o estás dejando dinero?`
- `¿Cuántas marcas tienen el mismo CAC en mayo?`
- `¿Qué haces cuando un cliente quiere parar 3 días?`

### (4) Caso con número
- `ZZEN: cómo pasamos de 80€/día a 1.500€/día`
- `Cidrera: vendieron el 70% del cupón en 3 días`
- `MUTO: el cambio que duplicó AOV`

### (5) Promesa concreta
- `Framework de Smart Mix para Q3`
- `Plantilla: brief creativo que usamos en 24 marcas`
- `3 cosas que cambié en el flow Welcome esta semana`

### (6) Curiosity gap (úsalo con cuidado)
- `Algo raro está pasando con Meta`
- `Si tu CPM subió, lee esto`
- `No hagas BFCM como el año pasado`

## Anti-patrones

- ❌ `Hoy te traigo…` — nadie quiere lo que "traes hoy".
- ❌ `5 tips para…` — desgastado.
- ❌ `Newsletter semanal #12` — nadie abre por número de orden.
- ❌ `Marcel López comparte contigo…` — tercera persona = humo.
- ❌ Emojis de relleno: `🚀💥🔥` al principio.

## Cómo entregar al cliente (Marcel)

Para cada email, entrega **3 propuestas de asunto** con etiqueta de tipo:

```
Propuesta de asuntos para el email "Smart Mix Q3":

[NÚMERO + DOLOR]
"3 marcas, 1 estructura: Smart Mix Q3"

[HOT TAKE]
"Por qué dejamos de usar CBO en frío"

[PROMESA CONCRETA]
"Framework Smart Mix completo (Q3 2026)"
```

Marcel elige el que más le encaje el día del envío.

## Pre-headers

Siempre incluir. Patrones que funcionan:

- Continuación del asunto: si asunto es `Por qué dejamos de usar CBO en frío`, pre-header puede ser `→ y qué usamos en su lugar`.
- Promesa: `Lectura de 4 minutos. Sale framework al final.`
- Anti-CTA (contraintuitivo): `Solo léelo. Sin venta hoy.`

Nunca repetir el asunto en el pre-header.
