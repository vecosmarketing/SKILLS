# Cómo conectar la newsletter con LinkedIn

La newsletter y LinkedIn son canales hermanos. No son lo mismo, pero se alimentan.

## Distribución sugerida (de cada 12 emails / mes)

- **~6 emails (50%)** — Deep dive de un post LinkedIn que funcionó.
- **~3-4 emails (30%)** — Tema EXCLUSIVO para suscriptores. Nunca sale en LinkedIn.
- **~2-3 emails (20%)** — Recap / curaduría de los mejores posts de la semana.

## Patrón (A): Deep dive de post viral

**Cuándo usar:** post de LinkedIn con engagement por encima de tu media → la gente quiere más.

**Estructura:**
1. **Hook** referencia al post: *"El otro día en LinkedIn dije que XYZ. 800 likes y 60 comentarios después, toca explicar el cómo."*
2. **Resumen del post en 2-3 frases** — no asumas que todos lo vieron.
3. **Los 3-5 puntos del post, EXPANDIDOS:**
   - Cada punto = un mini-bloque con framework + ejemplo + por qué falla la alternativa.
4. **Framework consolidado** — tabla, diagrama mental, o lista numerada.
5. **CTA suave:** *"Si te ha sido útil, contesta y dime en qué punto se te ha encendido la bombilla."*

**Por qué funciona:**
- Convierte tráfico de LinkedIn en suscriptores cualificados (los que se molestaron en buscar y suscribir).
- Hace que la lista valga la pena: lo que en LinkedIn es de 150 palabras, aquí son 700.

## Patrón (B): Contenido EXCLUSIVO

**Cuándo usar:**
- Tema más sensible (números muy concretos, opinión polémica, casos con nombre que no quieres airear).
- Recurso de descarga (template, sheet, prompt).
- Anuncio interno (cambio de equipo, nueva marca onboard, programa que estás cocinando).

**Estructura:**
1. **Hook que justifica la exclusividad:** *"Esto no lo voy a poner en LinkedIn porque…"*
2. **Cuerpo** sin holding back. Datos completos, screenshots, opinión fuerte.
3. **CTA si aplica** (puede ser el de venta del ciclo).

**Por qué funciona:**
- Hace sentir VIP al lector → menos unsubscribes.
- Construye intimidad con la lista → conversión más alta cuando hay oferta.

## Patrón (C): Recap semanal LinkedIn

**Cuándo usar:** viernes (típicamente). Email corto que cierra la semana.

**Estructura:**
1. **Hook:** *"Esta semana en LinkedIn pasaron 3 cosas que quiero rescatar aquí, por si te las has perdido."*
2. **3-4 mini-bloques:**
   - Título del post + 1 frase de qué iba.
   - Insight EXTRA que no cupo en el post original (esto es lo que justifica el email).
3. **Cierre suave:** pregunta abierta, "nos vemos el lunes".

**Por qué funciona:**
- Recupera lectores que no pasan por LinkedIn cada día.
- Te posiciona como editor / curador de tu propio contenido.

## Reglas comunes a los 3 patrones

- **Nunca copiar el post de LinkedIn tal cual.** Si lo van a leer en email, dales más.
- **Linkar a LinkedIn solo si necesitan el contexto** (ej. en un recap). En deep dive, NO mandes al post.
- **El email es un destino, no un trampolín.** El lector lee aquí, no clica fuera salvo CTA principal.
- **Tu firma puede mencionar LinkedIn** ("Sígueme aquí si no me sigues") sin pasar por CTA principal.

## Decisión rápida

Pregunta: **¿el lector que solo recibe newsletter (no usa LinkedIn) saca todo el valor?**
- Sí → publica como exclusiva o como deep dive.
- No (necesita LinkedIn para entenderlo) → mete el contexto al principio del email.
