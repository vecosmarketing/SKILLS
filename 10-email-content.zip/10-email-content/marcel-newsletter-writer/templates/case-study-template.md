# Template: Case Study (MIÉRCOLES o VIERNES — 400-600 palabras)

**Cuándo usar:** caso real con números. Vehículo perfecto para construir autoridad sin parecer agencia que se vende. El caso DEBE tener datos concretos.

---

## Estructura

### 1. Asunto + Pre-header
- Asunto: incluir el NÚMERO clave del caso.
- Ej. `Bajamos el CAC -40% sin tocar la oferta`.

### 2. Hook (1-2 frases)
- El resultado en seco.
- Ej. `Una marca de Q1 facturaba 30k al mes con CAC de 48€. Hoy factura 80k al mes con CAC de 28€. En 90 días.`

### 3. Quién era / situación inicial (1 párrafo)
- Categoría de marca (sin nombre si sensible).
- Tamaño aproximado.
- Problema concreto: por qué nos llamaron.

### 4. El diagnóstico (1-2 párrafos)
- Qué encontramos al entrar.
- Lo que NADIE más estaba viendo (esto es lo que el lector quiere saber).
- 1-2 datos concretos: CAC, ROAS, AOV, conversion rate.

### 5. La intervención (lista numerada, 3-5 cambios)
Cada cambio:
- **Qué hicimos:** verbo + objeto + cuándo.
- **Por qué:** racional en 1 línea.
- Sin entrar en cómo implementarlo (eso es para deep dive).

### 6. El resultado (lista corta con números)
- Métrica antes → después.
- Ventana temporal clara (`en 60 días`, `en 4 semanas`).
- Si hay revenue impacto: cifra (o rango).

### 7. La lección extraíble (1 párrafo)
- Lo que aplica al lector incluso si su contexto es distinto.
- Frase tipo: `Esto no fue magia. Fue X. Y X aplica a tu cuenta también.`

### 8. Cierre + firma
- Si NO es email de venta: pregunta abierta.
- Si SÍ es email de venta: ver `cta-template.md`.

---

## Ejemplo (parcial)

```
ASUNTO: ZZEN: cómo pasamos de 80€/día a 1.500€/día

Una marca de suplementos en España.
Magnesio, omega 3, focus.
ARR ~700k cuando entramos.

Vinieron en febrero con un problema:
gastaban 80€/día en Meta y no podían subir
sin que el ROAS se hundiera.

Lo que encontramos al entrar:

- Single bottles como hero en paid frío.
  → Break Even ROAS 2.43x. Imposible escalar.
- 0 retargeting estructurado.
- Naming caótico que no permitía leer la cuenta.

Lo que cambiamos:

1. Cambiar la oferta hero a Modo ZZEN (bundle 3 productos).
   → Break Even pasa a 1.35x.

2. Estructurar RMK con audiencias de 14/30/90 días.
   → Cada audiencia con copy y oferta distintos.

3. Naming convention nueva: TIPO_OBJETIVO_AUDIENCIA_CREATIVO_FECHA.
   → Cualquier persona del equipo lee la cuenta en 2 minutos.

Resultado en 60 días:
- Spend: 80€/día → 1.500€/día (18x).
- ROAS blended: 2.1x → 2.4x (subió, no bajó).
- Revenue Meta: 4k/mes → 75k/mes.

La lección: el problema no era el media buyer.
Era la oferta. Si tu hero en paid es tu producto
con peor unit economics, no escalas.

Marcel
```

---

## Reglas duras

- **Siempre con números.** Sin números, no es case study.
- **Sin nombres si NO tienes permiso del cliente.** Categoría + tamaño basta.
- **No exageres.** Si el caso fue 3 meses, di 3 meses. No 90 días para que suene mejor.
- **Incluye la cagada honesta:** "lo que NO funcionó al principio" da credibilidad.
