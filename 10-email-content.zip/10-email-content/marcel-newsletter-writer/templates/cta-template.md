# Template: CTA / Email de venta (1 de cada 5 — 450-650 palabras)

**Cuándo usar:** el 5º email del ciclo. Venta suave o directa. UNA sola oferta, claro.

---

## Estructura (formato BPV: Belief / Problem / Vehicle)

### 1. Asunto + Pre-header
- Asunto NO comercial. Debe abrirse como si fuese valor.
- Ej. `3 patrones que veo en las marcas que se han atascado`.
- Pre-header puede dar pista: `Y cómo lo desbloqueamos.`

### 2. Hook + storytelling (1-2 párrafos)
- Caso real, observación, conversación con un cliente esta semana.
- El lector debe leer las 5 primeras líneas SIN darse cuenta de que es venta.

### 3. El problema universal (1-2 párrafos)
- De ese caso particular, sacas el patrón.
- "Esto le pasa al 80% de las marcas que veo."
- El lector se identifica.

### 4. Por qué la solución típica NO funciona (1 párrafo)
- "Lo que suele hacer la gente: X. Por qué falla: Y."
- Crea el espacio para tu oferta.

### 5. Cómo lo resolveríamos (1-2 párrafos)
- Tu enfoque, en alto nivel.
- Sin spoiler completo (eso es valor de los otros 4 emails).
- Aquí empieza la oferta implícita.

### 6. La oferta (sección clara, 1 párrafo)
- Nombre del producto/servicio.
- A quién aplica (criterio claro).
- Qué incluye.
- Cuánto cuesta (si aplica) o "agenda llamada para ver fit".

### 7. La CTA (1 línea + link)
- UNA. No dos. No tres.
- `Agenda 15 min aquí: [link]`.
- `Apuntate aquí si quieres entrar antes de [fecha]: [link]`.

### 8. La escasez REAL (si aplica)
- "Tengo 3 slots libres este mes."
- "Cierra el lunes que viene."
- NO inventar escasez falsa. Si no hay, no la metas.

### 9. Recordatorio del valor (1 línea de cierre)
- Para los que NO clican: "Si no encaja, no pasa nada. Volvemos al valor el lunes."

### 10. Firma + PD

---

## Ejemplo

```
ASUNTO: 3 patrones que veo en las marcas atascadas

PRE: Y cómo lo desbloqueamos.

Esta semana llamó un founder de una marca de
cosmética. Facturan 50k/mes desde hace 6 meses.
No suben.

Le pasé media hora mirando la cuenta.
Encontré los 3 patrones de siempre.

1. Spend disperso en 4 categorías cuando solo 1
   tiene unit economics que aguanten escalado.
2. RMK genérico (audiencia 90d, copy igual al frío).
3. Naming caótico → nadie del equipo sabe lo que
   ve cuando abre Ads Manager.

Esto le pasa al 80% de las marcas que veo cuando
nos llaman.

Lo que normalmente hace la gente:
contrata otro media buyer, espera que arregle
"el problema técnico".

Por qué falla:
no es problema técnico. Es problema de oferta
y estructura. Y eso lo arregla creative strategy
+ media buyer trabajando juntos, no un fichaje.

Cómo lo hacemos en MLO:

Empezamos por Jump Start Program — 4 semanas para
diagnosticar oferta, hacer KPI panel real,
estructurar la cuenta, y dejar al equipo del cliente
con un manual operativo claro.

Si los 3 patrones de arriba te suenan, esto te aplica.

🎯 Tengo 2 slots para arrancar en julio.

Si quieres ver si encajamos: agenda 15 min aquí.
[LINK]

Sin venta dura. Si veo que no encajamos, te digo.
Y volvemos al valor el lunes.

Marcel

PD: si los patrones NO te suenan, ignora este email.
Volvemos a deep dive el lunes con framework de cohort
analysis para Klaviyo.
```

---

## Reglas duras del email de venta

- **UNA sola CTA.** Una. No tres.
- **Escasez REAL.** Si dices 3 slots, son 3 slots. No invento.
- **No prometer resultado.** "Aprendí a calmar el growth en 24 marcas". No "Te garantizo +50%".
- **No insultar al lector.** Ni a los media buyers, ni a la competencia, ni a "los gurús".
- **Storytelling real al inicio.** Si es inventado, se nota.
- **Si NO encaja, dilo.** Genera confianza brutal.
- **La PD compensa.** Para los que no clican: prometer valor el próximo lunes los retiene.

---

## Variantes según tipo de oferta

### (A) Auditoría gratuita
- Más suave, "agenda 15 min y la grabamos".
- Menos escasez.
- CTA puede ser dos pasos: responde + agendamos.

### (B) Programa de pago (Jump Start, mentoría)
- Más estructurado. Decir cuánto cuesta o link a pagina con precio.
- Escasez real (slots por mes).

### (C) Recurso gratuito con captación de email (lead magnet)
- Más ligera. Solo entrega del recurso. Sin venta.
- Cuenta como valor del ciclo, NO como venta.

### (D) Apertura de lista para servicio
- "Estoy abriendo cupo para 1 nueva marca este Q3."
- Más exclusivo. Filtro claro de a quién va.
