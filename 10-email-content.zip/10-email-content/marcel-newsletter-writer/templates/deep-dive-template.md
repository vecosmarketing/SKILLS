# Template: Deep Dive (LUNES — 600-900 palabras)

**Cuándo usar:** lunes. Tema central de la semana. Framework completo con ejemplos. Suele expandir un post viral de LinkedIn.

---

## Estructura

### 1. Asunto + Pre-header
- 3 propuestas de asunto (ver `references/subject-lines.md`).
- Pre-header complementa, no repite.

### 2. Hook (1-3 frases)
- Afirmación contraintuitiva, dato fuerte, o referencia al post viral.
- NO saludo, NO "hoy te traigo".

### 3. Contexto (1-2 párrafos cortos)
- De dónde sale esto. Caso real, observación de cliente, conversación reciente.
- Por qué importa AHORA al lector.

### 4. La tesis (1 párrafo, negrita en frase clave)
- En 2-3 frases, la idea central que vas a desarrollar.
- Spoiler arriba: el lector ya sabe la conclusión, ahora viene el cómo.

### 5. Desarrollo del framework (el grueso, 4-7 puntos numerados)
Cada punto sigue:
- **Subtítulo corto** (3-6 palabras).
- **1 frase de qué es.**
- **1-2 párrafos de cómo aplicar** (con verbos imperativos: "haz", "filtra", "ajusta").
- **1 ejemplo concreto** con marca/dato real cuando sea posible.
- **Anti-patrón** si aplica: "lo que NO funciona es X. Por esto:".

### 6. Recap accionable (lista corta)
- "Si te llevas 3 cosas de este email:"
- Punto 1, 2, 3 en una línea cada uno.

### 7. Cierre
- Frase que cierre en seco (NO "espero que…").
- Si CTA suave: pregunta abierta o "responde y dime".
- Si NO es turno de venta: dejar sin CTA comercial.

### 8. Firma
```
Marcel
```

### 9. PD (opcional)
- Link a post relevante de LinkedIn.
- O nada.

---

## Ejemplo de hook + tesis (referencia)

```
ASUNTO: 1.62x: por debajo, pierdes

Esta mañana revisé el dashboard de un cliente nuevo y vi
el ROAS rodando en 1.5x.

Lo paré.

Esto es lo que está pasando en el 70% de las cuentas
que abrimos: están dejando dinero encima de la mesa
porque NADIE les ha dado el Break Even ROAS de SUS productos.

Y sin eso, escalar es ruleta rusa.

Hoy te paso cómo lo calculamos en MLO en 5 minutos.
Y cómo lo usamos para decidir cuándo subir budget,
cuándo bajar, y cuándo parar.
```

---

## Notas de copy

- **Longitud objetivo: 600-900 palabras.** Si pasas de 1000, hay paja.
- **Negritas: 3-5 en todo el email.** En frases clave, no en palabras sueltas.
- **Listas: máximo 2 listas en todo el email.** Más, cansa.
- **Subtítulos de framework: máximo 6 palabras.** Si necesitas más, mal síntoma.
