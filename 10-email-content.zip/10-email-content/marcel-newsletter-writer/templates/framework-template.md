# Template: Framework (MIÉRCOLES — 400-600 palabras)

**Cuándo usar:** miércoles. Mecánica concreta, 4-7 pasos accionables. Más táctico que deep dive.

---

## Estructura

### 1. Asunto + Pre-header

### 2. Hook (1-2 frases)
- Problema o pregunta concreta del lector.
- Ejemplo: `¿Sabes cuánto le estás gastando a Meta en frío sin saber si ese ROAS te da margen?`

### 3. Mini-contexto (2-4 frases)
- Por qué este framework existe.
- En qué situación lo usas.

### 4. El framework (lista numerada de 4-7 pasos)
Cada paso:
- **Paso N: Verbo + objeto** (ej. `Paso 1: Calcular el Break Even ROAS`).
- 1-3 frases de qué hace y cómo.
- Si necesita explicación más larga → sub-bullet.

### 5. Caso de aplicación (1 párrafo)
- Cómo lo usaste en una marca real.
- Resultado.
- Sin nombres si es sensible: "marca de suplementos en España".

### 6. Cierre (1-2 frases)
- "Si te suena el problema, prueba el framework esta semana."
- "Si no encaja, dime por qué — me interesa saber dónde se rompe."

### 7. Firma + PD opcional

---

## Ejemplo de framework

```
ASUNTO: Framework de testing creativo en 5 pasos

Antes de tirar 2.000€ al mes en testing creativo,
hay 5 cosas que tienes que tener claras.

Si te saltas una, el test no mide lo que crees.

1. UNA variable por test
Hook, copy, ángulo, formato. Una. Cambiar dos
a la vez = no sabes qué movió la aguja.

2. Mismo budget mínimo por adset
Si dejas a Meta decidir, gasta todo en el ganador
de la primera hora. No es señal estadística, es CBO
funcionando.

[...continúa con pasos 3-5...]

En MUTO aplicamos esto en marzo. Pasamos de
testear 12 variaciones al mes (con conclusiones
flojas) a 4 tests al mes con learnings claros.

Resultado: doblamos AOV en 8 semanas.

Si lo pruebas esta semana, contéstame qué paso
te ha funcionado peor.

Marcel
```

---

## Notas

- **El framework debe ser repetible.** Si solo aplica a 1 contexto, no es framework.
- **Verbos imperativos.** "Haz", "calcula", "filtra", "ajusta".
- **Sin metáforas largas.** Ve al cómo.
