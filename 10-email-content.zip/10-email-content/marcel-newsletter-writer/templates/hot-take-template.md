# Template: Hot Take (MIÉRCOLES — 400-550 palabras)

**Cuándo usar:** miércoles. Opinión fuerte, contraintuitiva, ~10 minutos de escritura. Cierra debates. Genera respuestas.

---

## Estructura

### 1. Asunto + Pre-header
- Asunto contrario al consenso.
- Ej. `El ROAS está mintiendo`, `Tu media buyer no es el problema`.

### 2. Hook (1-2 frases)
- La opinión, soltada en seco.
- Sin matizar todavía.

### 3. La razón principal (2-3 párrafos)
- Por qué la opinión es verdadera.
- 1-2 ejemplos cortos para sostenerla.
- Tono: directo, sin disculpa.

### 4. La objeción anticipada (1 párrafo)
- "Vas a decirme: pero qué hay de X."
- Responder: por qué X no invalida el take.

### 5. Lo que SÍ funciona (1-2 párrafos)
- La alternativa que tú propones.
- Brevemente, sin convertir el hot take en framework.

### 6. Cierre con pregunta o desafío
- "¿En tu cuenta, qué te dice esto?"
- O afirmación final que cierra el debate: "Esto es lo que vemos en 24 marcas. Punto."

---

## Ejemplo

```
ASUNTO: El ROAS está mintiendo

El ROAS es la métrica más sobrevalorada
del marketing digital.

Y la peor para decidir si tu cuenta es rentable.

Aquí está la razón:

ROAS = Revenue / Ad Spend.
Pero el coste real de tu marca no es solo el ad spend.
Es: producto + envío + comisiones + opex + taxes.

Una marca con ROAS 2.5x puede estar perdiendo dinero
si el margen bruto es 35% y los costes operativos son
altos.

Y una marca con ROAS 1.8x puede estar ganando un 25%
neto si tiene margen del 65% y opex bajo.

El ROAS no te dice si ganas dinero.
Te dice cuánto facturas por cada euro de ads.
Son cosas distintas.

Vas a decirme: pero todos los media buyers reportan ROAS.

Sí. Porque es lo que Meta y Google te dan crudo.
Lo cómodo, no lo correcto.

Lo que sí funciona:

Calcular Break Even ROAS por producto.
Calcular Target ROAS por margen objetivo.
Reportar POAS (Profit On Ad Spend) en los weeklies con cliente.

Cuando empezamos a hacer esto con las marcas,
las conversaciones cambian.
El cliente deja de obsesionarse con un número
que no le dice nada y empieza a tomar decisiones
de verdad.

En la newsletter del lunes te paso el Break Even
calculator que usamos en 24 marcas.

Marcel
```

---

## Reglas

- **El hot take debe ser DEFENDIBLE.** Si no aguanta una sola objeción, no es hot take, es opinión vacía.
- **Datos reales o casos reales.** Sin ellos, suena a humo.
- **No insultes a la audiencia.** "Tu media buyer es un inútil" → ❌. "Tu media buyer no es el problema" → ✅.
- **No tengas miedo de decepcionar al lector con la verdad.** Es el sentido del hot take.
