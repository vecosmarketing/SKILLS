# Template: Recap (VIERNES — 300-450 palabras)

**Cuándo usar:** viernes. Email corto que recupera lo mejor de la semana en LinkedIn + insight extra exclusivo.

---

## Estructura

### 1. Asunto + Pre-header
- Asunto tipo: `Esta semana en LinkedIn: 3 cosas + 1 que no salió`.
- O número específico: `3 posts, 1 hot take, 0 paja`.

### 2. Hook (1 frase)
- `Esta semana en LinkedIn pasaron 3 cosas que quiero rescatar antes del finde.`
- O directamente: `Recap de la semana en 4 minutos:`.

### 3. Post 1 (mini-bloque)
- **Título del post / tema** en negrita.
- 1 frase de qué iba.
- **Insight extra:** 2-3 frases con algo que NO salió en el post original.
- (Opcional) Link al post si quieres mandar tráfico de vuelta.

### 4. Post 2 (mini-bloque, misma estructura)

### 5. Post 3 (mini-bloque, misma estructura)

### 6. El bonus exclusivo (1 párrafo)
- Algo que NO subiste a LinkedIn esta semana.
- Caso pequeño, pregunta de un cliente, learning operativo.
- Esto es lo que justifica el email para el suscriptor que ya ve LinkedIn.

### 7. Cierre
- `Buen finde.`
- O pregunta abierta: `¿Cuál te lleva pensando? Contéstame con un emoji.`

### 8. Firma

---

## Ejemplo

```
ASUNTO: Esta semana en LinkedIn: 3 cosas + 1 que no salió

Recap rápido de la semana. 3 posts que quiero rescatar
+ 1 cosa que no subí porque no me cabía.

1. POR QUÉ EL ROAS DE PLATAFORMA MIENTE
Hablé del problema de sumar ROAS de Meta + Google
sin contar el cruce de atribución. 800 likes,
muchos DMs con "esto es justo lo que necesito".

Extra que no cupo: en una marca, sumando ROAS
de plataformas teníamos 4.2x. Mirando blended
en Triple Whale, real era 2.6x. Toda la estrategia
de presupuesto estaba mal calibrada.

2. CÓMO ELEGIR LA OFERTA HERO EN PAID
Post sobre que el producto con peor unit economics
NO debe ser el de paid frío. Bastante debate
en comentarios.

Extra: la pregunta que me hicieron por DM 7 veces:
"¿y si mi bundle no convierte porque es más caro?".
Respuesta: convierte un 30% peor, sí. Pero el AOV
te compensa con creces. Hay que mirar profit por
visitante, no conversion rate.

3. NAMING CONVENTION META — LA QUE USAMOS EN 24 MARCAS
Compartí la convención completa. La gente la pidió
muchísimo en DM. Si te la perdiste:
TIPO_OBJETIVO_AUDIENCIA_CREATIVO_FECHA.

Extra: tip pequeño que no metí. Si vas a usar
emojis en el naming, hazlo SOLO en el campo CREATIVO,
nunca en TIPO o OBJETIVO. Los filtros de Meta a veces
los cortan.

—

Bonus exclusivo, lista:

Un cliente nuestro hizo Summer Sale ayer con cupón
de 72 horas. Vendió el 70% de los cupones en 3 días.
La clave NO fue el descuento. Fue tener 6 lives
de aniversario en paralelo conectando con la comunidad.

El descuento abre el carrito. La comunidad lo cierra.

Buen finde,
Marcel
```

---

## Reglas

- **Corto. NO pasar de 450 palabras.** El viernes nadie lee largo.
- **El bonus exclusivo es lo más importante.** Es lo que justifica el email para suscriptores LinkedIn-aware.
- **No mandar al lector a LinkedIn salvo que NECESITE el contexto.** El email es destino, no trampolín.
