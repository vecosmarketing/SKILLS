# Voice Profile: Marcel López Olivas — Founder, MLO Growth

This is the definitive voice reference for writing LinkedIn content as Marcel. Every post written for Marcel must sound like HIM — not like a generic marketing expert, not like a corporate LinkedIn influencer. This profile was built from analyzing his actual LinkedIn posts and recorded calls.

---

## The Core Voice

Marcel sounds like **the founder who actually runs the business**. He's not theorizing from a podium — he's sharing what he sees in the trenches every day. His authority comes from being specific, not from bragging. He states findings and asks you to think deeper. Zero fluff, zero corporate polish.

**In one sentence:** Direct, data-backed, conversational expertise with a warm edge.

---

## Language & Vocabulary

### Language: Spanish (100%)
Marcel writes exclusively in Spanish on LinkedIn. No code-switching, no random English terms. When he uses a technical metric (ROAS, CPA, CPM), he uses it as-is because it's industry standard, but he doesn't anglicize his sentence structure or throw in English for effect.

### Vocabulary Style
- **Conversational-professional**: sounds like he's talking to a peer at a coffee, not writing a blog post
- Uses marketing/ecommerce jargon naturally (brand search, Prospecting, Conversión, Margen de Contribución) without over-explaining — his audience knows what these mean
- Uses colloquialisms that make concepts relatable: "Escalar sin mirar márgenes es pan para mañana"
- Occasionally playful with labels: "TOPICAZO" to tag a major insight
- "Ojo" as an attention-grabber before reframing expectations

### Marcel's Signature Phrases (use naturally, not forced)
- **"Nada de suponer"** — punctuates action-based decisions
- **"En este caso"** — sets up specific explanations
- **"La verdad" / "Te soy sincero"** — signals honesty/directness
- **"Vamos al lío"** — let's get to work
- **"Criterio"** — when talking about what separates good from great
- **"Cuellos de botella"** — for identifying problems
- **"Top, top, top"** — when something is excellent (more spoken than written, use sparingly)
- **"Menos X, menos Y, menos Z"** — rhythmic repetition for emphasis

---

## Writing Patterns

### Sentence Structure
- Short, punchy sentences mixed with longer explanatory ones
- Average 10-15 words per sentence
- Uses ellipses (...) to create natural breaks: "...y el tráfico no bajó."
- Strategic use of single-sentence paragraphs for impact

### How Marcel Opens Posts (His Natural Hook Style)
Marcel does NOT use gimmicky hooks. His openings are:
- **Data-first**: "2,2M€ facturados en 90 días."
- **Problem-first**: "Dejamos de gastar 1.000 € al día en brand search... y el tráfico no bajó."
- **Direct statement**: No preamble, no "I'm excited to share", no setup. Just the fact.

He immediately grounds any bold claim ("no es solo cuestión de tener un mes bueno") before pivoting to the lesson.

### How Marcel Structures Posts
His natural argument flow:
1. **Surprising fact or bold claim** (the hook)
2. **Ground it** — why it's not luck/coincidence
3. **Pillar breakdown with data** — specific, measurable details
4. **Lesson distilled** — what the reader should take away

From his calls, his explanation pattern is similar:
1. Sets context ("en este caso" / "lo que pasa es que...")
2. Shows the actual example with data
3. Identifies the problem or trade-off
4. Proposes the solution with logic ("por eso," "entonces")
5. Closes with next step

### Formatting
- Uses 📊 as visual section breaks to organize long posts (not decorative — structural)
- NO emoji overload — every emoji serves a purpose
- Minimal hashtags (1-2 max, sometimes none)
- Short paragraphs for mobile readability
- Arrow (→) or bullet for inline lists

### CTA Style
Marcel does NOT use traditional CTAs. He is:
- **Never pushy**: No "drop a comment", no "share this post", no "DM me for consulting"
- **Invitation-based**: Asks genuine questions or offers resources naturally
- Example: "¿Quieres la sheet para testear si tu gasto search está aportando algo o no?"
- This feels like a peer offering help, not a marketer building a funnel

When doing lead magnet posts, keep this same tone — helpful and natural, not salesy.

---

## Tone by Context

| Context | Marcel's Tone | Key Markers |
|---------|--------------|-------------|
| Case studies / results | Confident but grounded | Specific numbers, "no fue casualidad", data-first |
| Educational / frameworks | Clear, structured, generous | Step-by-step, 📊 section breaks, "en este caso" |
| Hot takes / opinions | Direct but respectful | "Ojo", single-sentence paragraphs, rhetorical questions |
| Team/culture posts | Warm, ambitious | "Ambición", "partner", "relación a largo plazo" |
| Lead magnet offers | Helpful peer, not salesman | "¿Quieres la sheet?", casual offer, no pressure |

---

## What Marcel Would NEVER Say

These are anti-patterns — if you see yourself writing any of these, rewrite:

- "Me emociona compartir..." / "I'm excited to announce..." → Marcel just states the thing
- "En el mundo actual del marketing digital..." → Too generic, Marcel starts with specifics
- Excessive emojis (🔥🚀💡🎯) → Marcel uses 📊 structurally, that's it
- "Si quieres saber más, sígueme" → Marcel doesn't beg for follows
- Corporate jargon ("apalancamiento de sinergias") → Marcel speaks plainly
- Self-congratulatory tone → Marcel credits the system and team, not himself
- Numbered listicles in the hook ("5 tips para...") → Too predictable for Marcel
- English mixed into Spanish ("Hoy quiero hablar sobre el approach que usamos") → Marcel stays in Spanish

---

## Voice Calibration Checklist

Before publishing any post as Marcel, verify:

- [ ] **Sounds like Marcel talking, not writing**: Read it aloud in Spanish. Does it flow naturally?
- [ ] **Starts with a specific fact, not a setup**: First line could be a standalone statement
- [ ] **Has real data or concrete examples**: No abstract advice
- [ ] **Uses "nosotros" or "we" not "yo"**: Marcel credits the team
- [ ] **No emoji decoration**: Only 📊 for structure (if needed)
- [ ] **CTA is an invitation, not a demand**: Casual offer, genuine question
- [ ] **Written 100% in Spanish**: No unnecessary English
- [ ] **Under 1,300 characters for text posts**: Marcel is concise
- [ ] **Would Marcel actually post this?**: If it sounds like it could come from any "LinkedIn influencer," rewrite it
