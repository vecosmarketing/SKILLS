# Content Pillar Examples — LinkedIn for Ecommerce

Three example posts for each major content pillar. These demonstrate the tone, structure, and specificity level expected from this skill.

---

## Pillar 1: Creative Strategy

### Example 1.1 — Text Post (PAS Structure)
```
Most ecommerce brands test creatives wrong.

They launch 5 ads, wait a week, pick the "winner."

Then wonder why performance doesn't improve.

The problem isn't the creatives. It's the system.

Here's what top-performing brands do instead:

→ They test one variable at a time (hook, body, CTA)
→ They define kill criteria BEFORE launching (CPA > $X after $Y spend = off)
→ They run 15-20 concepts per week, not 3-5
→ They categorize every test by angle, not just by format
→ They track creative fatigue signals (frequency > 3, CTR drop > 20%)

The brands spending $500K+/month on Meta aren't better at making ads.

They're better at systematically finding what works.

What does your creative testing system look like?

#creativestrategy #metaads #ecommerce #dtcbrands
```

### Example 1.2 — Carousel Outline (Framework Drop)
```
SLIDE 1 (Cover): "The Creative Audit Framework We Use for Every Client"
SLIDE 2: "Most agencies look at ad performance. We look at creative patterns."
SLIDE 3: "Step 1: Executive Creative Summary → What's working and WHY (not just what has low CPA)"
SLIDE 4: "Step 2: Awareness Level Split → Unaware / Problem-Aware / Solution-Aware / Product-Aware — Where are most purchases coming from?"
SLIDE 5: "Step 3: Format Split → UGC vs Static vs High Production vs Mashup — Which FORMAT is driving results?"
SLIDE 6: "Step 4: Persona Analysis → Which customer personas respond to which messages?"
SLIDE 7: "Step 5: Hook Pattern ID → The 3 hooks that drive 80% of engagement"
SLIDE 8: "Step 6: New Concept Directions → Data-backed hypotheses for next round of tests"
SLIDE 9: "This system has helped us improve creative hit rates from ~8% to 25%+ for our clients."
SLIDE 10: "Want the full Creative Audit template? Comment 'AUDIT' and I'll DM it to you. Follow for more ecommerce breakdowns."
```

### Example 1.3 — Text Post (Contrarian Take)
```
Hot take: Your creative team doesn't need more designers.

They need a better brief.

After auditing 40+ ecommerce brands, I've noticed a pattern:

The brands with the BEST ads don't have the most talented designers.

They have the most specific creative briefs.

A great brief includes:
→ The exact customer persona (not "women 25-45")
→ The awareness level (are they problem-aware or product-aware?)
→ The specific desire or objection to address
→ 3-5 reference ads that show the direction
→ Clear success metrics and kill criteria

A mediocre designer with a great brief will outperform a great designer with "just make something cool."

Every time.

Agree or disagree? I'll debate you in the comments.

#creativestrategy #ecommerce #facebookads
```

---

## Pillar 2: Performance & Metrics

### Example 2.1 — Text Post (Data Story)
```
We cut CPA by 43% for a skincare brand last month.

We didn't change the ads.
We didn't change the audience.
We didn't increase budget.

We rebuilt the landing page.

Here's what we changed:

Old page: Homepage → full product catalog → hope they buy

New page: Dedicated LP → single product → one clear CTA

The specifics:

→ Removed navigation menu (bounce rate dropped 28%)
→ Added social proof above the fold (3 review quotes, not a carousel)
→ Simplified from 5 CTAs to 1
→ Added urgency (stock counter, not fake — real Shopify inventory)
→ Mobile-first design (their audience is 73% mobile)

Result:
- Conversion rate: 1.8% → 4.2%
- CPA: $67 → $38
- Same ad spend, 43% more purchases

Your ads might not be the bottleneck.

Your post-click experience probably is.

Save this for your next landing page rebuild.

#ecommerce #cro #landingpages #metaads
```

### Example 2.2 — Text Post (Framework)
```
The only 5 metrics that matter when scaling ecommerce.

(Stop looking at 47 different dashboards)

1. **MER** (Marketing Efficiency Ratio)
Total revenue ÷ Total ad spend.
Not platform-reported ROAS. TOTAL business efficiency.
Why: It tells you if your WHOLE machine is working, not just one channel.

2. **New Customer CPA**
Cost to acquire a genuinely NEW customer.
Why: Blended CPA includes returning customers and hides real acquisition cost.

3. **60-Day LTV**
Revenue per customer in their first 60 days.
Why: If LTV > CPA, scale aggressively. If not, fix retention before spending more.

4. **Creative Win Rate**
% of new creatives that beat your CPA target.
Why: If it's below 15%, your creative system needs work.

5. **Contribution Margin**
Revenue - COGS - Ad Spend - Shipping = what you actually keep.
Why: Revenue means nothing if you're not profitable.

Everything else is noise until these 5 are healthy.

What metrics does your team track daily?

#ecommerce #performance #dtcbrands #growth
```

### Example 2.3 — Carousel Outline (Data Breakdown)
```
SLIDE 1: "We Analyzed 30 Ecommerce Brands' Q4 Performance. Here's What Separated Winners from Losers."
SLIDE 2: "The top 10 brands grew revenue 85% YoY. The bottom 10 were flat or declined. Same market. Same tools. What was different?"
SLIDE 3: "Finding #1: Winners spent 60%+ of budget on prospecting. Losers over-indexed on retargeting (45%+ of spend)."
SLIDE 4: "Finding #2: Winners had 3x more creative variants live at any given time. Volume > perfection."
SLIDE 5: "Finding #3: Winners' email revenue was 30-40% of total. Losers relied on paid for 80%+."
SLIDE 6: "Finding #4: Winners had dedicated landing pages per campaign. Losers sent everything to the homepage."
SLIDE 7: "Finding #5: Winners reviewed creative performance WEEKLY. Losers did monthly 'check-ins.'"
SLIDE 8: "The pattern is clear: Winners build SYSTEMS. Losers rely on tactics."
SLIDE 9: "Which group does your brand fall into?"
SLIDE 10: "Follow for weekly ecommerce breakdowns backed by real data."
```

---

## Pillar 3: Case Studies & Results

### Example 3.1 — Text Post (SLA Structure)
```
A client came to us with a 0.8x ROAS.

They were about to turn off Meta Ads entirely.

"We've tried everything," they said.

They hadn't.

Here's what we found in the audit:

Their account had 47 active campaigns.
One campaign had 80% of the spend.
That campaign was targeting the same audience with the same 3 ads for 6 months.

Frequency was 8.7. Creative fatigue was off the charts.

What we did:

Week 1: Consolidated to 3 campaigns (prospecting, retargeting, retention)
Week 2: Launched 15 new creative concepts based on our Creative Audit framework
Week 3: Built dedicated landing pages for top 3 products
Week 4: Implemented proper attribution (Shopify + UTMs + post-purchase survey)

Day 30 results:
→ ROAS: 0.8x → 2.1x
→ CPA: $94 → $47
→ Revenue: +127%
→ Same budget

Day 60:
→ ROAS: 2.8x (and climbing)

The lesson: "Nothing works" usually means "we kept doing the same thing and expecting different results."

If your ROAS is stuck, it's almost never a platform problem.

It's a structure + creative problem.

#ecommerce #metaads #casestudy #growth
```

### Example 3.2 — Text Post (Behind the Scenes)
```
We just onboarded a new ecommerce client.

Here's exactly what happens in the first 7 days:

Day 1: Discovery call
→ We map their entire customer journey
→ Current metrics, goals, pain points
→ Access to Shopify, Meta, Klaviyo, GA4

Day 2: Full audit
→ Ad account structure review
→ Creative performance analysis
→ Landing page conversion audit
→ Email flow assessment

Day 3: Strategy presentation
→ What's broken (with data)
→ What's working (don't fix this)
→ 90-day roadmap with weekly milestones

Day 4-5: Foundation rebuild
→ Simplify campaign structure
→ Fix tracking/attribution
→ Brief first round of new creatives

Day 6-7: Launch
→ New campaigns go live
→ First creative tests running
→ Reporting dashboard set up

By day 7, they have:
✓ Clean account structure
✓ Fresh creatives in market
✓ Working attribution
✓ Clear KPIs and targets
✓ Weekly optimization schedule

That's what a proper onboarding looks like.

What does your agency's first week look like?

#agencylife #ecommerce #onboarding #growth
```

### Example 3.3 — Carousel Outline (Before/After)
```
SLIDE 1: "From $30K/mo to $300K/mo in 90 Days. Here's the Exact Playbook."
SLIDE 2: "THE BRAND: Supplements DTC brand. Single hero product. US market. Starting point: $30K/month revenue, 1.1x ROAS."
SLIDE 3: "MONTH 1 — Foundation. Consolidated 12 campaigns → 3. Launched 20 new creative concepts. Built 3 dedicated landing pages. Result: Revenue hit $75K. ROAS: 1.8x"
SLIDE 4: "MONTH 2 — Scale Creative. Identified top 3 winning hooks. Created 30 variations of each. Introduced UGC testimonial format. Result: Revenue hit $150K. ROAS: 2.4x"
SLIDE 5: "MONTH 3 — Full Scale. Increased budget 3x on proven creatives. Launched email flows (welcome, abandoned cart, post-purchase). Added Google Shopping as secondary channel. Result: Revenue hit $300K. ROAS: 2.8x. Email = 28% of revenue."
SLIDE 6: "KEY INSIGHT: We didn't scale budget first. We scaled creative volume first. Budget followed performance."
SLIDE 7: "The 3 things that mattered most: (1) Creative testing velocity (2) Landing page optimization (3) Email capturing what paid media attracted"
SLIDE 8: "Want the full scaling checklist? Comment 'SCALE' and I'll DM it to you."
```

---

## Pillar 4: Frameworks & Methodologies

### Example 4.1 — Carousel Outline
```
SLIDE 1: "The ICE Framework for Prioritizing Growth Experiments"
SLIDE 2: "Too many ideas. Limited resources. How do you decide what to work on first?"
SLIDE 3: "ICE = Impact × Confidence ÷ Effort. Score each idea 1-10 on three dimensions."
SLIDE 4: "IMPACT: How much will this move the needle? 10 = doubles revenue. 1 = marginal improvement."
SLIDE 5: "CONFIDENCE: How sure are you it'll work? 10 = proven by data. 1 = gut feeling."
SLIDE 6: "EFFORT: How much does it take? 10 = months of work. 1 = can do it today. (Note: LOWER effort = HIGHER priority)"
SLIDE 7: "Example: 'Build dedicated landing page for hero product' → Impact: 8 | Confidence: 7 | Effort: 3 → Score: 18.7"
SLIDE 8: "Example: 'Complete brand redesign' → Impact: 6 | Confidence: 4 | Effort: 9 → Score: 2.7"
SLIDE 9: "Run this exercise with your team every month. It eliminates debates and keeps focus on high-leverage actions."
SLIDE 10: "Want the ICE scoring spreadsheet? Comment 'ICE' and I'll DM it."
```

---

## Pillar 5: Hot Takes & Debates

### Example 5.1 — Text Post
```
Unpopular opinion: Most ecommerce brands should spend LESS on ads.

Not because ads don't work.

Because they're spending on ads INSTEAD of fixing their funnel.

I see it constantly:

→ Spending $50K/month on Meta with a 1.5% landing page conversion rate
→ Zero email flows beyond "thanks for your order"
→ Homepage as the primary landing page for every campaign
→ No post-purchase upsell or cross-sell

Fix those four things FIRST.

Then your $50K in ad spend will generate 3-4x more revenue without changing a single ad.

Ads amplify what works.

If your funnel is broken, ads just amplify the break.

Controversial? Maybe. But I've seen this play out with 40+ brands.

What's the one thing you'd fix before increasing ad spend?

#ecommerce #unpopularopinion #growth #marketing
```
