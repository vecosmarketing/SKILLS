# LinkedIn Hook Swipe File — Ecommerce & Growth Marketing

50+ proven hook templates organized by type. Each hook follows the 3-line technique: Line 1 (max 62 chars) + empty line + Line 2 (max 50 chars).

---

## Category 1: Data & Numbers Hooks

These work because specific numbers signal credibility and trigger curiosity.

```
We spent $500K on Meta Ads last month.

Here's what nobody tells you about scaling.
```

```
I analyzed 200 ecommerce ad accounts.

The top 10% all do this one thing differently.
```

```
Our client went from $30K/mo to $300K/mo.

It took 90 days and zero new products.
```

```
ROAS dropped from 4x to 1.2x overnight.

Here's exactly how we fixed it in 48 hours.
```

```
We tested 47 ad hooks in 14 days.

3 patterns drove 82% of all purchases.
```

```
$0 ad spend. $127K in revenue.

Here's the email flow that did it.
```

```
CPA went from $85 to $22 in 3 weeks.

We changed exactly one thing.
```

```
I audited a $10M ecommerce brand yesterday.

They were making this mistake on every single ad.
```

---

## Category 2: Contrarian / Hot Take Hooks

These work because they challenge conventional wisdom and spark debate.

```
Scaling your ad spend is the worst way to grow.

Here's what actually moves the needle.
```

```
Stop optimizing for ROAS.

The metric that actually predicts growth is different.
```

```
Your "best" ad creative is probably killing your account.

Here's how to know for sure.
```

```
Broad targeting isn't dead.

You're just doing it wrong.
```

```
The brands scaling fastest right now aren't running more ads.

They're doing something most agencies ignore.
```

```
Attribution is a lie.

And it's costing you thousands in bad decisions.
```

```
Your creative team doesn't need more talent.

They need a better system.
```

```
Email marketing isn't boring.

It's the highest-ROI channel you're neglecting.
```

---

## Category 3: Story / Vulnerability Hooks

These work because they create emotional connection and authenticity.

```
I almost lost our biggest client last month.

Here's the mistake I made and what saved it.
```

```
3 years ago I was running ads from my bedroom.

Last month our agency managed $4M in ad spend.
```

```
The worst campaign I ever launched taught me everything.

Here's the story.
```

```
A client fired us after 2 weeks.

6 months later, they came back. Here's why.
```

```
I've made every media buying mistake possible.

Here are the 5 that cost the most money.
```

```
My first ecommerce brand failed spectacularly.

The lesson was worth more than the loss.
```

---

## Category 4: Framework / Process Hooks

These work because they promise a clear, actionable system.

```
The 3-step creative testing framework we use for every client.

It's stupidly simple. And it works every time.
```

```
Here's exactly how we audit a new ad account.

Day 1 through Day 7, step by step.
```

```
The 5-5-5 method for scaling Meta Ads.

We've used it to scale 30+ ecommerce brands.
```

```
Our email flow template generates $50K+/month.

Here's the exact structure, flow by flow.
```

```
The creative brief template behind our best-performing ads.

Takes 10 minutes. Changes everything.
```

```
How to build a media buying dashboard in 30 minutes.

The one we use for every single client.
```

---

## Category 5: Before/After Hooks

These work because they show transformation and proof.

```
Before: $15K/month revenue. After: $150K/month.

Same product. Same audience. Different strategy.
```

```
6 months ago this brand had a 0.8x ROAS.

Today it's 3.4x. We changed one thing.
```

```
January: 200 orders. March: 2,000 orders.

Here's the exact scaling playbook we used.
```

```
Their landing page converted at 1.2%.

We rebuilt it. Now it converts at 4.8%.
```

```
Email was generating 8% of revenue.

We rebuilt their flows. Now it's 35%.
```

---

## Category 6: Question Hooks

These work because they trigger self-reflection and engagement.

```
What if your ads aren't the problem?

What if it's everything that happens AFTER the click?
```

```
Why do some brands scale to $1M/month easily...

While others plateau at $50K no matter what they try?
```

```
Are you actually testing creatives?

Or are you just launching random ideas and hoping?
```

```
What's your creative kill criteria?

If you don't have one, you're wasting at least 30% of spend.
```

---

## Category 7: List / Listicle Hooks

These work because they set clear expectations and promise density.

```
7 ecommerce metrics that actually matter.

(Hint: ROAS isn't #1)
```

```
5 email flows every ecommerce brand needs.

Most brands are missing at least 2 of these.
```

```
The 3 landing page elements that drive 80% of conversions.

Everything else is noise.
```

```
8 creative angles that work in every niche.

Tested across 50+ ecommerce brands.
```

---

## Category 8: Lead Magnet Hooks

These work because they promise immediate, tangible value.

```
I built the Meta Ads creative tracker we use for all our clients.

Comment "TRACKER" and I'll DM it to you (free).
```

```
Our email marketing audit checklist catches $50K+ in missed revenue.

It's 47 questions. DM me "AUDIT" for the free copy.
```

```
The exact spreadsheet we use to plan $500K+ in monthly ad spend.

Comment "BUDGET" and it's yours.
```

```
I compiled every winning ad hook from our top 10 accounts.

87 hooks. One swipe file. Comment "HOOKS."
```

---

## How to Use These Hooks

1. **Pick a hook that matches your content type** (data hook for metrics posts, story hook for case studies, etc.)
2. **Customize with YOUR specific numbers and context** — generic hooks don't work. "We spent $500K" is better than "We spent a lot"
3. **Test hooks against each other** — write 3 hook options for each post and pick the one that would make YOU stop scrolling
4. **Track what works** — note which hook types get the most engagement for your specific audience
