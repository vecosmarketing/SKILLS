# Carousel Creation Guide for LinkedIn

Carousels are the highest-performing content format on LinkedIn (596% more engagement than text-only posts). This guide covers how to create carousels that get saved, shared, and generate leads.

## Anatomy of a High-Performing Carousel

### Slide Count
- **Sweet spot**: 7-10 slides
- **Minimum**: 5 slides (fewer feels incomplete)
- **Maximum**: 12 slides (beyond that, completion rate drops)
- Remember: LinkedIn's algorithm now tracks "consumption rate" — a 7-slide carousel that people finish beats a 15-slide carousel that people abandon.

### Slide 1: The Cover (Hook Slide)

This is the most important slide. It appears in the feed and determines whether someone swipes.

**Elements:**
- **Headline**: 5-8 words maximum. Bold, specific, curiosity-driven.
- **Subheadline** (optional): One line that adds context or stakes
- **Visual**: Clean background, high contrast, readable on mobile (remember 57% of LinkedIn is mobile)
- **Author branding**: Small logo or name in corner (builds recognition over time)

**Cover slide formulas:**

| Formula | Example |
|---------|---------|
| Number + specific promise | "7 Meta Ad Hooks That Generated $2M in Revenue" |
| How to + specific outcome | "How to Cut Your CPA in Half Without Reducing Spend" |
| The [framework] for [result] | "The 3-3-3 Framework for Scaling Creative Production" |
| [Thing] is dead. Here's what works. | "Broad Targeting is Dead. Here's What's Replacing It." |
| I [did thing]. Here's what I learned. | "I Audited 50 Ecommerce Ad Accounts. Here's What the Top 10% Do Differently." |

### Slides 2-8: The Content Slides

**One idea per slide.** This is the golden rule. If a slide tries to communicate two things, split it into two slides.

**Content slide structure:**
- **Heading**: 3-6 words that name the concept
- **Body**: 15-30 words maximum that explain it
- **Visual element** (optional): Icon, simple diagram, or data point
- **Slide number**: Bottom corner (helps readers know where they are)

**Writing tips:**
- Use fragments and short sentences, not full paragraphs
- Lead with the insight, not the setup
- Use "→" to show cause and effect
- Bold or color the most important phrase on each slide
- Every slide should make sense even if read in isolation

### Slide 9-10: The CTA Slides

**Second-to-last slide**: Summarize the key takeaway in one sentence. This is what people screenshot.

**Last slide**: Clear call to action:
- "Follow [name] for more ecommerce breakdowns"
- "Comment 'TEMPLATE' and I'll DM you the free version"
- "Save this for your next campaign launch"
- "Share this with your media buyer"

---

## Carousel Content Templates

### Template 1: The Framework Breakdown
1. Cover: "[Number] Steps to [Desired Outcome]"
2. Context slide: Why this matters / the problem it solves
3-8. One step per slide
9. Summary / recap slide
10. CTA

### Template 2: The Case Study
1. Cover: "How [Brand] Achieved [Result] in [Timeframe]"
2. The situation / starting point (with numbers)
3. The problem / challenge
4-7. What we did (one action per slide)
8. The results (with specific metrics)
9. Key takeaway
10. CTA

### Template 3: The Myth Buster
1. Cover: "[Number] [Topic] Myths That Are Costing You Money"
2-8. One myth per slide: "Myth: [common belief]" → "Reality: [truth with data]"
9. Summary of what to do instead
10. CTA

### Template 4: The Comparison
1. Cover: "[Option A] vs [Option B]: Which Actually Works?"
2. Context: Why this comparison matters
3-4. Option A breakdown (pros, cons, when to use)
5-6. Option B breakdown (pros, cons, when to use)
7. Side-by-side comparison (the money slide)
8. The verdict
9. When to use each
10. CTA

### Template 5: The Data Story
1. Cover: "We Analyzed [Number] [Things]. Here's What We Found."
2. Methodology (brief — 1 sentence)
3-7. One finding per slide with specific data
8. The surprising insight (save the best for last)
9. What to do with this information
10. CTA

---

## Design Principles

Since the user or a designer will create the visuals, provide these guidelines:

### Typography
- **Title font**: Bold, sans-serif, 28-36pt
- **Body font**: Regular weight, 18-24pt
- **Minimum readable size on mobile**: 16pt

### Colors
- Use the author's or brand's colors for consistency
- High contrast between text and background (dark on light or light on dark)
- Use accent color for emphasis (not more than 2 colors total)
- Avoid: gradients that reduce readability, low-contrast combinations

### Layout
- Keep text in the top 80% of the slide (bottom gets cropped in some feed views)
- Left-aligned text reads better than centered on mobile
- Consistent margins on all slides (minimum 40px from edges)
- White space is your friend — resist the urge to fill every pixel

### Branding
- Small, consistent logo or name placement (same position on every slide)
- Consistent color scheme across all slides
- Same layout grid throughout (builds visual rhythm)

---

## Carousel Post Text

The text that accompanies the carousel in the feed should:
1. **Repeat the hook** from slide 1 (many people read the text before swiping)
2. **Add context** that doesn't appear in the carousel
3. **Include the CTA** in the text as well (some people won't swipe to the last slide)
4. **Hashtags** at the end

**Example:**
```
We spent $2.3M on Meta Ads for DTC brands last quarter.

After analyzing every campaign, 7 hook patterns drove 80% of conversions.

I broke them down slide by slide ↓

(Save this for your next creative brief)

Comment "HOOKS" and I'll send you the full swipe file with 50+ examples.

#ecommerce #facebookads #creativestrategy #dtcbrands
```
