---
name: mlo-email-marketing-lab
description: >-
  Registra, enriquece y analiza las campañas de email de MLO Growth en el "Email Marketing Lab"
  de Notion (base compartida, filtrada por marca). Tres modos: LOG (apuntar una campaña con su
  tagging e hipótesis); ENRICH (para campañas enviadas, tirar de Klaviyo las métricas —Open %,
  CTR %, Unsub %, Conversiones, Revenue—, rellenarlas, pasar Estado a Enviado y redactar el
  aprendizaje); y ANALYZE (sacar mejores días, horas y temáticas por marca y escribir las
  conclusiones en Notion). ALWAYS use (ES/EN) cuando digan: "apunta esta campaña en el email lab",
  "registra/sube resultados de [marca]", "enriquece el email lab con Klaviyo", "analiza el email
  lab", "¿qué días/horas/temática funcionan mejor para [marca]?", "conclusiones de email de
  [marca]", "email marketing lab", "email lab". Trigger también para peticiones parciales sobre
  apuntar campañas, subir métricas de email desde Klaviyo o sacar aprendizajes de email de
  cualquier marca, aunque no se nombre el Lab ni Klaviyo.
---

# Email Marketing Lab

El **Email Marketing Lab** es el archivo cross-marca de campañas de email de MLO Growth en Notion.
Una sola base de datos (`📨 Campañas de Email`), filtrada por marca en cada portal de cliente. Cada
campaña se etiqueta antes de enviar, se enriquece con métricas de Klaviyo después de enviar, y la
tabla acumulada se explota para aprender qué funciona por marca.

Tu trabajo con esta skill es cubrir tres flujos según lo que pida Marcel:

- **LOG** — apuntar una campaña nueva (tagging + hipótesis), normalmente antes del envío.
- **ENRICH** — rellenar las métricas de campañas ya enviadas tirando de Klaviyo.
- **ANALYZE** — sacar conclusiones (mejores días, horas, temáticas) por marca.

El flujo real de Marcel es: **él apunta la campaña primero** (LOG), y **más tarde la skill tira los
resultados de Klaviyo** (ENRICH). No asumas que tienes que crear filas desde Klaviyo de cero: por
defecto enriqueces filas que ya existen.

## Cadencia — mensual, por marca

Esto **no es un ejercicio puntual**: se repite **cada mes con cada marca**. El ciclo mensual por
marca es LOG (apuntar las campañas del mes) → ENRICH (subir de Klaviyo las métricas de lo ya
enviado) → ANALYZE (sacar conclusiones) → actualizar la página `📈 Conclusiones — [Marca]`.

El objetivo es **acumular aprendizajes mes a mes**, no analizar un mes aislado:

- Identifica las **temáticas / ángulos / segmentos / días / horas ganadores para replicarlos** el
  mes siguiente, y los **perdedores para dejar de repetirlos** y liberar hueco.
- Cada mes se **testean opciones nuevas** (ángulos, horas, segmentos) para que el Lab tenga siempre
  variación con la que aprender. Tenlo presente al analizar: si todo se envía igual (misma franja,
  misma audiencia), no hay nada que comparar — señálalo y sugiere qué variar.
- Cuando Marcel pida el análisis mensual de una marca, **no describas solo el mes**: compáralo con
  los meses anteriores ya en el Lab (¿el ganador del mes pasado se replicó y aguantó?, ¿el test
  nuevo funcionó?) y cierra siempre con **qué replicar y qué descartar** el mes que viene.

## Identificadores fijos

- **Base de datos (data source):** `collection://e68ac3ea-1e4b-4f1a-8e1f-3651b5f952d5`
- **Página del Lab:** `3b86c997-7eb7-8141-a5c3-e00494b9fb16`

Usa el `data_source_id` `e68ac3ea-1e4b-4f1a-8e1f-3651b5f952d5` para crear, consultar y actualizar
filas. Los IDs pueden cambiar si se recrea la base; si una llamada falla por ID inválido, haz
`notion-search "Email Marketing Lab"` y `notion-fetch` de la página para recuperar el data source
actual antes de seguir.

## Esquema de la base (mapea los campos EXACTAMENTE)

Los nombres llevan acentos y espacios tal cual — cópialos literalmente o la escritura falla.

**Tagging (lo rellena LOG):**

- `Campaña` — *title*. Nombre de la campaña. Usa el mismo nombre con el que la marca la nombra en
  Klaviyo siempre que puedas: es lo que permitirá casarla después en ENRICH.
- `Marca` — *select*: `Moncho Moreno`, `Hobbitalf`, `Nurse is Love`. Lista ampliable: si la marca
  aún no existe como opción, ver "Marca nueva" abajo.
- `Estado` — *select*: `💡 Idea`, `✍️ En copy`, `📅 Programado`, `✅ Enviado`.
- `Tipo` — *select* (la "temática", clave para el análisis): `Educación`, `Social Proof`, `Venta`,
  `Promo`, `Lanzamiento`, `Bienvenida`, `Winback`, `Nurture`, `Fecha señalada`. Cómo elegir el
  Tipo → ver "Clasificar el Tipo por intención principal" en el Modo LOG.
- `Lifecycle` — *select*: `Bienvenida`, `Nurture`, `Conversión`, `Retención`, `Reactivación`.
- `Awareness` — *select*: `Unaware`, `Problem Aware`, `Solution Aware`, `Product Aware`, `Most Aware`.
- `Fecha envío` — *date* con hora. Guárdala **con hora** (`is_datetime = 1`) siempre que la sepas —
  el análisis de "mejor hora" depende de ello.
- `Producto`, `Segmento`, `ICP`, `Angulo` — *text* (fíjate: `Angulo` va **sin** acento en el esquema).
- `Hipótesis` — *text*. Qué espera Marcel que pase y por qué. Es el corazón del método: sin hipótesis
  no hay aprendizaje que contrastar.

**Métricas (las rellena ENRICH desde Klaviyo):**

- `Open %`, `CTR %`, `Unsub %` — *number* (porcentajes; guarda el número, p. ej. `42.3` para 42,3 %).
- `Conversiones` — *number*.
- `Revenue` — *number* (euros).

**Aprendizaje (lo cierra ENRICH):**

- `Aprendizaje` — *text*. Qué pasó vs. la hipótesis, en una o dos frases accionables.

**No tocar:**

- `Naming` — *formula*, de solo lectura. Nunca intentes escribirla; se calcula sola. Tampoco es
  consultable por SQL.

---

## Modo LOG — apuntar una campaña

Cuando Marcel describe una campaña ("apunta en el email lab la promo de rebajas de Hobbitalf que
sale el jueves a las 10h"), crea una fila nueva.

1. **Extrae lo que te dé y mapea a los selects.** No inventes tagging: si Marcel no dice el
   Awareness o el Lifecycle, no lo fuerces — pregunta solo por lo que de verdad falte y sea
   importante (Marca, Tipo y Fecha suelen ser lo mínimo útil). Marcel es directo y valora poca
   ida y vuelta: rellena lo evidente, confirma lo dudoso en una sola pregunta.
2. **Estado por defecto:** si no lo dice, dedúcelo — si describe una idea, `💡 Idea`; si ya tiene
   fecha puesta, `📅 Programado`. No lo marques `✅ Enviado` en LOG (eso lo hace ENRICH).
3. **Fecha con hora.** Si dice "jueves a las 10h", guárdala como datetime.
4. **Crea la fila** con `notion-create-pages`, parent `data_source_id`
   `e68ac3ea-1e4b-4f1a-8e1f-3651b5f952d5`. Ejemplo de properties:

```json
{
  "Campaña": "Rebajas 24h — 20% OFF",
  "Marca": "Hobbitalf",
  "Estado": "📅 Programado",
  "Tipo": "Promo",
  "Lifecycle": "Conversión",
  "Awareness": "Most Aware",
  "date:Fecha envío:start": "2026-08-20T10:00:00",
  "date:Fecha envío:is_datetime": 1,
  "Producto": "Snacks air-dried",
  "Segmento": "Compradores últimos 90 días",
  "Hipótesis": "Una promo con urgencia de 24h a Most Aware convierte mejor que educación"
}
```

5. **Confirma en una línea** qué apuntaste y con qué tagging. No narres el proceso.

### Clasificar el Tipo por intención principal

El `Tipo` se decide por el **objetivo principal del email**, no por si lleva o no un enlace de
producto (casi todos lo llevan). Regla de Marcel:

- **Educación** — el objetivo es enseñar algo (ciencia, tips, mitos, cómo funciona un ingrediente),
  aunque cierre con un CTA a un menú. Si el email educa y de paso enlaza producto, es Educación.
  Es la temática mayoritaria; no la descartes solo por llevar un CTA de venta.
- **Venta** — solo cuando el objetivo principal *es* empujar la compra de un producto o menú
  concreto (el email gira en torno a ese producto, no a un aprendizaje).
- **Fecha señalada** — email anclado a una fecha del calendario o día mundial (Día de la Madre,
  del Perro, del Gato, de las Mascotas, Medio Ambiente, Océanos, eclipse…). Va aquí tanto si es
  puramente emocional/branding como si lleva regalo o snack sorpresa; en ese caso, refleja la
  oferta en `Angulo`. Así el análisis aísla los envíos movidos por el calendario.
- **Lanzamiento** — estreno o novedad de producto/servicio (SuperToppers, Suscripción, nueva textura).
- **Social Proof** — testimonios o colaboraciones con voz externa (p. ej. el email del adiestrador).
- **Promo** — oferta o incentivo NO ligado a una fecha del calendario (descuento genérico, encuesta
  con 10 %, etc.). Si la oferta va atada a un día señalado, usa `Fecha señalada`, no `Promo`.

Ante la duda entre dos, pregúntate qué haría el lector si solo leyera el asunto y el hero: ¿aprender,
comprar, o celebrar una fecha? Esa es la intención principal.

---

## Modo ENRICH — tirar métricas de Klaviyo

Cuando Marcel pide subir/actualizar resultados ("sube los resultados de las campañas enviadas de
Nurse", "enriquece el email lab de Hobbitalf con Klaviyo").

**Precondición — la cuenta de Klaviyo correcta.** Cada marca tiene su **propia** cuenta de Klaviyo.
Antes de tirar datos, asegúrate de que la conexión de Klaviyo activa es la de esa marca (puedes
confirmarlo con la cuenta/perfil de Klaviyo). Si no coincide, dilo y pide a Marcel que conecte la
cuenta de la marca en cuestión — no mezcles métricas de otra marca. Solo hay **una** conexión de
Klaviyo activa a la vez: para cambiar de marca, Marcel desconecta Klaviyo y reconecta la cuenta de
la marca que toca. Una señal fácil de que estás en la cuenta correcta: los nombres de campaña que
devuelve Klaviyo coinciden con las campañas de esa marca (en Hobbitalf vienen como `06/05/26 -
¿Las has probado todas?`, con fecha + gancho).

**Principio — barrido completo hasta hoy, siempre.** Cada vez que enriquezcas una marca, **no
subas solo lo nuevo**: reconcilia TODO el histórico enviado hasta el presente. El objetivo de
Marcel es que el Lab esté **siempre completo y actualizado**, no que crezca a trozos. En concreto:

- La **fuente de verdad de qué se ha enviado** es la **lista de campañas** de Klaviyo con
  `status = Sent` (`get_campaigns` filtrando por canal email), NO un solo `get_campaign_report`
  con una ventana temporal: un reporte de "últimos 12 meses" u otra ventana puede **cortar y
  dejarse envíos recientes fuera** (le pasó a esta skill: un primer reporte se saltó todo agosto).
  Lista primero todo lo enviado, y para las métricas usa `get_campaign_report` cubriendo bien el
  rango (si dudas, tira reportes por tramos y únelos).
- **Refresca también las recientes que ya están en el Lab.** Revenue y conversiones siguen
  entrando durante la ventana de atribución, así que re-tira las métricas de las campañas enviadas
  en las últimas ~2–4 semanas aunque ya tuvieran datos, y actualízalas.
- Al terminar, **cuadra por conteo**: las filas `✅ Enviado` de esa `Marca` en el Lab deben igualar
  las campañas `Sent` de Klaviyo (menos exclusiones intencionadas, p. ej. envíos de setup sin
  temática). Si no cuadra, busca y añade lo que falte antes de dar por cerrado.
- Cierra siempre **refrescando la página `📈 Conclusiones — [Marca]`** al nuevo total.

1. **Reconcilia el Lab con lo enviado.** Trae de Klaviyo la lista completa de campañas `Sent` de
   la marca y compárala con las filas ya en el Lab (`notion-query-data-sources`, ver Modo ANALYZE).
   Trabaja sobre: las **enviadas que faltan** (crear ya enriquecidas) + las **recientes a
   refrescar** + las filas en `📅 Programado`/`✍️` cuya fecha ya pasó (ahora tienen métricas).
2. **Trae los datos de Klaviyo.** Haz `tool_search` de las herramientas de Klaviyo de reporting de
   campañas (get_campaigns / get_campaign_report y afines) y obtén, por campaña enviada:
   - Open rate → `Open %`
   - Click rate → `CTR %`
   - Unsubscribe rate → `Unsub %`
   - Conversions / Placed Order → `Conversiones`
   - Revenue (`conversion_value`) → `Revenue` (€)
   - **Unidades:** Klaviyo devuelve `open_rate` / `click_rate` / `unsubscribe_rate` como fracción
     0–1 — multiplícalas ×100 antes de guardarlas en los campos `%` (0.2098 → `20.98`). Usa la
     métrica de conversión **Placed Order**; su ID cambia por cuenta, así que sácalo con
     `get_metrics` en cada marca (no lo hardcodees).
   - **Audiencia → `Segmento`.** Guarda a quién se envió (lista completa vs. un segmento como
     `engaged 90 days`). Es imprescindible para el análisis: mezclar segmentos engaged con lista
     completa distorsiona cualquier conclusión (ver ANALYZE).
   - **Fecha y hora real de envío** → refresca `Fecha envío` con hora (`is_datetime = 1`) si en LOG
     solo se apuntó el día. Klaviyo guarda el timestamp exacto del envío; capturarlo es lo que
     habilita el análisis de "mejor hora" — sin él, ese corte queda vacío.
3. **Casa cada campaña de Klaviyo con su fila del Lab.** Empareja primero por **nombre de campaña**;
   si el nombre no coincide claro, usa la **proximidad de fecha de envío**. Si sigue habiendo
   ambigüedad (dos candidatas plausibles), pregunta a Marcel en vez de adivinar — un match erróneo
   contamina el análisis.
4. **Actualiza la fila** con `notion-update-page`: mete las métricas, pon `Estado` = `✅ Enviado`, y
   redacta un `Aprendizaje` corto contrastando el resultado con la `Hipótesis` que ya estaba escrita
   (p. ej. "La hipótesis se cumple: la promo con urgencia batió a educación en CTR y revenue").
5. **Resume** en chat qué campañas enriqueciste y con qué números clave. Si alguna candidata no
   tenía datos en Klaviyo todavía (recién enviada), déjala como estaba y dilo.

**Ojo con los opens (Apple MPP).** Las tasas de apertura de Klaviyo vienen infladas por Apple Mail
Privacy Protection. Guárdalas igualmente, pero cuando saques conclusiones (sobre todo de "mejor
hora"), apóyate más en clicks, conversiones y revenue que en opens. Deja constancia de esto si el
aprendizaje se basa en aperturas.

---

## Modo ANALYZE — sacar conclusiones

Cuando Marcel pregunta qué funciona ("¿qué días van mejor para Moncho?", "analiza el email lab de
Hobbitalf", "¿qué temática convierte más?").

1. **Consulta la tabla** con `notion-query-data-sources` sobre el data source, filtrando por `Marca`
   y por `Estado = '✅ Enviado'` (solo campañas con resultados). Recuerda:
   - La fecha se consulta con las columnas expandidas: `date:Fecha envío:start`, etc.
   - `Naming` no es consultable — no la incluyas en el SELECT.
2. **Agrega según la pregunta:**
   - **Mejor día de envío por marca** → agrupa por día de la semana (derivado de `date:Fecha
     envío:start`); compara CTR, conversiones y revenue medios.
   - **Mejor hora por día** → agrupa por franja horaria; apóyate en clicks/revenue, no solo opens.
   - **Temática que mejor funciona** → agrupa por `Tipo` (Venta, Educación, Social Proof…); mira
     CTR, conversiones y revenue.
   - Cruza también `Awareness` / `Lifecycle` / `Segmento` si la pregunta lo pide.
   - **Controla por audiencia antes de comparar días/horas/temáticas.** Un envío a un segmento
     engaged (p. ej. `engaged 90 days`) abre y convierte muchísimo más que uno a la lista completa
     — es efecto de la audiencia, no del día ni de la hora. No los promedies juntos: separa por
     `Segmento`. Para comparar rendimiento usa métricas de tasa (`CTR %`, `Open %`), que son
     comparables entre listas; recuerda que `Revenue` y `Conversiones` son absolutos y suben solo
     por tener más destinatarios. (Si en el futuro se añade un campo de destinatarios al Lab, se
     podrá normalizar por revenue-por-destinatario, que es el corte más justo.)
3. **Sé honesto con el tamaño de muestra.** Con pocas campañas por marca, "el mejor día" es ruido.
   Muestra **cuántas campañas** respaldan cada conclusión (N) y marca explícitamente cuando los
   datos son demasiado finos para concluir ("solo 2 campañas los martes — señal, no conclusión").
   No sobre-afirmes patrones que la muestra no aguanta: es lo que hace útil (y creíble) el Lab.
4. **Muestra en chat** las conclusiones de forma directa: titular accionable + los números que lo
   respaldan + el N.
5. **Escribe las conclusiones de vuelta en Notion.** Mantén una página de conclusiones bajo el Lab
   (`📈 Conclusiones — [Marca]`, hija de la página del Lab `3b86c997-7eb7-8141-a5c3-e00494b9fb16`).
   Si no existe, créala; si existe, actualízala con fecha y los aprendizajes vigentes. Así el Lab
   tiene memoria y el portal de cada cliente puede verla. Confirma a Marcel dónde quedó.

---

## Casos borde

- **Marca nueva.** Cuando Marcel conecte una marca que aún no está en el select `Marca`, hay que
  añadir la opción al esquema antes de crear filas (`notion-update-data-source` sobre el data
  source, añadiendo la opción al select `Marca`). Hazlo, avisa de que la añadiste, y sigue.
- **Campaña sin hipótesis.** Se puede apuntar, pero recuérdaselo suavemente: sin hipótesis, el
  ENRICH no tendrá contra qué contrastar el aprendizaje.
- **Backfill masivo de histórico** (p. ej. cargar un calendario entero de campañas ya enviadas
  desde un Google Doc). Cuando las campañas YA están enviadas, no las crees "vacías" para luego
  actualizarlas: crea cada fila **ya enriquecida** (Estado `✅ Enviado` + métricas de Klaviyo +
  Fecha/hora real) en un solo `notion-create-pages` en lote (acepta hasta 100 páginas). Menos
  llamadas y sin estado intermedio. Casa doc↔Klaviyo por fecha+gancho. Si una campaña del doc no
  aparece en Klaviyo, no la des por enviada: quizá no llegó a salir — apúntala como `📅 Programado`
  sin métricas o déjala fuera, pero no inventes números.
- **Métrica que Klaviyo no da para esa campaña** (p. ej. revenue si no hay tracking de conversión):
  deja el campo vacío en vez de meter un 0 que falsee las medias del análisis.
- **Idioma.** Responde en el idioma en que te escriba Marcel (ES por defecto). El contenido que
  escribas en Notion, en español.
