---
name: "kit-broadcast-scheduler"
description: "Crea/programa newsletters (broadcasts) en Kit (ConvertKit) por navegador de forma fiable. Usar cuando Marcel diga \"programa las newsletters en Kit\", \"sube los emails a Kit\", \"deja los broadcasts en Kit\", \"crea los borradores en Kit\", o cualquier petición de dejar emails montados/programados en Kit. Kit NO tiene API — todo por Claude in Chrome. Complementa marcel-newsletter-writer (redacción); esta skill es la de MONTAJE en Kit."
---

# Kit Broadcast Scheduler

Montar newsletters (broadcasts) en **Kit (ConvertKit)** por navegador, de forma fiable, sin corromper el cuerpo. Kit **no tiene API ni conector MCP** → todo se hace con **Claude in Chrome**. Esta skill es la de MONTAJE/PROGRAMACIÓN en Kit; la redacción la cubre `marcel-newsletter-writer`.

## Cuenta y fuentes

- **Cuenta Kit:** "Marcel Ecom" (lista personal de Marcel, ~458 subs). https://app.kit.com. Navegador ya logueado.
- **Contenido:** normalmente un doc de handoff con cada newsletter (asunto elegido + alternativos, pre-header, cuerpo completo, fecha L/X/V, tipo valor/vende), o la vista **📧 Newsletter** en Notion (base "Publicaciones (LinkedIn·YT·IG·TK)", filtro Canal = Newsletter).
- **Cadencia por defecto (desde ago 2026):** **2/semana, martes y viernes**, alternando **10:00 y 17:00 (Madrid)** para el test de hora de envío. Antes era 3/semana L/X/V a las 12:00.
- **Programar sí**, no dejar en borrador, salvo que Marcel diga lo contrario. **Excepción innegociable:** un email con un placeholder sin resolver (`[LINK AGENDA]`, `[X]`, etc.) **NUNCA se programa** — se deja en borrador y se avisa con la fecha límite.

## Cómo es el editor por dentro (verificado, ago 2026)

- El editor de cuerpo es **Slate**, no ProseMirror. Se localiza con `document.querySelector('[data-slate-editor]')`. Los párrafos son `<p>`, las viñetas `<li>`.
- Los `input` de asunto y pre-header son React controlados.
- La ventana del navegador y el screenshot no comparten escala: `k = 1288 / window.innerWidth` (≈0.747). Para convertir coordenadas CSS → coordenadas de click hay que multiplicar por `k`. Calcular siempre con `getBoundingClientRect()` en vez de hardcodear píxeles.

## ⚠️ Reglas críticas (leer antes de tocar nada)

1. **Flujo de un broadcast:** `/broadcasts` → **"New Broadcast"** → selector de plantilla (`/editor/starting-points`) → **"Plain Text" (Classic)** → se abre como **Draft** automático (`/campaigns/{id}/draft`). Auto-guarda, no hay que pulsar guardar.
2. **El cuerpo viene PRE-RELLENADO** con el texto de ejemplo de la plantilla ("Somos tan malos que somos muy buenos…"). Hay que **reemplazarlo entero**.
3. **BUG CLAVE — NO usar `cmd+a` + teclear en el cuerpo.** El texto se **inserta en medio de un bloque** en vez de reemplazar y queda mezclado con la plantilla. Prohibido el patrón "click + cmd+a + type" en el cuerpo. (Ya corrompió borradores.)
4. **El pegado de HTML NO funciona.** Si el portapapeles lleva `text/html`, Slate **no pega absolutamente nada** (ni siquiera cae al `text/plain` de respaldo). **Solo `text/plain`.** Las viñetas se aplican después, no vienen del pegado.
5. **Un salto de línea (`\n`) por párrafo.** Con `\n\n` se crean párrafos vacíos y el email queda con huecos dobles (así se veían los borradores corruptos antiguos).
6. **Asunto y pre-header: nunca justo después de crear el borrador.** React re-hidrata el formulario a los pocos segundos y **pisa lo que hayas escrito**. Ponerlos **después de pegar el cuerpo**, con la página ya asentada, y **verificar siempre leyendo el `value` del input**.
7. **El pre-header solo persiste si después tocas el cuerpo.** Escribirlo y navegar = se pierde. Hay que forzar un autosave tocando el body (p. ej. re-pegar el último párrafo) y esperar ~8s.
8. **"This broadcast is locked".** Si queda otra pestaña abierta con el mismo borrador, Kit lo bloquea y **los clicks dejan de responder sin error visible** (parece que el navegador falla, pero es el lock). Trabajar con **una sola pestaña**; si aparece el diálogo, "Take over editing" y cerrar la otra.
9. **Dejar como BORRADOR.** No pulsar Publish/Schedule/Send salvo petición explícita (entonces: Publish → Schedule, fecha indicada, hora 12:00 Europe/Madrid).

## Método fiable (probado con 12 newsletters seguidas)

### 1. Crear el borrador
Ir a `https://app.kit.com/editor/starting-points`, esperar ~8s y **clicar la plantilla por JS** (el click de ratón sobre la card falla ~50% de las veces: la primera vez solo la enfoca):

```js
[...document.querySelectorAll('button')]
  .find(x => x.textContent.trim().startsWith('Plain Text')).click()
```

### 2. Pegar el cuerpo (reemplaza plantilla y contenido en un solo paso)
No hay que vaciar nada antes: se selecciona todo por rango y el paste lo sustituye.

```js
const el = document.querySelector('[data-slate-editor]');
el.focus();
const r = document.createRange(); r.selectNodeContents(el);
const s = getSelection(); s.removeAllRanges(); s.addRange(r);
await new Promise(x => setTimeout(x, 400));
const dt = new DataTransfer();
dt.setData('text/plain', TXT);          // SOLO text/plain, párrafos con \n simple
el.dispatchEvent(new ClipboardEvent('paste',
  { clipboardData: dt, bubbles: true, cancelable: true }));
```

**Verificar por JS** (más barato y fiable que un screenshot):

```js
const ps = [...el.querySelectorAll('p')].map(p => p.textContent);
({ n: ps.length, first: ps[0], last: ps[ps.length-1],
   tmpl: el.textContent.includes('Somos tan malos'),
   empties: ps.filter(t => !t.trim()).length })
```
Debe dar: primer párrafo correcto, `last === "Marcel"`, `tmpl: false`, `empties: 0`.

### 3. Viñetas
Seleccionar por rango los párrafos de la lista, abrir el menú de bloque y clicar "Bulleted List". Todo en **una sola llamada JS** (si se parte en dos, el menú se cierra o se pierde la selección):

```js
const ps = [...el.querySelectorAll('p')];
const sel = () => { const r = document.createRange();
  r.setStart(ps[i0], 0); r.setEnd(ps[i1], ps[i1].childNodes.length);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); };
sel(); await new Promise(x => setTimeout(x, 400));
[...document.querySelectorAll('button')]
  .find(b => b.getAttribute('aria-label') === 'change block type').click();
await new Promise(x => setTimeout(x, 700));
sel(); await new Promise(x => setTimeout(x, 300));   // el botón limpia la selección: re-seleccionar
const e = [...document.querySelectorAll('div,span,li,button')]
  .find(x => !x.children.length && /^Bulleted List$/i.test(x.textContent.trim()));
const t = e.closest('button,[role="menuitem"],li') || e;
for (const ty of ['pointerdown','mousedown','pointerup','mouseup','click'])
  t.dispatchEvent(new MouseEvent(ty, { bubbles: true, cancelable: true, view: window }));
```
Comprobar con `el.querySelectorAll('li').length`. Si hay **dos listas** en el mismo email, aplicar primero la de índices **más altos** (así no se descolocan los índices de la otra).

### 4. Links
Seleccionar por rango el texto de la URL → clicar el botón `aria-label="open link menu"` → escribir la URL en el input del popover → **Apply**. Verificar con `el.querySelectorAll('a')`. Sin esto la URL queda como texto plano.

### 5. Asunto y pre-header (al final, nunca al principio)
- Click real en el input de asunto → **comprobar `document.activeElement.tagName === 'INPUT'`** antes de teclear. Si sale `BODY`, repetir el click (a veces hace falta un segundo).
- `cmd+a` + teclear. **Ojo con el `+` inicial**: se pierde al teclear la cadena entera; ponerlo aparte colocando el cursor en la posición 0 y tecleando solo `+`.
- Pre-header: click en "Add preview text" → teclear.
- **Forzar autosave tocando el cuerpo** (re-pegar el último párrafo) y esperar ~8s.

### 6. Verificación final (obligatoria)
**Recargar cada borrador** y leer por JS: `inputs` (asunto + pre-header), nº de `p`, nº de `li`, `a`, último párrafo y `tmpl`. Lo que se ve en pantalla antes de recargar **no prueba que se haya guardado** — asunto y pre-header fallan justo ahí. Después, `/broadcasts` → pestaña **Draft** para confirmar el recuento y los asuntos.

### 7. A/B de asunto (opcional pero recomendado)
Kit trae A/B de asunto en el plan actual (hasta 2 variantes; 5 es Creator Pro). Los asuntos alternativos del doc de handoff sirven de variante B.

Toggle `button[role=switch]` del panel derecho → tile **"Subject lines"** → rellenar `[placeholder="Enter subject line B"]` y el **segundo** `[placeholder="Enter preview text"]` (mismo pre-header que A: solo debe variar el asunto) → duración: cambiar el input de `240` a **60** → Continue/Save. Todo con el setter nativo de React (`Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set`) + eventos `input`/`change`; aquí sí persiste, porque el guardado va contra el botón del modal y no contra el autosave.

**Por qué 60 y no 240:** Kit manda A y B a una parte de la lista, espera la duración y luego manda el ganador al resto. Con 240 min el grueso del envío se va 4h más tarde y destroza el test de hora. Con 458 subs el "ganador" automático es ruido — el valor está en acumular datos entre envíos, no en cada veredicto.

### 8. Programar (Publish → Schedule)
`Continue` → marcar **"Send email"** (dejar "Add to your Newsletter site" sin marcar) → bajar a "When would you like to send this?".

- El link **"Schedule" exige un click REAL** — el click sintético no lo abre. Sacar coordenadas con `getBoundingClientRect()` × `k = anchoScreenshot / window.innerWidth`.
- **Flecha de mes y día: clicks reales, uno por llamada.** Encadenar dos clicks en el mismo batch cierra el popup. Verificar por screenshot entre paso y paso.
- **Hora: por JS** (`scrollIntoView` + eventos sintéticos sobre el leaf con el texto exacto, p. ej. `4:00 AM`). Los 288 slots están en el DOM; la rueda del ratón no scrollea esa lista.
- El popup **se reposiciona** al elegir día (a veces salta a la esquina superior izquierda): no reutilizar coordenadas antiguas.

⚠️ **La cuenta está en GMT-4 (horario del Este), no en Madrid**, y "cada suscriptor en su zona" es de pago. Hay que convertir: **10:00 Madrid = 4:00 AM · 17:00 Madrid = 11:00 AM** (válido mientras EEUU y Europa estén ambos en horario de verano; el desfase pasa a 5h entre el 25 oct y el 1 nov).

⚠️ **En el modal de revisión hay dos botones.** Si NO se ha fijado fecha, el botón es **"Send email" y envía en el acto**. Fijada la fecha, es **"Schedule email"**. Verificar siempre el texto `Scheduling for <fecha> at <hora> GMT-4` antes de pulsar, y pulsar solo el botón cuyo texto sea exactamente `Schedule email`.

## Workflow

1. **Limpieza previa:** en `/broadcasts`, abrir y confirmar que los borradores corruptos lo están, y borrarlos (menú `···` → Delete → "Yes, delete") antes de recrear.
2. **Por cada newsletter, en orden:** crear (JS click) → pegar cuerpo → viñetas → links → asunto + pre-header → tocar cuerpo para guardar → A/B de asunto → programar.
3. **Verificación final:** recargar cada una y comprobar campo a campo; luego `/broadcasts` → pestaña **Scheduled** para confirmar el recuento y las fechas/horas. Reportar la tabla a Marcel.

## Diseño del test de hora de envío (activo desde ago 2026)

Bloques alternos, **sin partir la lista** (con 458 subs cada brazo se quedaría en ~229 y el ruido se lo come). Cada semana: un envío a las 10:00 y otro a las 17:00, alternando qué día lleva qué hora. Así cada brazo acumula el mismo nº de martes y de viernes y el mismo mix valor/venta, y cualquier efecto estacional golpea a los dos por igual.

Realismo obligatorio al reportar: **la hora es una palanca pequeña**. Los 8 envíos previos, todos a la misma hora, fueron del 54% al 37% de apertura — 17 puntos de variación solo por asunto y contenido. El efecto típico de la hora es de 2-5 puntos y queda enterrado. Con 12 envíos se obtiene una lectura **direccional, no un veredicto**: actuar solo si la diferencia supera los **10 puntos**. Medir sobre **aperturas**, nunca sobre clics (0-7 clics por envío: no hay señal).

## Si algo falla

- Si el paste sintético deja de funcionar (Kit cambió su editor), **PARAR y reportar** en vez de dejar borradores corruptos.
- Si los clicks dejan de responder: sospechar del **lock de pestaña** antes que del navegador.
- Cadencia típica: 3/semana L/X/V; 8 de valor + 4 que venden por cada tanda de 4 semanas.
