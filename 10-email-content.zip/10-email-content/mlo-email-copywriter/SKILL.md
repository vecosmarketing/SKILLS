---
name: mlo-email-copywriter
description: >-
  Capa de calidad para redactar emails de marketing de clientes de MLO Growth (campañas y flujos de
  Klaviyo: lanzamientos, promos, nurture, bienvenida, carrito/checkout, post-compra, follow-up).
  Garantiza emails fluidos, claros y visuales, con UN solo hilo conductor, donde el asunto y el
  preview se complementan (nunca se repiten), cada elemento avanza la historia, y no hay pegotes de
  texto ni mensajes duplicados. ALWAYS use (ES/EN) al redactar, escribir, revisar o mejorar cualquier
  email de marketing o secuencia de emails para una marca cliente, aunque no la nombren: "redacta el
  email", "escribe la campaña", "email de lanzamiento", "secuencia de emails", "mejora este email",
  "asunto y preview", "programación de emails", "flujo de bienvenida / carrito / post-compra /
  follow-up", "campaña de expectativa". Es una capa de CRAFT: se aplica ENCIMA de la voz y el
  compliance de cada marca, no los sustituye.
---

# MLO Email Copywriter

Capa de redacción para que **todos** los emails de marketing de MLO se lean fluidos, se entiendan de
un vistazo y lleven un solo hilo. No decide estrategia ni segmentos (eso viene de la auditoría / el
brief): decide **cómo se escribe cada email para que enganche y convierta**.

> **Primero carga la marca, luego escribe.** Esta skill es de craft. Antes de teclear una palabra,
> ten a mano las reglas de la marca: voz y tono, emojis sí/no, compliance (claims permitidos), idioma
> y localización, oferta y segmentos. Ejemplo Henric Fuster: español mexicano ("cabello", "shampoo",
> "regadera", "tableta"), **sin em dashes nunca**, suplementos = "no es un medicamento, no cura"
> (claims suaves), farma = COFEPRIS (sin "detiene la caída", probabilístico, +18, indicación médica).

---

## Los 5 principios (innegociables)

1. **Un solo hilo conductor.** Cada email defiende UNA idea. Escríbela en una frase antes de empezar.
   Asunto, preview, hero, cuerpo y CTA sirven a esa idea. Si un bloque no la empuja, sobra.
2. **Asunto y preview se complementan, nunca se repiten.** El asunto abre; el preview lo continúa,
   lo completa o añade el dato que el asunto calla. Se leen juntos como una frase de dos partes.
3. **Fluidez y claridad.** Frases que se encadenan (y / pero / porque, comas, dos puntos) con algún
   remate corto puntual. Prohibida la "ametralladora" de frases cortas seguidas: es el tic que delata
   a la IA. Una idea por bloque.
4. **Visual, sin pegotes de texto.** Bloques de 1 a 3 líneas, aire entre ellos, una línea hero, un
   CTA claro. Nada de párrafos-ladrillo. Se diseña pensando en el móvil.
5. **Cero repetición de mensaje.** Ningún elemento repite lo que ya dijo otro. Asunto ≠ preview ≠
   hero ≠ cuerpo ≠ CTA. Cada uno aporta algo nuevo.

---

## El hilo conductor, paso a paso

Antes de redactar, completa esto en tu cabeza (o en una nota):

- **Idea única (1 frase):** qué quiero que entienda y sienta esta persona.
- **Tensión / emoción:** qué le mueve (miedo, deseo, curiosidad, alivio, pertenencia).
- **Acción:** qué hace al terminar (el CTA).

Luego reparte esa historia en "beats", uno por elemento:

| Elemento | Su trabajo (beat) |
|---|---|
| Asunto | Gancho: abre la curiosidad o promete algo |
| Preview | Giro o concreción: completa el asunto, no lo repite |
| Hero | La idea única, en una línea |
| Cuerpo | El porqué + la prueba, en 2-4 bloques cortos |
| CTA | La acción, con verbo + valor |

**Test del hilo:** si tapas el logo, ¿se entiende de qué va y qué hacer? ¿Cada bloque dice algo
nuevo? Si dos bloques dicen lo mismo, funde o corta.

---

## Asunto + preview (el par)

- Preview de ~35 a 90 caracteres (se ve en bandeja justo después del asunto).
- El preview **no** reutiliza las palabras clave del asunto.
- Relación válida asunto → preview: **continuación** (puntos suspensivos que se cierran),
  **respuesta** a la pregunta del asunto, o **el dato concreto** que el asunto esconde.
- Nunca dejes el preview vacío ni con "Ver en el navegador": es espacio de venta desperdiciado.

Patrones que funcionan: Curiosidad → Concreción · Pregunta → Respuesta parcial · Afirmación → Giro ·
Beneficio → Prueba o urgencia.

**Bien (se complementan):**
- Asunto: `Algo nuevo viene. Y tú lo verás primero.`
  Preview: `Nada de minoxidil. Es para cuidar tu cabello desde dentro.`
- Asunto: `Tu 15% de cliente sigue en pie.`
  Preview: `Pero solo hasta el domingo a medianoche.`

**Mal (se repiten):**
- Asunto: `Algo nuevo viene a Henric` · Preview: `Viene algo nuevo, atento.`
- Asunto: `Aprovecha tu descuento` · Preview: `Descuento disponible para ti.`

---

## Anatomía visual de un email

1. **Preheader** (par con el asunto).
2. **Header / logo.**
3. **Hero:** una línea que ES la idea única (más imagen si suma).
4. **Cuerpo:** 2 a 4 bloques cortos, un beat cada uno. Orden típico: lo que siente → qué es → por
   qué / prueba.
5. **CTA principal:** un botón, verbo + valor ("Quiero mi acceso", no "Clic aquí"). Un secundario
   solo si no compite con el principal.
6. **Cierre corto.**
7. **Footer** (baja, dirección, compliance).

Reglas visuales:
- Bloques de 1 a 3 líneas. Si un bloque pasa de 4 líneas, pártelo o recórtalo.
- Como mucho una idea en negrita por bloque.
- Listas solo si se escanean mejor que la prosa, y de 3 a 4 ítems máximo.
- Imágenes que aporten (producto, prueba, contexto), nunca de relleno.
- **Un solo CTA dominante.** Si hay varios destinos, jerarquiza; no pongas tres botones iguales.

---

## Fluidez: cómo evitar el tic de la IA

- Encadena con conectores. Frases de 15 a 30 palabras que respiran, no fragmentos sueltos en fila.
- **Prohibido:** "Frase. Otra. Otra corta. Y otra." en ráfaga. Suena a máquina.
- Escribe como habla una persona contándotelo, no como viñetas convertidas en prosa.
- Lee el email en voz alta: si te quedas sin aire o suena entrecortado, reescribe.
- Sin em dashes si la marca lo pide (Henric: jamás; usa comas, dos puntos o paréntesis).

---

## Anti-repetición (comprobación rápida)

Antes de dar por bueno el email, verifica que **no** se repiten entre elementos: la promesa, el
beneficio, la frase gancho ni el nombre del producto en cada línea. Ejemplo: si el asunto ya dijo
"descuento", el preview no repite "descuento", dice **cuánto**, **hasta cuándo** o **para quién**.

---

## Entrega en programaciones / campañas

Cuando la tarea sea una programación o calendario de envíos, entrega por cada email, en formato
ejecutable (tabla o bloque, cero teoría):

- Nombre / tag de Klaviyo (convención de la marca, para tracking).
- Fecha y hora de envío (en la **zona horaria correcta** de la cuenta; verifícala).
- Segmento destinatario.
- Asunto (con variante A/B si aplica) **y preview**.
- Cuerpo listo para montar (no "estructura", el copy real).
- CTA principal.
- Producto / PDP destino.

---

## Checklist final (antes de dar un email por bueno)

- [ ] ¿Cuál es la idea única? ¿Todo el email la sirve?
- [ ] ¿Asunto y preview se complementan sin repetirse?
- [ ] ¿Cada bloque dice algo nuevo?
- [ ] ¿Fluye al leerlo en voz alta o suena a ametralladora?
- [ ] ¿Es visual: bloques cortos, una línea hero, un CTA, sin pegotes?
- [ ] ¿Cumple voz + compliance + idioma de la marca?
- [ ] ¿El CTA es uno, dominante, con verbo + valor?

---

## Mini-ejemplos (antes / después)

**Cuerpo entrecortado (mal) → fluido (bien):**
- ❌ "El problema no era el minoxidil. Era el formato. Dos veces al día. Todos los días. Sin fallar."
- ✅ "El problema nunca fue el minoxidil, era el formato: te pide aplicártelo dos veces al día, todos
  los días, y en cuanto la vida se complica dejas de hacerlo."

**Pegote (mal) → visual (bien):**
- ❌ Un párrafo de 8 líneas con la historia, los ingredientes, el precio y el CTA metidos juntos.
- ✅ Bloque 1 (2 líneas): la tensión. Bloque 2 (2 líneas): qué es. Bloque 3 (1 línea hero): el
  beneficio. Botón: el CTA. Cada cosa en su sitio, con aire.

**Repetición (mal) → progresión (bien):**
- ❌ Asunto, hero y CTA dicen los tres "Nuevo suplemento para tu cabello".
- ✅ Asunto abre curiosidad, hero nombra la idea única, CTA dice la acción concreta. Nadie repite.
