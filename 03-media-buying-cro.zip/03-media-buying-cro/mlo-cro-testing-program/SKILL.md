---
name: mlo-cro-testing-program
description: >
  MLO Growth's CRO A/B TESTING PROGRAM operator — runs a data-driven, on-site conversion testing program
  end-to-end for any brand: builds the evidence-gated test backlog, writes IF/THEN/BECAUSE hypotheses tagged
  by behavioral principle, scores & prioritizes ideas on the 0–15 scorecard, computes the runtime/MDE
  (how long to run + what uplift you can detect at 95%), reads results by the decision rule (user-based CR,
  ≥95%, runtime reached → Winner or Learning), segments desktop/mobile & new/returning for personalization,
  and keeps the Testing Loop Map (owner-per-step + the 3 numbers the client always asks). Grounded in the
  Accelerated Advisory course (modules 18 & 19). ALWAYS use this skill (ES/EN) when the user says
  "monta el programa de testing CRO de [marca]", "backlog de tests", "prioriza estos tests / scórame estas ideas",
  "hipótesis A/B", "cuánto tiempo corro el test", "¿es significativo este test?", "lee este resultado de test",
  "roadmap de CRO", "CRO testing program", "score these test ideas", "how long to run this test",
  "is this test significant", "read this A/B result", "build the test backlog / roadmap for [brand]".
  Trigger for any MLO brand. It COMPLEMENTS mlo-cro-2026 (foundations/audit), cro-expert, mlo-nathan-audit-method
  (store audit + heatmap teardown), and creative-report-builder (before-the-call cadence, Winner/Learning framing).
  This is the PROGRAM/OPERATIONS layer: hypothesis → backlog → prioritize → runtime → read → segment → learn → re-prioritize.
---
# CRO Testing Program

## What it does
Runs MLO's **on-site A/B testing program end-to-end** for a brand — the operations layer that sits on top of the CRO foundations. It turns website evidence (GA4/GTM/Hotjar/Clarity) into a **prioritized, evidence-gated backlog**, writes each idea as an **IF/THEN/BECAUSE hypothesis tagged with a behavioral principle**, **scores** it on the 0–15 scorecard, computes **how long to run** the test and **what uplift is detectable** (runtime/MDE at 95%), **reads the result** by a strict decision rule, **segments** the read for personalization, and files the outcome as a **Winner or a Learning** — then re-prioritizes. It maintains the **Testing Loop Map** (owner-per-step) and the CRO Program Template as the living tracker. This is CRO *testing* (website/RPU/CVR/AOV), NOT paid creative testing.

## When to use (ES + EN trigger phrases)
- **ES:** "monta/arranca el programa de testing CRO de [marca]", "hazme el backlog de tests", "prioriza estos tests", "scórame estas ideas de test", "escribe la hipótesis A/B de esto", "pásalo a IF/THEN/BECAUSE", "¿cuánto tiempo tengo que correr este test?", "¿ya es significativo?", "lee este resultado de A/B", "¿es winner o learning?", "roadmap de CRO del mes", "qué testeo primero".
- **EN:** "set up the CRO testing program for [brand]", "build the test backlog / roadmap", "prioritize / score these test ideas", "write the A/B hypothesis", "how long do I run this test", "what MDE can I detect", "is this test significant yet", "read this A/B result", "winner or learning?", "which test goes first".
- **Do NOT use for:** paid-media / creative testing → `mlo-estratega-creativo` / `mlo-winner-strategist`; the CRO *foundations*, store audit or a landing teardown → `mlo-cro-2026` / `cro-expert` / `mlo-nathan-audit-method`; building the actual landing/advertorial code → `mlo-page-cooker`; the recurring performance deck → `creative-report-builder`. This skill is the **program/ops loop**, not the audit and not the page build.

## Inputs needed
1. **Brand / store** (and its Brand Brain if it exists, for VoC + tone).
2. **Data sources connected** — GA4, GTM, Hotjar and/or Clarity. If none is named, that is a **blocker, not a test idea** (see evidence rule).
3. **The page(s) in scope** — start with the **paid-traffic × revenue** page (highest first).
4. **Traffic numbers for the runtime math** — weekly users on the page + weekly conversions (or current CVR), so runtime/MDE can be computed.
5. Optional: existing idea list / client requests, heatmaps, survey/review VoC, seasonal events, the CRO Program Template + Winning Tests Database sheets if already in use.

## Method (numbered — the living loop)
1. **Apply the evidence rule first.** No test enters the roadmap without a **named data source**. The only sources that count are **GA4, GTM, Hotjar, Clarity**. An idea with no source is not deleted — it goes to a **"needs evidence"** list until data is found. If a required source is missing entirely, that is a blocker to fix, not a test to run.
2. **Read the quant map.** Set up GA4+GTM tracking every interaction (scroll 10/25/50/75/90%, image clicks/zoom, quantity, accordions, menu/filter) and build the store "map" — pins where **high traffic meets high drop-off**. Start on the paid-traffic × revenue page.
3. **Read heatmaps the right way.** Never open a heatmap with **<2,000 pageviews**. Read by **RANK, not absolute %** (a lone % says nothing; the rank vs other elements does). **Ignore expected interactions** (carousel, size selector); **hunt anomalies** (over-clicked footer link, "recommended products" ranked #4 = they want more products). **Scrollmap = visibility gate:** if only ~8% reach a section, a test there won't move the needle — move the important content above the drop-off.
4. **Cross with qualitative.** Surveys (pre/post), CS, own + competitor reviews → sort topics into **Motivation / Value / Anxiety (FUDs)**. Quant tells you **where**, qual tells you **why** → that intersection is the hypothesis.
5. **Run the 4 usability levers** on every analysis: **User-flow · Effort · Choice · Motivation.** Each observed problem maps to one (or more) of these.
6. **Write the hypothesis** in MLO format (one per row): `IF we do X → THEN Y → BECAUSE Z | GOAL | Effect(behavioral principle)`. The **Effect** column is load-bearing: it names the behavioral principle so a winning principle raises the win-probability of sibling hypotheses and transfers to ads/email/LP.
7. **Score & prioritize on the 0–15 scorecard** (see reference). The **score = probability of winning, NOT the size of the uplift.** Highest score is tested first. Log **every** idea in the backlog; re-prioritize continuously (and whenever the client flags a seasonal event).
8. **Design the variant** — Before (left) / After (right); make **all fixes at the design stage** (moving pixels is cheap; changing code after QA burns test velocity). Get client sign-off, then code + QA.
9. **Compute runtime/MDE before launch.** From weekly users + conversions at **95% confidence** + power, get the **MDE** (minimum detectable effect). Rule of thumb: **1 week ≈ 22.5% · 2 weeks ≈ 15% · 3 weeks ≈ 12%** detectable uplift — longer runtime detects smaller effects. Fix the minimum worthwhile uplift, then cap runtime. **Only evaluate at the pre-calculated runtime** (a "winner" on day 1 can be a loser on day 10). Only exception: kill an obvious loser early.
10. **Read the result by the decision rule.** Use **user-based CR** (not session-based — less bot/revisit noise, more reliable significance). **Implement only if uplift is positive AND confidence ≥95% AND runtime reached.**
11. **Segment → personalize.** Split **desktop/mobile** and **new/returning** (opposite effects cancel out in the aggregate). If a **segment** wins significantly, ship the variant **to that segment only** — flip it to 100% of the winning segment in the tool while the theme is coded.
12. **File the outcome — only two are valid: Winner (ship) or Learning.** Never "inconclusive." Move status **Pipeline → Development → Running → Completed**, record the behavioral principle learned, **re-prioritize** the backlog, repeat. It's a living loop.

## Rules & standards (MLO non-negotiables)
- **Evidence rule is absolute:** no test on the roadmap without a named data source (GA4/GTM/Hotjar/Clarity). No source → "needs evidence," not the trash.
- **Analysis runs BEFORE the biweekly call, never after** (same cadence discipline as `creative-report-builder`).
- **Heatmaps:** ≥2,000 pageviews or don't look; read by rank not absolute %; hunt anomalies; scrollmap visibility gate ≈8%.
- **Hypothesis is always `IF → THEN → BECAUSE` with a GOAL and a tagged behavioral principle.** No naked "let's try X."
- **Score = win-probability, not uplift size.** Test the highest score first; keep every idea; re-prioritize continuously.
- **Runtime is pre-calculated and respected.** Never call a test at day 1–3; evaluate at the computed runtime. User-based CR, ≥95%, runtime reached — all three or it doesn't ship.
- **Segment before you conclude.** Aggregate can hide opposite desktop/mobile or new/returning effects; ship to the winning segment only.
- **Only two outcomes: Winner or Learning.** Every completed test produces a shippable change or a documented behavioral principle.
- **Naming: `ACC_[client]_[Page]_[NN]`** (e.g. `ACC_VE_Product_04`). Status flow: **Pipeline → Development → Running → Completed.**
- **The CRO Program Template + Winning Tests Database sheets are the tracker** — the backlog, scores, runtimes, reads and behavioral-principle library live there, not in chat.
- **Goal taxonomy:** Higher CVR / AOV / **RPU** / ATC · Lower Abandoned Carts/Checkouts · More Leads. (RPU = AOV × CVR is the connector metric from site to revenue.)

## Output (exact shapes)
**A) Hypothesis (one backlog row):**
```
ID: ACC_[client]_[Page]_[NN]
Hypothesis: IF we [change X] → THEN [KPI Y moves] → BECAUSE [reason Z]
Goal: [Higher CVR / AOV / RPU / ATC | Lower abandoned carts | More leads]
Effect (behavioral principle): [e.g. contrast / social proof / anchoring / friction reduction]
Evidence source: [GA4 | GTM | Hotjar | Clarity + what it showed]
Page URL: [url] · Ready-for-Prio: [Y/N]
Score (0–15): [n]  → Status: [Pipeline/Development/Running/Completed]
```
**B) Runtime/MDE call:**
```
Weekly users on page: [n] · Weekly conversions (or CVR): [n / %]
At 95% confidence: 1wk ≈ 22.5% | 2wk ≈ 15% | 3wk ≈ 12% MDE
Minimum worthwhile uplift: [x%] → Required runtime: [~N weeks]
Evaluate ON: [date]. Do not read before then (kill early only if clear loser).
```
**C) Result read:**
```
Metric: user-based CR · Variant vs Control: [+/–x%] · Confidence: [xx%] · Runtime reached: [Y/N]
Decision: [SHIP / KEEP RUNNING / LEARNING] (ship only if positive AND ≥95% AND runtime reached)
Segments: desktop [..] · mobile [..] · new [..] · returning [..] → ship to: [segment or all]
Outcome: [Winner → ship to theme | Learning → principle recorded: ___]
```

## Guardrails
- Never put a test on the roadmap without a named data source; never fabricate a data source or a significance number.
- Never call a test before the pre-calculated runtime (day-1 winners lie); never read session-based CR when user-based is available.
- Never conclude "inconclusive" — it's a Winner or a Learning. Never ship at <95% or without runtime reached.
- Never conclude from the aggregate alone when a segment split is available and material.
- Don't do the store audit or landing teardown here (→ `mlo-nathan-audit-method` / `mlo-cro-2026`) and don't build the page code here (→ `mlo-page-cooker`); this skill runs the testing *program*.
- ES/EN: write in the brand's language; keep MLO decimal/format conventions (coma decimal in ES) when numbers appear.
- The exact scorecard scale, runtime table and Testing Loop Map worksheet live in the reference file; the backlog/scores/reads live in the CRO Program Template sheet.

## References
- **Full knowledge base:** `reference/cro-program.md` (0–15 scorecard with every sub-score, hypothesis columns, page legend, runtime/MDE table + decision rule, segmentation→personalization, Testing Loop Map worksheet + the 3 numbers, quant/qual buckets, heatmap rules, behavioral-principle library, tools).
- **Course grounding:** Accelerated Advisory `modules/18-analysis-iteration.md` (analysis & iteration SOP, evidence rule, heatmaps, 4 levers, scorecard) and `modules/19-testing-program.md` (the testing program end-to-end: hypothesis, backlog scoring, runtime/significance, read rules, segmentation, Testing Loop Map).
- **Complements (do not fork):** `mlo-cro-2026` (CRO foundations), `cro-expert`, `mlo-nathan-audit-method` (store audit + heatmap teardown), `creative-report-builder` (before-the-call cadence + Winner/Learning framing). Philosophy-only overlap with `mlo-winner-strategist` / `mlo-estratega-creativo` (hypothesis+evidence loop) — mechanics here are web-CRO, not Meta; do not mix the metrics.
