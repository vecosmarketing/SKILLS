# CRO Testing Program — Knowledge Base

Deep reference for `mlo-cro-testing-program`. Grounded in Accelerated Advisory modules 18 (Analysis & Iteration) and 19 (The Testing Program). The live backlog, scores, runtimes and reads live in the **CRO Program Template** + **Winning Tests Database** sheets; this file is the method.

---

## 1. The evidence rule (gate before anything)
**"No test enters the roadmap without a named data source."**
- The only sources that count: **GA4, GTM, Hotjar, Clarity.** If a required source is missing entirely → that's a **blocker to fix**, not a test idea.
- An idea with no source is **not deleted** → it moves to a **"needs evidence"** list until data is found for it (idea-first: go hunt evidence for parked ideas).
- First page to analyze = **paid-traffic × revenue** (highest first).

**Evidence-rule / idea-audit worksheet:**
| Idea | Who asked for it | Data source | Verdict (keep / needs evidence / park) |
|------|------------------|-------------|----------------------------------------|

---

## 2. Quant map + heatmap method
**Quant setup (GA4 + GTM):** track every interaction — scroll depth (10/25/50/75/90%), image clicks/zoom, quantity selector, accordions, menu/filter. Tool: **Adswerve dataLayer Inspector**. Output = a **"map"** of the store: pins where **high traffic meets high drop-off.**

**Heatmap / scrollmap rules:**
- **Never open a heatmap with <2,000 pageviews.** (Clarity/Hotjar.) Filter by date, device, **URL regex** (`/products` aggregates all PDPs), traffic source.
- **Read by RANK, not absolute %.** A lone % says nothing; the rank of an element vs the others does.
- **Ignore EXPECTED interactions** (carousel, size selector). **Hunt ANOMALIES:** a prominent banner ranked low = doesn't matter; an over-clicked footer "About us" = curiosity signal; "recommended products" ranked #4 = they want more product options. For accordions, improve the one with the most clicks first.
- **Scrollmap = visibility / drop-off gate:** if only ~8% reach a section, a test there won't move the needle → move important content (product USPs) **above** the drop-off.
- **Cases:** Butter Cloth (image zoom, +9% CVR), Oliver Cabell (About-Us story, +8% CVR), Westy (USPs above the fold).

---

## 3. Qualitative → 3 buckets
Qual = surveys (pre/post) + CS + reviews (own + competitor). Extract topics into:
- **Motivation** — the reason to buy; the hardest lever; must be understood.
- **Value** — USPs / benefits.
- **Anxiety (FUDs)** — min order, risk, returns, "will it work for me?".

Quant = **where**; qual = **why** → the intersection is the hypothesis.

---

## 4. The 4 usability levers
Apply on **every** analysis; each observed problem maps to one or more:
1. **User-flow** — is the path to purchase clear and unbroken?
2. **Effort** — how much work is the user doing (clicks, typing, thinking)?
3. **Choice** — too many / too few / badly framed options?
4. **Motivation** — is the reason-to-buy present and strong at this point?

---

## 5. Hypothesis format (backlog row, columns verbatim)
`IF we do X | THEN Y | BECAUSE Z | GOAL | Effect (behavioral principle) | Notes | Page URL | Ready-for-Prio`

- **IF → THEN → BECAUSE:** e.g. *IF* we change the CTA color *→ THEN* CVR rises *→ BECAUSE* higher contrast draws the eye.
- **Effect column = the behavioral principle** (load-bearing): a winning principle raises the win-probability of sibling hypotheses that use it, and **transfers to ads / email / LP**. Build a **behavioral-principle library** over time.
- **GOAL taxonomy:** Higher CVR / AOV / **RPU** / ATC · Lower Abandoned Carts/Checkouts · More Leads.
- **RPU = AOV × CVR** — the connector metric from site → revenue.

**Naming:** `ACC_[client]_[Page]_[NN]` (e.g. `ACC_VE_Product_04`).
**Page legend:** TopBar · Header · Menu · Homepage · Category · Product · Upsell · CartDrawer · CartPopUp · CartPage · Checkout · Search · Filter · ATF · LandingPage.

---

## 6. ⭐ The 0–15 prioritization scorecard
**Score = probability of WINNING, not the size of the uplift.** Sum the sub-scores; test the highest total first. Each independent data source adds support (Data-support characteristic stacks).

| # | Characteristic | Scoring |
|---|----------------|---------|
| 1 | **Above-fold?** | Yes = 1 / No = 0 |
| 2 | **User-testing support?** | Yes = 1 / No = 0 |
| 3 | **Quant data support?** | Yes = 1 / No = 0 |
| 4 | **Heatmaps support?** | Yes = 1 / No = 0 |
| 5 | **Noticeable in 5 seconds?** | Yes = **2** / No = 0 |
| 6 | **Dev effort** | 4h = **3** / 8h = **2** / 2 days = **1** / more = 0 |
| 7 | **Add vs Remove** | Adds an element = **2** / Removes = 0 |
| 8 | **High-traffic page?** | Yes = 1 / No = 0 |
| 9 | **Increases Motivation?** | Yes = 1 / No = 0 |
| 10 | **Simplifies purchasing?** | Yes = 1 / No = 0 |
| 11 | **Team confidence** | High = **2** / Med = 1 / Low = 0 |

**Max = 15.** Worked examples from the course: *"stronger value prop on Homepage" = 12*; *"payment icons below cart" = 6.* Higher → test first. Re-score / re-prioritize continuously (and when the client flags a seasonal event).

> The exact numeric scale is mirrored in the **CRO Program Template** sheet — keep the sheet as source of truth; this table is the method.

---

## 7. Design & velocity
- Variant shown **Before (left) / After (right)**.
- Make **ALL fixes at the design stage.** Moving pixels in a mockup is cheap; changing things after code + QA introduces delays and burns **test velocity**. Get client sign-off on the design, then code + QA, then launch.

---

## 8. Runtime & significance (the MDE math)
**The danger is stopping early:** 17 sessions / 1 txn vs 11 sessions / 3 txns reads as a false **+364%**. A day-1 "winner" can be a day-10 loser. **Only evaluate at the pre-calculated runtime.**

**Calculator inputs:** weekly users on the page + weekly conversions + significance **95%** + power → **MDE** (minimum detectable effect).

**Runtime → detectable uplift (verbatim guide):**
| Runtime | Detectable uplift (MDE) @ 95% |
|---------|-------------------------------|
| 1 week  | ~22.5% |
| 2 weeks | ~15% |
| 3 weeks | ~12% |

Longer runtime = smaller detectable uplift. Workflow: **fix the minimum worthwhile uplift**, then that caps the runtime you must commit to. Exception to "wait for runtime": kill an obvious clear loser early.

---

## 9. Reading results (decision rule)
- **Use user-based CR, not session-based** — less manipulable by bots/revisits, so significance is more reliable.
- **Decision rule — ship ONLY if ALL three hold:**
  1. Uplift is **positive** (green), AND
  2. Confidence **≥ 95%**, AND
  3. **Runtime reached** (the pre-calculated one).
- Otherwise: keep running (not yet at runtime) or file as **Learning**.

**Only two valid outcomes: Winner (ship) or Learning.** Never "inconclusive." Every completed test yields a shippable change or a documented behavioral principle.

**Status flow:** **Pipeline → Development → Running → Completed.**

---

## 10. Segmentation → personalization
- Aggregate can hide **opposite effects** that cancel out. Always split:
  - **Desktop / Mobile**
  - **New / Returning**
- If a **segment** wins significantly → **implement the variant for that segment only.**
- **Rollout:** flip to **100% of the winning segment** in the testing tool while the change is being coded into the theme.

---

## 11. Testing Loop Map (worksheet) + the 3 numbers
**"A step without an owner doesn't happen."**

| STEP | OWNER | INPUT | WHERE RECORDED | LIVE TODAY |
|------|-------|-------|----------------|------------|
| Setup tracking | | GA4/GTM | | |
| Collect data | | | | |
| Build map | | heatmaps/scrollmaps | | |
| Cross with qual | | surveys/reviews | | |
| Hypotheses | | IF/THEN/BECAUSE | CRO Program Template | |
| Backlog + score | | 0–15 scorecard | CRO Program Template | |
| Design variant | | Before/After | Figma | |
| Client sign-off | | | | |
| Code + QA | | theme | | |
| Launch | | testing tool | | |
| Run to runtime | | MDE calc | | |
| Read (user-CR, 95%) | | | | |
| Segment / personalize | | | | |
| Implement in theme | | | | |
| Learn (behavioral principle) | | principle library | Winning Tests Database | |
| Re-prioritize | | | | |

- **Input check:** tick only what you actually opened **today** (not what exists in theory).
- **The 3 numbers the client always asks:** (1) how many tests running in parallel, (2) which day is the review, (3) which day the results land.
- **Definition of Done:** every step has an owner; the roadmap has a CRO block + date; the client knows where the next idea comes from and which day the result arrives.

**Monthly roadmap shape:** a Focus + ~5 tests + a Research item.

---

## 12. Tools
- **GA4 + GTM** (tracking) · **Adswerve dataLayer Inspector** (verify dataLayer).
- **Microsoft Clarity + Hotjar** (heatmaps/recordings; GTM custom HTML tag → filter recordings/heatmaps by experiment name + variation).
- **Testing tool** (Conversion.io / Verify / "Accelerated Experiment"); significance via GA API on in-house SaaS.
- **Kameleoon** is referenced in the CRO Program Template (module 18) but not in module 19 — different sources; note it, don't treat it as mandatory.

---

## 13. How this fits the MLO skill stack
- **Complements** `mlo-cro-2026` (foundations), `cro-expert`, `mlo-nathan-audit-method` (store audit + heatmap teardown — feeds this program's evidence), `creative-report-builder` (before-the-call cadence, Winner/Learning framing).
- **Philosophy-only overlap** with `mlo-winner-strategist` / `mlo-estratega-creativo`: the behavioral-principle library mirrors the winner/iteration logic (a winning principle lifts sibling ideas + transfers to ads/email). **But the mechanics here are web-CRO, not Meta — do not mix the metrics** (RPU/CVR/AOV, user-based CR — not ROAS/hit rate).
- **Productizable** as a "CRO Testing Program" retainer deliverable alongside the Scale Report; the DoD + owner-per-step worksheet is the onboarding template for a testing retainer.
- **Analysis runs BEFORE the biweekly call**, never after.
