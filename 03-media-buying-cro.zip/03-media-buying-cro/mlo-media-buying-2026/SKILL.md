---
name: mlo-media-buying-2026
description: El cerebro de media buying y estructura de cuenta de M.L.O Growth para Meta Ads en la era Andromeda (2026). Contiene el sistema completo — qué murió y qué sigue vivo del media buying, cómo optimiza Meta de verdad (revenue per user, atribución multi-touch, breakdown effect, Andromeda/vector space), por qué el ROAS pierde fiabilidad al bajar en la estructura (medir a nivel ad set), la estructura por CONCEPTO para alto volumen creativo, consolidación vs segmentación y las 5 preguntas diagnóstico, los playbooks por tramo de gasto (<50k / 50-250k / 250k+), ABO vs CBO (el criterio real, los 5 escenarios, min/max spend caps), el manual bidding (cost cap / bid cap / max value / auction diversification / low-bidcap inflado), por qué los ads mueren a las 48h (novelty bias + audience pockets) y la decisión keep/kill por breakdown (nueva audiencia vs existentes, incremental vs 1-day-view), el sequence thinking (TOF amplifica demanda / BOF cierra), el back-propagation del presupuesto de test, los settings que hay que apagar (flexible ads, 1-day-view, auto-optimizaciones), retargeting/DPA/clientes existentes como capa de soporte con mentalidad de escasez, y los 2 no-negociables (integridad de datos + alineación comercial) con las 4 preguntas diagnóstico. ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan: "cómo estructuro la cuenta de [marca]", "ABO o CBO", "cómo escalo esta campaña", "por qué se me mueren los ads a los 2 días", "cómo estructuro el testing", "cuánto budget pongo por ad set", "cost caps / bid caps / manual bidding", "cómo diagnostico esta cuenta", "consolidar o segmentar", "estructura por tramo de gasto", "media buying 2026", "estructura de cuenta Meta", o cuando haya que redactar formación, SOPs o lead magnets de media buying/estructura/escalado. Dispara también con peticiones parciales o coloquiales sobre estructura de cuenta, ABO/CBO, bidding, escalado, fatiga de ads, retargeting o por qué una cuenta no escala.
---

# Sistema de Media Buying M.L.O 2026 (Meta / Andromeda)

Este skill es el **cerebro de media buying y estructura de cuenta** de M.L.O Growth. Reúne, sintetizado y en nuestra voz, todo el sistema para estructurar, testear y escalar una cuenta de Meta en la era Andromeda — con alto volumen creativo, sin destruir la eficiencia y generando aprendizajes que retroalimentan el creativo. Lo usamos para:

- **Estructurar cuentas** (campañas, ad sets, ABO/CBO, segmentación) alineadas al negocio.
- **Escalar** con criterio (regla del 20%, sequence thinking, manual bidding, flash campaigns).
- **Diagnosticar** por qué una cuenta no escala o por qué mueren los ads.
- **Formar al equipo** y **generar lead magnets/SOPs** de media buying (Módulo 04 del lead bucket).

## Cómo usarlo

1. **Lee el cerebro completo** en `references/media-buying-brain.txt`. Es la fuente única de verdad: estructura, tramos de gasto, ABO/CBO, bidding, fatiga, sequence thinking, settings y diagnóstico.
2. **Cruza con el resto del sistema M.L.O**: el sistema creativo (persona × ángulo × oferta, awareness, EPIC, hooks) en `[[mlo-sistema-creativo-2026]]`; las definiciones de winner/KPIs y forecasting creativo en `[[mlo-estratega-creativo]]`; la Matriz Andromeda (naming/estructura) y el preset FFM.
3. **Adapta a la voz M.L.O**: frases cortas, sin anglicismos innecesarios, práctico, sin humo. Para cliente/lead magnet, cierra con el CTA de auditoría gratuita (mlo-growth.com/adquisicion/metodolgia-mlo-growth-3).

## Reglas de oro

- **No hay estructura universal.** La complejidad de la cuenta = producto de la complejidad del negocio. Se construye con las 5 preguntas diagnóstico, no con una plantilla.
- **Dos no-negociables:** integridad de datos (la estructura produce datos legibles y accionables) + alineación comercial (encaja con productos, margen, personas, regiones y retención).
- **No se juzga un ad en aislado.** Los creativos trabajan en SECUENCIA; el ROAS a nivel ad engaña. Se mide a nivel ad set/campaña.

## Origen

Destilado e internalizado a estándar M.L.O a partir de material de mercado sobre estructura de cuenta, ABO/CBO, manual bidding, fatiga de ads y estrategia de testing en Meta 2026. Reescrito en su totalidad con nuestra terminología y ejemplos genéricos. Se mejora con el tiempo (versionado en el propio cerebro).
