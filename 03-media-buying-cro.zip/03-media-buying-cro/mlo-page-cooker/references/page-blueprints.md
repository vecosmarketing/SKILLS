# Blueprints por tipo de página + reglas de código

Estructura de secciones para cada tipo. El **copy** sale de las skills de estrategia
([[mlo-cro-2026]], [[advertorial-strategist]], [[mlo-listicle-advertorial-brief]]); aquí está el
**esqueleto de construcción** y cómo maquetarlo. Adapta el número de secciones al producto; no
metas relleno.

## Reglas de código (para las tres)
- Un solo contenedor raíz con **prefijo de clase único** por página (`.mlopc-<marca>-<tipo>`), y
  **todos** los selectores prefijados. Evita colisiones con el tema de Shopify.
- Tokens de marca como variables CSS (ver `brand-look-and-feel.md`).
- `html,body{margin:0;padding:0;width:100%}` dentro del embed; contenedores `width:100%`,
  `max-width` + `margin:0 auto` para centrar.
- **Nunca** `min-height:100vh` (rompe alturas en editores/embeds). Sin `<script>` externos.
- Fuentes por `@import`/`<link>`; imágenes por URL (CDN Shopify o imgur), nunca base64 pesado.
- Responsive: grids 3→2→1 con `@media`; imágenes `max-width:100%`.
- Acentos con entidades HTML. CTA a la oferta/PDP/checkout reales.
- Accesibilidad mínima: jerarquía `h1>h2>h3`, `alt` en imágenes, contraste suficiente.

## 1. Landing CRO (venta directa)
Para tráfico solution-aware / warm o post-presell. Objetivo: una decisión (comprar).
Secciones típicas:
1. **Hero above-the-fold** — responde las 4 preguntas ([[mlo-cro-2026]]): qué es, para quién, por
   qué mejor, qué hago ahora. Titular claro + subtítulo + CTA + visual de producto + trust bar.
2. **Prueba inmediata** — reseñas/estrellas/logos reales (o `[PRUEBA REAL]`).
3. **Beneficios benefit-led** — 3–4 bloques (no features sueltas; pasa el "so-what test").
4. **Cómo funciona / mecanismo** — 3 pasos o el mecanismo único.
5. **Oferta** — bundle/regalo/envío como posicionamiento, no solo descuento. Precio real o `[PRECIO]`.
6. **Prueba profunda** — foto/vídeo primero, testimonios con nombre, antes/después si es real.
7. **Objeciones / FAQ** — las 5–7 reales del avatar.
8. **Garantía / risk reversal**.
9. **CTA final** + recap de oferta.

## 2. Advertorial (editorial, tráfico frío)
Parece un artículo, no una PDP. Entra por síntoma/curiosidad/sesgo, nunca por el producto.
Anatomía de 10 secciones ([[mlo-cro-2026]] Parte B + [[advertorial-strategist]] para el ángulo):
1. **Hook / titular editorial** (breaking-news, historia, contrarian).
2. **Dolor emocional** — mete el dedo en la llaga del avatar.
3. **Por qué nada funcionó** — descarta soluciones previas.
4. **Causa raíz** — el "aha" que reencuadra el problema.
5. **Mecanismo único** — cómo el producto ataca la causa raíz.
6. **Proof story** — historia/caso real (o `[CASO REAL]`).
7. **Objeciones** — resolución natural dentro del texto.
8. **Precio + escasez** (real).
9. **Garantía**.
10. **Comentarios/social proof** al pie (reales).
Diseño: ancho de lectura tipo artículo (`max-width:720px`), tipografía legible, imágenes
intercaladas, CTA repartidos (después del mecanismo, tras la proof story y al final). Debe parecer
contenido, con disclaimer "publirreportaje/contenido patrocinado" si la marca/plataforma lo exige.

## 3. Listicle (presell en lista)
"Los 5 …", "3 razones por las que …". Bueno para categorías conocidas donde el producto es "el
mejor entre varios".
1. **Titular de lista** + intro corta (promesa + credibilidad).
2. **Ítems de la lista** (3–7) — cada uno: subtítulo, imagen, párrafo, mini-CTA. El producto
   aparece como el ítem ganador o transversal.
3. **Comparativa / por qué gana** — tabla o bloque de diferenciación (datos reales).
4. **Prueba** — reseñas reales.
5. **CTA final** + oferta.
Diseño: ritmo de lectura escaneble, números grandes, imagen por ítem, CTA suave hasta el cierre.

## Patrón de módulos reutilizables
Reutiliza estos bloques (mismos que en las páginas de caso de MLO) volcando tokens:
- **Hero** con eyebrow (pill), `h1` con `<em>` en `--font-accent`, meta y CTA.
- **Stat row** (3 columnas) para datos clave reales.
- **Cards** con hover de acento (`border-color:var(--accent)`).
- **Bullets** con punto/flecha en `--accent`.
- **Cita/social proof** centrada o en grid de 3.
- **CTA band** con botón `--accent` / `--accent-ink`.

## Checklist antes de dar por hecha la página
- [ ] Copy real (0 claims inventados; placeholders marcados).
- [ ] Tokens de marca aplicados (se ve de la marca).
- [ ] Above-the-fold responde las 4 preguntas / el hook engancha.
- [ ] Responsive verificado (desktop + móvil).
- [ ] CTA apunta a destino real.
- [ ] CSS scoped, sin scripts externos, sin base64 pesado.
