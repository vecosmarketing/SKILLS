# Look & feel de la marca — token set

El objetivo es que la página **parezca de la marca**, no de plantilla. Para eso construimos un
"token set": un pequeño JSON con las variables de diseño de la marca, que luego se vuelca a
variables CSS (`:root { --brand-... }`) en el código de la página.

## Schema del token set

```json
{
  "brand": "8HOURS",
  "store_url": "https://8hours.example",
  "mode": "dark",                         // dark | light — según el fondo dominante de la marca
  "colors": {
    "bg": "#090909",                      // fondo principal
    "surface": "#141414",                 // tarjetas / secciones elevadas
    "text": "#ffffff",                    // texto principal
    "muted": "#c2c2c9",                   // texto secundario
    "accent": "#4AFF53",                  // color de marca / CTA
    "accent_ink": "#04240f",              // texto SOBRE el accent (contraste)
    "line": "rgba(255,255,255,.12)"       // bordes/hairlines
  },
  "fonts": {
    "heading": "'Satoshi', system-ui, sans-serif",
    "body": "'Satoshi', system-ui, sans-serif",
    "accent_italic": "'Instrument Serif', serif",   // opcional, para dato clave
    "imports": [
      "https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700,900&display=swap"
    ]
  },
  "button": {
    "radius": "100px",                    // px o %
    "padding": "15px 28px",
    "weight": 700,
    "style": "solid"                      // solid | outline | pill
  },
  "radius": "18px",                        // radio general de tarjetas
  "spacing": "generous",                   // tight | normal | generous
  "notes": "Estética premium, mucho negro, verde neón como único acento."
}
```

## Cómo rellenarlo (fusiona las 3 fuentes)

Prioridad de mayor a menor cuando haya conflicto: **(3) brandbook manual > (2) Brand Brain > (1) auto-escaneo**.
El auto-escaneo aporta fidelidad al CSS real; el Brand Brain aporta la intención oficial; el
brandbook manual es la última palabra de Marcel.

### Fuente 1 — Auto-escaneo de la tienda live
Corre el script y parte de su salida como base:

```bash
python3 scripts/extract_brand_tokens.py https://la-tienda-de-la-marca.com
```

Devuelve un JSON con `colors`, `fonts` (incluye `imports` detectados) y `button` inferidos del
CSS y el HTML de la home. Trátalo como **borrador**: revisa que el accent sea el color de marca
(no un color de banner puntual) y que las fuentes sean las de contenido (no íconos).

Si el script no puede acceder (sin URL, bloqueo, JS-only), pásate a las otras dos fuentes y/o
pide screenshots a Marcel.

### Fuente 2 — Brand Brain
Lee `mlo-brand-brain-<marca>` (p. ej. `mlo-brand-brain-8hours`, `mlo-brand-brain-ancestra`). Saca:
paleta oficial, tipografías, tono visual (editorial/premium/divertido), y **do/don'ts** de marca
y de claims. Úsalo para corregir el borrador del escaneo.

### Fuente 3 — Brandbook manual
Si Marcel te da colores/fuentes/logo, mandan. Pídeselos si la marca es sensible o el escaneo salió
pobre.

## Volcar tokens a CSS

En el `<style>` de la página, define las variables sobre el contenedor con prefijo único:

```css
.mlopc-8h{
  --bg:#090909; --surface:#141414; --text:#fff; --muted:#c2c2c9;
  --accent:#4AFF53; --accent-ink:#04240f; --line:rgba(255,255,255,.12);
  --radius:18px; --btn-radius:100px;
  --font-h:'Satoshi',system-ui,sans-serif; --font-b:'Satoshi',system-ui,sans-serif;
  --font-accent:'Instrument Serif',serif;
  font-family:var(--font-b); background:var(--bg); color:var(--text);
}
```

Y usa siempre las variables (`background:var(--accent)`, etc.), nunca colores hardcodeados sueltos.
Así, cambiar de marca = cambiar el token set, no reescribir la página.

## Reglas de contraste y modo
- Si `mode:dark`, texto claro sobre fondos oscuros; el accent es para CTA y datos clave, no para
  párrafos largos.
- Comprueba contraste del texto sobre `--accent` con `--accent-ink` (el CTA tiene que leerse).
- Respeta el modo real de la marca aunque el ejemplo de MLO sea oscuro: una marca clean-beauty
  suele pedir `light`/editorial.
