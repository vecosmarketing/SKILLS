# Publicar en Shopify — Página nativa y Sección de tema

Se publica con el **Shopify MCP conectado**. Herramientas relevantes (nombres tal cual):
`list-stores`, `switch-shop`, `get-shop-info`, `graphql_query`, `graphql_mutation`,
`graphql_schema`. Todo el código de la página va dentro del HTML que mandas en la mutation.

> Regla de seguridad: **publicar es una acción de cara al público**. Crea siempre en **borrador**
> (Página `isPublished:false`) o sobre un **tema UNPUBLISHED** (Sección), enseña la preview a
> Marcel, y solo publica en vivo con su OK explícito. Nunca escribas en el tema live sin permiso.

## Paso 0 — Seleccionar la tienda correcta
```
list-stores                      → ver las tiendas conectadas
switch-shop <la de la marca>     → fijar la activa
get-shop-info                    → confirmar dominio/plan/currency antes de escribir
```
Si la marca no está entre las tiendas conectadas, avisa a Marcel (hay que conectarla); no publiques
en la tienda equivocada.

## Comprobar versión de API y scopes
Antes de una mutation nueva, valida el shape con `graphql_schema` (los inputs cambian por versión).
Scopes necesarios (si falla por permisos, es esto):
- Página nativa → `write_online_store_pages`.
- Sección de tema → `read_themes` + `write_themes`.
Si un scope no está, díselo a Marcel (hay que ampliarlo en la app); no intentes rodearlo.

---

## Modo A — Página nativa (recomendado por defecto)

Crea una Online Store Page cuyo cuerpo es tu HTML/CSS. Rápida, segura, reversible.

### Crear en borrador
```graphql
mutation CrearPagina($page: PageCreateInput!) {
  pageCreate(page: $page) {
    page { id title handle isPublished onlineStoreUrl }
    userErrors { field code message }
  }
}
```
Variables:
```json
{
  "page": {
    "title": "8HOURS — Duerme mejor",
    "handle": "8hours-landing",
    "body": "<!-- TODO tu HTML/CSS scoped aquí -->",
    "isPublished": false,
    "templateSuffix": null
  }
}
```
- `body` admite HTML + `<style>` inline (por eso el CSS va scoped). Sin `<script>` externos.
- Revisa `userErrors` siempre. Guarda el `id` y el `handle`.
- Preview del borrador: `https://<dominio>/pages/<handle>` puede requerir tema con vista previa;
  si no, usa el editor de Shopify. Comparte la URL/really el estado con Marcel.

### Actualizar / publicar en vivo (tras OK)
```graphql
mutation ActualizarPagina($id: ID!, $page: PageUpdateInput!) {
  pageUpdate(id: $id, page: $page) {
    page { id isPublished onlineStoreUrl }
    userErrors { field code message }
  }
}
```
Para publicar: `pageUpdate` con `{ "isPublished": true }`. Para editar el contenido: manda de nuevo
`body`. (Compatibilidad: si la versión de API no expone `pageCreate/pageUpdate`, usa la Page REST
Admin con `body_html` vía la herramienta REST equivalente, mismo concepto.)

### Rollback
Despublicar → `pageUpdate { isPublished:false }`. Borrar → `pageDelete(id)`.

---

## Modo B — Sección / plantilla de tema (avanzado)

Máxima integración: la página vive dentro del tema y es editable desde el theme editor. Escribe
archivos del tema con `themeFilesUpsert`. **Hazlo sobre un tema duplicado/UNPUBLISHED.**

### 1. Localizar el tema y trabajar sobre uno unpublished
```graphql
query { themes(first: 20, roles: [MAIN, UNPUBLISHED, DEVELOPMENT]) {
  nodes { id name role } } }
```
Elige o crea un tema UNPUBLISHED (para clientes, ideal duplicar el MAIN antes de tocar nada; si el
MCP no expone duplicado por GraphQL, pide a Marcel que duplique el tema en el admin y trabaja sobre
esa copia).

### 2. Subir sección + plantilla
`themeFilesUpsert` acepta varios archivos a la vez:
```graphql
mutation SubirArchivos($files: [OnlineStoreThemeFilesUpsertFileInput!]!, $themeId: ID!) {
  themeFilesUpsert(files: $files, themeId: $themeId) {
    upsertedThemeFiles { filename }
    userErrors { field code message }
  }
}
```
Sube dos archivos:
1. `sections/mlopc-<marca>-<tipo>.liquid` — tu HTML/CSS dentro de la sección, con un bloque
   `{% schema %}` mínimo al final para que sea válida:
   ```liquid
   <!-- tu HTML/CSS scoped -->
   {% schema %}
   { "name": "MLO Page — <tipo>", "settings": [], "presets": [{ "name": "MLO Page — <tipo>" }] }
   {% endschema %}
   ```
2. `templates/page.mlopc-<marca>-<tipo>.json` — plantilla que instancia la sección:
   ```json
   { "sections": { "main": { "type": "mlopc-<marca>-<tipo>" } }, "order": ["main"] }
   ```
Pasa el contenido en `files` como `[{ "filename": "...", "body": { "type": "TEXT", "value": "..." } }]`
(valida el shape exacto de `OnlineStoreThemeFilesUpsertFileInput` con `graphql_schema`).

### 3. Conectar una página a la plantilla
Crea/actualiza la Page (Modo A) con `templateSuffix: "mlopc-<marca>-<tipo>"` para que use tu
plantilla. Así el contenido vive en el tema pero se sirve como página.

### 4. Preview y publicar
Previsualiza el tema UNPUBLISHED desde el admin (o su preview URL). Publicar el tema es un cambio
grande de cara al público → **solo con OK explícito de Marcel** (`themePublish(id)` si está
disponible, o que lo publique él en el admin).

### Rollback
Restaura el tema anterior (seguía publicado) o borra los archivos subidos con la mutation de
delete de archivos de tema. Como trabajaste sobre un tema unpublished, el live no se toca hasta
publicar.

---

## Errores comunes
- **`userErrors` con `handle` duplicado** → cambia el `handle`.
- **Permiso denegado** → falta scope (arriba). Avísalo, no lo rodees.
- **El CSS "se sale" o hereda estilos del tema** → tu CSS no estaba bien scoped; prefija todo.
- **Fuentes no cargan** → Shopify puede tener CSP; usa fuentes de Google/Fontshare por `<link>` y
  deja fallback de sistema en cada `font-family`.
- **Imágenes** → súbelas al CDN de Shopify (Files) o usa imgur; referencia por URL absoluta.
