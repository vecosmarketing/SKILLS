# NIL — Catálogo de productos y ángulos por SKU

Cada producto tiene un ángulo ganador validado en Meta Ads. Úsalo como hilo conductor del guion, no inventes uno nuevo salvo que el usuario te pida explícitamente probar algo diferente.

---

## ZUECOS

**Colección:** /collections/zuecos

**Qué es:** zuecos de enfermería ligeros, homologados, con suela antideslizante. Disponibles en varios colores (rosa, blanco, negro, morado, etc.). Producto estrella de NIL.

**Ángulos validados (orden de fuerza):**
1. Comodidad real en turno largo de 12h
2. Respeto anatómico del pie (no comprime los dedos como zuecos tradicionales más estrechos)
3. Ligereza (no notas que los llevas)
4. Diseño con estilo (rosa, no el típico blanco aburrido)

**Beneficios reales (que SÍ se pueden afirmar):**
- Ligeros
- Antideslizantes
- Cómodos desde el primer uso
- Aguantan turnos largos
- Estilo

**Cuidado / guardrails:**
- ❌ NO sobreprometer durabilidad ("duran años", "para toda la vida")
- ❌ NO mencionar "plantilla acolchada" — NIL no tiene plantilla acolchada
- ❌ NO comparar agresivamente con marcas competidoras nombradas

**Verbatims usables:**
- "Acabo el turno y ya no me arrastro al coche"
- "Por fin unos zuecos que aguantan turnos largos"
- "Cómodos desde el primer día"

---

## MEDIAS DE COMPRESIÓN

**Colección:** /collections/medias-de-compresion

**Qué es:** medias de compresión graduada diseñadas específicamente para enfermería (presión validada para 12h de pie). Vienen en pack/set.

**Ángulos validados:**
1. Presión justa que NO se baja durante el turno
2. Diseñadas específicamente para enfermería (no son de farmacia genéricas)
3. Llegar a casa sin las piernas reventadas
4. Para turnos largos / doblar turnos

**Beneficios reales:**
- Presión graduada
- No se bajan
- Pensadas para 12h de pie
- Diseño cuidado

**Cuidado / guardrails:**
- ❌ NO sobreprometer consistencia entre tallas (algunas reviews mencionan variaciones)
- ❌ NO mezclar con calcetines en el mensaje (son productos distintos para use cases distintos)
- ❌ NO prometer cura de varices ni problemas circulatorios crónicos (es producto de prevención/comodidad, no médico)

**Insight VOC:**
- 38% las lleva siempre, 21% solo turnos largos. La media es producto situacional.
- Verano: muchas las cambian por calcetines transpirables porque dan calor.

---

## CALCETINES

**Qué es:** calcetines de enfermería estampados, cómodos, transpirables. Versión básica diaria.

**Ángulos validados:**
1. **El básico diario del uniforme** (no es un accesorio, es lo que llevas todos los días)
2. Comodidad pura — el 72% de la comunidad lo dice
3. Transpirable en verano (oportunidad estacional clave junio-agosto)
4. Estampados con personalidad enfermera

**Beneficios reales:**
- Cómodos
- Transpirables
- Estampados cuidados
- Caben bien dentro del zueco

**Cuidado / guardrails:**
- ❌ NO confundirlo con medias de compresión — son productos distintos
- ❌ NO posicionarlo como accesorio aspiracional, es básico diario
- ✅ SÍ enfatizar transpirabilidad y comodidad pura

**Verbatim usable:**
- "Comodidad que no aprieta y aguanta el turno"

---

## NEVERITA

**Colección:** /collections/neveritas

**Qué es:** bolsa térmica para llevar la comida al hospital. Mantiene la temperatura varias horas. Color principal: morado café.

**Ángulos validados:**
1. **Comer caliente en el descanso** — adiós al bocata frío
2. Capacidad real (cabe lo de un turno entero)
3. Diseño estampado, no térmica fea de plástico
4. Aguanta toda la mañana sin perder temperatura

**Beneficios reales:**
- Mantiene la temperatura horas
- Capacidad para tuper + bebida + snack
- Estampados cuidados
- Cómoda de llevar (bandolera/asas)

**Cuidado / guardrails:**
- ❌ NO mencionar que va DENTRO del bolso NIL — son productos separados que se compran por separado
- ❌ NO prometer que "no se enfría" (mantiene varias horas, pero un turno de 12h va a notar temperatura)

**Verbatim usable:**
- "Como caliente en el descanso, ya no más bocata frío"
- "Aguanta toda la mañana sin perder temperatura"

---

## GORROS DE QUIRÓFANO (cuffie)

**Qué es:** gorros de tela reutilizables para enfermeras de quirófano con **botones laterales** para enganchar la goma de la mascarilla. Estampados variados.

**Ángulos validados (ESTOS SON MUY FUERTES):**
1. **El botón lateral elimina el dolor de orejas por la mascarilla** ← insight VOC clave, no obvio para quien no es de quirófano
2. Estampados que se quieren llevar (no el típico gorro feo desechable)
3. **Tribal adoption — todo el equipo de quirófano los lleva** ← otro insight VOC potente
4. Reutilizables, no monouso

**Beneficios reales:**
- Botones a ambos lados para enganchar la goma de la mascarilla
- Estampados variados
- Reutilizables (lavables)
- Cómodos para 12h

**Cuidado / guardrails:**
- ✅ Posicionar específicamente para enfermeras de quirófano (es el use case principal)
- ❌ NO posicionarlo para enfermeras generales como sustituto de coleteros o accesorio decorativo

**Insight VOC clave:**
- *"12 horas con la mascarilla sin notarla"*
- *"El botón lateral me ha salvado las orejas"*
- *"Mis compañeras me los piden, ya tenemos todo el equipo"*

**Italiano:**
- "Gorro" en italiano sanitario = **cuffia** (femenino), plural **cuffie**. NO "copricapo". Aplicar concordancias femeninas.

---

## ORGANIZADOR DE BOLSILLO

**Colección:** /collections/organizador-de-bolsillo

**Qué es:** organizador pequeño que se mete en el bolsillo de la casaca para llevar tijeras, boli, linterna, etc. ordenado. Tiene compartimentos.

**Ángulos validados:**
1. Material siempre a mano, ya no se pierden las tijeras
2. Profesional (versus llevar las cosas sueltas)
3. Compartimento para cada cosa

**Beneficios reales:**
- Compartimentos pensados para el material de enfermería
- Cabe en el bolsillo de la casaca
- Material visible y accesible

**Cuidado / guardrails:**
- ❌ NO sobreprometer agarre de imanes (algunas reviews lo mencionan)
- ❌ NO sobreprometer corte/calidad de las tijeras incluidas (son tijeras auxiliares de presentación, no quirúrgicas)
- ❌ NO posicionarlo como sustituto de tijeras quirúrgicas profesionales

**Verbatim usable:**
- "Ya no busco las tijeras 3 veces por turno"
- "Cada cosa en su sitio, no se me cae nada"

---

## BOLSO

**Colección:** /collections/bolsos

**Qué es:** bolso/tote para llevar al hospital. Capacidad grande, compartimentos para uniforme + zapatos + tuper + accesorios. Estampados.

**Ángulos validados (REGLA INFLEXIBLE):**
1. **CAPACIDAD / ORGANIZACIÓN — cabe todo el turno** ← ángulo principal
2. Compartimentos pensados para enfermería
3. Aguanta el uso diario

**Cuidado / guardrails (MUY IMPORTANTE):**
- ❌❌ **NUNCA posicionar el bolso por dolor de espalda u hombro** — guardrail validado. El ángulo es capacidad, no dolor
- ❌ NO mencionar que la neverita va dentro del bolso (son productos separados)
- ❌ NO sobreprometer impermeabilidad

**Verbatim usable:**
- "Cabe el turno entero, ya no llevo dos bolsas"
- "Compartimentos para todo lo del hospital"
- "Por fin un bolso pensado para enfermería"

---

## AGENDA

**Colección:** /collections/agendas

**Qué es:** agenda anual diseñada para enfermería con apartados de turnos, guardias, formación, citas personales. Estampados NIL.

**Ángulos validados:**
1. Organizar turnos y vida personal en un solo sitio
2. Diseñada con apartados que una agenda genérica no tiene
3. Estética NIL

**Cuidado:**
- Si es lanzamiento anual (septiembre típicamente), apoyarse en novedad
- Si es momento medio del año, posicionar como complemento al planning de turnos del hospital

---

## LANYARD

**Colección:** /collections/lanyards

**Qué es:** cinta para colgar la tarjeta de identificación del hospital. Estampados NIL.

**Ángulos validados:**
1. Estilo / personalidad (el típico es feo)
2. Práctico — la tarjeta siempre a mano
3. Detalle que da personalidad al uniforme

**Cuidado:**
- Es producto de bajo precio (€) — los guiones deben ser cortos, no VSSL largos
- Ideal para ads de UGC corto, bundle con otros productos, o cross-sell

---

## PORTATIJERAS

**Colección:** /collections/porta-tijeras-enfermeria

**Qué es:** funda pequeña para llevar las tijeras enganchada al bolsillo.

**Ángulos:**
1. Las tijeras ya no se pierden
2. Profesional (no llevar las tijeras sueltas)

**Cuidado:**
- Producto complementario, suele venderse junto con tijeras o como cross-sell

---

## GIFT SETS / PACKS

Combinaciones de varios productos a precio agrupado.

**Ángulos:**
1. Regalo perfecto para enfermera (graduación, cumple, día de la enfermera)
2. Equiparse de golpe (ideal para recién graduadas que necesitan todo)

**Buyer persona específico:** Para gift sets puede aparecer la persona **COMPRADOR DE REGALO** (familiar/pareja que regala a la enfermera). Adapta el guion para esa persona si el contexto lo justifica.
