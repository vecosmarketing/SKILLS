# NIL — Guardrails (lo que NO se puede decir)

Estos guardrails están validados con el cliente sobre reviews negativas y/o no publicadas reales. Cumplirlos no es opcional — incumplirlos hace que el guion no se apruebe y, en el peor caso, expone a la marca a quejas legales.

---

## Reglas generales (aplican a todos los productos)

### ❌ No prometer lo que el producto no cumple
Si una review negativa o no publicada menciona que el producto no cumplió X, X no se puede afirmar en el guion. Aunque sea un caso aislado.

### ❌ No usar comparativas agresivas con competidores nombrados
NIL es marca con personalidad propia, no necesita ensuciar a otras. Está permitido decir "zuecos baratos" o "el típico gorro feo" — pero NO "como [marca X] pero mejor".

### ❌ No excluir colectivos del público objetivo
Específicamente: **TCAE** (técnicos auxiliares de enfermería) y técnicas auxiliares son cliente potencial real. NO usar frases como "solo para enfermeras de grado", "solo para profesionales con título universitario", etc.

### ❌ No copy con tono médico clínico
NIL no es marca médica. Evitar:
- "Estudios clínicos demuestran..."
- "Avalado por la ciencia"
- "Tratamiento de la insuficiencia venosa"
- "Recomendado por médicos especialistas"

Sí está bien decir "diseñado por y para enfermeras", "pensado para 12h de pie", "presión justa para el turno".

### ❌ No usar emojis en guion hablado
Los emojis son para copy de ad escrito (primary text, headlines). En guion de vídeo (lo que dice la persona en cámara) NO van — no se ven en pantalla y rompen la naturalidad del habla.

### ❌ No hacer promesas absolutas ("siempre", "nunca", "para toda la vida")
Convertir absolutos en relativos:
- "Duran para toda la vida" → "Aguantan turno tras turno"
- "Nunca se bajan" → "No se bajan durante el turno"
- "Siempre cómodos" → "Cómodos desde el primer día"

---

## Guardrails específicos por producto

### ZUECOS

❌ NO decir: "tienen plantilla acolchada" → **no la tienen**
❌ NO decir: "duran años" → marca de durabilidad no se aprueba
❌ NO decir: "perfectos para correr" o "para hacer deporte" → son de trabajo, no deportivos
❌ NO decir: "aprobados por podólogos" → no hay aval profesional médico
✅ SÍ decir: "ligeros", "antideslizantes", "cómodos desde el primer día", "aguantan turnos largos"

### MEDIAS DE COMPRESIÓN

❌ NO decir: "todas las tallas quedan igual" → variabilidad reportada en reviews
❌ NO decir: "curan las varices" → no es producto médico
❌ NO decir: "elimina la celulitis" → fuera del scope del producto
❌ NO confundir con calcetines: "calcetines de compresión" cuando hablas de medias
✅ SÍ decir: "presión justa", "no se bajan", "diseñadas para enfermería", "llegas a casa sin las piernas reventadas"

### CALCETINES

❌ NO posicionarlo como producto médico ni "calcetín de compresión" → es calcetín normal cómodo
❌ NO confundir con medias
✅ SÍ enfatizar: "comodidad pura", "transpirables", "para el día a día"

### NEVERITA

❌ NO decir: "va dentro del bolso NIL" → son productos SEPARADOS, esta confusión genera devoluciones
❌ NO decir: "mantiene caliente todo el día" → mantiene varias horas, no 12h enteras
❌ NO decir: "es nevera de verdad" → es bolsa térmica, no nevera eléctrica
✅ SÍ decir: "mantiene la temperatura horas", "comer caliente en el descanso", "cabe el turno entero"

### GORROS (cuffie)

❌ NO posicionarlo como accesorio de moda casual → es producto profesional para quirófano
❌ NO decir: "elimina toda fricción de la mascarilla" → reduce significativamente, no elimina al 100%
✅ SÍ enfatizar: "botón lateral para la mascarilla", "12h sin notar la mascarilla", "estampados que mola llevar"

### ORGANIZADOR DE BOLSILLO

❌ NO sobreprometer agarre de imanes (reviews reportan que se pueden soltar con movimiento brusco)
❌ NO decir: "las tijeras cortan todo" → son auxiliares, no quirúrgicas profesionales
❌ NO decir: "indispensable para cirugía" → es para trabajo de planta, no quirófano
✅ SÍ decir: "cada cosa en su sitio", "ya no pierdes las tijeras", "compartimentos pensados"

### BOLSO

❌❌❌ **NUNCA** posicionarlo por dolor de espalda/hombro → guardrail clave del cliente
❌ NO decir: "la neverita va dentro" → productos separados
❌ NO decir: "impermeable" → resistente al agua, no impermeable
✅ SÍ decir: "cabe el turno entero", "compartimentos para todo", "aguanta el día a día del hospital", "pensado para enfermería"

### AGENDA

❌ NO posicionarlo como agenda genérica → su valor está en los apartados específicos de enfermería
✅ SÍ enfatizar: "apartados para turnos", "tu vida profesional y personal en un solo sitio"

### LANYARD

❌ NO sobreprometer resistencia del enganche → es accesorio, no equipo industrial
✅ SÍ enfatizar: "estilo", "la tarjeta siempre a mano"

---

## Confusiones frecuentes a evitar

1. **Calcetines ≠ medias de compresión**
   - Calcetín = básico diario, cómodo, transpirable
   - Media = producto situacional para turnos largos o doblar
   - NO usarlos como sinónimos en el mismo guion

2. **Neverita ≠ bolso**
   - Productos SEPARADOS, se compran por separado
   - NO decir que la neverita va dentro del bolso
   - Si quieres que aparezcan los dos en el guion, son dos productos distintos

3. **Gorros NIL ≠ gorros desechables del hospital**
   - NIL es reutilizable, de tela, con botones laterales
   - Los del hospital son monouso, finos, sin botones
   - Este contraste sí se puede usar como pattern de "antes con gorro del hospital / ahora con NIL"

4. **Tijeras del organizador ≠ tijeras quirúrgicas profesionales**
   - Las que vienen con el organizador son auxiliares
   - NO posicionarlas como sustituto de tijeras profesionales

---

## Cuando dudes

Si dudas sobre si un claim se puede hacer o no:
- Por defecto, **omítelo** y usa una formulación más conservadora
- Mejor un guion suave que un guion bonito que no se aprueba
- Avisa al usuario: "He suavizado X porque sin más contexto no puedo verificar el claim — si lo tienes confirmado podemos meterlo"
