# NIL — Voz española de España

Todo el contenido para el mercado ES tiene que sonar a España, no a Latinoamérica neutra ni a "español de marca corporativa". El target es enfermera española, que habla así en su día a día.

---

## Vocabulario obligatorio (España)

| Decimos | NO decimos | Contexto |
|---|---|---|
| bambas | deportivas / tenis | "ir con bambas al hospital" |
| mola / molan | está genial / es cool | "los estampados molan" |
| currar / curro | trabajar (a veces sí, según contexto) | "después de currar 12h" |
| hecha polvo / reventada | exhausta / cansada | "llego a casa hecha polvo" |
| mogollón | muchísimo / un montón | "tengo mogollón de tijeras perdidas" |
| vale | está bien / OK | "Vale, te lo explico" |
| fonendo | estetoscopio | habla casual de enfermería |
| coger (algo) | tomar / agarrar | "coger el bolso" |
| doblar (un turno) | hacer turno doble | "cuando doblo turno..." |
| pijama / casaca / bata | scrubs | uniforme de trabajo |
| chaval / chavala | persona joven | "es una chavala recién graduada" |
| flipar | alucinar / sorprenderse | "vas a flipar con la diferencia" |
| dar palo | dar pereza | "me da palo cargar dos bolsas" |
| pasarse | ir demasiado lejos | "esto se pasa, no aguanto más" |
| de p\*ta madre | muy bien | usar SOLO si guion muy casual, suave censura por escrito |

---

## Vocabulario sanitario natural (no clínico)

Lo que diría una enfermera hablando con otra, no lo que pondría en un informe médico.

| Decimos | NO decimos |
|---|---|
| la planta (de cardio, de pediatría...) | unidad / servicio |
| el office | sala de descanso |
| el turno (de mañana / tarde / noche) | jornada laboral |
| doblar | hacer doble turno |
| quirófano | sala operatoria / SO |
| guardias | turnos de fin de semana / festivos |
| los compis / las compis | compañeros / colegas |
| pasarse el turno | culminar el turno |
| el carro | trolley de medicación |
| el bolsillo de la casaca | el bolsillo del uniforme |
| las tijeras (de enfermera) | tijeras de Mayo |
| el fonendo | estetoscopio (en habla casual) |
| la mascarilla | el barbijo / cubrebocas (NUNCA — eso es México) |

---

## Estructura natural del habla

Una enfermera no habla en frases cortas perfectas tipo eslogan. Habla más así:

✅ **Natural:**
- "Yo es que después de 10h ya estoy hecha polvo, vaya"
- "Bueno mira, te lo digo en serio: el organizador me ha cambiado el turno"
- "Y luego pum, la goma de la mascarilla rozándote toda la mañana"

❌ **Antinatural (suena a copy de ad):**
- "Mi rendimiento profesional se ve potenciado por el uso del organizador"
- "Mis turnos son significativamente más eficientes ahora"
- "Es un producto de calidad excepcional"

### Conectores y muletillas que se pueden usar

- "Mira", "Bueno mira", "A ver"
- "O sea", "Es que", "Es que tía / es que chica"
- "De hecho", "La verdad es que"
- "Pum", "Y zas", "Y nada" (transiciones casuales)
- "Vamos", "Vamos que..."
- "Te digo una cosa", "Te juro"
- "Y ya está", "Y punto"

---

## Palabras / expresiones PROHIBIDAS (suenan a latinoamericano o a corporate)

- "Padrísimo" / "chévere" / "está chido" / "qué chimba" → es España, no LATAM
- "Tenis" (cuando se refiere a zapatillas) → en España es "bambas" o "zapatillas"
- "Te platico" → "te cuento"
- "Ahorita" → "ahora"
- "Manejar (un coche)" → "conducir"
- "Computadora" → "ordenador"
- "Solución integral" → suena a corporate, no a persona real
- "Experiencia premium" → no encaja en NIL
- "Innovador / disruptivo" → palabras vacías
- "Calidad excepcional" → genérico
- "Producto único en el mercado" → tópico
- "Como sabéis bien" / "Como bien sabes" → suena a marca antigua

---

## Si el guion es para italiano

NO traducir literal las muletillas españolas. Adaptar a equivalentes italianos naturales:

| ES | IT |
|---|---|
| "mira" | "guarda" |
| "bueno mira" | "allora guarda" / "senti" |
| "es que..." | "il fatto è che..." |
| "vamos" | "insomma" |
| "te juro" | "te lo giuro" |
| "y ya está" | "e basta" |
| "hecha polvo" | "distrutta" |
| "mogollón" | "un sacco" |
| "currar" | "lavorare" (en italiano no hay equivalente casual igual de fuerte) |
| "mola" | "è figo" / "spacca" |

---

## Detalles de tono adicionales

- **Tutea siempre.** Jamás "usted" ni "ustedes". Las enfermeras se hablan de tú entre ellas.
- **No exagera vacío.** No "¡¡¡INCREÍBLE!!!" ni "¡¡cambiará tu vida!!". NIL no grita, conversa.
- **Habla en femenino por defecto** cuando hablas a la enfermera. El 90% del target es femenino. Solo masculino genérico si el contexto lo exige.
- **Reconoce sin dramatizar.** "Estás reventada después de 12h" ✅ — "Tu heroico sacrificio cuidando vidas" ❌
- **Concreto > abstracto.** Mejor "buscar las tijeras 3 veces por turno" que "ineficiencias en la organización del material".
