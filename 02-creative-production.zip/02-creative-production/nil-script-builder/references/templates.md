# NIL — Templates de guion validados

Estos son los esqueletos de guion que mejor funcionan para NIL en Meta Ads e Instagram. Cada uno tiene una estructura probada — úsalos como base y adapta al producto.

---

## TEMPLATE 1 — UGC Testimonial Review (15-30s)

**Cuándo usarlo:** anuncios de social proof, cierre de funnel (MOFU/BOFU), cuando ya conocen NIL y necesitan un empujón final.

**Estructura:**

```
SEGUNDO 0-3 (HOOK):
[Plano selfie de la enfermera en uniforme, en su entorno real — vestuario, hospital, casa]
"Mira, te voy a contar por qué [producto] me ha cambiado el turno"

SEGUNDO 3-10 (PROBLEMA):
[Mismo plano o B-roll del dolor — pies cansados, bocata frío, etc.]
"Antes [situación de dolor concreta]. [1 frase de validación del problema]"

SEGUNDO 10-22 (SOLUCIÓN):
[Muestra el producto, plano cercano. Lo sostiene, lo usa, lo señala]
"Desde que tengo [producto], [beneficio concreto]. La diferencia es que [diferenciación específica]"

SEGUNDO 22-28 (REFUERZO):
[Vuelta al plano cara, sonrisa natural]
"En serio, [validación corta], [llamada emocional]"

SEGUNDO 28-30 (CTA):
[Plano del producto + nombre/logo NIL en pantalla]
"Si eres enfermera, échale un ojo. Se llama Nurse is Love"
```

**Tono:** confidencial, como hablando con una compañera de planta en el office.
**Wardrobe:** uniforme real (casaca, bata, pijama de quirófano según producto).
**Plano:** 1ª persona, selfie, vertical 9:16. Luz natural, no estudio.

---

## TEMPLATE 2 — Problema → Solución (30-45s)

**Cuándo usarlo:** TOFU/MOFU. Audiencia que tiene el problema pero no conoce la solución.

**Estructura:**

```
SEGUNDO 0-3 (HOOK — el dolor):
[Plano cercano del problema: pies, oreja con roce, bocata frío, tijeras perdidas]
"Si llegas a casa después del turno con [problema concreto]..."

SEGUNDO 3-8 (VALIDACIÓN):
[Plano de enfermera, gesto de cansancio o frustración]
"...sabes de qué te hablo. No eres tú, no es que aguantes poco. Es el [producto antiguo / falta de producto adecuado]"

SEGUNDO 8-20 (REVELACIÓN):
[Muestra el producto NIL]
"Hace [tiempo] empecé a usar [producto]. Y [cambio concreto]"

SEGUNDO 20-35 (PRUEBA CONCRETA):
[Demo del producto en uso: zueco caminando, gorro con botón lateral, neverita abierta con tuper caliente]
"[Característica específica que resuelve el problema]. Mira, [muestra cómo funciona]"

SEGUNDO 35-43 (RESULTADO TANGIBLE):
"Ahora [resultado palpable y específico, no genérico]"

SEGUNDO 43-45 (CTA):
"Se llama Nurse is Love. Está en la bio"
```

**Tono:** validación + revelación. La creadora habla como descubridora del producto, no como vendedora.

---

## TEMPLATE 3 — VSSL Educacional (60-90s)

**Cuándo usarlo:** TOFU para audiencia fría. Cuando hay que explicar un problema o categoría antes de presentar el producto.

**Estructura:**

```
SEGUNDO 0-5 (HOOK — pregunta o stat):
"¿Sabías que [stat concreto / pregunta retórica sobre el problema]?"

SEGUNDO 5-20 (EDUCACIÓN):
[Plano enfermera explicando, plano B-roll de hospital]
"La realidad es que [explicación del problema]. Pasa porque [razón concreta]"

SEGUNDO 20-40 (REGLA / DESCUBRIMIENTO):
"Lo que aprendí después de [contexto] es que [insight no obvio]. [Por qué el insight importa]"

SEGUNDO 40-65 (PRODUCTO COMO RESPUESTA):
[Muestra el producto]
"Por eso uso [producto]. [Característica 1 + por qué importa]. [Característica 2 + por qué importa]"

SEGUNDO 65-80 (PRUEBA SOCIAL / RESULTADOS):
"Lo llevo [tiempo] y [resultado concreto]. Mis compañeras también [validación grupal]"

SEGUNDO 80-90 (CTA):
"Si te suena este problema, échale un ojo a Nurse is Love"
```

**Tono:** docente, casi como una mini-charla. La creadora es autoridad blanda (lleva años en el hospital, sabe de lo que habla).
**Visual:** alterna plano cara con B-roll de hospital, productos en mesa, ilustraciones simples si ayudan.

---

## TEMPLATE 4 — Comparativa antes / ahora (20-30s)

**Cuándo usarlo:** producto que reemplaza algo claramente identificable (gorro tradicional → gorro NIL, zueco tradicional → zueco NIL).

**Estructura:**

```
SEGUNDO 0-3 (HOOK):
[Plano split o secuencia rápida: producto antiguo vs producto NIL]
"Esto es lo que llevaba antes. Y esto es lo que llevo ahora"

SEGUNDO 3-12 (ANTES):
[Muestra producto antiguo, problemas reales: roce, dolor, incomodidad]
"Con el [producto antiguo], cada turno acababa con [problema concreto]"

SEGUNDO 12-22 (AHORA):
[Muestra producto NIL en uso, beneficio visible]
"Con [producto NIL], [beneficio observable]. La diferencia está en [característica específica]"

SEGUNDO 22-28 (REFUERZO):
"No vuelvo atrás"

SEGUNDO 28-30 (CTA):
"Nurse is Love. En la bio"
```

**Tono:** descubrimiento, casi confesional. "He probado las dos cosas y ya tengo opinión".

---

## TEMPLATE 5 — Tribal Adoption (especialmente bueno para gorros) (20-30s)

**Cuándo usarlo:** producto que se adopta en grupo (gorros de quirófano principalmente). Activa el FOMO de pertenencia.

**Estructura:**

```
SEGUNDO 0-3 (HOOK):
[Plano del equipo completo de quirófano con gorros NIL]
"Mira a mi equipo de quirófano. Nos los pusimos uno, y al mes los teníamos todos"

SEGUNDO 3-10 (CONTEXTO):
[Plano cercano de una compañera con gorro NIL, luego de otra, luego de otra]
"Empezó [nombre], luego me los pillé yo, luego [otra compañera]..."

SEGUNDO 10-22 (RAZÓN CONCRETA):
[Plano del producto, característica diferencial]
"Y al final fue por [razón concreta: botón lateral, estampados, lo que sea]. Una vez los pruebas, los del hospital ya no los quieres usar"

SEGUNDO 22-28 (REFUERZO):
"Ya somos todo el equipo de [unidad]"

SEGUNDO 28-30 (CTA):
"Se llaman Nurse is Love"
```

**Tono:** orgullo grupal, complicidad. "Nosotras lo sabemos primero".

---

## TEMPLATE 6 — Day in the Life (45-60s)

**Cuándo usarlo:** mostrar el producto integrado en la rutina real. Ideal para creadoras con audiencia que sigue su día a día.

**Estructura:**

```
SEGUNDO 0-5 (HOOK):
[Plano matutino, casa, preparándose]
"Empieza mi turno de 12h. Esto es lo que llevo en el bolso"

SEGUNDO 5-25 (REPASO DEL EQUIPO):
[Saca los productos NIL uno a uno mientras los nombra]
"[Producto 1]: para [beneficio]. [Producto 2]: para [beneficio]. ..."

SEGUNDO 25-50 (TURNO EN MARCHA):
[B-roll del turno: caminando por pasillo, descanso comiendo caliente, momento con el organizador, etc.]
"[Momento 1 donde se nota el producto]. [Momento 2]. ..."

SEGUNDO 50-60 (CIERRE):
[Vuelta a casa, primer plano]
"Llego a casa [estado: cómoda, sin estar reventada, etc.]. Y eso, hace 6 meses, no pasaba"

SEGUNDO 60 (CTA):
"Nurse is Love. Ahí lo dejo"
```

**Tono:** documental personal. Casi como un vlog corto.

---

## Reglas universales para todos los templates

1. **Primera frase = todo.** Si los primeros 3 segundos no enganchan, el resto no se ve. Invierte tiempo en el hook.
2. **Mostrar > decir.** Si puedes demostrar visualmente lo que dices, hazlo. Beneficio dicho + visualizado = el doble de impacto.
3. **CTA suave.** No "compra ahora con descuento". Mejor "se llama Nurse is Love" o "échale un ojo". La marca no es agresiva.
4. **Nombre de marca al final.** Salvo en el hook (rara vez), el nombre "Nurse is Love" aparece al final, no al principio.
5. **Duración real del guion ≤ duración objetivo.** Si el formato es 30s, el guion hablado debe caber en 25-28s para dar respiro. No 32s pretendiendo que cabe.
6. **Una creadora = una opinión.** No mezclar varias creadoras en el mismo guion salvo template 5 (tribal). Una creadora habla, una opinión real.
7. **Texto en pantalla opcional, no obligatorio.** Si vas a recomendar texto en pantalla, dilo en notas de dirección — no en el guion hablado.
