# NIL — Brand DNA (referencia para guiones)

## Qué es Nurse is Love

Marca DTC española fundada por gente cercana al sector sanitario que diseña accesorios y apparel pensados específicamente para enfermeras. No vende uniformes industriales ni se posiciona como marca clínica fría — vende **producto bonito + funcional + comunidad** para profesionales que pasan 12 horas en pie cuidando de otros.

**Web:** nurseislove.com
**Instagram:** @nurseislove
**Mercados:** España (principal), Italia y Portugal (secundarios)

---

## Posicionamiento (qué SÍ es NIL)

- Producto **pensado por y para enfermeras** (no de catálogo industrial)
- Estética **bonita, juvenil, identitaria** (estampados de jeringas/medicina, colores rosa/morado, ilustraciones cute)
- Función **real** (botón lateral en gorros, presión validada en medias, compartimentos pensados para el material que llevan)
- **Comunidad** — el canal #NurseLover en Instagram con enfermeras reales que comparten su día a día y dan feedback
- Identidad **profesional con orgullo** — ser enfermera es algo de lo que se enorgullecen, no algo que sufrir

## Qué NO es NIL

- NO es marca **clínica fría** — nada de "tecnología médica avanzada", "innovación científica"
- NO es marca de **descuentos / promo agresiva** — no hace black friday brutal ni descuentos del 70%
- NO recolecta datos de cumpleaños — el guion **no debe** referirse a "regalos por tu cumple" como si lo supiéramos
- NO es marca **lujo / aspiracional** — el precio es accesible (rangos típicos 25-90€)
- NO es marca **paternalista** — no le habla a la enfermera como si necesitara ser cuidada
- NO compite con vestuario del hospital — compite con el extra que la enfermera se compra ella misma

---

## Tono de voz

### Cualidades

| Cualidad | Cómo se nota |
|---|---|
| **Cercana** | Tutea siempre, jamás "usted". Habla de "tu turno", "tus compañeras" |
| **Real** | Frases del día a día del hospital. Si no las dice una enfermera, no las decimos nosotros |
| **Sin postureo** | Cero corporate-speak. Nada de "soluciones integrales", "experiencia premium" |
| **Validante** | Reconoce el esfuerzo sin convertirlo en drama ("estás reventada después de 12h" ✅ / "tu sacrificio heroico" ❌) |
| **Cómplice** | Habla como una compañera de planta, no como una marca. "Tú y yo sabemos..." |
| **Honesta** | No sobreprometemos. Lo que dice el guion lo tiene que cumplir el producto |
| **Con humor sutil** | Pequeños guiños del día a día (la goma de la mascarilla, perder las tijeras, el bocata frío) |

### Cómo NO suena

- ❌ Profesional fría / clínica
- ❌ Vendedora agresiva
- ❌ Influencer beauty con muchos emojis y mayúsculas
- ❌ Aspiracional pretenciosa
- ❌ Paternalista ("cuidamos de quien cuida" — ya lo usan todos, suena a tópico)
- ❌ Latina neutra ("estoy súper genial con mis tenis")

---

## Ángulos emocionales que conectan

Por orden de fuerza en Meta Ads (validados con tests reales):

1. **Comodidad sin compromiso** — "Aguanta el turno sin notarlo"
2. **Pertenencia / identidad enfermera** — "Por fin algo pensado para nosotras"
3. **Reconocimiento del esfuerzo** — "Tu esfuerzo merece un beneficio"
4. **Validación del problema** — "No es normal acabar reventada, hay solución"
5. **Tribal adoption (especialmente gorros)** — "Mis compañeras me los piden, ya tenemos todo el equipo"
6. **Pequeños placeres del turno** — "Comer caliente en el descanso después de 6h"

---

## Insights de la comunidad #NurseLover (124 respuestas)

Datos validados con encuesta a la comunidad. Útiles como verbatims o para fundamentar claims:

- **72%** valora la **comodidad general** en calcetines de trabajo (no transpiración, no compresión — comodidad pura)
- **38%** lleva **medias de compresión siempre**, **29%** casi nunca, **21%** solo en turnos largos
- **40%** lleva **calcetines siempre**, **27%** depende del día
- **Mensaje que convierte** validado: **"Comodidad que no aprieta y aguanta el turno"**
- **Verano** = oportunidad para calcetín transpirable (la media se siente caliente en julio-agosto)
- **Insight clave:** calcetín = básico diario; media = producto situacional (turnos largos / doblar)

### Verbatims reales (usables en guion como "dice la propia comunidad")

- *"Yo uso siempre calcetines de compresión, en verano y en invierno."*
- *"Medias solo me las pongo cuando doblo. Si hago solo las 7 o 10h me vale con calcetines. En verano suelo llevar finas."*
- *"Siempre medias, sobre todo en turnos largos."*
- *"Calcetines solo cuando voy a estar en mañana tranquila haciendo extracciones."*
- *"De las medias lo importante es que tengan buena presión para que no se te carguen mucho."*

---

## Talento UGC recurrente (creadoras validadas)

Si el usuario menciona una de estas, sabes que es una creadora que ya ha funcionado para NIL:

- **Mónica** — UGC casual, enfermera real, día a día
- **Patri** — testimonial review, lenguaje sencillo
- **Rebeca** — buena para hooks problema/solución
- **Marta** — VSSL educacional, voz más estructurada

Si el usuario no menciona ninguna, asume "enfermera UGC genérica" y deja la dirección abierta.
