---
name: ai-video-director
description: >
  MLO Growth's AI-VIDEO production director. Turns a finished concept/script/brief into a ready-to-generate
  PROMPT SHEET: matches the right tool to each job (Veo 3.1 cinematic+native audio, Runway Gen-4
  character/brand consistency, Kling 3.0 high-volume social, Seedance photoreal UGC, Midjourney stills,
  ElevenLabs VO/voice-clone, HeyGen avatars) and writes cinematic prompts beat-by-beat — shot, camera,
  motion, lighting, consistency, pacing, audio — per scene. Output = per-scene prompt sheet + tool choices
  + shot list. ALWAYS use (ES/EN) when the user says "pásame el guion a prompts de IA", "prompts de
  Veo/Runway/Kling/Seedance", "genera el vídeo con IA", "qué herramienta de IA uso para esta escena",
  "prompt cinematográfico", "hazme el prompt sheet", "clona la voz / avatar de HeyGen", "turn this script
  into AI-video prompts", "which AI tool for this shot", "cinematic Veo/Runway prompt", "build the prompt
  sheet", "generate this ad with AI". For any MLO brand (ZZEN, 8hours, Moncho Moreno, Bala di Gala, Alma,
  Chic&Love, HobbitAlf…). iPhone-shot-on-phone UGC → defer to seedance-20-ugc-ad-director / ugc-director;
  this skill owns the cinematic multi-tool AI stack.
---
# AI Video Director — MLO's concept→AI-video prompt engine

## What it does
Turns a **finished concept / script / Script→Brief** into a **production prompt sheet**: (1) a **tool-choice
matrix** matching the right AI tool to each job, (2) **cinematic prompts written beat-by-beat** for every
scene (shot, camera, motion, lighting, character/brand consistency, pacing, audio), and (3) a **shot list +
generation order** an editor can run today. It is the AI-production layer of MLO's Creative Strategy &
Scripting suite — it does not write the script (that's `framework-scriptwriter`); it *produces* it with AI.

**Alignment (don't fork — note the relationship):**
- Upstream: the **script/brief** comes from `framework-scriptwriter` (or `mlo-winner-strategist` iterations);
  the **angle/avatar** from `angle-generator`; **QA** from `script-doctor`. This skill starts *after* the brief.
- **`seedance-20-ugc-ad-director`** owns the **single-tool, anti-cinematic, iPhone-UGC** path (native lipsync,
  Pinterest creator refs, "never say cinematic"). **When the job is UGC-that-must-look-shot-on-phone, hand it to
  Seedance — do not fight its rules here.** This skill owns everything *cinematic and multi-tool*: pro/branded
  spots, hero product films, mixed-tool ads, stills→I2V, avatar+VO pipelines.
- **`ugc-director`** owns the broader AI-UGC/avatar workflow; this skill covers avatars (HeyGen/ElevenLabs) as one
  lane of the full stack and defers deep UGC persona-multiply to it. `edit-guide` owns the EDIT layer after render.

This skill reuses the **"Concept → AI Video"** section of `iteration-playbooks.md` (tool matrix, Veo 5-part
formula, character consistency, avatar+VO workflow) and MLO's **Módulo 2 — Librería de Prompts de IA** pipeline
(shotlist [9] → edit guide [10]).

## When to use (ES + EN trigger phrases)
- **ES:** "pásame este guion a prompts de IA", "prompt de Veo/Runway/Kling/Seedance para esta escena",
  "qué herramienta de IA uso aquí", "prompt cinematográfico", "hazme el prompt sheet del anuncio", "genera el
  vídeo con IA", "clona la voz con ElevenLabs / avatar de HeyGen", "mantén el mismo personaje en todas las tomas".
- **EN:** "turn this script into AI-video prompts", "which AI tool for this shot/scene", "cinematic Veo/Runway
  prompt", "build the prompt sheet", "generate this ad with AI", "keep character consistent across shots",
  "clone the VO / make an avatar for this".

## Inputs needed (ask only for what's missing — never block; make creative calls and proceed)
1. **The script/brief** (beats or the MLO brief table). If only a concept, ask for the script or derive beats.
2. **Format & length** (short ad 15–30s / VSL / hero spot) and **aspect ratio** (9:16 default for paid social).
3. **Register:** cinematic/branded/pro **vs** UGC-iPhone. *If UGC-iPhone → route to Seedance and say so.*
4. **Brand assets:** product photo, logo/lockup, brand colors, a start-frame or reference image if character/
   product consistency matters, existing VO/voice sample.
5. **Language** (ES/EN per brand) for on-screen text + dialogue.
6. **Whether audio is needed in-gen** (Veo native) or added in edit (ElevenLabs VO track).

## Method (the core)
**Step 0 — Respect Trinidad; you're producing a locked message.** The message/angle is already set upstream. Your
job is **fidelity of the beats**, not rewriting them. Message > format > tool. Never let a cool visual bury the hook.

**Step 1 — Break the script into SCENES/BEATS.** One beat = one generation arc (one action change). Map to the winner
anatomy: `Hook (0–3s) → Problema/Deseo → Mecanismo → Prueba → CTA`. AI video generates in short clips (Veo/Runway
~4–10s, Kling longer, Seedance 4–15s) → **one action arc per clip**; a 30s ad ≈ 4–8 clips. Lock the **beat sheet with
timestamps** first (reuse AIDA/awareness timing from the brief).

**Step 2 — Match the TOOL to each job** (this is the skill's signature move — never one-tool-fits-all):

| Job in the ad | Tool | Why (from `iteration-playbooks.md`) |
|---|---|---|
| Cinematic look + **native dialogue/SFX** in one gen, controllable camera & lighting | **Google Veo 3 / 3.1** | Strongest prompt-to-cinematography + native audio |
| **Character / product / brand consistency** across shots, reference-image control, motion brush | **Runway Gen-4 / 4.5** | Marketers' pick for I2V consistency |
| **High-volume social** output, fast motion, best value, minutes-long clips | **Kling 3.0** | The daily-driver |
| **Photoreal UGC-style** ad clips (but iPhone-raw → use the Seedance skill) | **Seedance** | MLO's tested UGC workflow |
| **Stills** — hero frames, I2V start-frames, thumbnails | **Midjourney / DALL·E** | Feed the still into Runway/Kling for I2V consistency |
| **Voiceover / voice clone** | **ElevenLabs** | Record VO first; it drives the avatar |
| **AI avatar / talking-head** at scale | **HeyGen** (Avatar IV) | Full-body motion, micro-expressions, gestures |

Practical pattern: **Kling as daily driver; switch to Runway or Veo when a specific look or brand consistency is
required.** A single ad often mixes tools (e.g. Midjourney start-frame → Runway I2V for the hero shot → Kling for
b-roll → ElevenLabs VO over the top). **State the tool per scene and why.**

**Step 3 — Write each scene as a cinematic prompt using the Veo 5-part formula** (transfers to Runway/Kling):
`[Cinematography] + [Subject] + [Action] + [Context] + [Style & Ambiance] (+ [Audio] for Veo)`.
- **Cinematography = the most powerful tone lever.** Name the **shot** (wide / close-up / ECU / low angle / two-shot),
  the **camera move** explicitly (dolly-in, tracking, crane, slow pan, POV, aerial), the **lens** (shallow DoF / macro /
  wide). **If you want the camera to move, SAY SO** — Veo defaults to static/handheld otherwise.
- **Subject = hyper-specific** ("woman late 20s, wavy auburn hair, light freckles, cream linen shirt" > "a woman").
- **Action = one concrete thing** the subject does in this clip.
- **Context = thorough scene** ("bright minimalist bathroom, morning, soft window light camera-left").
- **Lighting = precise** ("golden-hour backlight," "harsh overhead fluorescents," "volumetric fog rays").
- **Style & Ambiance = aesthetic + mood** (photoreal / film noir / claymation / VHS).
- **Audio (Veo native, separate line)** — define dialogue + SFX + ambience explicitly so sound matches picture.
- **Method:** start simple, then **layer detail incrementally — more detail = more control.**

**Step 4 — Enforce CHARACTER & BRAND consistency across the whole ad.** Pick a fixed **start-frame** (Midjourney/DALL·E
or a product photo) and reuse it as the reference image in **Runway Gen-4 character controls** for every shot; repeat the
exact subject/product description verbatim in each prompt; keep **brand colors + logo lockup identical** across scenes.
Call this out explicitly in every prompt ("hold the same face/label across all shots — reference image attached").

**Step 5 — Set PACING to the beat.** Hook clip is tight (0–3s, motion in first frame). Mechanism/proof clips can breathe.
Every clip must read **sound-off** (burned-in captions from the TEXT column of the brief) **and** sound-on. Map each clip
to a duration that sums to the ad length; note the **generation order** (stills first → hero I2V → b-roll → VO last).

**Step 6 — For avatar/VO ads, run the ElevenLabs→HeyGen pipeline** (reuse `iteration-playbooks.md`): (1) **voice first** —
clean 1–3 min sample, tune stability/similarity; (2) **avatar** — train on 2–5 min even-lit footage; (3) keep it raw for
cold; (4) **batch** 5–10 scripts → all VOs → all avatar clips in one session; (5) cut + overlay AI b-roll; (6)
**persona-multiply** one avatar into many variants (defer heavy persona-multiply to `ugc-director`).

**Step 7 — Assemble the SHOT LIST + edit note.** Produce MLO's shotlist [prompt 9] equivalent and a one-line edit note per
clip; hand the finished render spec to `edit-guide` for the retention edit.

## Rules & standards (MLO non-negotiables)
- **Message > format > tool.** The upstream angle/hook is locked — produce it faithfully; don't rewrite the script here.
- **Match the tool to the job — never one-tool-for-everything.** State the tool per scene and the reason.
- **UGC-iPhone ≠ cinematic.** If the ad must look shot-on-phone, route to `seedance-20-ugc-ad-director` and follow ITS
  anti-cinematic rules (there, never use "cinematic"). Only apply cinematic prompting when the register is pro/branded.
- **Character/product/brand consistency is mandatory** across a multi-shot ad — fixed reference image + verbatim subject
  description + identical logo/colors.
- **Explicit camera or no camera move** — never leave motion to chance.
- **Every clip = one action arc**, reads sound-off (burned captions) and sound-on.
- **Precision > filler.** Concrete shot/lighting/subject detail beats adjectives like "epic/stunning" (which don't steer models).
- **Don't fabricate** brand assets, proof, or claims; carry the brief's real VoC/mechanism through.
- Measure downstream with **FFM** (hook rate, hold rate, CTR, ROAS); on-screen text in the brand's language (ES = coma decimal).

## Output (exact shape + a concrete example)
Deliver in this order: **(A) Beat sheet** (timestamps + which tool per beat, and why) → **(B) Per-scene prompt sheet**
(one block per clip, in the 5-part formula, with the reference-image/consistency line) → **(C) Audio plan** (Veo-native vs
ElevenLabs VO) → **(D) Shot list + generation order + one-line edit notes**.

**Per-scene prompt block shape:**
```
### Scene N — [Beat name] ([t0]–[t1]) · Tool: [Veo 3.1 / Runway Gen-4 / Kling / Seedance] · Why: [reason]
[Cinematography] ...
[Subject] ...
[Action] ...
[Context] ...
[Style & Ambiance] ...
[Audio] ...            (Veo only; else note "VO added in edit — see Audio plan")
Consistency: hold [same face/product/label] via [reference image / start-frame]; brand colors [hex], logo lockup identical.
On-screen text (sound-off): "[caption from brief TEXT column]"
```

**Mini worked example** — Brand: ZZEN (magnesium), 20s branded spot, 9:16, angle "you're not stressed, you're
magnesium-depleted", Product-aware, pro register (NOT iPhone-UGC).
- **Beat sheet:** Hook 0–3s (Runway Gen-4, needs consistent hero talent) → Mechanism 3–10s (Veo 3.1, native VO + macro of
  glycinate dissolving) → Proof 10–15s (Kling, fast b-roll of "87%" stat build) → CTA 15–20s (Runway, hero bottle + logo).
- **Scene 1 — Hook (0–3s) · Runway Gen-4:** `[Cinematography] Slow push-in, close-up, shallow DoF. [Subject] Woman early
  40s, tired eyes, natural minimal makeup, grey linen. [Action] She presses a hand to her chest and exhales. [Context]
  Dim bedroom at dawn, cool window light camera-left. [Style] Photoreal, muted calm palette. Consistency: reference image
  @hero; hold this face across all scenes; brand green #—. On-screen text: "No es estrés // es déficit de magnesio."`
- **Scene 2 — Mechanism (3–10s) · Veo 3.1:** macro dolly on a magnesium-glycinate capsule dissolving; `[Audio]` calm female
  ES VO "El glicinato de magnesio es la forma que tu cuerpo sí absorbe…" + soft ambient tone, no music.
- **Generation order:** Midjourney hero start-frame → Runway Scene 1 & 4 (same @hero) → Veo Scene 2 → Kling Scene 3 → hand to `edit-guide`.

## Guardrails
- Don't rewrite the locked script/angle — produce it. If the message is unclear, get the brief; don't invent beats.
- Don't apply cinematic prompting to an iPhone-UGC job — route to Seedance and respect its rules.
- Don't default to one tool for the whole ad; justify each tool choice against the job.
- Don't drop character/brand consistency, camera direction, or burned-in captions.
- Don't fabricate assets/claims/VoC; don't promise a model can do what it can't (note Sora's 2026 discontinuation — avoid for long-running work).
- If format/register/assets are missing, make a sensible creative call and state your assumption — don't stall.

## References
See `reference/knowledge-base.md`. Reused expert brain: **`mlo-winner-strategist/reference/iteration-playbooks.md`**
(Concept → AI Video: tool matrix, Veo 5-part formula, character consistency, ElevenLabs+HeyGen workflow, static→video,
short→VSL). MLO playbook modules used: **Módulo 2 — Librería de Prompts de IA M.L.O** (`02-Modulo-Libreria-Prompts-IA-MLO.md`,
esp. pipeline [5]/[6] script → [9] shotlist → [10] edit guide), grounded by **Módulo 0 — INDEX** (Trinidad, 3A, Awareness,
FFM, precisión > relleno). Aligns with sibling skills `framework-scriptwriter`, `seedance-20-ugc-ad-director`,
`ugc-director`, `edit-guide`, `mlo-winner-strategist`.
