# Knowledge Base — ai-video-director

> Distilled production knowledge for turning a locked concept/script into AI-video generation prompts.
> Two grounding pillars: **MLO's Módulo 2 (AI prompt library)** and the reused **iteration-playbooks.md**
> "Concept → AI Video" section. Generic advice never; MLO system + cited expert frameworks only.

---

## 0. Where this skill sits (MLO system)

MLO's Sistema de Scripting runs **Trinidad (message first) → 3A (Audience·Angle·Ad) → framework → script →
brief → production → edit → test/scale**, all measured with **FFM** (hook rate, hold rate, CTR, ROAS) and
governed by **precisión > relleno** (source: `00-INDEX-Sistema-Scripting-MLO.md`).

This skill is the **production** node for the **AI-video** path. It consumes the locked brief and emits generation
prompts. It does NOT re-open message/angle decisions (those are Trinidad/3A, owned upstream).

**Módulo 2 pipeline position** (`02-Modulo-Libreria-Prompts-IA-MLO.md`): after `[5] Script desde Concepto` /
`[6] Script Bulletproof` produce the script, the production layer is `[9] Shotlist B-Roll` → `[10] Guía de
Edición`. This skill sits between them for AI-generated footage: it converts the script's beats into **tool-matched,
cinematic generation prompts**, then feeds the shotlist skill (`shotlist-broll`) and edit skill (`edit-guide`).

**Relationship to sibling skills (do not fork):**
- `framework-scriptwriter` — writes the script + Script→Brief table (upstream; this skill starts after it).
- `seedance-20-ugc-ad-director` — **the** UGC-iPhone, anti-cinematic, single-tool director (native lipsync,
  Pinterest creator refs). **Route iPhone-UGC jobs to it and follow its rules there.** This skill = cinematic/multi-tool.
- `ugc-director` — broader AI-UGC/avatar workflow + persona-multiply (defer heavy persona work to it).
- `shotlist-broll` — turns the approved script into a shootable shotlist (hand off after prompts).
- `edit-guide` — the retention edit layer after render.
- `mlo-winner-strategist` — supplies the reused `iteration-playbooks.md` brain and winner iterations.

---

## 1. Tool-selection matrix (2025–2026)

Source: `mlo-winner-strategist/reference/iteration-playbooks.md` → "Concept → AI Video" (all rows cited there).

| Tool | Best for | Notes |
|---|---|---|
| **Google Veo 3 / 3.1** | Cinematic look + **native audio/dialogue** in one gen; controllable camera & lighting | Strongest prompt-to-cinematography control (DeepMind; Google Cloud) |
| **Runway Gen-4 / 4.5** | **Marketers' pick** — reference-image control, brand-friendly **character consistency**, motion brush, Turbo speed, built-in editor | Pro benchmark for image-to-video (invideo; Masonry) |
| **Kling 3.0** | **High-volume social**, fast motion, best value; minutes-long clips in one pass | Common daily driver (invideo) |
| **Sora 2** | Photoreal + narrative coherence | ⚠️ OpenAI announced Sora web/app discontinued **Apr 26 2026**, API **Sep 24 2026** — avoid for long-running projects (Coburger) |
| **Seedance** | Photoreal UGC-style clips | Use the **`seedance-20-ugc-ad-director`** skill for the iPhone-raw workflow |
| **Midjourney / DALL·E** | **Stills** — hero frames, I2V start-frames, thumbnails | Feed the still into Runway/Kling for I2V consistency |
| **ElevenLabs** | **Voiceover / voice clone** | Record first; the voice drives the avatar |
| **HeyGen** | **AI avatars / talking-head** at scale | Avatar IV (Aug 2025): full-body motion, micro-expressions, gestures |

**Daily-driver pattern:** Kling for volume; switch to **Runway** (consistency) or **Veo** (specific cinematic look +
native audio) when the shot demands it (invideo). Real ads usually **mix tools** across scenes.

**Decision cues:**
- Need spoken dialogue *in the gen*? → **Veo** (native audio) or **HeyGen** avatar (talking-head) + ElevenLabs VO.
- Same face/product across 4+ shots? → **Runway Gen-4** reference-image / start-frame from **Midjourney**.
- 20 b-roll clips fast and cheap? → **Kling**.
- Must look like an iPhone selfie (cold UGC)? → **Seedance** (its own skill) — NOT this cinematic prompt style.
- Talking-head testimonial at persona scale? → **HeyGen + ElevenLabs** (defer persona-multiply to `ugc-director`).

---

## 2. Beat breakdown (one clip = one action arc)

AI models generate short clips: Veo/Runway ~4–10s, Kling longer, Seedance 4–15s. So:
- **One action arc per prompt** — don't cram two scene changes into one clip.
- A 30s ad ≈ **4–8 clips**. Map clips to the winner anatomy: `Hook (0–3s) → Problema/Deseo → Mecanismo → Prueba → CTA`.
- Lock a **beat sheet with timestamps** first (reuse AIDA/awareness timing from the brief: 0–2s attention, 2–7s
  interest/problem, 7–12s desire/proof, 12–15s action — `iteration-playbooks.md` static→video AIDA timing).
- The hook clip must have **motion in the first frame** and stop the scroll within 3s.

---

## 3. Cinematic prompting — the Veo 5-part formula (transfers to Runway/Kling)

Source: `iteration-playbooks.md` (fal; DeepMind). Formula:
`[Cinematography] + [Subject] + [Action] + [Context] + [Style & Ambiance] (+ [Audio] on Veo)`.

- **Cinematography — the strongest tone lever.** Name the **shot** (wide / close-up / ECU / low-angle / two-shot),
  the **camera move EXPLICITLY** (dolly-in, tracking, crane, aerial, slow pan, POV), the **lens** (shallow DoF / macro
  / wide-angle / deep focus). **Veo defaults to static/subtle handheld — if you want movement, state it.**
- **Subject — hyper-specific.** "Woman late 20s, wavy brown hair, light freckles" > "a brown-haired woman."
- **Action — one concrete verb.** What the subject does in *this* clip.
- **Context — thorough scene.** "A smoky jazz club at night" > "a jazz club."
- **Lighting — precise.** "golden-hour backlighting," "harsh overhead fluorescents," "dappled forest light,"
  "volumetric fog rays."
- **Style & Ambiance — aesthetic + mood.** realistic / claymation / film noir / VHS.
- **Audio (Veo native, separate line).** Define SFX + ambience + dialogue so sound matches picture.
- **Method — incremental detail.** Start simple, then layer detail; more detail = more control. Use an LLM to expand.

**Prompt template (paste target: Veo/Runway/Kling):**
```
[Cinematography] Slow dolly-in, low angle, shallow depth of field, macro on the product label.
[Subject] A woman in her late 20s, wavy auburn hair, light freckles, cream linen shirt.
[Action] She uncaps the bottle and applies a single drop to the back of her hand; it absorbs instantly.
[Context] Bright minimalist bathroom, morning, soft window light from camera-left.
[Style & Ambiance] Photoreal, warm golden-hour tone, calm premium mood.
[Audio] Gentle ambient room tone; a soft "click" as the cap opens; no music.
Consistency: hold the same character face and bottle label across all shots (reference image attached).
```

### 3b. Per-tool prompt templates (tune the 5-part formula to each engine)

Same skeleton, engine-specific knobs. Fresh 2026 model notes cited in **Sources**.

**Veo 3.1 — cinematic + native synced audio.** The only engine doing 48kHz synced *dialogue* (not just SFX); put dialogue/SFX/ambience/music on the `[Audio]` line ([tensoria](https://tensoria.fr/en/tools/runway-pro-ai-video-generation); [DeepMind](https://deepmind.google/models/veo/prompt-guide/)).
```
[Cinematography] <shot + explicit camera move + lens>.
[Subject] <hyper-specific>. [Action] <one arc>. [Context] <scene + lighting>. [Style] <aesthetic + mood>.
[Audio] Dialogue (ES/EN): "<line>"; SFX: "<sfx>"; ambience: "<room tone>"; music: none/<bed>.
Consistency: hold same face + label across shots; brand #—, logo lockup identical.
```

**Runway Gen-4/4.5 — character & brand consistency, I2V from a start-frame.** Marketers' pick for reference-driven consistency + motion brush; clips ~5–10s ([tensoria](https://tensoria.fr/en/tools/runway-pro-ai-video-generation); [invideo](https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/)).
```
Reference image: @hero_startframe (Midjourney still or product photo).
[Cinematography] <shot + camera move>; motion brush on <element> only.
[Subject] EXACT verbatim from Scene 1. [Action] <one arc>. [Context]+[Lighting]+[Style].
Consistency: hold face/product identical to reference; brand green #—, logo unchanged.
(No native audio — VO added in edit; see Audio plan.)
```

**Kling 3.0 — high-volume b-roll, long single-pass, multi-shot storyboard w/ synced audio.** Best value (~$0.84 / 10s 1080p w/ audio); minutes-long in one pass ([tensoria](https://tensoria.fr/en/tools/runway-pro-ai-video-generation)).
```
[Cinematography] <shot + camera move + fast motion>. [Subject]+[Action]+[Context]+[Lighting]+[Style].
Storyboard/multi-shot mode for the <X>s stat-build; keep audio synced across cuts.
Use for b-roll volume; switch to Runway/Veo only where look/consistency demands it.
```

**Seedance (1.0/2.x) — photoreal, multi-shot narrative (NOT iPhone-raw UGC).** Rewards physical specificity; 2.5 = native 30s 4K, no stitching ([seed.bytedance](https://seed.bytedance.com/en/seedance); [digitalapplied](https://www.digitalapplied.com/blog/seedance-2-5-bytedance-ai-video-model-2026)).
```
[Cinematography]+[Subject]+[Action]+[Context]+[Style: photorealism].
Physics: <object mass / gravity / friction / how it moves>.
Multi-shot: <shot 1 → shot 2 → shot 3> as one cohesive gen.
(iPhone-raw UGC? → do NOT use this; route to seedance-20-ugc-ad-director.)
```

**Midjourney / DALL·E — still → I2V start-frame.**
```
<product/subject verbatim>, <lighting>, <background>, brand palette #—, aspect 9:16,
photoreal product hero, sharp label legibility. → export as start-frame for Runway/Kling I2V.
```

**Sora 2 — physics-heavy realism, ≤25s.** ⚠️ Product discontinued Apr 26 2026; API sunset Sep 24 2026 — do NOT anchor a pipeline on it; reward it with explicit physical constraints if used at all ([wavespeed](https://wavespeed.ai/blog/posts/openai-sora-2-complete-guide-2026/); [atlabs](https://www.atlabs.ai/blog/sora-2-pro-prompting-guide-for-2026-create-stunning-ai-videos)).

---

## 4. Character / product / brand consistency (mandatory for multi-shot ads)

Source: `iteration-playbooks.md` (invideo; Masonry).
- Fix a **start-frame** (Midjourney/DALL·E hero image, or a real product photo) and reuse it as the **Runway Gen-4
  reference image** in every shot.
- Repeat the **exact subject/product description verbatim** in each prompt (models drift otherwise).
- Keep **brand colors + logo lockup identical** across scenes; state hex + placement.
- Add an explicit consistency line to every prompt: "hold the same face/label; brand green #—; logo lockup identical."

---

## 5. AI UGC / avatar pipeline (ElevenLabs → HeyGen)

Source: `iteration-playbooks.md` (HeyGen; ElevenLabs; vidau). For talking-head/testimonial ads:
1. **Voice first (ElevenLabs):** clean 1–3 min sample, quiet room; tune **stability & similarity** until natural — the
   voice drives the avatar.
2. **Avatar (HeyGen):** train on **2–5 min of even, good lighting** footage — footage quality decides realism. Avatar
   IV = full-body motion, micro-expressions, gestures.
3. **Keep it raw** for cold prospecting — best UGC "sounds like an iPhone recording" (raw beats studio for cold).
4. **Batch:** write 5–10 scripts → generate all VOs → render all avatar clips in one session.
5. **Cut + b-roll:** cut frequently, overlay AI b-roll (Kling/Runway) or in-house footage.
6. **Persona-multiply:** one avatar → many persona variants by mixing faces/voices/tones; A/B test to the top converter
   without reshoots. (Heavy persona-multiply → hand to `ugc-director`.)

**Rule of thumb:** UGC beats polished on cold-prospecting CPA (~22–38% in most DTC categories); polished wins on premium
positioning and high-consideration/technical products (`iteration-playbooks.md` UGC⇄high-production). Choose register by
audience/objective/funnel — not dogma.

---

## 6. Adjacent production playbooks this skill can invoke

Both from `iteration-playbooks.md` — useful when the "concept" is actually a format shift:
- **Static → video:** audit layered statics → pick a motion technique (parallax / kinetic type / data reveal /
  cinemagraph / vector path) → sequence AIDA 0–15s → format per placement → measure hook/hold/completion. Converted
  video ads showed **~133% higher CTR, ~24% lower CPM** vs static.
- **Short ad → 2–2.5 min VSL:** 4-phase (Hook 0:00–0:12 → Lead 0:12–0:40 → Body+Mechanism 0:40–1:45 → Close 1:45–2:15),
  passing Problem-Aware → Solution-Aware → Most-Aware; the "mechanism click" is the core persuasion event. On paid social
  favor **30–90s micro-VSLs** that feel UGC but are structured like a sales letter.

---

## 7. Non-negotiables recap (MLO)

- Message > format > tool; produce the locked brief faithfully.
- Match tool to job; justify per scene; never one-tool-for-all.
- iPhone-UGC → Seedance (anti-cinematic there); cinematic prompting only for pro/branded.
- Consistency (reference image + verbatim subject + identical logo/colors) is mandatory across shots.
- Explicit camera move or none; one action arc per clip; reads sound-off (burned captions) + sound-on.
- Precisión > relleno — concrete shot/lighting/subject detail beats "epic/stunning."
- No fabricated assets/claims/VoC. Avoid Sora for long-running projects (2026 discontinuation).
- Measure with FFM; on-screen text in the brand's language (ES = coma decimal).

---

## Sources

**MLO Playbook modules (source of truth):**
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, FFM, precisión > relleno.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/02-Modulo-Libreria-Prompts-IA-MLO.md` — MLO AI prompt library / pipeline (script [5]/[6] → shotlist [9] → edit guide [10]).

**Reused expert brain (winner-strategist):**
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/iteration-playbooks.md` — "Concept → AI Video" (tool matrix,
  Veo 5-part formula, character consistency, ElevenLabs+HeyGen pipeline), static→video, short→VSL.

**External (freshened July 2026):**
- Tensoria — Runway Gen-4 vs Veo 3.1 vs Kling 2026 hands-on (audio table-stakes, per-tool strengths, clip lengths, value, Sora sunset): https://tensoria.fr/en/tools/runway-pro-ai-video-generation
- Get AI Perks — Best AI Video Generators 2026 (Sora 2 vs Veo 3.1 vs Kling 3.0 vs Runway): https://www.getaiperks.com/en/blogs/44-best-ai-video-generators-2026
- Google DeepMind — Veo prompt guide (5-part components, subject specificity, lighting, native audio, incremental detail): https://deepmind.google/models/veo/prompt-guide/
- Google Cloud — Ultimate prompting guide for Veo 3.1: https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-veo-3-1
- fal — Veo 3 prompt guide (5-part formula, explicit-camera-move default, anti-adjective): https://fal.ai/learn/devs/veo3-prompt-guide-master-google-video-generation
- invideo — Kling vs Sora vs Veo vs Runway (tool selection, character consistency, daily-driver pattern): https://invideo.io/blog/kling-vs-sora-vs-veo-vs-runway/
- Masonry — Best AI Video Generators 2026 comparison: https://masonry.so/blog/best-ai-video-generator-2025-comparison
- OpenAI — Sora 2 (synced dialogue/SFX, physics, world-state persistence, ≤25s): https://openai.com/index/sora-2/
- WaveSpeed — Sora 2 complete guide 2026 (features/pricing; product discontinued Apr 26 2026, API sunset Sep 24 2026): https://wavespeed.ai/blog/posts/openai-sora-2-complete-guide-2026/
- Atlabs — Sora 2 prompting guide 2026 (detailed prompts + physical constraints): https://www.atlabs.ai/blog/sora-2-pro-prompting-guide-for-2026-create-stunning-ai-videos
- ByteDance Seed — Seedance 1.0 (multi-shot narrative, stylistic parsing, physical realism, camera control): https://seed.bytedance.com/en/seedance
- Digital Applied — Seedance 2.5 (native 30s 4K, no stitching): https://www.digitalapplied.com/blog/seedance-2-5-bytedance-ai-video-model-2026
- HeyGen Community — Scale realistic UGC ads with AI avatars (Avatar IV, batching, raw-feel, persona-multiply): https://community.heygen.com/public/resources/how-i-scale-realistic-ugc-video-ads-with-ai-avatars-2025-05-15
- ElevenLabs — Create AI characters with HeyGen Avatar IV + ElevenLabs (voice-first, stability/similarity): https://elevenlabs.io/blog/how-to-create-ai-characters-with-heygen-avatar-iv-and-elevenlabs-voice-changer
- DIY AI — HeyGen + ElevenLabs workflow 2026 (voice→avatar→editor order): https://diyai.io/ai-tools/video-generation/workflows/heygen-elevenlabs-workflow/
- AI Tools SME — ElevenLabs & HeyGen voice cloning tested 2026 (HeyGen cloning = ElevenLabs under the hood): https://www.aitoolssme.com/blogs/elevenlabs-heygen-ai-voice-cloning
- EzUGC — HeyGen review 2026 (Avatar IV, 1,100+ library, cold-traffic authenticity): https://www.ezugc.ai/blog/heygen-review
- Oakgen — Best AI UGC ad tools 2026 (multi-model credit pools: Veo 3.1 / Sora 2 Pro / Kling v3 / ElevenLabs): https://oakgen.ai/learn/best-ai-ugc-ad-tools-2026
