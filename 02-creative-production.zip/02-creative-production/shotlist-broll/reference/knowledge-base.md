# Knowledge Base — Shotlist & B-Roll (Script → Production)

> Distilled knowledge for the `shotlist-broll` skill. Purpose: take a **finished, approved script** (any MLO framework) and break it down into a **production shotlist + b-roll capture list + coverage checklist** that a shooter (creator/videographer) or an editor can execute without asking a single question. This is the step *after* Script→Brief: the brief says WHAT is said and roughly what to grab; the shotlist says exactly HOW each thing is shot and guarantees full coverage.

**Position in the MLO pipeline:** Árbol de Cascada (avatar+ángulo) → 3A → framework choice (12 frameworks) → script → **Script→Brief table** → **THIS: shotlist + b-roll breakdown** → shoot → edit → FFM measurement → iterate (winner-strategist). It does not replace the brief; it *operationalizes* it for the set.

---

## 1. MLO grounding — the source of truth (cite: Module 01)

Everything below is anchored in `01-Modulo-Frameworks-y-Script-to-Brief.md` and `00-INDEX-Sistema-Scripting-MLO.md`.

### 1.1 The Script→Brief table (Module 01 §3) — our starting artifact
The brief is a table where each script line carries: which **framework beat** it belongs to, what is **said** (`FROM UGC` / `FOR VO` / `FOR AI VO`), the **on-screen TEXT**, and the **B-ROLL** (what to film). Our shotlist expands the B-ROLL column into a real, per-shot production plan and consolidates every capture into one shoot-ready list.

Notation carried over from Module 01 (teach the team, keep it consistent):
- **`//`** in TEXT = split into 2 separately-shown on-screen texts.
- **`→`** in B-ROLL = a *sequence* of shots inside one beat (this is where the shotlist earns its keep — each `→` becomes its own numbered shot).
- **HOOK 1…5** = multiple hook entries over one shared body → each hook is its own opening shot to test (variation, not "3 headlines in one ad set" — see Andromeda).
- **Tick-off list** at the end = the coverage checklist. We formalize it.

### 1.2 Anatomy of the winner (Module 01 §0) drives coverage
Every framework walks the same anatomy: `Hook → Problema/Deseo → Mecanismo → Prueba → CTA con razón para actuar ya`. The shotlist must guarantee **every anatomy stage has enough footage to cut it** — that's the whole point of the coverage checklist. Missing "Mecanismo" footage = the edit "suena a otro anuncio más."

### 1.3 Filming Requirements (Module 01 §3) — non-negotiable, bake into every shotlist
These MLO rules are copied verbatim into the shotlist header so nothing is improvised on set:
- Raw via Google Drive · iPhone **HDR OFF** · **unedited** (no captions, transitions).
- **Talking-head and B-roll shot separately**, **no voiceover while filming**.
- Natural, some improvisation OK · **DO NOT show the product in the hooks** (only where the script says).
- Good light · **vertical 9:16** · don't talk right up against the lens (leave crop + text margin).
- No background noise · camera at **eye level** · comfortable clothes **no logos/brands** · **change clothes** between talking-head and B-roll blocks.

### 1.4 Framework beats → shot intent (Module 01 §2)
The framework tells you *what each beat is trying to do*, which dictates the shot. Examples pulled straight from Module 01:
- **DISRUPT / Declassify the secret** → a "reveal" shot: close-up on the suppressed ingredient/mechanism, hand pointing at the label.
- **SIMPLE / Lifestyle win** → a before/after contrast: the old effort (chaotic kitchen) vs the easy now.
- **SHOW / Us vs Them** → split-screen head-to-head demo, simultaneous.
- **PURE / Organic** → "day diary" scenes (7am, 10am, 4pm), unfiltered, handheld.
- **UGLY** filter → deliberately cheap: vertical phone, natural light, Paint-style graphics, text cards instead of lines. Applies OVER any framework.
- **PAS / Agitate** → the pain shown physically (hand on chest, gasping), not just narrated.
- **FOUNDER** → founder-to-camera, human, mission setting (workshop/field, not a studio).

### 1.5 Quality gate (Module 01 §4) inherited into coverage
The script's own quality checklist becomes shoot coverage requirements: the **mechanism** must be *shown* (not just said), **proof** (study/social/demo) must have footage, the **CTA** must have a shot with a reason-to-act-now, and there must be **3–5 hook shots** captured.

---

## 2. Production discipline — how to break a script into shots (external craft)

MLO's playbook stops at "what to grab"; standard film/video production craft supplies the vocabulary for a *real* shotlist. Distilled from recognized production references (sources at end).

### 2.1 What a shotlist column set must contain
A professional shotlist is a table, one row per shot, columns ([StudioBinder](https://www.studiobinder.com/blog/how-to-make-a-shot-list/), [Boords](https://boords.com/how-to/shot-list)):
1. **Shot # / Scene** — sequential ID, groups by scene/beat.
2. **Framework beat** — MLO link back to the script (which anatomy stage this serves).
3. **Shot size** — the framing (see 2.2).
4. **Angle** — eye-level / low / high / overhead / Dutch / OTS / POV.
5. **Camera movement** — static / pan / tilt / handheld / dolly-push / tracking / whip.
6. **Lens / focus** — wide / normal / macro; shallow vs deep; rack focus.
7. **Action / description** — what happens, concretely, in the frame.
8. **Talent** — creator on cam / hands only / none (b-roll).
9. **Location / setup** — where + light setup.
10. **Props / wardrobe** — exactly what's in frame.
11. **Audio** — sync sound / MOS (mute) / SFX to capture. (MLO: b-roll is MOS, no VO.)
12. **Duration / coverage notes** — approx length + "get 2–3 takes / extra handles."

### 2.2 Shot sizes (the framing vocabulary) — use these exact names
([StudioBinder shot size guide](https://www.studiobinder.com/blog/types-of-camera-shots-sizes-in-film/))
- **EWS / Extreme Wide** — establish the world/location.
- **WS / Wide** — subject full body in context.
- **MW / Medium Wide (cowboy)** — knees/thighs up.
- **MS / Medium** — waist up; the talking-head default.
- **MCU / Medium Close-Up** — chest up; intimate talking-head.
- **CU / Close-Up** — face or a single object filling frame; emotion/reveal.
- **ECU / Extreme Close-Up** — texture/detail (product label, drop absorbing, ingredient).
- **OTS** — over-the-shoulder (demos, comparisons).
- **POV** — through the subject's eyes (using the product first-person).
- **Insert / Macro** — a cutaway detail dropped into the edit.

### 2.3 B-roll = the editor's escape hatch and the demo layer
B-roll is supplemental/cutaway footage that supports the main (A-roll/talking-head) footage; it hides cuts, illustrates the words, and *shows* the claim the A-roll only *says* ([Descript](https://www.descript.com/blog/article/b-roll-footage-guide), [Frame.io](https://blog.frame.io/2020/07/13/b-roll/)). Rules of thumb baked into the b-roll list:
- **Shoot 2–3× more b-roll than you think you need** — editors are always starved for cutaways ([Descript](https://www.descript.com/blog/article/b-roll-footage-guide)).
- **Every claim/mechanism/proof line needs a matching b-roll shot** so the edit can *show* it, not just say it (Module 01 §4 mechanism rule + AIDA "demo the claim," see iteration-playbooks static→video).
- **Get handles**: start recording ~2s before and after the action so the editor has room to cut.
- **Capture ambient/room tone & product SFX** (uncap click, pour, sizzle) separately — sound-off ads still benefit from a sound-on layer (see iteration-playbooks static→video §4).
- **Multiple sizes of the hero action** (WS + MS + ECU of the same beat) so the editor can build rhythm.

### 2.4 Coverage — the guarantee you can cut the ad
"Coverage" = shooting a beat from enough sizes/angles that the edit is never stuck ([StudioBinder coverage](https://www.studiobinder.com/blog/what-is-coverage-in-film/)). MLO coverage minimum per ad:
- **A-roll:** every talking-head line captured MS **and** MCU (so you can cut for pace).
- **Hooks:** 3–5 distinct hook openers captured (Module 01 §4).
- **Mechanism:** at least one ECU/insert that *demonstrates* the "why it works."
- **Proof:** footage for each proof asset (demo, before/after, testimonial, on-screen data card b-plate).
- **CTA:** a shot that carries the reason-to-act-now (product + offer/urgency element).
- **Safety/pattern-interrupt b-roll:** 3–5 generic lifestyle cutaways for cut-hiding and hook tests.

---

## 3. Framework-beat → default shot map (MLO 12 frameworks × craft)

Use as the starting template; adapt to the actual script. (Frameworks from Module 01 §2.)

| Framework | Signature beat | Default shot(s) | Signature b-roll |
|---|---|---|---|
| **Bandwagon (CROWD)** | Wave the proof | MS talking-head + insert of social proof | Screenshots/logos b-plate, crowd/lifestyle |
| **Industry Contrarian (DISRUPT)** | Declassify the secret | CU talking-head + ECU reveal | Macro of ingredient/label, "myth" text card b-plate |
| **Listicle (CURE)** | Curiosity list hook | MS to-cam + numbered text cards | Quick ECU per list item |
| **Founder (FOUNDER)** | Feature the founder | MCU founder in workshop/field | Founder working, product origin, team |
| **How to X without Y (SIMPLE)** | Lifestyle win | MS to-cam + before/after WS | Chaotic "before" vs easy "after" scenes |
| **Organic (PURE)** | Unfiltered chaos | Handheld POV/selfie, day-diary | Real 7am/10am/4pm slices, messy real life |
| **PAS** | Agitate | MCU emotional to-cam | Pain shown physically (hand on chest), ECU tension |
| **Ugly Ads (UGLY)** | (filter over any) | Vertical phone, natural light, text cards | Deliberately cheap inserts, Paint graphics |
| **Founder Objections (PROVE)** | Victory | MCU founder + insert of result/data | Proof of the win (fields powered, before/after) |
| **Us vs Them (SHOW)** | Head-to-head | Split-screen OTS demo, locked-off | Simultaneous test, ECU of the winning feature |
| **Triple G (Goal-Gap-Gains)** | Gains bridge | MS to-cam + product demo | Aspiration lifestyle, the "missing piece" ECU |
| **TEASE** | Tease claim | MS to-cam pattern-interrupt | Story-scene b-roll that pays off the claim later |

---

## 4. Sources

**MLO (source of truth):**
- `01-Modulo-Frameworks-y-Script-to-Brief.md` — 12 frameworks, Script→Brief table, Filming Requirements, notation (`//`, `→`, HOOK 1–5), tick-off list, quality gate, common errors.
- `00-INDEX-Sistema-Scripting-MLO.md` — system map (Trinidad, 3A, Awareness, EPIC, Árbol de Cascada, Andromeda, FFM); "mensaje primero, formato es la caja."

**MLO reuse (winner-strategist reference):**
- `iteration-playbooks.md` — static→video AIDA beat timing & "demo the claim not the text"; b-roll capture in AI-UGC workflow; hook-variation logic (angle vs hook); AI-video 5-part cinematic shot formula (`[Cinematography]+[Subject]+[Action]+[Context]+[Style]+[Audio]`) reused for AI-generated b-roll shots.

**External production craft:**
- StudioBinder — How to make a shot list: https://www.studiobinder.com/blog/how-to-make-a-shot-list/
- StudioBinder — Camera shot sizes: https://www.studiobinder.com/blog/types-of-camera-shots-sizes-in-film/
- StudioBinder — What is coverage: https://www.studiobinder.com/blog/what-is-coverage-in-film/
- Boords — How to build a shot list: https://boords.com/how-to/shot-list
- Descript — B-roll footage guide (shoot 2–3× more, handles): https://www.descript.com/blog/article/b-roll-footage-guide
- Frame.io — What is B-roll and how to use it: https://blog.frame.io/2020/07/13/b-roll/
