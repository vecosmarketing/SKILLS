---
name: shotlist-broll
description: >
  Converts a FINISHED, approved ad script (any MLO framework — UGC, VSL, advertorial, static) into a
  production-ready SHOTLIST + B-ROLL capture list + coverage checklist a shooter or editor can execute
  with zero questions. For each script beat it specifies shot size, angle, camera move, framing, action,
  location, props/wardrobe, talent, audio and the exact b-roll/cutaways; then consolidates every capture
  into one shoot list and a coverage checklist tied to the winner anatomy (Hook→Problema→Mecanismo→Prueba→CTA).
  This is the step AFTER Script→Brief — it operationalizes the B-ROLL column into real shots. ALWAYS use
  this skill (ES/EN) when the user says "hazme la shotlist", "desglosa este guion en planos", "lista de
  b-roll", "qué tengo que grabar", "plan de rodaje / shooting plan", "shotlist para el creador/editor",
  "coverage checklist", "break this script into shots", "make a shotlist", "b-roll list", "what do I film",
  "shooting plan for this script". Works for any MLO brand (8hours, ZZEN, Moncho Moreno, Bala di Gala, Alma,
  HobbitAlf, Chic&Love, etc.). Do NOT trigger to WRITE a script (framework-scriptwriter) or QA one (script-doctor).
---

# Shotlist & B-Roll Builder

## What it does
Takes a **finished script** (ideally already in MLO's Script→Brief table) and produces the three artifacts a shoot day and an edit need:
1. A **production shotlist** — one row per shot, tied to the framework beat, with size/angle/move/lens/action/location/props/talent/audio.
2. A **consolidated b-roll capture list** — every cutaway/insert grouped by location so the creator shoots efficiently.
3. A **coverage checklist** — a tick-off that guarantees every winner-anatomy stage (Hook→Problema→Mecanismo→Prueba→CTA) has enough footage to cut the ad.

It is the operational bridge between MLO's **Script→Brief** (Module 01 §3) and the actual shoot/edit. It does not rewrite the script — it makes it shootable.

## When to use (ES + EN trigger phrases)
- **ES:** "hazme la shotlist", "desglosa el guion en planos", "lista de b-roll", "qué grabamos / qué tengo que grabar", "plan de rodaje", "shotlist para el creador", "brief de rodaje para el editor", "checklist de cobertura", "convierte este brief en planos".
- **EN:** "make a shotlist", "break this script into shots", "b-roll list", "what do I film", "shooting plan", "shot breakdown", "coverage checklist", "shooting brief for the creator/editor".
- Any MLO brand. Use after the script/brief is approved and before the shoot.
- **Do NOT** use to write a script (→ framework-scriptwriter) or to score/fix one (→ script-doctor).

## Inputs needed
- **The finished script or Script→Brief table** (FRAMEWORK | SCRIPT | TEXT | B-ROLL). Required.
- **Framework used** (one of MLO's 12) — dictates the signature shots. If not given, infer from the beats.
- **Format** (UGC / VSL / advertorial / static-to-motion / founder) and **awareness stage**.
- **Talent & assets available** (creator, founder, product, location constraints).
- **AI or real footage?** If AI b-roll is wanted, we write cinematic prompts (reuse iteration-playbooks 5-part formula).
- Brand + product for context (helps prop/wardrobe/location specificity).

## Method (numbered — MLO system + production craft)
1. **Lock the anatomy map.** Read the script and tag every line to its winner-anatomy stage: Hook · Problema/Deseo · Mecanismo · Prueba · CTA (Module 01 §0). This is what coverage is measured against — a shotlist that can't cut the *mecanismo* has failed.
2. **Confirm the framework's signature beats.** From the 12 frameworks (Module 01 §2), pull the beats that demand a specific shot (e.g. DISRUPT→reveal ECU; SHOW→split-screen OTS; PURE→day-diary handheld; SIMPLE→before/after; PAS→pain shown physically). Use the framework→shot map in the knowledge base as the default, then adapt.
3. **Split each beat into shots.** Expand every `→` in the brief's B-ROLL column into its own numbered shot. For each shot specify: **shot size** (EWS/WS/MW/MS/MCU/CU/ECU/OTS/POV/Insert), **angle**, **camera move**, **lens/focus**, **action** (concrete), **talent** (creator/hands/none), **location/light**, **props/wardrobe**, **audio** (sync / MOS / SFX to grab).
4. **Apply MLO Filming Requirements to every row** (Module 01 §3): 9:16, iPhone HDR-off, raw/unedited, eye-level, good light, no logos on wardrobe, **talking-head and b-roll shot separately with NO voiceover**, **product NOT shown in hook shots**, change clothes between A-roll and b-roll blocks. Put these in the shotlist header AND enforce per-row.
5. **Build A-roll coverage.** Every talking-head line gets **MS + MCU** so the editor can cut for pace. Capture the **3–5 hook openers** (HOOK 1–5 from the brief) as separate shots — variation, not one ad set.
6. **Build the b-roll / demo layer.** For every claim / mechanism / proof line, spec a b-roll shot that **shows** it (demo the claim, don't just say it — reuse iteration-playbooks static→video "demo the claim not the text"). Add multiple sizes of the hero action (WS+MS+ECU) and **3–5 safety pattern-interrupt cutaways**. Rule: **shoot 2–3× more b-roll than you think you need**, always with 2s handles.
7. **Consolidate by location.** Regroup all shots (A-roll + b-roll) by setup/location so the creator shoots in one efficient order, not script order. Note wardrobe changes and product-in/out.
8. **Spec audio & SFX capture.** List room tone + product SFX (uncap click, pour, sizzle) as MOS captures — the sound-on layer for sound-off ads.
9. **If AI footage:** for each AI b-roll shot, write a prompt with the 5-part cinematic formula `[Cinematography]+[Subject]+[Action]+[Context]+[Style & Ambiance]+[Audio]` and add a character/product-consistency note (iteration-playbooks §Concept→AI Video).
10. **Write the coverage checklist.** A tick-off proving: all A-roll captured MS+MCU · 3–5 hooks · ≥1 mechanism ECU/insert that *demonstrates* · proof footage for each proof asset · a CTA shot carrying reason-to-act-now · safety b-roll · SFX/room tone. Nothing is "done" until every box is checkable (formalizes Module 01's tick-off list).

## Rules & standards (MLO non-negotiables)
- **Message > format (Trinidad-first).** The shot serves the beat's *job*; never add a "cool shot" that doesn't advance Hook→Problema→Mecanismo→Prueba→CTA.
- **Coverage is the deliverable's spine.** If any anatomy stage lacks footage, the shotlist is incomplete — the mechanism and proof stages are the ones most often under-shot.
- **Filming Requirements are law** (9:16, HDR-off, raw, no VO on set, A-roll/b-roll separate, no product in hooks, no logo wardrobe, change clothes).
- **Precision > relleno.** Every shot row is unambiguous — a creator with the sheet and no other context can shoot it. No "get some product shots."
- **Notation stays consistent with Module 01:** `//` = split on-screen text; `→` = shot sequence (each becomes a numbered shot); HOOK 1–5 = separate testable openers.
- **B-roll is over-shot on purpose** (2–3×) — the editor is always starved; give handles.
- **FFM downstream:** the hooks and mechanism/demo shots exist so the edit can win hook rate / hold rate / CTR — spec them accordingly.

## Output (exact shape + concrete example)

**1) Header block** (brand · framework · format · awareness · Filming Requirements copied in).

**2) Shotlist table**

| # | Beat (anatomy · framework) | Size | Angle | Move | Lens/Focus | Action | Talent | Location/Light | Props/Wardrobe | Audio |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Hook · DISRUPT "Declassify" | MCU | Eye | Static | Normal, shallow | Creator: "Nadie te dijo por qué esto falla…" (NO product) | Creator | Bedroom, window light L | Casual, no logo | Sync |
| 2 | Hook alt (HOOK 2) | MS | Eye | Handheld | Normal | Same line, punchier open | Creator | Same | Same | Sync |
| 3 | Mecanismo · reveal | ECU | High | Slow push | Macro | Finger points to key ingredient on label | Hands | Kitchen counter, soft | Product, label up | MOS + "cap click" SFX |
| 4 | Prueba · demo | MS→ECU | Eye | Static | Deep→macro | Drop absorbs in 10s on back of hand | Hands | Same | Product | MOS |
| 5 | CTA · reason-now | MS | Eye | Static | Normal | Creator holds product: "30 noches o reembolso" | Creator | Bedroom | Product in | Sync |

**3) B-roll capture list (grouped by location)** — e.g. *Kitchen counter:* label macro ×2 sizes, pour, uncap; *Bedroom:* lifestyle wide, morning routine; *Safety cutaways:* 3–5 pattern-interrupts.

**4) Coverage checklist**
- [ ] All A-roll lines captured MS **and** MCU
- [ ] 3–5 hook openers shot (HOOK 1–5)
- [ ] ≥1 mechanism ECU/insert that *demonstrates* (not narrates)
- [ ] Proof footage for each proof asset (demo/before-after/testimonial/data b-plate)
- [ ] CTA shot with reason-to-act-now (product + offer/urgency)
- [ ] 3–5 safety pattern-interrupt b-roll cutaways
- [ ] Room tone + product SFX captured (MOS)
- [ ] Filming Requirements respected on every row (9:16, HDR-off, raw, no VO, no logo, product out of hooks)

## Guardrails
- Never invent MLO frameworks or add beats not in the approved script — this skill *shoots* the script, it doesn't rewrite it. Send script problems to **script-doctor**; script writing to **framework-scriptwriter**.
- If the script isn't final, say so and ask to lock it first (don't build a shotlist on a moving target).
- Don't drop Filming Requirements to "look premium" unless the brief explicitly calls for high-production (then note the register change per iteration-playbooks UGC⇄high-production).
- AI-footage prompts are a supplement, not a default — flag when a real capture is cheaper/more authentic.

## References
- Full detail, framework→shot map, and craft vocabulary: `reference/knowledge-base.md`.
- MLO playbook grounding: `01-Modulo-Frameworks-y-Script-to-Brief.md` (Script→Brief table §3, Filming Requirements, notation, tick-off list, quality gate §4, 12 frameworks §2) and `00-INDEX-Sistema-Scripting-MLO.md` (Trinidad, anatomy of the winner, FFM).
- Reused: `mlo-winner-strategist/reference/iteration-playbooks.md` (static→video "demo the claim," AI-video 5-part cinematic prompt, b-roll capture in AI-UGC).
- Aligns with (don't fork): framework-scriptwriter (writes the script/brief upstream), script-doctor (QA upstream), ai-video-director / ugc-director / seedance-20-ugc-ad-director (AI execution downstream), mlo-ad-brief-builder.
