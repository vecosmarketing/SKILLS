# Proceso de redacción + generar la presentación

## Cómo se redacta (part-por-part)

No escribas el VSL entero de una sentada. Se redacta **parte por parte** con su plantilla (ver `estructura-y-plantillas.md`) y al final se unen.

1. **Parte por parte.** Abre cada bloque, lee "qué redactar", copia la plantilla y redáctala para la oferta real. De una en una, en orden (Promesa → … → CTA final).
2. **Une el guion definitivo.** Documento nuevo, vuelca las 10 partes en orden. Léelo entero de principio a fin: que **fluya** y el **tono** sea coherente.
3. **Vuelca en la presentación.** El VSL va en formato presentación (no hace falta salir en cámara). Diseño **muy simple** (fondo blanco o color de marca, sin decoración), texto grande y legible, una idea por slide, que puedas ir leyendo y explicando.

## Prompt para generar la presentación con Claude

Cuando el guion definitivo esté listo, se genera la presentación con este prompt (rápido). Rellena color/tipografía de marca; si no, fondo blanco neutro (lo que mejor funciona). Revisa los marcadores `[AQUÍ VA: captura]` y añade ejemplos reales + prueba social.

```
Eres un experto en diseño de presentaciones para VSL de ventas. Te voy a dar el guion completo de un VSL. Tu tarea es convertirlo en una presentación lista para grabar.

Reglas de la presentación:
- Diseño muy simple y limpio: fondo blanco (o el color de marca que te indique), sin decoración recargada, sin animaciones.
- Texto grande y muy legible, pensado para que se lea bien en vídeo.
- Reparte el guion en slides de forma lógica: cada idea o bloque en su slide. No metas párrafos largos en una sola slide; trocea.
- Respeta el orden y el contenido del guion. No añadas información que no esté ni inventes datos, cifras ni testimonios.
- Donde el guion mencione mostrar ejemplos, prueba social o capturas, deja un marcador claro tipo [AQUÍ VA: captura / ejemplo] para que yo lo añada después.
- El objetivo es que yo pueda ir pasando slides mientras leo y explico cada una en voz alta.

Branding (rellena si aplica): color principal = [COLOR], tipografía = [TIPOGRAFÍA].

Este es el guion del VSL:

[PEGA AQUÍ TU GUION DEFINITIVO]
```

Después: repasa que cada slide se lea bien, coloca capturas/prueba social en sus marcadores, y a grabar.
