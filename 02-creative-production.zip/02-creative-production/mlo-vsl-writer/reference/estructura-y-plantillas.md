# Las 10 partes del VSL — qué redactar, plantilla y ejemplo

Fuente: entrenamiento "Redacción del VSL". Redacta **una parte por una**, con su plantilla, y al final las unes. El ejemplo usa una oferta genérica (web por 97€/mes) — sustitúyelo por la oferta real. Para MLO, cruza con `contexto-mlo.md` + Notion.

---

## Parte 1 · Promesa
**Qué:** apertura que decide si te siguen viendo. En los primeros segundos, entregable + precio + rapidez, conectando con lo que la persona quiere. **Cohesión total con el anuncio** del que viene. Nombra de paso la fricción que le frenaba (la desarrollas en el dolor).

**Plantilla:**
> *Si quieres [RESULTADO QUE DESEA], pero [FRICCIÓN / LO QUE LE FRENABA]…*
> *[ENTREGABLE] por [PRECIO], listo en [RAPIDEZ], sin que tengas que preocuparte de nada.*
> *Y lo mejor de todo: [GARANTÍA / CONDICIÓN QUE QUITA EL RIESGO, si aplica].*

**Ejemplo:**
> *Si quieres una página web profesional que dé buena imagen y te traiga clientes, pero no quieres pagar miles por adelantado ni esperar meses… Te creamos una web profesional por solo 97€/mes, sin coste por adelantado, lista en menos de 7 días. Y lo mejor: si no te gusta cómo queda, no pagas.*

---

## Parte 2 · El dolor
**Qué:** los **mismos dolores/bloqueos de la landing**, para que piense "esto me pasa a mí". No hundirle. Nombra la situación frustrante y **lo que le ha impedido resolverlo** (precio, tiempo, complicación técnica, malas experiencias). Conecta el dolor con tu promesa: eso que le frenaba es lo que tú eliminas. Breve.

**Plantilla:**
> *Seguramente ya sabes que [POR QUÉ IMPORTA EL RESULTADO / QUÉ SE PIERDE SIN ÉL].*
> *Pero hasta ahora, conseguirlo significaba [DOLOR 1], [DOLOR 2] y [DOLOR 3].*
> *Por eso la mayoría lo va dejando… y mientras tanto, [CONSECUENCIA DE NO TENERLO].*

**Ejemplo:**
> *Seguramente ya sabes que si tu negocio no tiene web profesional, pierdes clientes cada día… Pero hasta ahora eso significaba pagar 1.000-3.000€ por adelantado, esperar semanas y pelearte con dominios y hostings. Por eso la mayoría lo va dejando… y mientras tanto siguen dando una imagen pobre y perdiendo clientes.*

---

## Parte 3 · Qué es y cómo funciona
**Qué:** el **mecanismo**: qué haces exactamente y cómo, de forma lógica y sencilla. No reveles la salsa secreta, solo la claridad para que confíe. Lenguaje de cliente, no técnico. Di lo que te diferencia (más rápido/barato/sin que él haga nada).

**Plantilla:**
> *Déjame explicarte exactamente qué hacemos y cómo funciona.*
> *[QUÉ ES EL SERVICIO EN UNA FRASE].*
> *La forma en que lo hacemos es [MECANISMO EN SENCILLO], lo que nos permite [VENTAJA].*
> *Para ti, esto significa que [BENEFICIO CONCRETO].*

---

## Parte 4 · El paso a paso
**Qué:** el recorrido exacto desde que compra/agenda hasta el entregable. Quita el miedo a lo desconocido y refuerza que es fácil para él. Numera; en cada paso, qué haces tú y qué (poco) hace él. El último paso = el resultado final disfrutándolo.

**Plantilla:**
> *Y si te preguntas cómo sería el proceso, es muy sencillo:*
> *1. [PASO 1: justo después de empezar]. 2. [PASO 2]. 3. [PASO 3]. 4. [PASO 4]. 5. [PASO FINAL: ya disfruta del resultado].*

---

## Parte 5 · Ejemplos de lo que recibe
**Qué:** enseña, lo más visual posible, lo que se lleva, para que se lo imagine suyo. En el guion deja marcadores y una frase que dirija la atención a lo importante. Muestra distintos estilos/sectores para que cualquiera se vea representado.

**Plantilla:**
> *Para que te hagas una idea de lo que vas a recibir, mira algunos ejemplos:*
> *[AQUÍ VAN: ejemplos visuales del entregable].*
> *Como ves, [FRASE QUE DIRIGE A CALIDAD / VARIEDAD / RESULTADO].*

---

## Parte 6 · Precio
**Qué:** dilo **abierto** (el precio es la ventaja), **después** de mostrar el valor, y **anclado** contra lo que cuesta lo mismo en el mercado. Refuerza el ángulo de la oferta (ej. sin pago por adelantado) y recuerda la garantía. *(En el modelo de venta en 2 pasos, el precio puede omitirse y dejarse para la auditoría.)*

**Plantilla:**
> *Ahora hablemos del precio.*
> *Normalmente, [LO QUE OFRECES] cuesta [PRECIO DE MERCADO ALTO], y encima [FRICCIÓN HABITUAL].*
> *Con nosotros, lo tienes por [TU PRECIO], [ÁNGULO].*
> *Y recuerda: [GARANTÍA / CONDICIÓN QUE QUITA EL RIESGO].*

---

## Parte 7 · Prueba social
**Qué:** máxima confianza en el menor tiempo. Respalda con hechos que tu promesa es real. **5-10 elementos**, priorizando los más potentes y **alineados con el resultado exacto que prometes**. Orden de mayor a menor confianza: resultados propios en el sector → resultados de clientes en tiempo real → nombres de clientes con su resultado → prensa/medios → capturas de comentarios → reseñas (Trustpilot). *Si no tienes ≥10 buenos elementos de gente que llegó a ese resultado, ese no es tu embudo todavía.*

**Plantilla:**
> *Y no, no te fíes solo de lo que digo yo. Mira nuestro historial.*
> *Ya lo hemos hecho para [NÚMERO] negocios como [NOMBRE], [NOMBRE], [NOMBRE]… y muchos más.*
> *Y esto es lo que dicen de nosotros: [AQUÍ VAN: capturas de reseñas/testimonios alineados con la promesa].*

---

## Parte 8 · CTA (primero)
**Qué:** va **justo antes de las FAQ**. Da salida a quien ya está convencido para que no espere al final. Paso de **bajo compromiso**: no le pides comprar, solo dar el primer paso. Directo: qué hacer y qué pasa después. Se repite igual al final.

**Plantilla:**
> *Si ya lo tienes claro, esto es lo único que tienes que hacer:*
> *[Regístrate y escríbenos por WhatsApp | Agenda tu auditoría]. [QUÉ PASA DESPUÉS].*
> *Y si todavía te queda alguna duda, sigue viendo, que ahora las resuelvo todas.*

---

## Parte 9 · Preguntas frecuentes
**Qué:** resuelve proactivamente las objeciones típicas, para que llegue al CTA final sin dudas. Respuestas cortas y tranquilizadoras. Objeciones habituales: qué incluye exactamente, qué pasa si no le gusta, qué tiene que hacer él, cuánto tarda, qué pasa si quiere cambios, qué pasa si deja de pagar.

**Plantilla:**
> *Antes de terminar, respondo las dudas más frecuentes:*
> *[PREGUNTA 1]? → [RESPUESTA CORTA Y TRANQUILIZADORA].*
> *[PREGUNTA 2]? → [RESPUESTA]. … (4-6 preguntas)*

---

## Parte 10 · CTA final
**Qué:** cierre del VSL, **repite el mismo CTA** que antes de las FAQ (mismo mensaje y acción, para no confundir). Va aquí porque, resueltas las dudas, es cuando más gente está lista. Cierra reforzando **bajo riesgo y facilidad** (garantía / ángulo principal). Es lo último que oye.

**Plantilla:**
> *Así que si quieres [RESULTADO], esto es lo único que tienes que hacer:*
> *[Regístrate y escríbenos por WhatsApp | Agenda tu auditoría]. [QUÉ PASA DESPUÉS].*
> *Sin compromiso y sin riesgo. [REFUERZO FINAL: garantía / ángulo principal].*
