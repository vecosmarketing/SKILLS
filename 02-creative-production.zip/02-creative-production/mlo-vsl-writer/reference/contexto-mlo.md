# Contexto MLO para VSLs

El detalle vivo (ofertas exactas, tiers, casos con cifras) está en **Notion** (Business Context, brand brains, skill `mlo-estratega-creativo`) y en el Cloud Project "VSL Expert". Consúltalo antes de redactar; aquí va el ancla.

## Modelo de venta
MLO vende en **2 pasos**: el VSL/anuncio → **agendar auditoría gratuita** (cualificar) → auditoría con Marcel → cierre. CTA por defecto de los VSL de agencia = "agenda tu auditoría". (El método de 10 partes en su forma pura es venta directa registrarse+WhatsApp; se usa esa variante solo si la oferta lo pide.)

## Las 4 líneas de VSL
1. **General (Agencia · Creative Scale):** DTC ≥10k/mes con ROAS inestable al escalar. Mecanismo = motor creativo data-driven + media buying. Tiers 3.000 / 4.000 / 5.000 €/mes.
2. **UGC (Creators Scale):** marca con fatiga creativa que necesita volumen de contenido nativo. Mecanismo = motor de creadores + whitelisting + data.
3. **Sistema Creativo:** produce creativos "a ojo", ROAS cae al escalar. Mecanismo = la math de winners (cuántos creativos necesitas, hit rate, churn, €/winner). Diferenciador flagship.
4. **Consultoría (Creative Scale 1:1):** founder <6 cifras que quiere montar el sistema in-house guiado. 5 meses, 1 sesión/sem + Slack. Palanca actual: relanzamiento septiembre, 5 plazas, luego pasa a grupal.

## Voz de Marcel
Tuteo, directo, cercano, cero humo. Coloquial ("hostia", "pastón", "darle caña", triple "súper/guay"). Seguro sin ser prepotente. **Medimos por rentabilidad**, no por ROAS de vanidad. "Lo que no se sabe, se pregunta o se busca — no se inventa."

## La garantía (reversión de riesgo estrella)
> "Si no generas más beneficio neto del que nos pagas, para nosotros es un fracaso, y trabajamos hasta conseguirlo."
Es el cierre del bloque de Precio / CTA. Va casi siempre.

## Pruebas (casos) — SIEMPRE cifras reales
Saca los casos de Notion; nunca inventes números. Ejemplos documentados a **confirmar antes de grabar**: Claudia&Julia (+39% ventas, ~8,25x ROAS), 8hours (+300% en <1 año), Moncho Moreno (+67% clientes nuevos, ~12x en 70 días), Bala di Gala (Hot Sales México: 500→10.000 €/día en 2 días manteniendo NCPA). Marca cualquier cifra sin fuente como "⚠️ confirmar con Marcel".

## Ángulos/mecanismos con nombre (banco)
Volumen creativo calculado · hit rate · los 3 churn · €/winner sostenido · awareness stages (Schwartz) · nCPA vs ROAS de vanidad · pujas manuales (coscap/bitcap) + wave surfing · landing/listicle/advertorial · VSL ads. (Detalle en `mlo-estratega-creativo`.)

## Guardraíles MLO específicos
- Nada de value stacks. La ventaja es la math + la garantía.
- Un nivel de consciencia por VSL; misma historia que la landing/anuncio de origen.
- Compliance Meta/YouTube; sin claims absolutos.
