# VSL avanzado — lente Jeremy Haynes (high-ticket / call funnel)

Segunda capa, complementaria a la estructura de 10 partes. La de 10 partes es ideal para **venta directa** (producto/servicio con precio abierto → registrarse). Esta lente sirve cuando el VSL va a un **funnel de llamada / high-ticket** y cuando hay que decidir **tono, longitud y diseño según el público**. Fuente: masterclass "$1M/month VSL" (Jeremy Haynes).

## El modelo mental que lo ordena todo
Un VSL es **una conversación de ventas normal capturada en vídeo, sin las respuestas del interlocutor.** Cada paso debe responder **la siguiente pregunta que esa persona tendría** en una conversación real. Si dejas una pregunta sin responder y sigues hablando, la persona "deja de oírte" y se va (dropoff). Adivina bien qué necesita saber a continuación.

## Affluent vs General Public (elige antes de escribir)
| | **Affluent (rico/founder serio)** | **General public (masas)** |
|---|---|---|
| Longitud | 2-15 min | 5-60 min (más info, más escepticismo) |
| Tono | directo, punchy, autoridad auténtica, sin fluff | más empático (si eres muy directo, quedas de creído) |
| Claims | conservadores, **undershoot** | los **más grandes que sigan siendo creíbles** rinden mejor |
| Diseño | minimalista (fondo blanco/negro, texto, sin logos) | **bien diseñado** (el minimalismo les huele a estafa) |
| Escasez | poca falta (ya son sesgados a la acción) | **escasez real + descuento creíble** funcionan mucho |
| Prueba social | pocos elementos pero potentes | muchos testimonios **muy creíbles** (del sitio donde se capturaron) |

Extra: el **personaje** (cómo vistes/hablas/entorno) debe **coincidir con lo que ese público espera**. "Camaleón": no finjas, pero preséntate como esperan (ej. captar inversores serios → outfit neutro, no un Gucci jumpsuit).

## El flujo de 7 pasos (para VSL de funnel de llamada)
1. **Hook / opener** — "esto es lo que puedo hacer por ti" + por qué vale la pena ver el vídeo. Directo. *(Un dropoff fuerte al inicio = opener malo o estás en un "minority hook" → cámbialo.)*
2. **El porqué (por qué TÚ/tu empresa)** — credibilidad y expertise **reales** (no relleno tipo "un poco sobre mí"). Aquí plantas objection-handlers y prueba dura (ej. "X clientes, tasa de disputa 0,6%").
3. **La foto grande / buying motives** — cascada del **majority hook → minority hooks**: todas las razones por las que la gente compra, de la mayoritaria a las minoritarias. Suele ser un buen trozo.
4. **La oferta** — presenta lo que vendes (la oferta principal que quieres vender al que ve esto).
5. **Precio — DILO SIEMPRE.** Decir el precio **cualifica** (menos llamadas basura, mejor show rate) y **condiciona el pixel** hacia gente cualificada. **Nunca value stacks** (no cumplen FTC y matan la confianza). Sí: descuento creíble + escasez real.
6. **Objection handling** — objeciones **reales** sacadas de llamadas/clientes reales, no inventadas. Transición: "y por cierto, creo que es una oferta perfecta, te explico por qué…".
7. **Cualificación (para quién SÍ / para quién NO)** → **CTA claro** (rellena application → agenda). Opcional: testimonios creíbles + CTA final (sin pasarte de la longitud ideal del público).

## Diagnóstico de rendimiento (cómo se lee un VSL)
- **Play rate** (de los que llegan a la página, cuántos le dan a play): 30%+ es bueno. Bajo = desconexión anuncio↔página o **demasiado contenido** bajo el vídeo. Página simple (headline + VSL + application) = más play rate.
- **Retención:** caída **gradual y descendente** = normal y sana (la gente se autocualifica y actúa o se va). Caída **muy pronunciada al principio** = arregla el opener/hook o estás en un minority hook.
- No esperes que vean el 100%: la gente se va en cuanto concluye "esto es/no es para mí".
- Herramienta recomendada: Wistia (analíticas + video thumbnail → mejor play rate que thumbnail estático tipo "no te saltes esto").

## Cómo lo aplica MLO
- El **modelo de agencia MLO es 2 pasos** (VSL → agendar auditoría): usa el flujo de 7 pasos con CTA = "agenda tu auditoría", y **decide con Marcel si el precio va en el VSL** (Haynes recomienda decirlo para cualificar; MLO a veces lo reserva para la auditoría).
- Avatar MLO (founders DTC) = tira a **affluent/serio**: VSL más corto, directo, autoridad auténtica, claims conservadores, prueba con **casos y cifras reales** (nunca inventadas), **garantía de rentabilidad** como reversión de riesgo.
- **Prohibido** el value stack. La ventaja de MLO es la math y la garantía, no inflar precios.
