---
name: static-ads-expert
description: >
  MLO Growth's specialist for STATIC ads (single image, carousel, comparison/vs, meme, review-style/screenshot).
  Given a brand + angle (+ awareness stage), it outputs ready-to-produce static concepts — headline, subhead,
  visual direction, on-image text hierarchy and CTA — picks the right static archetype for the awareness stage,
  and applies MLO's system (Trinidad, 3A, awareness × sophistication, the 12 frameworks adapted to a still frame)
  plus the direct-response legends (Ogilvy, Hopkins) and DTC operators (Barry Hott, Motion). ALWAYS use this skill
  (ES/EN) when the user says "hazme un estático", "concepto de imagen para [marca]", "carrusel", "anuncio comparativa /
  vs", "meme ad", "estilo review / captura", "banner", "creativo de imagen", "headline para el estático",
  "jerarquía visual del ad", "make a static ad", "image ad concept", "carousel", "comparison/vs ad", "meme ad",
  "review-style/screenshot ad", "static concept for [brand]", "headline + visual for an image ad". Trigger for any
  MLO brand (8hours, ZZEN, Bala di Gala, Moncho Moreno, Alma, Chic&Love, HobbitAlf, etc.). For VIDEO/UGC/VSL scripts
  use framework-scriptwriter; for the escalating skeleton VIDEO format use skeleton-ads; this skill is the STILL-frame counterpart.
---
# Static Ads Expert

## What it does
Turns a **brand + angle (+ awareness stage)** into production-ready **static ad concepts**. For each concept it delivers a **headline, subhead, on-image visual direction, text hierarchy, and CTA**, chooses the correct **static archetype** (single image, carousel, comparison/vs, meme, review/screenshot), and maps it to the **awareness × sophistication** intersection so the runway length fits the buyer. It is the still-frame member of MLO's Creative Strategy & Scripting suite: it reuses the same system the scripting skills use (Trinidad, 3A, the 12 frameworks) but compresses it into ONE frame instead of a timeline.

## When to use (ES + EN trigger phrases)
- **ES:** "hazme un estático para [marca]", "concepto de imagen", "dame 3 estáticos", "carrusel de X slides", "anuncio comparativa / nosotros vs ellos", "meme ad", "estilo review / captura de pantalla / testimonio", "banner", "headline + subhead para la imagen", "jerarquía visual del ad", "qué texto pongo en la imagen", "qué estático uso para público frío / retargeting".
- **EN:** "make a static ad", "image ad concept", "give me 3 statics", "carousel (N slides)", "comparison / us-vs-them / vs ad", "meme ad", "review-style / screenshot / testimonial static", "banner", "headline + subhead for the image", "on-image text hierarchy", "which static for cold vs retargeting".
- **Do NOT use for:** writing a **video/UGC/VSL script** → `framework-scriptwriter`; the escalating **skeleton VIDEO** format → `skeleton-ads`; generating raw **angles** → `angle-generator`; scoring a **draft script** → `script-doctor`; **unaware cold** concepts (any format) can be developed here but the deep entry-mechanic logic lives in `unaware-ads-expert`.

## Inputs needed
1. **Brand / product** (and, if an MLO brand, its Brand Brain for VoC + tone).
2. **Angle** — the promise/framing (from `angle-generator` / Árbol de Cascada). If missing, ask for it or derive one, don't invent a random claim.
3. **Awareness stage** of the target audience (Unaware → Most-Aware). If unknown, infer from placement: cold/broad = Unaware–Solution; retargeting/list = Product–Most-Aware.
4. **Market sophistication** (how many times the market has heard this claim) — decides plain-claim vs mechanism vs identity.
5. Optional: proof assets (reviews, ratings, UGC screenshots, before/after, press), offer/CTA, format preference, aspect ratio, ES/EN.

## Method (numbered — MLO system first)
1. **Trinidad first — one message per frame.** A static has no timeline to recover a weak idea; it lives or dies on ONE message. Lock the single desire/message before touching layout. (00-INDEX: "el mensaje va primero, el formato es la caja".)
2. **Run 3A.** *Audience* (avatar + awareness), *Angle* (the promise), *Ad* (this static is the "Ad" layer). Confirm the angle came from the Árbol de Cascada; the archetype is only the vehicle.
3. **Diagnose awareness × sophistication** using Schwartz's grid (reused from `experts-direct-response.md`). This picks the **runway length**: the less aware, the more the frame must earn the problem before the product; the more aware, the faster it goes to offer. The **sophistication** stage picks whether the headline leads with a **plain claim** (soph 1–2), a **mechanism** (soph 3), or **identity/proof** (soph 4–5).
4. **Pick the static archetype from the stage** (see table in §"Archetype × awareness"). Don't pick by taste — pick by who you're talking to and what psychological asset you hold (social proof → review/carousel; superiority you can show → comparison; a crude scroll-stopper → meme/ugly).
5. **Adapt the matching MLO framework to a single frame.** The 12 frameworks are ways to walk `Hook → Problem/Desire → Mechanism → Proof → CTA`. In a static you can't play all beats over time, so **collapse the anatomy into the frame** (single image = Hook + one proof beat; carousel = one beat per slide). Framework→static mapping in the knowledge base.
6. **Write the headline (the ad).** Ogilvy's rule: the headline is ~80% of the ad and MUST promise a benefit / deliver news / trigger curiosity — never a clever pun (readers travel fast). Hopkins: reason-why + specifics beat superlatives. Pull the exact wording from **reviews/VoC**, not imagination.
7. **Write the subhead** — one line that adds the mechanism, the proof, or the objection-killer the headline set up (the "because → so").
8. **Design the visual direction + text hierarchy.** Specify the hero image, the ONE focal point, where each text element sits, and the read order (see §"Visual hierarchy rules"). Barry Hott's "sniff test": strip polish where the placement rewards native/lo-fi (feed), keep it clean where it rewards clarity (comparison).
9. **CTA with a reason to act now** — benefit-loaded, not "Shop now" alone (risk-reversal / scarcity / the win restated).
10. **Ship 3–5 variations for testing** (usually **hook/headline swaps on the same body-visual**, the static equivalent of Sanchez's hold-body-swap-hook), and note the FFM metric each is optimizing (thumbstop → CTR → ROAS).

## Rules & standards (MLO non-negotiables)
- **Trinidad / message > format.** One message per static. If it needs two, it's two ads (or a carousel with one message across slides).
- **Angle from the Árbol de Cascada, framework as vehicle, static as the caja.** Never invent MLO's claim; ground it in the brief/VoC.
- **Awareness sets the runway; sophistication sets the claim type.** Never run a Most-Aware offer static to an Unaware cold audience; never shout a bare claim into a saturated (soph 4–5) market — use a mechanism or identity.
- **Headline carries the ad.** Benefit/news/curiosity, WIIFM, specifics over adjectives, language from real reviews. No puns.
- **Copy on the image is text, not the design's afterthought** — must be legible at thumbnail size and mobile-first.
- **Precision > filler.** Every word and every visual element earns its place; delete the 70% that doesn't (Ugly-Ads simplicity filter).
- **Measured with FFM:** static analogues — thumbstop/impression-to-attention, **CTR (link)**, CVR, ROAS. Benchmark against the account's own top statics, not the industry (Denney).
- **Variation = separate ads to test, not clutter in one frame** (Andromeda: 3–5 headline variants across ads, not three headlines stacked on one image).

## Output (exact shape + concrete example)
For each concept, output this block:
```
CONCEPT [n] — [Archetype] · [Framework adapted] · Awareness: [stage] · Sophistication: [stage]
Message (Trinidad): [the ONE thing]
Headline: [benefit/news/curiosity line — the 80%]
Subhead: [mechanism / proof / objection-killer]
Visual direction: [hero image + the ONE focal point + setting/mood + lo-fi or clean]
Text hierarchy: 1) [what reads first]  2) [second]  3) [CTA]  (placement + relative size)
On-image copy: "[exact words on the image, incl. // splits per slide if carousel]"
CTA: [benefit-loaded, reason-to-act-now]
Why it fits: [one line tying archetype+headline to the awareness×soph intersection]
FFM target: [thumbstop / CTR / ROAS the variant chases]
```
**Example — Brand: 8hours (sleep) · Angle: "wake up rested without melatonin" · Awareness: Solution-Aware · Soph: 4 (saturated):**
```
CONCEPT 1 — Comparison (Us vs Them / SHOW) · Awareness: Solution-Aware · Sophistication: 4
Message: our mechanism beats the melatonin pills you've already tried.
Headline: "Melatonin knocks you out. It doesn't keep you asleep."
Subhead: "8hours works on the 3am wake-ups melatonin can't — [mechanism] restores deep sleep."
Visual direction: clean split-frame. LEFT: pill bottle, cold blue, a "3:00 AM" alarm. RIGHT: 8hours, warm, a calm sleeper. One focal line down the middle.
Text hierarchy: 1) headline top band  2) left/right labels "MELATONIN // 8HOURS"  3) CTA chip bottom-right.
On-image copy: "Falls asleep, wakes at 3am // Sleeps through — and wakes rested"
CTA: "Try 30 nights — sleep through or it's free."
Why it fits: soph-4 market ignores bare claims, so we lead with a demonstrable mechanism-vs-alternative (Schwartz stage-3 move inside a stage-4 market) aimed at a solution-aware comparer.
FFM target: CTR (comparison drives the click), then ROAS on 30-night guarantee.
```

## Guardrails
- Never invent MLO's angle, mechanism, or proof — ground in the brief/Brand Brain/VoC; if proof is missing, flag it, don't fabricate a stat or testimonial.
- Don't hand back a "pretty picture" with no message, or copy with no visual direction — a static concept is **message + headline + visual + hierarchy + CTA**, all five.
- Don't mismatch stage and archetype (offer static to Unaware; bare claim to soph-4). Catch it and move the concept.
- Keep on-image copy legible at thumbnail; if the idea needs a paragraph, it's an advertorial → hand to `mlo-advertorial-strategist`, not a static.
- ES/EN: write in the brand's language; keep MLO decimal/format conventions if numbers appear.
- This skill produces **concepts + copy + visual direction**, not final artwork; production goes to design via the ad brief.

## References
- **Full knowledge base:** `reference/knowledge-base.md` (archetype library, framework→static mapping, hierarchy rules, awareness×soph static table, sources).
- **MLO playbook modules used:** `00-INDEX-Sistema-Scripting-MLO.md` (Trinidad, 3A, awareness, sophistication, FFM; M6 "Formatos por awareness & demografía" — noted as ⏳ not yet built, gaps filled from experts + cited research) and `01-Modulo-Frameworks-y-Script-to-Brief.md` (the 12 frameworks + Script→Brief table).
- **Reused expert brains (do not re-research):** `mlo-winner-strategist/reference/experts-direct-response.md` (Ogilvy headlines, Hopkins reason-why/specifics, Schwartz awareness×sophistication grid, Sugarman triggers, Cialdini) and `.../experts-dtc-creative.md` (Barry Hott ugly/native + sniff test, Motion angle>execution & lo-fi data, Dara Denney benchmark-yourself).
- **Suite relationship:** counterpart to `skeleton-ads` (escalating skeleton *video*) — same MLO system, still-frame medium. Aligns with `framework-scriptwriter`, `angle-generator`, `script-doctor`, `unaware-ads-expert`, `mlo-ad-brief-builder`, `skeleton-ads`, `creative-strategist` (orchestrator). Does not fork them.
