# Static Ads Expert — Knowledge Base

Distilled knowledge for building **STATIC ads** (single image, carousel, comparison/vs, meme, review-style/screenshot) inside MLO Growth's Creative Strategy & Scripting system. MLO system first; reused expert frameworks named and cited; fresh web research kept separate with URLs.

**Suite relationship:** This is the still-frame counterpart of `skeleton-ads` (which owns the escalating narrated *video* format). Both sit under the same MLO engine. Where `framework-scriptwriter` writes a script over a timeline, this skill **collapses the winner anatomy into a single frame (or one beat per carousel slide)**. Angles come from `angle-generator` / Árbol de Cascada; unaware cold logic from `unaware-ads-expert`; QA from `script-doctor`; orchestration from `creative-strategist`.

---

## 1. The MLO system, applied to a still frame (source: `00-INDEX` + `01-Frameworks`)

### 1.1 The three rules that still govern (even without a timeline)
1. **The message goes first; the format is the box.** (00-INDEX: *"el mensaje va primero, el formato es la caja… Precisión > relleno."*) A static is the tightest box there is — ONE message per frame. If you need two messages, it's two ads, or a carousel that carries one message across slides.
2. **The hook talks to ONE person.** The viewer doesn't know or care about the brand — only their problem. A static's "hook" is the **first frame = the whole ad**: headline line + key visual must stop the *right* scroller in <1s.
3. **Winner anatomy** (`01-Frameworks` §0): `Hook → Problem/Desire → Mechanism (why it works) → Proof → CTA with a reason to act now`. In a **single image** you compress this: the headline is the Hook + Desire, the visual + subhead carry Mechanism/Proof, the CTA chip closes. In a **carousel** you get one beat per slide (Hook slide → Problem → Mechanism → Proof → CTA), which is the closest static gets to the full anatomy.

### 1.2 Trinidad → 3A → framework, for statics
- **Trinidad (message first):** lock the single desire before layout.
- **3A** = *Audience* (avatar + awareness) · *Angle* (the promise, from the Árbol de Cascada) · *Ad* (this static). The archetype is only the vehicle that carries the angle.
- **Framework as vehicle:** the 12 frameworks are 12 ways to walk the winner anatomy. For a static you pick one and **collapse it** (§3).

### 1.3 FFM for statics (measurement preset, adapted)
The FFM preset is built for video (hook rate = 3s plays ÷ impressions, hold rate, CTR, ROAS). Static analogues:
- **Thumbstop / attention:** there's no 3s-play metric on a still; proxy with **impression→outbound-CTR** and early scroll-past behavior. The first frame doing its job shows up as CTR.
- **Link CTR** — the primary static "does the hook work?" signal.
- **CVR** (post-click) and **ROAS** — does the promise convert.
- **Benchmark against the account's own top statics**, not universal numbers (Dara Denney rule, `experts-dtc-creative.md`).
- **Variation ≠ clutter.** Test 3–5 headline variants as *separate ads* (Andromeda), not three headlines stacked in one frame.

---

## 2. The static archetype library (which archetype, and its anatomy)

Five core archetypes. Each is a *format vehicle* — the angle and framework fill it.

| Archetype | What it is | Best psychological asset | Native format cues |
|---|---|---|---|
| **Single image** | One hero frame: headline + key visual + CTA. | A punchy claim, a curiosity gap, a striking product/result shot. | Feed-native, mobile-first, one focal point. |
| **Carousel** | 2–10 swipeable frames, one beat per slide. | A list/story that needs sequence (Listicle/CURE, before→after, step-by-step, objection stack). | Slide 1 must earn the swipe; each slide one idea; last slide = CTA. |
| **Comparison / "vs"** | Split or table frame showing you vs the alternative. | Demonstrable superiority / a mechanism you can *show* (Us vs Them / SHOW, How-to-X-without-Y). | Clean, legible, labeled columns, one focal dividing line. |
| **Meme / ugly** | Native meme, screenshot-of-a-text, Impact-font, crude on purpose. | A relatable pain, an in-joke, a scroll-stopping crude claim (Ugly Ads filter). | Deliberately lo-fi; looks like a user post, not an ad. |
| **Review / screenshot / testimonial** | A real review, star rating, DM/comment, press quote made into the creative. | Social proof, authority, third-party credibility (Bandwagon/CROWD, Cialdini social proof). | Looks like a genuine screenshot; keep the platform chrome. |

**Selection rule (MLO):** pick by *audience + awareness* and *the asset you hold*, never by taste. Have social proof volume → review/carousel. Can *show* superiority → comparison. Need a crude cold scroll-stopper → meme/ugly. A "secret"/mechanism → single image with a mechanism headline.

---

## 3. Framework → static mapping (adapting MLO's 12 to one frame)

Each of MLO's 12 frameworks (`01-Frameworks` §2) collapsed into a still. "Beat → frame element" tells you where each beat of the acronym lands.

| Framework (acronym) | Best static archetype | How it collapses into a still/carousel |
|---|---|---|
| **Bandwagon — CROWD** | Review / carousel | Headline = "Call out the movement" ("12 chefs switched to…"); visual = the crowd/logos/UGC wall; subhead waves the proof; CTA directs. |
| **Industry Contrarian — DISRUPT** | Single image / carousel | Headline = "Declassify the secret" / myth-bust; subhead = industry failure + your mechanism; visual dramatizes the hidden thing. |
| **Listicle — CURE** | **Carousel** (native fit) | Slide 1 = curiosity list hook *with the reason for the number*; each slide = one item (uncover→remedy→evidence); last = CTA. |
| **Founder — FOUNDER** | Single image (founder photo) | Headline = mission line; visual = founder + product; subhead = numbers/eureka; CTA = "join". |
| **How to X without Y — SIMPLE** | Comparison / single image | Headline IS the framework ("Eat healthy without Sunday meal-prep marathons"); visual contrasts effort-before vs easy-now. |
| **Organic — PURE** | Meme / review / single image | Looks native, not an ad; headline reads like a caption; visual = unfiltered real moment. |
| **PAS** | Single image / meme | Headline = the pain in their words; subhead agitates (loss aversion / social-proof gap); CTA = the relief. |
| **Ugly Ads — UGLY** | Meme / ugly | Not a structure — a *filter over any archetype*: simpler (≤5 words), cheaper-looking, opposite of the competitor. |
| **Founder Objections — PROVE** | Carousel / review | Slide/line per objection → crushed with a result; visual = founder + proof. |
| **Us vs Them — SHOW** | **Comparison** (native fit) | Split-frame showdown; headline sets the challenge; the "outcome & why" (the feature) is the subhead. |
| **Triple G — Goal·Gap·Gains** | Single image / carousel | Headline uses a concrete year for urgency ("Make hydration a habit in 2026"); visual shows the gap→gain bridge. |
| **TEASE** | Single image / carousel | Headline = an impossible/curiosity claim that only resolves on click or on the next slide (max curiosity). |

**Ugly-Ads simplicity filter** (`01-Frameworks` ⑧) applies to ANY static: (1) *Can I say it in ≤5 words?* delete 70% of the copy; (2) *Can I show it cheaper?* phone-shot, natural light, Paint-tier graphics, real screenshot; (3) *What's the opposite of every competitor's frame?*

---

## 4. Which static archetype fits which awareness stage

Diagnose **awareness (the prospect)** and **sophistication (the market)** first — the reused Schwartz grid (`experts-direct-response.md`). Awareness sets the **runway length**; sophistication sets the **claim type** (plain claim → mechanism → identity/proof).

### 4.1 Awareness → runway → archetype

| Awareness | What they know | Static runway | Best archetypes | Headline move |
|---|---|---|---|---|
| **Unaware** | Not even the problem. | Longest — don't lead with the product. | Meme/organic, curiosity single-image, listicle carousel, review that reads native. | Symptom / curiosity / identity call-out ("10 signs your ___ is quietly failing you"). Product hidden. See `unaware-ads-expert`. |
| **Problem-Aware** | Feels the pain, not the cause/fix. | Medium — validate + diagnose. | PAS single-image, listicle carousel, meme of the pain. | Name the pain precisely in their words, then the root cause. |
| **Solution-Aware** | Comparing approaches, not brands. | Medium — lead with mechanism/USP. | **Comparison/vs**, How-to-X-without-Y, carousel. | Mechanism vs alternatives ("why X beats the pills you've tried"). |
| **Product-Aware** | Knows your product, hasn't committed. | Short — kill objections. | Review/testimonial, comparison, before/after carousel. | Handle the objection: proof, guarantee, before/after. |
| **Most-Aware** | Ready, needs the offer/moment. | Shortest — offer + CTA. | Single image (offer), review reinforcing. | Offer + urgency + risk-reversal ("30% off ends tonight"). |

### 4.2 Sophistication → claim type in the headline (source: `experts-direct-response.md`)
- **Soph 1–2 (fresh claim):** state the benefit plainly; a bare benefit headline still lands.
- **Soph 3 (mechanism):** the bare claim is disbelieved → the **headline leads with the mechanism** ("the reason it works is X").
- **Soph 4–5 (saturated/skeptical — most mature DTC: supplements, skincare, weight-loss):** a bare claim is invisible → lead with **elaborated proof + comparison** (soph 4) or **identity/reinvention** (soph 5). This is why a winning static's ROAS decays: the *market* advanced a stage — respond by adding a mechanism or shifting to identity, not by shouting louder.

### 4.3 The static awareness × sophistication cheat (intersection → concept)

| | **Soph 1–2** (fresh) | **Soph 3** (mechanism) | **Soph 4–5** (saturated) |
|---|---|---|---|
| **Unaware** | Curiosity/story single-image → plain benefit. | Curiosity image revealing the *hidden cause* (mechanism as reveal). | Identity meme/organic, native review — never ad-feeling. |
| **Problem-Aware** | PAS: pain → direct promise. | PAS: pain → mechanism ("the real reason you can't…"). | Pain + data/demo carousel; lead with credibility. |
| **Solution-Aware** | "The [category] that finally works." | **Comparison**: mechanism-vs-alternatives. | Elaborated-proof comparison; out-prove the category. |
| **Product-Aware** | Benefit + why-us single image. | Mechanism + guarantee. | Review/before-after stack + risk-reversal. |
| **Most-Aware** | Offer + CTA single image. | Offer + one proof point. | Offer + urgency + risk-reversal review. |

**Two failures the grid catches:** (1) offer static to Unaware cold → move left to a problem/curiosity image; (2) bare claim in soph-4/5 → move up to a mechanism (comparison) or identity (organic/meme).

---

## 5. Headline & copy craft for statics (reused: Ogilvy, Hopkins, Sugarman)

From `experts-direct-response.md`:
- **The headline is ~80% of the ad (Ogilvy).** On a static/thumbnail the headline line + first frame *is* the ad. It must **promise a benefit, deliver news, trigger curiosity, or recognize a problem** — never a clever pun ("readers travel fast through this jungle"). Telegraph WIIFM.
- **Specifics over adjectives (Ogilvy + Hopkins).** Replace "amazing results" with the number, ingredient, timeframe. "Reason-why" copy ("*because* it's made with X, it does Y") out-converts "it's the best." Mechanism = reason-why (ties to Schwartz soph-3).
- **Language from real reviews/VoC**, not invented — mine Shopify/Amazon reviews, comments, support tickets for the exact words (the headline bank).
- **Sugarman triggers** to stack on a static (3–5 max): curiosity (open loop the image can't close), specificity ("30,847 sold"), authority (logos/"as seen in"), social proof, scarcity/urgency, honesty (admit a flaw → every other claim becomes believable), value/proof-of-value.
- **Subhead job:** deliver the mechanism, the proof, or the objection-killer the headline set up. One line.
- **CTA:** benefit-loaded + reason to act now (risk-reversal / scarcity / restated win) — not "Shop now" alone.

---

## 6. Visual hierarchy rules (reused: Barry Hott, Motion; + cited research)

### 6.1 MLO/expert-grounded rules
- **Second-0 / first-frame test (Barry Hott, `experts-dtc-creative.md`):** judge the frame at second 0 — does the imagery + message stop the *right* scroller? If not, nothing else matters.
- **The Sniff Test — over-polished red flags viewers reject (Hott):** heavy branding/logo in the first frame, artificial lighting, white/blank backgrounds, obvious studio quality, heavily scripted feel. For **feed placements**, strip these → native/lo-fi wins (Motion: 42% of top-spend ads are lo-fi). For **comparison/table** statics, clarity beats lo-fi — keep it clean.
- **Angle > execution (Motion):** a fresh angle beats a prettier version of a tired one. Exhaust angles before re-designing.
- **One focal point.** A static has one job per frame; the eye must land on ONE thing (the result, the pain, the comparison line, the product-in-use).
- **Problem-first, not product-first (Hott):** lead the frame with the felt problem before the product/brand reveal (except Most-Aware).

### 6.2 Layout & legibility rules (design fundamentals — cited)
- **Read order = size + contrast + position.** Establish a clear visual hierarchy: the most important element (headline) is largest / highest-contrast, then the supporting element, then the CTA — the eye should travel 1→2→3 without hunting. [1][2]
- **Mobile-first, thumbnail-legible.** Assume the ad is seen small in-feed: headline must be readable at thumbnail size; avoid tiny body text on a still. [3]
- **Contrast and whitespace** make the focal point pop; don't fill every pixel (whitespace *is* hierarchy). [1][2]
- **Meta's ~20% text guideline (legacy but useful):** heavy text-over-image reads as an ad and can suppress delivery/attention — keep on-image text lean; let the *headline field* and image split the load. Treat "≤20% of the image is text" as a native-feel heuristic, not a hard rule today. [4]
- **Directional cues:** faces/eyes and arrows guide the viewer toward the focal point and CTA. [2]
- **Consistent, limited type + brand palette** for legibility; 1–2 fonts, high contrast for the headline. [1][3]

### 6.3 Text hierarchy template (what to specify in every concept)
```
1) HEADLINE   — largest, highest contrast, top or over the focal point. Reads first.
2) SUBHEAD / labels — supports the headline (mechanism/proof or comparison labels). Reads second.
3) CTA chip   — benefit-loaded, bottom, visually distinct (button/chip). Reads last, drives the click.
(+ carousel: slide 1 earns the swipe; one idea per slide; final slide = CTA.)
```

---

## 7. Carousel-specific spec
- **Slide 1 is the whole ad's hook** — it must earn the swipe on its own (Sugarman slippery-slide: each element sells the next).
- **One idea per slide**, mapped to the winner anatomy: 1 Hook → 2 Problem/Desire → 3 Mechanism → 4 Proof → 5 CTA (compress or expand to slide count).
- **Continuity:** consistent type/palette so it reads as one story; optional bleed/arrow across slides to pull the swipe.
- **Best frameworks:** Listicle (CURE), Founder Objections (PROVE), before→after, step-by-step, objection stack.

---

## 8. Testing statics (reused: Denney, Sanchez, Andromeda)
- **Hold the body-visual, swap the headline** — the static equivalent of Sanchez's hold-body-swap-hook. 3–5 headline/first-frame variants per concept, each a separate ad (Andromeda naming), never stacked in one frame.
- **Benchmark against your own top statics** (Denney), by CTR then ROAS.
- **Ship variations, isolate one variable** (headline OR visual OR archetype), so a win is attributable.
- Static concepts flow into MLO production via the **ad brief** (hand to `mlo-ad-brief-builder`) — this skill outputs the concept + copy + visual direction, not final artwork.

---

## 9. Common mistakes (static-specific)
- Two messages in one frame (violates Trinidad) → split into two ads or a single-message carousel.
- Offer static ("20% off") to an Unaware cold audience → wrong runway.
- Bare claim in a soph-4/5 market → invisible; needs a mechanism (comparison) or identity (organic).
- Pretty picture, no message; or copy with no visual direction — a concept is all five parts (message, headline, visual, hierarchy, CTA).
- On-image text too small / too much → illegible at thumbnail, reads as "an ad."
- Inventing a stat/testimonial → ground proof in VoC/Brand Brain or flag it missing.
- Picking the archetype by taste instead of by awareness + the asset you hold.

---

## Sources

**MLO playbook modules (source of truth):**
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/00-INDEX-Sistema-Scripting-MLO.md` — Trinidad, 3A, Awareness, Market Sophistication, FFM; **M6 "Formatos por awareness & demografía"** listed as ⏳ *por construir* (not yet written) — static-format specifics below M-level are therefore filled from the reused expert brains + cited research, and should be reconciled with M6 once Marcel builds it.
- `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/01-Modulo-Frameworks-y-Script-to-Brief.md` — the 12 frameworks, winner anatomy, Script→Brief table, Ugly-Ads filter.

**Reused MLO expert brains (do not re-research):**
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/experts-direct-response.md` — Schwartz Awareness × Sophistication grid, Ogilvy (headline = 80%, benefit/specifics), Hopkins (reason-why, specifics), Sugarman triggers, Cialdini.
- `/Users/mlo/.claude/skills/mlo-winner-strategist/reference/experts-dtc-creative.md` — Barry Hott (ugly/native, sniff test, second-0), Motion (angle>execution, lo-fi data), Dara Denney (benchmark-yourself), Sanchez (hook-swap testing).

**External design-fundamentals research (fresh, cited):**
1. Visual hierarchy fundamentals (size, contrast, whitespace, position) — Interaction Design Foundation: https://www.interaction-design.org/literature/topics/visual-hierarchy
2. Visual hierarchy in advertising / directional cues & focal point — Nielsen Norman Group on visual hierarchy: https://www.nngroup.com/articles/visual-hierarchy-ux-definition/
3. Mobile-first / thumbnail-legibility for social ads — Meta Business Help (image ad best practices): https://www.facebook.com/business/help/980593475366490
4. Meta text-in-image guidance (legacy 20% rule → current native-feel heuristic) — Meta Business Help / text overlay: https://www.facebook.com/business/help/980593475366490 and background: https://www.adespresso.com/blog/facebook-20-text-rule/
