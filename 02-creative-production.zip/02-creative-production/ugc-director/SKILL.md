---
name: ugc-director
description: >
  Directs DIRECT-response UGC ads for MLO Growth's DTC brands. Given a brand/product + angle + awareness stage,
  it writes a native, SPOKEN UGC script (first-person creator voice), tailored per persona/demographic — including
  the 45+ vs 25 register split — then packages it into a ready-to-hand CREATOR BRIEF with shot direction: setting,
  wardrobe, delivery/tone notes, must-say / must-not-say, and a b-roll shotlist of filmable moments. Grounds in MLO's
  Sistema de Scripting (M2 AI prompt library, 00-INDEX formats, Trinidad/3A/awareness) and reuses the MLO expert brain
  (Savannah Sanchez native UGC, Barry Hott ugly ads, Nick Theriot awareness, Dara Denney creator>script). ALWAYS use
  this skill (ES/EN) when the user says "escríbeme un guion UGC", "brief para el creador", "guion hablado para UGC",
  "dame el brief de UGC para [marca]", "shotlist / b-roll para el creador", "guion UGC para 45+ / para 25", "adáptalo por
  persona", "write a UGC script", "creator brief", "spoken UGC script", "shot direction for the creator", "UGC brief for
  [brand]", "b-roll shotlist". Trigger for any MLO brand (8hours, ZZEN, Moncho Moreno, Bala di Gala, Alma, Chic&Love,
  HobbitAlf, etc.). This skill directs REAL human creators — for AI-generated Seedance video prompts use
  seedance-20-ugc-ad-director; for a static/VSL script use framework-scriptwriter.
---
# UGC Director

## What it does
Turns a brand + angle + awareness stage into a **shootable, direct-response UGC package for a real human creator**:
1. a **spoken UGC script** written in native first-person creator voice (not a VO essay), tuned to a specific persona/demographic, and
2. a **creator brief with shot direction** — setting, wardrobe, delivery/tone, must-say / must-not-say, and a **b-roll shotlist** of filmable (not editable) moments — so the strategist can hand it straight to a creator (or a creator-coordinator) and get footage back that performs.

It writes for the **register of the buyer**: the 45+ ad and the 25 ad for the same product are *different scripts*, not the same script read differently.

## When to use (ES + EN trigger phrases)
- ES: "escríbeme un guion UGC", "brief para el creador/creadora", "guion hablado para UGC", "dame el brief de UGC de [marca]", "shotlist / b-roll para el creador", "adáptalo por persona / demografía", "guion UGC para 45+ / para gente joven", "qué le digo al creador", "direcciones de rodaje".
- EN: "write me a UGC script", "creator brief", "spoken UGC script", "shot direction for the creator", "b-roll shotlist", "UGC brief for [brand]", "adapt this per persona / demographic", "what do I tell the creator".
- Trigger for any MLO brand and for media buyers/strategists who need footage a creator can shoot this week.

## Relationship to the rest of the suite (align, don't fork)
- **seedance-20-ugc-ad-director** → produces AI-generated *synthetic* UGC via Seedance prompts + Pinterest character refs. **This skill is its human-creator twin**: same UGC discipline, but the output is a script + brief for a *real person* to film. Route AI-video asks there; route "hand this to a creator" asks here.
- **framework-scriptwriter** owns picking the 12-framework + Script→Brief for any format (static/VSL/UGC). Use it upstream to lock framework+angle; this skill takes a UGC angle and turns it into creator-ready direction. **edit-guide** owns the post-production edit. **research-engine / angle-generator** feed the persona + angle. **script-doctor** QAs the draft. **creator-coordinator** sources/contracts the creator this brief goes to.

## Inputs needed
Required: **brand/product**, **angle or concept** (from angle-generator / a winner), **awareness stage** (Unaware→Most-Aware), **target persona/demographic** (esp. 45+ vs 25).
Strongly recommended: brand brain / Categorized Insights (VoC), key persona language notes, product mechanism/USP, proof available (testimonial/demo/data), must-not-say (compliance), duration target (default <15s; up to 30–45s for education/unaware).
If a required input is missing, ask ONE tight question or state the assumption and proceed.

## Method (numbered — MLO system + expert frameworks)
1. **Trinidad first (message > format).** Lock the ONE message before writing a word. Confirm angle + awareness stage + market sophistication. Single-message discipline — one desire, one persona, one promise per ad (00-INDEX). Don't let "it's UGC" become an excuse for a grab-bag.
2. **Set the register by persona/demographic.** Decide the creator archetype and voice for THIS buyer:
   - **25 / younger:** faster pace, native slang, trend-aware, "I was today years old…", messy-real, jump-cuts assumed, phone-in-hand energy, lower proof threshold, higher pattern-interrupt.
   - **45+ / older:** slower, warmer, plain-spoken, credibility & reassurance early, real-life stakes (energy, sleep, joints, kids/grandkids, money), fewer trends, more "here's what finally worked for me," proof and specificity carry more weight. Bigger on-screen text, no jargon.
   Name the archetype (e.g. "busy mom 40s," "gym-bro 24," "skeptical dad 50") — casting is a strategic decision, not logistics (Denney: creator > script).
3. **Open in the first 3 seconds, spoken.** The hook is ~90% of the job (Sanchez). Write a *said-out-loud* opener the creator delivers to camera — problem-first, not brand-first (Hott: "Judge Second 0"). Match awareness (Theriot): Unaware → mindset/symptom, Problem-Aware → name the pain, Solution-Aware → the outcome, Product-Aware → superiority/proof, Most-Aware → offer. Pattern-interrupt must be **visual + verbal** in the first 3–5s (Meta needs visual distinctness to read a new variation — Sanchez hook-swap rule).
4. **Write the spoken body as a UGC arc, not a VO.** Beats: **hook → problem/relatable moment → mechanism (why it works) → proof (show, don't claim) → CTA with reason-to-act-now.** Keep it in the creator's mouth — contractions, "so basically," self-interruptions, one idea per breath. Native-first: it must look and sound *made on the platform* (Sanchez), lo-fi/ugly over polished (Hott; Motion: 42% of top-spend ads are lo-fi). Default <15s; extend to 30–45s only for unaware/education (delay product reveal). Every line earns the next second.
5. **Direct the shoot (this is what makes it UGC, not a voiceover).** Specify:
   - **Setting** — the real location(s) that read native (kitchen, car, bathroom mirror, gym, on a walk) and why it fits the persona.
   - **Wardrobe & look** — everyday, on-persona; explicitly no studio gloss, no heavy branding in frame (Hott sniff test).
   - **Delivery/tone** — pace, energy, eye contact, where to smile/pause/lower voice; the emotional progression (curiosity → identification → belief → release-via-CTA).
   - **Framing** — selfie/handheld, natural light, phone-quality; where to switch to product-in-hand.
6. **Write the b-roll shotlist — filmable, not editable.** 8–15 shots the creator must *capture on the day* (per MLO AI prompt [9]: "algo que se GRABA, no se edita"). One line each with the exact action + angle, mapped to the script beat it covers (hook, problem, mechanism, proof/demo, CTA). Cover every claim with a shot — a "absorbs in 10s" claim needs a shot that *demonstrates* it, not a text card.
7. **Add must-say / must-not-say + brief-then-get-out-of-the-way.** List required lines (offer, mechanism name, guarantee), forbidden lines (compliance/claims), and 3–5 dos/don'ts — then trust the creator to make it theirs (Sanchez). Keep hook variations attached so the creator can shoot 2–3 openers over the same body (hook-swap = cheapest test lever).
8. **Package + QA.** Output the script + brief in the exact shape below. Sanity-check against MLO's UGC pre-delivery gut-checks (hook engages first 3s, ~3s min between frames, hook→story→CTA, a human desire addressed, clear visual focus, "is this better than the inspiration?"). Offer next steps: 2–3 hook variants, a 45+/25 counterpart, or hand-off to script-doctor / edit-guide / creator-coordinator.

## Rules & standards (MLO non-negotiables)
- **Trinidad first, message > format.** One message, one persona, one promise per ad.
- **Spoken, native, lo-fi.** First-person creator voice; must look made-on-platform; strip polish. If it reads like a brand film or a VO essay, rewrite it.
- **Register matches the buyer.** 45+ and 25 are different scripts. Never ship a "generic" UGC script.
- **Problem-first, product-later.** Lead with the felt problem; delay the brand reveal (harder the colder the traffic).
- **Show, don't claim.** Every claim maps to a filmable b-roll shot. B-roll is captured, never "fixed in the edit."
- **Precision > filler.** Real customer language (VoC), specifics over adjectives, no corporate speak, nothing invented — if a fact is missing write "⏳ pendiente."
- **FFM-ready.** The hook is engineered for hook rate/hold rate; the CTA for CTR; success = hook rate → CTR → ROAS (FFM preset).
- **Creator > script.** Cast the archetype deliberately; brief richly, then let the creator perform.

## Output (exact shape + concrete example)
```
# UGC Creator Package — [Brand] · [Angle] · [Awareness stage]
Persona/Register: [archetype, age band] · Duration: [~Ns] · Format: native handheld UGC

## 1) SPOKEN SCRIPT (creator says this to camera)
HOOK (0-3s): "…"          [visual: what's on screen]
PROBLEM (3-Xs): "…"
MECHANISM: "…"
PROOF (show): "…"
CTA: "…"
[+ 2-3 alternate HOOK lines to shoot over the same body]

## 2) CREATOR BRIEF
- Casting/archetype: …
- Setting(s): …
- Wardrobe & look: …
- Delivery/tone: pace, energy, where to pause/smile/lower voice; emotional arc
- Framing: selfie/handheld, natural light, product-in-hand at [beat]
- MUST-SAY: [offer / mechanism name / guarantee]
- MUST-NOT-SAY: [compliance/forbidden claims]
- Dos & don'ts: 3-5 bullets

## 3) B-ROLL SHOTLIST (filmable — capture on the day)
1. [action + angle]  → covers: [beat]
… 8-15 shots, every claim covered …

## 4) NEXT STEPS
[45+/25 counterpart · hand to script-doctor / edit-guide / creator-coordinator]
```
**Concrete micro-example (ZZEN magnesium, 45+, Problem-Aware, ~20s):**
- HOOK (0-3s): *"If you're 50 and you're waking up at 3am every night — this is for you."* [visual: creator in dim bedroom, phone selfie, tired]
- PROBLEM: *"I blamed stress for years. Turns out most of us over 45 are just low on magnesium."*
- MECHANISM: *"This one has the glycinate form — the kind that actually absorbs and calms your nervous system, not the cheap oxide."*
- PROOF (show): *"Third night in, I slept through. I'm not exaggerating."* [b-roll: hand taking one capsule with water before bed]
- CTA: *"They're running a bundle this week — link's right here, try it before you write off sleep for good."*
- B-roll must-haves: capsule-in-hand close-up, bottle label macro, bedside glass of water, creator waking up rested by window light.

## Guardrails
- Never output a voiceover essay labeled "UGC" — if there's no creator on camera and no shot direction, it's the wrong skill.
- Don't invent claims, testimonials, or numbers; respect must-not-say/compliance; use VoC language only where it's real.
- Don't hand back one script for "everyone" — anchor to a named persona; offer the counterpart register on request.
- For AI-generated (synthetic creator) video → route to **seedance-20-ugc-ad-director**. For the post edit → **edit-guide**. For a static/VSL → **framework-scriptwriter**. For sourcing the actual creator/contract → **creator-coordinator**.

## References
Depth in `reference/knowledge-base.md`. Grounded in MLO's Sistema de Scripting:
`00-INDEX-Sistema-Scripting-MLO.md` (Trinidad, 3A, awareness, M6 formatos por awareness & demografía),
`02-Modulo-Libreria-Prompts-IA-MLO.md` (AI prompt library — [6] Script Bulletproof, [7] Banco de Hooks, [9] Shotlist B-Roll, [12] Key Persona). Reuses the MLO expert brain:
`experts-dtc-creative.md` (Savannah Sanchez native UGC + strict role separation + brief-then-step-back; Barry Hott ugly ads/sniff test; Nick Theriot awareness stages; Dara Denney creator>script) and
`iteration-playbooks.md` (UGC⇄high-production register choice, hook-swap variation).
