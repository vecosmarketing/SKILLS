# UGC Director — Knowledge Base

> Depth reference for the `ugc-director` skill. This skill directs **REAL human creators** — it turns a brand + angle + awareness stage into a **spoken UGC script** and a **creator brief with shot direction** the strategist can hand straight to a creator (or a creator-coordinator). For AI-generated synthetic UGC use `seedance-20-ugc-ad-director`; for a static/VSL script use `framework-scriptwriter`; for the post edit use `edit-guide`.
>
> Every external claim below is followed by its source; the MLO-system claims cite the module + prompt they come from. Full list under **## Sources**.

---

## 0. First principle — UGC is *spoken + shot*, not voiced-over

The line between "a UGC script" and "a VO essay" is the whole job. A UGC ad has a **creator on camera speaking in first person** and a **shot direction** that makes the footage native. If there's no creator and no shotlist, it's the wrong deliverable (skill guardrail). The register of the words, the casting of the person, and the moments they *film on the day* are what make it read as content instead of an ad.

Two doctrines run through everything:

1. **Message > format (Trinidad).** Lock the ONE message — one desire, one persona, one promise per ad — before writing a word (MLO `00-INDEX`, "el mensaje va primero"). "It's UGC" is never an excuse for a grab-bag of benefits.
2. **Creator > script.** "Your creator and the talent that you work with is more important candidly than the script" (Dara Denney). Casting the archetype is a *strategic* decision, not logistics ([Denney / Motion](https://motionapp.com/library/expert/dara-denney/)).

---

## 1. Native spoken-script principles

The script must **sound said-out-loud by a real person**, and it must **look made on the platform**.

- **The hook is ~90% of the job.** "The hook is the most important part of the ad in that first three seconds." Put nearly all the effort into the first 3s; the body is comparatively cheap to hold constant (Savannah Sanchez, [Motion](https://motionapp.com/library/expert/savannah-sanchez/)).
- **Native-first: it has to look like it belongs on the platform.** "TikTok ads have to look like they belong and are made on TikTok" — native transitions, fonts, greenscreen, the comment-question overlay, phone-quality framing. Not a repurposed brand film (Sanchez, [Tydo](https://tydo.com/blog/deepdive-savannah)).
- **Lo-fi / ugly beats polished.** If your marketing is too pretty, it probably won't work on paid social. 42% of top-spending ads are lo-fi, and 53% of advertisers plan to invest *more* in lo-fi vs hi-fi ([Motion Creative Trends](https://motionapp.com/creative-trends); Barry Hott, [Hott](https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)). Ugly ads have shown ~30% lift in action intent, and in one case ~3× click rate and 3–5× higher conversion vs polished ([Practical Ecommerce](https://www.practicalecommerce.com/ugly-ads-perform-best-marketer-says)).
- **Write it in the creator's mouth, not on a page.** Contractions, "so basically," self-interruptions, one idea per breath. Read it aloud — if a human wouldn't say it that way to a friend, rewrite it.
- **Problem-first, product-later.** Lead with the felt problem before any product or brand reveal; the colder the traffic the longer you delay the brand (Hott: "getting people to pay attention to the problem" before production; [Hott](https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)).
- **Length.** Default **under 15 seconds** with an explicit spoken/on-screen CTA — "TikTok ads that are under 15 seconds are performing best" (Sanchez, [Tydo](https://tydo.com/blog/deepdive-savannah)). Extend to **30–45s only for unaware/education** concepts, where the top ads now introduce the product at 40–50s ([Motion Creative Trends](https://motionapp.com/creative-trends)); every extra second must advance the buy decision.
- **Every claim earns a shot.** "Show, don't claim" — a claim like "absorbs in 10 seconds" needs a shot that *demonstrates* it, not a text card. B-roll is *captured*, never fixed in the edit (MLO prompt [9]: "algo que se GRABA, no se edita").

### The spoken UGC arc (beats)

`Hook → problem / relatable moment → mechanism (why it works) → proof (show, don't claim) → CTA with reason-to-act-now.`

This is the MLO Script Bulletproof body applied to a creator on camera: **dolor → agitar → solución → credibilidad → gradualización → CTA**, with the "3 wins" of Disruptive Entry (0–3s), emotional progression (curiosity → identification → belief), and release-via-CTA (MLO `02-Modulo`, prompt [6]).

---

## 2. Persona / demographic register — the 45+ vs 25 split

**The same product needs a different script for an unaware buyer vs a most-aware buyer, and for a 45+ buyer vs a 25 buyer.** Most brands over-index on the bottom-funnel discount ad and ship one "generic" script for everyone — the single biggest register mistake (Theriot's 5 stages + Denney's Persona dimension; [Theriot](https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk), [Denney](https://motionapp.com/library/expert/dara-denney/)). MLO makes this explicit in **M6 — Formatos por awareness & demografía** ("mensaje 45+ vs 25, pace, founder-ad adaptations").

**Casting is strategy.** Name the archetype — "busy mom 40s," "gym-bro 24," "skeptical dad 50" — because who says it matters more than the exact words (Denney: creator > script).

| Lever | **25 / younger** | **45+ / older** |
|---|---|---|
| **Pace** | Fast, jump-cuts assumed, phone-in-hand energy | Slower, warmer, room to breathe |
| **Voice** | Native slang, trend-aware, "I was today years old…", messy-real | Plain-spoken, "here's what finally worked for me," no jargon |
| **Trust build** | Lower proof threshold, higher pattern-interrupt | Credibility & reassurance *early*; proof and specificity carry more weight |
| **Stakes** | Identity, aesthetics, belonging, FOMO | Real-life stakes: energy, sleep, joints, kids/grandkids, money |
| **On-screen text** | Small, fast, native captions | Bigger on-screen text, no jargon |
| **CTA** | Trend-native, urgency light | Reassuring, risk-reversal, "try it before you write it off" |

Rules of thumb:
- **Never ship a "generic" UGC script.** Anchor every draft to one named persona; offer the counterpart register (45+/25) on request (skill rule).
- **Match the register to the buyer, not the product.** The 45+ ad and the 25 ad for the same magnesium are *different scripts*, not the same script read at a different speed.
- **Use real customer language (VoC).** Pull the persona's exact words, pains, objections and "golden nuggets" from the brand's Categorized Insights (MLO prompt [2] Research Doc / prompt [12] Key Persona). Specifics over adjectives; nothing invented — if a fact is missing, write "⏳ pendiente."

---

## 3. Awareness → opener (Theriot's ladder, spoken)

Match the *first line the creator says* to where the buyer is on the awareness ladder ([Theriot](https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk); MLO `05-Modulo-Unaware-Ads`):

| Stage | What the opener does | Spoken example (mindset) |
|---|---|---|
| **Unaware** (largest pool) | Appeal to a mindset/symptom; name no problem or product; runs longer | *"If you're 50 and you're waking up at 3am every night — this is for you."* |
| **Problem Aware** | Name the felt pain | *"I blamed stress for my sleep for years…"* |
| **Solution Aware** | Name the outcome / category, not the product | *"The laziest fix for waking up at 3am."* |
| **Product Aware** | Establish superiority / trust / proof | *"This is the only magnesium that actually absorbs."* |
| **Most Aware** | Offer / price / urgency ("lowest marketing IQ" — use sparingly) | *"They're running a bundle this week."* |

**Target by the bait, not the audience** — keep targeting broad and let the stage-specific creative self-select the buyer (Theriot). The pattern-interrupt in the first 3–5s must be **visual + verbal** so Meta reads it as a distinct variation (Sanchez hook-swap rule, below).

---

## 4. Creator brief anatomy

A brief is what turns a script into footage that performs. **Brief richly, then get out of the way** — give benefits, must-say / must-not-say, and dos/don'ts, "then let the creator do their thing" (Sanchez, [Tydo](https://tydo.com/blog/deepdive-savannah)). The brief has these parts:

1. **Casting / archetype** — the named persona who fronts it (age band, vibe, life-stage). Strategic, not logistics.
2. **Setting(s)** — the real location(s) that read native for *this* persona and why (kitchen, car, bathroom mirror, gym, on a walk). The setting is a trust signal, not a backdrop.
3. **Wardrobe & look** — everyday, on-persona; explicitly **no studio gloss, no heavy branding in frame** (Hott sniff test — heavy first-frame branding is a top red flag).
4. **Delivery / tone** — pace, energy, eye contact, where to smile / pause / lower voice; the emotional arc (curiosity → identification → belief → release-via-CTA). This is where the register (§2) is enforced.
5. **Framing** — selfie / handheld, natural light, phone-quality; where to switch to product-in-hand.
6. **MUST-SAY** — required lines: the offer, the mechanism name, the guarantee.
7. **MUST-NOT-SAY** — forbidden lines: compliance/claims the brand can't make (respect brand guardrails; never invent claims, testimonials or numbers).
8. **Dos & don'ts** — 3–5 tight bullets.
9. **Hook variations attached** — 2–3 alternate openers the creator shoots over the *same body*, so the cheapest test lever is captured on the day (see §6).

### Hott's "Sniff Test" — five over-polished red flags to brief *against*

Run any planned shoot through these before the creator films; each one present makes it read as "an ad" ([Hott](https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)):
1. Heavy branding in the first frame (logo / brand fonts / colors).
2. Obviously artificial lighting.
3. White / blank backgrounds.
4. Video quality clearly *not* shot on a phone.
5. Heavily scripted, stiff dialogue.

---

## 5. Shot direction & b-roll capture

Directing the shoot is *what makes it UGC and not a voiceover.* Two layers:

**A-roll (the creator to camera):** specify setting, wardrobe, delivery/tone and framing (§4). The a-roll carries the spoken arc; the b-roll covers the claims.

**B-roll shotlist — filmable, not editable.** 8–15 shots the creator must **capture on the day**, one line each with the exact action + camera angle, mapped to the script beat it covers (hook / problem / mechanism / proof-demo / CTA). Rules (MLO prompt [9]):
- Every shot is *something you record, not something you edit* ("algo que se GRABA, no se edita").
- **Cover every claim with a shot.** An "absorbs in 10s" claim needs a demo shot, not a text card. A "third night I slept through" proof line needs a waking-up-rested shot.
- Include the workhorse close-ups: product-in-hand, label macro, the mechanism in action, the before/after or in-use moment, the CTA beat.
- Give the angle, not just the subject: "macro on the label, slow tilt up" beats "the bottle."

Pacing note for the edit hand-off: ~3s minimum between frames, hook engages in the first 3s (Sanchez pre-delivery checklist). The actual edit is owned by `edit-guide`.

---

## 6. The frameworks that govern this skill

### Savannah Sanchez — native UGC, roles, hook-swap
- **Hook = ~90% of the ad.** Concentrate effort on the first 3s ([Motion](https://motionapp.com/library/expert/savannah-sanchez/)).
- **Native-first / made-on-platform** — build inside the platform's visual language ([Tydo](https://tydo.com/blog/deepdive-savannah)).
- **Strict role separation — Strategist → Creator → Editor.** Strategist owns research/scripts/QC; creator shoots raw footage only; editor finishes. Don't collapse the three ([Motion](https://motionapp.com/library/expert/savannah-sanchez/)). *This skill sits in the Strategist seat and produces what the Creator shoots.*
- **Hook-swap testing — hold the body, swap the opening.** "If you're just changing the text on top, Facebook doesn't really see it as a different variation." Change the first 3–5s' **visual**, not just the on-screen text, to register a new variation. This is why the brief attaches 2–3 alternate hook *openers* the creator films over the same body — the cheapest, highest-leverage test lever ([Motion](https://motionapp.com/library/expert/savannah-sanchez/)).
- **Weekly slate (30k–100k/mo): 2 inspirations × 2 written hooks × 2 opening visuals** — disciplined 2×2×2 hook coverage ([Motion](https://motionapp.com/library/expert/savannah-sanchez/)).
- **Pre-delivery checklist:** hook engages first 3s · pacing (~3s min between frames) · storyline (hook → story → CTA) · a human desire addressed · clear visual focus · "Take Pride" gut-check: *is this better than the inspiration?* ([Motion](https://motionapp.com/library/expert/savannah-sanchez/)).

### Barry Hott — ugly ads, sniff test, judge second 0
- **Make ugly ads** — strip polish (shaky camera, natural light, phone-shot, imperfect audio, delayed/minimal branding) so it reads as native content, not an ad ([Hott](https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)).
- **Sniff Test** — the five red flags in §4.
- **Problem-first, not production-first** — lead with the problem the viewer feels ([Hott](https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads)).
- **Judge Second 0 first** — if the first frame doesn't stop the *right* scroller, nothing downstream matters ([Building Ads with Barry](https://www.buildingadswithbarry.com/)).

### Nick Theriot — awareness stages, bait-targeting
- **5 Stages of Market Awareness** (Schwartz applied to Meta) — build a distinct ad per stage; cover the full ladder (§3).
- **Target by the bait, not the audience** — broad targeting; the creative self-selects the buyer ([Theriot](https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk)).
- **7-variable brief** — Desire, Feature, Benefit, Market Awareness, Market Sophistication, Hook Pattern, Persona — so a win/loss maps to one changed variable ([Theriot Inner Circle](https://udcourse.com/product/nick-theriot-inner-circle-april-2026/)).
- **Unaware ads run longer**; concentrate budget on higher-stage winners ([Theriot](https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk)).

### Dara Denney — creator > script, content-level data
- **Creator/talent > script** — casting is the highest-leverage lever ([Motion](https://motionapp.com/library/expert/dara-denney/)).
- **Content-Level Data — Format · Creator · Messaging · Imagery · Persona** — tag each ad on these 5 axes so you can reproduce *why* it won ([Motion](https://motionapp.com/library/expert/dara-denney/)).
- **Content analysis > metrics analysis** — read the content first; metrics confirm the story, they don't tell it ([Motion](https://motionapp.com/library/expert/dara-denney/)).

### Register choice & variation (iteration playbooks)
- **UGC vs high-production is chosen by funnel position**, not dogma: UGC beats polished on cold-prospecting CPA by ~22–38%; polished wins for premium/retargeting. Typical DTC mix is 60–80% UGC ([ROASPIG](https://roaspig.com/blog/ugc-vs-produced-content/)). When a winner needs the opposite register, keep the **angle + proof fixed** and only change the production register (MLO `iteration-playbooks.md`, UGC⇄high-production).

---

## 7. FFM & benchmarks (grade the output)

Success ladder: **hook rate → hold rate → CTR → ROAS** (MLO FFM preset). The hook is engineered for hook rate/hold rate; the CTA for CTR. Calibration defaults (benchmark against your own account's trailing average first — every expert insists on this):
- **Hook rate** (3-second plays ÷ impressions × 100): <20% weak · 25–35% good/scalable · 40%+ elite scroll-stopper ([Exposure](https://www.exposure.com.au/blog/what-is-a-good-hook-rate)).
- **Hold rate** (3–15s retention): target ~25%+ alongside a 30–40% hook rate; the cheapest fix for a weak hook is to swap the opening — same hook-swap lever ([Billo](https://billo.app/blog/hook-rate-to-hold-rate/)).

---

## 8. Pre-delivery gut-checks (MLO + Sanchez)

Before handing the package off, confirm:
- [ ] Hook engages in the first 3s; pattern-interrupt is **visual + verbal**.
- [ ] It's **spoken** (creator on camera) with real shot direction — not a VO essay.
- [ ] Register is anchored to **one named persona** (45+/25 chosen deliberately); nothing "generic."
- [ ] Structure is hook → story → CTA; a real human desire is addressed; clear visual focus.
- [ ] ~3s minimum between frames; default <15s (or 30–45s only for unaware/education).
- [ ] **Every claim is covered by a filmable b-roll shot**; b-roll is captured, never "fixed in the edit."
- [ ] MUST-SAY / MUST-NOT-SAY present; no invented claims/testimonials/numbers; VoC used only where real.
- [ ] 2–3 alternate hook openers attached (hook-swap test lever).
- [ ] "Take Pride" gut-check: is this better than the inspiration?
- [ ] Offer next steps: 45+/25 counterpart · hand to `script-doctor` · `edit-guide` · `creator-coordinator`.

---

## Sources

**MLO Sistema de Scripting (internal, cite by file):**
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad (message first), 5 awareness levels, Market Sophistication, 3A (Audience·Angle·Ad), FFM preset; **M6 · Formatos por awareness & demografía** (mensaje 45+ vs 25, pace, founder-ad adaptations, incremental reach).
- `02-Modulo-Libreria-Prompts-IA-MLO.md` — AI prompt library: [2] Research Doc / Categorized Insights (VoC), [6] Script Bulletproof (12 frameworks, 3 wins, dolor→agitar→solución→credibilidad→gradualización→CTA), [7] Banco de Hooks, [9] Shotlist B-Roll ("algo que se GRABA, no se edita"), [12] Key Persona.
- `05-Modulo-Unaware-Ads.md` — Unaware / awareness masterclass.
- `mlo-winner-strategist/reference/experts-dtc-creative.md` — the expert brain (Sanchez, Hott, Theriot, Denney, Motion) distilled + cited.
- `mlo-winner-strategist/reference/iteration-playbooks.md` — UGC⇄high-production register choice, hook-swap variation, 1-angle→N-hooks.

**External:**
- Savannah Sanchez — Motion Library expert page: https://motionapp.com/library/expert/savannah-sanchez/
- Tydo — How to Create Quality TikTok Ads with Savannah Sanchez: https://tydo.com/blog/deepdive-savannah
- Barry Hott — "Ugly ads don't mean bad ads": https://www.hottgrowth.com/post/ugly-ads-dont-mean-bad-ads-try-these-expert-tips-for-high-intent-ads
- Barry Hott — Building Ads with Barry: https://www.buildingadswithbarry.com/
- Practical Ecommerce — "Ugly Ads Perform Best" (Hott): https://www.practicalecommerce.com/ugly-ads-perform-best-marketer-says
- Nick Theriot — 5 Stages of Market Awareness (LinkedIn): https://www.linkedin.com/posts/nicktheriot_the-5-stages-of-market-awareness-has-made-activity-7070031864496877568-8AAk
- Nick Theriot Inner Circle — 7-variable brief / Hook Formula Matrix: https://udcourse.com/product/nick-theriot-inner-circle-april-2026/
- Dara Denney — Motion Library expert page: https://motionapp.com/library/expert/dara-denney/
- Motion — 2025 Ad Creative & Creative Strategy Trends (lo-fi 42%, product reveal at 40–50s): https://motionapp.com/creative-trends
- ROASPIG — UGC vs Produced Content (CPA deltas, budget splits): https://roaspig.com/blog/ugc-vs-produced-content/
- Exposure — What is a good hook rate (benchmark tiers): https://www.exposure.com.au/blog/what-is-a-good-hook-rate
- Billo — From Hook Rate to Hold Rate: https://billo.app/blog/hook-rate-to-hold-rate/
