---
name: edit-guide
description: >
  Editing guide for MLO Growth's performance video ads. Turns a script or raw-footage description into
  precise EDITOR INSTRUCTIONS + a retention-optimized edit plan: first-3s hook edits, pacing/cut rhythm,
  captions & subtitles for muted viewing, sound design, pattern interrupts, b-roll rhythm, text overlays,
  and per-format edit specs (UGC vs VSL vs static-motion). Grounded in MLO's Hooks module (4 aligned
  components, visual manda) and the FFM preset (hook rate, hold rate). ALWAYS use this skill (ES/EN) when
  the user says "guía de edición", "cómo edito este anuncio", "plan de edición", "instrucciones para el
  editor", "brief de edición", "edit plan", "editor instructions", "how do I edit this ad", "retention
  edit", "pacing/subtítulos/sound design del anuncio", "optimiza la retención de este vídeo", or hands over
  a script/raw footage for an MLO brand (8hours, ZZEN, Moncho, Bala di Gala, Chic&Love, etc.) and wants
  the editing worked out. Complements mlo-creative-strategy, mlo-ad-brief-builder, seedance-20-ugc-ad-director,
  nil-script-builder and mlo-winner-strategist (this one owns the EDIT layer, not the script or the strategy).
---
# Edit Guide — Retention-Optimized Editing for Performance Video Ads

## What it does
Takes a **script** and/or a **raw-footage description** and outputs (1) **editor instructions** — a shot-by-shot / beat-by-beat cut sheet — and (2) a **retention-optimized edit plan** targeting the FFM metrics (hook rate, hold rate). It owns the **EDIT layer** of MLO's system: how the ad is *cut, captioned, sound-designed and paced*, not what it says (that's the script/strategy skills). Every decision is anchored to MLO's Hooks module (the 4 aligned components + "el visual manda") and per-format specs for **UGC vs VSL vs static-motion**.

## When to use (ES + EN trigger phrases)
- **ES:** "guía de edición", "cómo edito este anuncio", "plan de edición", "instrucciones para el editor", "brief de edición", "optimiza la retención de este vídeo", "arréglame el pacing / los subtítulos / el sound design", "el hook no retiene, qué corto", "pásame el cut sheet".
- **EN:** "editing guide", "edit plan", "editor instructions", "how do I edit this ad", "retention edit", "fix the pacing/captions/sound design", "the hook isn't holding, what do I cut", "give me the cut sheet".
- **Implicit:** user hands a script or a raw-footage/rushes description for an MLO brand and wants the edit worked out; a winner needs re-editing; hook rate or hold rate is below benchmark and needs a diagnostic.

## Inputs needed
1. **The script** (or its beats) and/or a **raw-footage description** (what clips exist: talking head, b-roll, demo, screen recording, stock).
2. **Format** — UGC / VSL / static-motion (if unknown, infer from footage; default UGC for lo-fi creator clips).
3. **Awareness level + avatar** (from the Árbol de Cascada / 3A). Cold/unaware ⇒ hook opens on curiosity/problem, never product.
4. **Placement & duration** target (Reels/Feed/Stories; UGC default <15s, short VSL 2:00–2:30).
5. Optional: brand, language (ES/EN by brand), any existing **hook rate / hold rate** to diagnose.

## Method (numbered — MLO system + expert frameworks)
1. **Lock the format & the retention target.** UGC → sub-15s, native, 1 idea; short-form VSL → 2:00–2:30 following the 7-step VSL skeleton; static-motion → 6–15s looping motion on a static/product asset. Set the FFM targets you're editing toward: **hook rate ≥30% (elite ≥40%), hold rate ≥50%** — benchmark against the account's own trailing average first (Denney).
2. **Engineer the first 3s (the 80/20).** Build the hook from MLO's **4 aligned components — Spoken · Visual · Text · Audio** — all pointing at the same idea. **The visual manda** (eyes process 10–100× faster than ears; order = visual→audio→visual). Cut the *strongest* frame to frame 1, put the on-screen **text hook** up by 0–0.5s, land the spoken hook in the first 2–4s, and drop an audio cue (see §4). Prep **3–5 opening-visual variants** for the same body so Meta registers them as distinct variations (Sanchez: swap the *visual*, not just the text).
3. **Set the pacing / cut rhythm.** Minimum ~one visual change every **2–3s** in the body; **first 3s** should carry 2–3 micro-cuts or a motion beat so nothing sits still. Kill dead air, "ums", and lead-in ramps — start *in motion*. Use **J/L-cuts** (audio leads or trails the picture) to keep momentum. Pace scales with awareness: cold/unaware runs a touch longer and more educational; hot/most-aware cuts faster.
4. **Sound design + music.** Assume **85%+ watch on mute → the video must fully work silent**, but design audio for the ones who don't: a hook SFX/whoosh on the first cut, a music bed that starts on beat 1 (not a 2s intro), rising tension under the agitation, a "ding"/pop on each proof point, and a beat drop or silence-break at the CTA. Duck music under VO. One reinforcing sound per pattern interrupt — never a wall of SFX.
5. **Captions & subtitles for muted viewing (non-negotiable).** **Burned-in, word-by-word (karaoke) captions**, center-frame or upper-third, large, high-contrast, inside safe zones (avoid the bottom UI band on Reels/TikTok). Emphasize the load-bearing word per line (color/scale pop). Captions ≠ text overlays: captions transcribe speech; **text overlays** carry the hook line, claims, and the CTA as designed graphics.
6. **Pattern interrupts every 3–5s to protect hold rate.** Rotate the interrupt type so the brain never predicts the next frame: zoom punch-in, hard cut to b-roll, angle change, text-overlay slam, meme-cut/greenscreen, a sound break, a speed ramp, or a "before" state slammed on screen. Each interrupt resets attention right where drop-off happens.
7. **B-roll rhythm.** Cut b-roll to *show the words* — when the VO says the pain, show the pain; when it says the result, show the result (visual↔spoken alignment = comprehension). Insert demo/b-roll at every claim as proof; don't let a talking head run more than ~5s without a cutaway. Reserve **explosion/high-energy clips for *after* the hook**, not on frame 1.
8. **Text overlays.** Hook line big and instant (0–0.5s); one idea per overlay; animate in (no static blocks); keep the CTA overlay on-screen through the last 2–3s. Overlays reconfirm what's said — never contradict the VO (misalignment = confusion = scroll).
9. **Assemble to the format skeleton** (see §Output and knowledge-base): UGC = hook→story→CTA sub-15s; VSL = hook→problem→agitate→mechanism→proof→offer→CTA across 2:00–2:30; static-motion = looping motion accent on a static key visual.
10. **Diagnose from metrics, rebuild the broken segment only.** Weak **hook rate** ⇒ rebuild the first 3s (§2) — swap opening *visual*, tighten the first cut, fix caption timing. Strong hook rate but weak **hold rate** ⇒ fix seconds 3–15: add pattern interrupts (§6), lift the pace (§3), cut filler. Good watch-through but no sales ⇒ that's script/offer, hand back to the strategy skills. Ship as **variations in separate ad sets** (Andromeda), never multiple hooks in one ad set.

## Rules & standards (MLO non-negotiables)
- **Trinidad-first / message > format:** the edit serves the message; a slick cut never rescues a wrong message. Fix the script upstream, don't polish over it.
- **El visual manda:** the visual hook outweighs text and VO — invest edit effort there first.
- **4 components aligned** in the hook (spoken·visual·text·audio); misalignment kills comprehension.
- **Muted-first:** if it doesn't work on mute, it doesn't ship. Captions burned in, always.
- **Native/lo-fi over polished** (Hott's "ugly ads", Sanchez native-first, Motion: 42% of top-spend ads are lo-fi): don't over-grade, don't front-load branding, keep it feeling like content.
- **FFM measures everything:** hook rate + hold rate are the edit's report card; benchmark against the account, not the industry.
- **Precisión > relleno:** cut every second that isn't earning attention. One idea per UGC ad.
- **Variations go in separate ad sets** (Andromeda), not stacked in one.

## Output (exact shape + a concrete example)
Deliver two blocks:

**A) EDIT PLAN (summary)** — Format · Duration target · FFM targets (hook/hold) · the retention thesis in 1–2 lines · list of the 3–5 opening-visual variants.

**B) EDITOR CUT SHEET (beat-by-beat table):**

| Time | Video / Cut | Spoken (VO) | Text overlay / Caption | Sound design | Pattern interrupt |
|---|---|---|---|---|---|

Concrete micro-example (UGC, cold, sub-15s, ZZEN magnesium):
| Time | Video / Cut | VO | Text overlay | Sound | Interrupt |
|---|---|---|---|---|---|
| 0:00–0:03 | Creator mid-action holding sachet, punch-in on frame 1 | "Llevo 3 años durmiendo fatal y no era el café." | **"No era el café ☕️❌"** (slam, upper-third) | whoosh on cut + beat 1 of bed | zoom punch-in |
| 0:03–0:07 | Hard cut to b-roll: tossing in bed, then sachet in water | "Era mi magnesio — o mejor dicho, que no tenía." | karaoke caption, key word "magnesio" pops | tension bed rises | hard cut to b-roll |
| 0:07–0:12 | Demo: stirs, drinks; cut to calm morning | "Un sobre antes de dormir y caigo en 10 min." | "10 min 😴" | soft ding on "10 min" | speed ramp |
| 0:12–0:15 | Creator to camera, product held, CTA overlay holds | "Pruébalo esta semana, link abajo." | **CTA overlay** on-screen through end | beat drop | text-slam CTA |

## Guardrails
- Don't rewrite the script or invent the strategy — request them or hand back to the script/strategy skills; this skill edits, it doesn't ideate the angle.
- Never contradict VO with the overlay/visual (comprehension breaks).
- Don't stack multiple hooks in one ad set; produce distinct opening-*visual* variants for separate ad sets.
- No over-polish, no first-frame logo dump, no 2s music intro before the hook.
- If no hook rate / hold rate is given, edit to the benchmarks and flag that measurement is needed; don't claim a diagnosis without data.

## References
Full detail in `reference/knowledge-base.md`. Grounded in MLO Playbook **M4 · Hooks** (`04-Modulo-Hooks.md`: 4 components, visual manda, 6 hook formats, pattern interrupts, gut-check) and **00-INDEX** (Trinidad, 3A, Andromeda, FFM). Reuses `mlo-winner-strategist/reference/experts-dtc-creative.md` (hook/hold benchmarks, Sanchez hook-swap, Hott ugly ads, Denney/Motion) and `experts-offers-hooks.md` (hook rate/hold rate formulas, short-form VSL 7-step skeleton, pattern-interrupt archetypes, Zeigarnik/open loops).
