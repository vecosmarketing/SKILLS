# Edit Guide — Knowledge Base

Distilled edit-layer knowledge for the `edit-guide` skill: how to **cut, caption, sound-design and pace** an MLO performance video ad so it wins hook rate and hold rate. Strategy and script live upstream (mlo-creative-strategy / framework-scriptwriter / research-engine); this file owns the EDIT.

---

## 1. MLO grounding — the Hooks module (M4) applied to the edit

From `/Users/mlo/Documents/MLO/Playbook-Scripting-MLO/04-Modulo-Hooks.md`:

- **The hook is the 80/20.** If the first 1–5s doesn't stop the scroll, nothing downstream is seen. The edit's #1 job is the first 3s.
- **4 aligned components the viewer receives at once:** **Spoken** (VO), **Visual** (what's shown), **Text** (overlay), **Audio** (sound/music/SFX). "500 vs 500,000 views = maximum alignment of the 4." If they contradict, comprehension breaks → scroll. Editing = making all 4 land on the *same* idea in the same instant.
- **The brain consumes video `visual → audio → visual`** (eyes 10–100× faster than ears; they see, then hear, then look back to confirm). ⇒ **the visual manda.** Changing the *visual hook* moves performance more than changing text or VO. So the edit lever with the highest leverage is **which frame you cut to frame 1** and the **3–5 opening-visual variants** you test.
- **6 hook formats** (Fortune Teller, Experimenter, Teacher, Magician, Investigator, Contrarian) — the **Magician** is a visual/verbal *stun* + a *visual pacifier* (background action that retains); it layers under any of the other 5. Editorially: the Magician is a fast match-cut / "check this out" stun on frame 1 with motion continuing underneath.
- **Curiosity = contrast** (viewer believes A → you show B). The edit should *stage* the contrast visually (show A, hard-cut to B).
- **Write-a-hook process (edit-relevant):** start from the **key visual**; pick the format that gives most contrast with it; VO = `context-lean → contrast → snapback to visual`; add a text hook that reconfirms; **gut-check comprehension in `visual → speech → visual`** — if it's not instantly clear, throw the hook/edit out and redo.
- **Common edit-killing errors:** spoken/visual/text misaligned; starting on the product in a cold hook; optimizing hook text while ignoring the visual; putting hook variants in the *same* ad set (that's not a test — see Andromeda).

From `00-INDEX-Sistema-Scripting-MLO.md`: **Trinidad (message first) → message > format**; avatar/angle from the **Árbol de Cascada + 3A (Audience·Angle·Ad)**; the **framework is the vehicle**; **FFM** measures everything (hook rate, hold rate, CTR, ROAS); **Andromeda** = naming + account structure ⇒ variations live in **separate ad sets**. *Precisión > relleno.*

---

## 2. FFM metrics — the edit's report card (reused: experts-offers-hooks.md + experts-dtc-creative.md)

**Formulas (Meta):**
- `Hook Rate = 3-second video plays ÷ Impressions` (×100)
- `Hold Rate = ThruPlays ÷ 3-second video plays` (×100) — share of scroll-stoppers who reach ~15s.

**Benchmarks (calibration — benchmark against the account's own trailing average first, per Denney):**

| Metric | Table stakes | Good | Elite |
|---|---|---|---|
| Hook rate | ~20–25% | >30% | >40% |
| Hold rate | ~40–50% | >50% | — |

Below ~20% hook rate Meta treats the creative as low quality and raises CPMs; 35%+ earns cheaper distribution. **Fix hook rate before hold rate.**

**Diagnostic map (which second to re-edit):**
- Weak **hook rate** → the first 3s: swap the opening *visual* (not just text), tighten the first cut, fix caption on-time, remove any intro ramp.
- Strong hook, weak **hold rate** → seconds 3–15: add pattern interrupts, lift pace, cut filler, tighten b-roll to the words.
- Good watch-through, no sales → mechanism/proof/offer = script/strategy layer, hand back upstream.

---

## 3. The first 3s edit (hook engineering)

- **Frame 1 = the strongest visual.** Start *in motion*; never on a logo, a blank/white background, or a static talking head lead-in (Hott's "sniff test" red flags: first-frame branding, artificial lighting, blank backgrounds, obviously-not-phone quality, over-scripted delivery).
- **Text hook up by 0–0.5s**, big, center/upper-third, animated in.
- **Spoken hook lands in 0–4s**; cut out "um", throat-clears, and any "hey guys" wind-up.
- **2–3 micro-cuts or a motion beat inside the first 3s** so nothing sits still.
- **Audio hook on the first cut** (whoosh/SFX) + music bed on beat 1.
- **3–5 opening-VISUAL variants** for the same body → separate ad sets. (Sanchez: "if you're just changing the text on top, Facebook doesn't see it as a different variation" — Meta needs *visual* distinctness in the first 3–5s.)
- Reserve **explosion/high-energy clips for *after* the hook** (M4), not frame 1.

---

## 4. Pacing / cut rhythm

- **Body: a visual change every ~2–3s** minimum (Sanchez pre-delivery checklist: ~3s minimum between frames). First 3s denser.
- **J-cuts / L-cuts** (audio leads or trails picture) to keep momentum across cuts.
- **No dead air, no ramps** — trim to the first spoken syllable.
- **Pace by awareness** (Theriot / Schwartz logic): cold/unaware = a touch longer, more educational, can walk the ladder in one ad; hot/most-aware = faster, tighter, straight to offer.
- **Lo-fi/native pace** beats over-produced (Motion: 42% of top-spend ads lo-fi, 53% investing more in lo-fi; Hott "ugly ads" ~30% lift in action intent, up to 3× click rate). Don't over-grade; keep it feeling like content, not a brand film.

---

## 5. Captions & subtitles (muted viewing)

- **~85%+ watch on mute → the video must work fully silent.** Non-negotiable: **burned-in captions.**
- **Word-by-word / karaoke style**, large, high-contrast (white + stroke/shadow or a bar), center or upper-third.
- **Safe zones:** keep captions and key overlays out of the bottom UI band (Reels/TikTok chrome) and platform-safe margins.
- **Emphasize the load-bearing word** per line (color/scale pop) — draws the eye to the point.
- **Captions ≠ text overlays.** Captions transcribe speech; overlays are designed graphics for the hook line, claims, and CTA.
- Language by brand (ES/EN); match the VO exactly — a caption that lags or paraphrases breaks comprehension.

---

## 6. Sound design + music

- Design for both mute and sound-on. **Mute-first**, but reward sound-on:
  - **Hook SFX** (whoosh/impact) on the first cut.
  - **Music bed starts on beat 1** — no 2s musical intro before the hook.
  - **Rising tension** under problem/agitation; **resolve** on the mechanism reveal.
  - **Ding/pop on each proof point** (review count, before/after, stat).
  - **Beat drop or a beat of silence at the CTA** to make it land.
  - **Duck music under VO** so speech stays intelligible; VO always on top.
- **One reinforcing sound per pattern interrupt** — not a wall of SFX (that reads as "ad").

---

## 7. Pattern interrupts (protect hold rate)

Insert an interrupt **every 3–5s**, rotating type so the next frame is never predictable (Zeigarnik/open-loop attention resets right where drop-off happens):

- Zoom / punch-in
- Hard cut to b-roll
- Camera-angle change
- Text-overlay slam
- Meme-cut / greenscreen / native platform element (Sanchez native-first)
- Sound break (drop the bed for a beat)
- Speed ramp
- "Before" state slammed on screen
- Visual pacifier under a Magician stun (background action that retains)

---

## 8. B-roll rhythm

- **Cut b-roll to the words:** VO says the pain → show the pain; VO says the result → show the result. Visual↔spoken alignment = comprehension (M4).
- **Proof-on-claim:** every claim gets a demo/b-roll/screenshot as visual proof (raises perceived likelihood — Hormozi value equation).
- **No talking head longer than ~5s without a cutaway.**
- Explosion/high-energy b-roll **after** the hook, not on it.

---

## 9. Text overlays

- Hook line **big and instant** (0–0.5s), animated in, one idea per overlay.
- **Reconfirm, never contradict** the VO/visual (misalignment = confusion = scroll).
- **CTA overlay holds through the last 2–3s.**
- Don't front-load a logo; delayed/minimal branding (Hott).

---

## 10. Per-format edit specs

### UGC (default lo-fi creator content)
- **Duration:** <15s (Sanchez: sub-15s TikTok/Reels perform best). One idea per ad (Trinidad).
- **Structure:** Hook (first 3s, creator mid-action) → Story/demo → CTA.
- **Look:** native, phone-shot, minimal grade, native transitions/fonts/greenscreen; captions karaoke; CTA spoken + overlay.
- **Roles (Sanchez):** strategist owns script/QC, creator shoots raw only, editor finishes — don't collapse them. Brief the creator richly, then get out of the way.
- **Test slate:** 2 inspirations × 2 written hooks × 2 opening visuals per week (Sanchez 2×2×2) → ad sets per Andromeda.

### Short-form VSL (2:00–2:30)
7-step skeleton (experts-offers-hooks.md), each beat = an edit job. Hook carries **~80%** of VSL performance.
- **0:00–0:05 Hook / pattern interrupt** — stop the scroll or the CVR never recovers.
- **0:05–0:30 Problem + Agitate** (PAS) — rising-tension sound, b-roll of the pain.
- **0:30–1:00 Unique Mechanism** — the named reframe; slow down, let it land; motion-graphic the mechanism.
- **1:00–1:40 Proof stack** — testimonials, before/after, data, reviews; ding on each; multi-angle (2–3 testimonials is not enough).
- **1:40–2:05 Offer / value stack** — on-screen stack graphic, risk-reversal.
- **2:05–2:15+ CTA** — specific next step, overlay holds, beat drop.
- **Pacing:** still cut ≥ every 2–3s; education-first for cold (Motion: top ads introduce product at 40–50s).

### Static-motion (motion on a static/product asset)
- **Duration:** 6–15s, seamless **loop**.
- **Job:** add a motion accent (subtle zoom/parallax, animated text reveal, kinetic type, one product-in-motion beat) to a strong static **key visual** so it earns a video slot and a hook rate.
- **Rules:** the key visual still carries the hook; big kinetic hook text on frame 1; one clear focal point; caption/claim reveals timed to a beat; still needs a CTA. Keep it clean — this format lives or dies on the strength of the static asset.

---

## 11. Editor cut-sheet template (the deliverable)

| Time | Video / Cut | Spoken (VO) | Text overlay / Caption | Sound design | Pattern interrupt |
|---|---|---|---|---|---|
| 0:00–0:03 | frame-1 key visual + punch-in | hook line | **hook overlay** (slam) | whoosh + bed beat 1 | zoom in |
| … | b-roll to the words | body | karaoke caption, key word pops | ding on proof | hard cut |
| end | CTA shot | CTA line | **CTA overlay holds** | beat drop | text slam |

Ship as **variations in separate ad sets** (Andromeda) with **3–5 opening-visual variants** for the same body. Grade against the account's own hook/hold trailing average, not the industry table.

---

## Sources

**MLO Playbook (source of truth):**
- `04-Modulo-Hooks.md` — 4 aligned components, visual manda, `visual→audio→visual`, 6 hook formats, curiosity=contrast, Magician + visual pacifier, write-a-hook process + comprehension gut-check, common errors.
- `00-INDEX-Sistema-Scripting-MLO.md` — Trinidad (message>format), 3A, Árbol de Cascada, Andromeda (variations in separate ad sets), FFM (hook/hold/CTR/ROAS), precisión>relleno.

**Reused MLO expert brain:**
- `mlo-winner-strategist/reference/experts-dtc-creative.md` — Sanchez (hook ~90%, hold-body-swap-hook, native-first, sub-15s, 2×2×2, strategist/creator/editor split, pre-delivery checklist ~3s between frames); Hott (ugly ads, sniff test, Second 0, ~30% lift / 3× click); Denney/Motion (benchmark against yourself; angle>execution; lo-fi 42%; product reveal at 40–50s); hook/hold benchmark tiers.
- `mlo-winner-strategist/reference/experts-offers-hooks.md` — hook rate / hold rate formulas + benchmarks + "fix hook before hold"; short-form VSL 7-step skeleton (hook=80%); pattern-interrupt hook archetypes; Zeigarnik/open loops; unique mechanism; Hormozi value equation (proof raises perceived likelihood).

External URLs are cited inline within those two reference files (Motion, Billo, Vaizle, Sovran, Exposure, Thrivethemes, etc.); no new web research was required for this skill.
