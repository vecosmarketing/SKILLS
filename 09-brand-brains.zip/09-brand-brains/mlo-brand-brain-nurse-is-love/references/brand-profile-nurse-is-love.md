# Brand Profile — Nurse is Love

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos o pendientes.

## Identidad
- **Marca:** Nurse is Love (NIL). Categoría: **productos y accesorios para enfermería** (*by & for nurses*).
- **Idea central:** no vende accesorios → vende **pequeñas mejoras en el día a día de una enfermera** (turno más cómodo, organizado y humano).
- **Misión:** hacer cada turno más cómodo, organizado y personal. **Visión:** ser la marca referente **en Europa** de accesorios para enfermería, creando comunidad.
- **Catálogo:** zuecos, medias de compresión, bolsos, neveritas, organizadores, lanyards, tijeras médicas, salvabolsillos, agendas, ropa laboral, accesorios de turno. Diseño: colores vivos, ilustraciones, funcional pero con personalidad.
- **Mercado / moneda:** España (core) / **EUR**. Expansión Europa en visión. Idioma client-facing: ES.
- **Cliente (lado marca):** **Carla** (comparte el Calendario oficial 2026 — fuente de verdad de promos/campañas/lanzamientos). _(Confirmar más contactos.)_
- **Responsables MLO:** _(confirmar media buyer / estratega creativo / diseño — no inventar roles)._

## Accesos por conector

### Meta Ads
- **Cuenta "Nurse is love 01" `797602994895930` (EUR).** Naming `CBO_ES_*` / `ABO_*`. Vía **Windsor.ai** (`facebook`) o **Claude in Chrome**.
- Campos revenue/compras en Windsor: `action_values_omni_purchase` (ventas) y `actions_purchase` (compras).

### Google Ads
- **Cuenta `819-391-4315`.** Campañas: **Brand ES**, **PMax All Products**, **Shopping (Max Value)**. Vía Windsor (`google_ads`). **Aísla Brand** (infla el ROAS de caja) para ver adquisición real.

### Shopify
- Store **`nurseislove`** (confirmar dominio exacto). Canal DTC principal. Si el conector Shopify está caído, vía Claude in Chrome (ShopifyQL por URL).

### GA4
- Propiedad **`423968420`** ("Nurse is Love").

### Triple Whale
- _(Confirmar si está activo.)_ Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- _(Canal del cliente/equipo: descúbrelo en runtime.)_

### Notion (TEAM HUB)
- **Portal de Cliente:** https://app.notion.com/p/30f6c9977eb780bea5def0aa538c5484
- **Brand DNA:** https://app.notion.com/p/30f6c9977eb78107b912d3026d431908 (misión/visión, tono, territorios y guardrails creativos, insights)
- **Ficha Cliente:** https://app.notion.com/p/30f6c9977eb781e0a21ae3c484deb319
- **Research:** https://app.notion.com/p/30f6c9977eb781dc93e3f100f8c628db
- **Calendario 2026 del cliente (Carla):** en la Navegación del portal — **consulta obligatoria antes de programar emails/promos**.
- Dentro del portal: Client Task Board, KPI Panel, Ad Copy Bank (en montaje, calcado a Bridge/8HOURS), reportes. Localízalos en runtime.

### Fireflies
- Calls con el cliente (Carla) _(confirmar cadencia)_.

## Voz de marca y guardrails creativos
- **Regla de oro:** suena como **una compañera de turno**. Cercano, cálido, positivo, empático, ligeramente divertido. Nunca técnico, clínico ni corporativo.
- **Ejemplos de tono:** "Para sobrevivir el turno con estilo" · "By and for nurses" · "Porque los bolsillos no dan para todo" · "Tu turno, pero mejor" · "Un poco de orden en el caos".
- **Territorios creativos:** comodidad · organización · identidad enfermera · orgullo de profesión · pequeñas alegrías dentro del hospital.
- **🚫 Evitar:** lenguaje médico excesivo, tono corporativo, estética hospitalaria fría, mensajes negativos sobre el trabajo sanitario.
- **✅ Mantener:** empatía, orgullo profesional, cercanía, comunidad, optimismo.
- **Insights de compra:** (1) el confort importa muchísimo (muchas horas de pie); (2) necesitan organización constante; (3) también quieren algo bonito (color/personalidad en material que suele ser frío).

## Cómo medir Nurse is Love
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Blended **Meta + Google**, reconciliado con Shopify + P&L. Aísla la Brand de Google.
- Marca de **accesorios** → ticket/margen ajustados: el **breakeven ROAS manda**. Vigila el impacto de descuentos/Summer Sale sobre el margen.
- Moneda: **EUR**.

## Benchmarks / cortes (del KPI Panel — confirmar)
- **Breakeven ROAS:** _(pendiente — clave en esta marca por el margen de accesorios)_
- **Target ROAS / Target CPA / margen de contribución / AOV / COGS / CAC:** _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS blended en ventana **< breakeven** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo/producto con **> 60–70%** del spend/alcance → 🟡 falta diversidad
- Creativo con tono clínico/corporativo → 🟡 (se pierde la voz de marca)

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta/Google (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.
- No programar promos/emails sin cruzar el Calendario 2026 del cliente (Carla).

## Snapshot inicial — Julio 2026
- **Meta** (`797602994895930`, EUR): gasto ≈ **€10.203** · ventas ≈ **€25.292** · **ROAS 2,48x** · 740 compras. Estructura: prospecting por línea de producto (Zuecos + Medias / Bolsos y Neveritas / Otros Productos), Summer Sale (ABO) y CostCap MIX. Productos con tracción: zuecos, medias de compresión, bolsos y neveritas.
- **Google** (`819-391-4315`, EUR): gasto ≈ **€3.811** · ventas ≈ **€17.277**. Brand 8,1x · PMax All Products 5,8x · Shopping 3,0x. **Sin marca ≈ 3,9x** (€3.263 → €12.820).
- Lectura: Meta a 2,48x (ojo al breakeven de accesorios); Google eficiente y con margen para escalar PMax/Shopping de adquisición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- 2026-08-23 — Brand Brain de Nurse is Love creado (perfil + playbooks) — para reportes/análisis con contexto — base inicial.

## Estado / notas (actualizar)
- Verano con Summer Sale activa. Foco: cerrar KPI Panel/benchmarks (breakeven), escalar Google de adquisición, montar Ad Copy Bank y consolidar líneas de producto ganadoras (zuecos/medias/bolsos). Última actualización: 2026-08-23.
