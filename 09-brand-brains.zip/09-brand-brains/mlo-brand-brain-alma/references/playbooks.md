# Playbooks — Brand Brain ALMA

Lee `brand-profile-alma.md` primero para los IDs. Estos son guías; cruza fuentes y usa criterio. "Saca de X" = localiza el conector de X y consúltalo en vivo; no inventes números. ALMA es cuenta **temprana**: prioriza fundamentos (medición, oferta, CRO) antes que escala. Meta tiene MCP habilitado → consulta directa.

## Routing

| Si preguntan…                                                        | Playbook |
| -------------------------------------------------------------------- | -------- |
| "cómo va ALMA", "reporte", "estado de la cuenta"                    | Reporte semanal |
| "por qué caen / suben las ventas", "qué está pasando"               | Diagnóstico de ventas |
| "cuántos creativos esta semana", "cuello de botella", "flujo creativo"| Flujo creativo & cuello de botella |
| "qué ha dicho el cliente / David", "qué pidió en Slack", "pendientes"| Pulso del cliente |
| "CRO", "PDP", "landing", "imágenes de producto"                     | CRO (skill cro-expert) + Diagnóstico de ventas |
| "pásale un update al equipo", "directriz semanal"                   | Mensaje/directriz al equipo |
| "hazme un dashboard / gráfica / vista de anuncios de ALMA"          | Dashboard / vista (ver "Qué puedes producir" en SKILL.md) |
| "¿hay algo que vigilar?", "alertas", "semáforos"                    | Alertas / semáforos |
| "anota esto", "qué cambió esta semana", "changelog"                 | Memoria / changelog semanal |
| "reporte para el cliente", "versión para cliente"                   | Modo cliente vs interno |
| "monta el reporte automático", "que corra cada lunes"               | Cadencia automática (ver SKILL.md) |

---

## Reporte semanal

Objetivo: foto clara de la semana en una lectura, conciliando cuenta con negocio.

1. **Shopify** — ventas, pedidos, AOV de la ventana (vs. periodo anterior). La verdad del negocio. Mira **conversión/PDP** (cuenta joven).
2. **Meta Ads (MCP directo)** — gasto, ROAS de plataforma (en ventana), CPA, frecuencia, top creativos.
3. **Triple Whale** (si aplica) — MER/blended y atribución first-party.
4. **Notion (Client Task Board / CRO Tracker)** — creativos subidos/lanzados y mejoras de CRO en marcha.
5. **Slack + Fireflies** — qué ha pedido o comentado el cliente (David), acuerdos de la última call, bloqueos.
6. **Sintetiza:** (a) Cómo vamos (tendencia blended + negocio + conversión), (b) Qué funciona, (c) Cuello de botella / riesgo (CRO incluido), (d) Próximas acciones con owner. Cierra con el "por qué importa".

> Regla: lee la **tendencia en ventana (7/14 días)**, nunca un día suelto. Reconcilia Meta con Shopify.

---

## Diagnóstico de ventas ("¿por qué caen/suben?")

1. Confirma en **Shopify** la caída/subida real (ventana, no día) y en qué (producto, AOV, nº pedidos, **conversión**).
2. Descarta por capas:
   - **Medición/atribución:** ¿real o solo peor en Meta por ventanas estrictas? Cruza con Triple Whale/Shopify.
   - **CRO/web:** ¿cae la conversión? Revisa PDP, imágenes, oferta — en cuenta joven suele ser aquí.
   - **Margen:** descuentos/promos que comprimen el margen.
   - **Caja/operativa:** stock, envíos, checkout.
   - **Cuenta/creativo:** fatiga, falta de diversidad, CPM/frecuencia, cambios recientes.
3. Conclusión: causa más probable + evidencia + acción concreta.

---

## Flujo creativo & cuello de botella

1. **Notion — Client Task Board / Listicle & CRO Tracker** de ALMA: piezas briefeadas, en edición, listas, subidas/lanzadas.
2. **Figma/Drive** — estado de los assets aprobados.
3. **Fireflies/Slack** — qué se acordó producir y feedback del cliente (David).
4. Identifica el **cuello de botella** real y quién lo desbloquea (responsable por asignar — flaggéalo).
5. Reporta: nº de creativos por estado, ritmo, dónde se atasca, acción.

---

## Pulso del cliente

1. **Slack** (canal de ALMA, si existe) — qué ha pedido/comentado el cliente, mensajes sin responder, urgencias.
2. **Fireflies** — última call y el audit de CRO: acuerdos, pendientes (PDP, imágenes de producto).
3. Devuelve: "esto es lo que el cliente espera / le preocupa ahora mismo" + pendientes + tono. Conecta con el estado real de la cuenta.

---

## Mensaje/directriz al equipo

Objetivo: convertir el análisis en una directriz clara para el equipo, lista para Slack.

1. Parte del reporte y del pulso del cliente.
2. Mensaje corto, en voz de equipo:
   - **Update:** 2-4 bullets (números clave en ventana + creativos + CRO).
   - **A vigilar:** 1-3 riesgos (conversión/PDP, fatiga, frecuencia, margen, responsable sin asignar).
   - **Ángulos / próximos pasos:** conceptos a trabajar y quién.
3. Tono directo y accionable. Cada punto, con su "por qué" o su owner.
4. **Muéstraselo a Marcel antes de enviarlo.** Solo se manda a Slack tras su OK.

> Molde: "Equipo, update ALMA de la semana: [X]. A vigilar: [Y]. Ángulos/CRO que podríamos trabajar: [Z]. Owners: […]."

---

## Alertas / semáforos

1. Lee el **Panel de KPIs (Meta Ads)** (breakeven/target ROAS, target CPA, margen) — sin esto no hay umbral real.
2. Saca de **Meta (MCP)** (ventana 7d) ROAS, CPA, frecuencia, reparto por creativo; de **Shopify** ventas y **conversión**.
3. Evalúa y asigna color:
   - ROAS en ventana < breakeven varios días → 🔴
   - Frecuencia > ~2.5–3 (7d) → 🟡
   - CPA > target sostenido → 🟡/🔴
   - Caída de ventas > X% en ventana → diagnóstico
   - Un creativo con >~60–70% del alcance → 🟡
   - Conversión web/PDP por debajo de lo esperado → 🟡 (CRO)
4. Para cada bandera: **causa probable + acción + owner**. Si todo en verde, dilo en una línea.

---

## Memoria / changelog semanal

1. Antes de un reporte, lee el **Changelog** del brand profile: qué se cambió/lanzó (incl. CRO/PDP) y qué se esperaba.
2. Compara "esta semana vs. la pasada".
3. Al cerrar un análisis con cambios relevantes, **ofrece anotar la entrada**: fecha + qué cambió + por qué + resultado.
4. Corto y factual.

---

## Modo cliente vs interno

1. Identifica el destinatario: equipo MLO (interno) o cliente/David (cliente). Si no está claro, pregunta.
2. **Interno:** directo, números crudos, jerga de casa, riesgos sin filtro, owners.
3. **Cliente:** narrativa de negocio y "por qué importa", tono calmado y seguro, sin vanity ni alarmismo. Menos siglas.
4. Mismos hechos, distinto envoltorio — nunca números distintos entre versiones.
5. Si va al cliente: enséñaselo a Marcel antes y envía tras su OK.
