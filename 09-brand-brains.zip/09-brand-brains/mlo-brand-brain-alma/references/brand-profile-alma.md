# Brand Profile — ALMA

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos.

## Identidad
- **Marca:** ALMA (Alma Balance). Producto: wellness/balance _(confirmar categoría exacta)_.
- **Cliente:** **David** _(confirmar apellido/rol)_ — apareció en la call y el audit de CRO reciente (estructura de PDP, imágenes de producto).
- **Responsables MLO:** **pendiente de asignar** (según portal).
- **Idioma:** ES.
- **Estado:** cuenta **temprana** — weekly call por definir, canal de Slack por crear, foco en CRO/fundamentos.

## Accesos por conector

### Meta Ads
- Ad account: **1212005727039270** ("Alma Balance", business "Alma Balance", EUR).
- **Ads MCP HABILITADO** y queryable → consulta directa (no hace falta Chrome para Meta).

### Shopify
- Store de ALMA _(confirmar dominio exacto)_. Si el conector está caído, vía Claude in Chrome.

### Triple Whale
- _(confirmar si ALMA lo tiene activo)_. Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- _(Sin canal localizado — probablemente aún no creado. Descúbrelo en runtime.)_

### Notion
- **Portal de Cliente:** `| ALMA – Portal de Cliente` → https://www.notion.so/3526c9977eb78038b2e5e55d0d1715f5
- **SOP — Panel de KPIs (Meta Ads):** https://www.notion.so/3526c9977eb781c9bf31eb819260db45
- **Listicle & CRO Tracker:** https://www.notion.so/8a1a0c04f80b4fcea58e0ac4d1a532c7
- Dentro del portal: Tareas ALMA (Client Task Board), Project Board, Planning Calendar, Announcements/Message Board.

### Fireflies
- Calls con el cliente (incluye el **audit de CRO** reciente con David: PDP e imágenes de producto). Weekly recurrente _(por programar)_.

## Cómo medir ALMA
- ROAS/MER en **ventana (7/14 días)**, no día suelto. En cuenta joven, más peso a la ventana por poco histórico.
- Reconciliar con el Panel de KPIs (Meta Ads) y P&L.
- **CRO primero:** revisa conversión y PDP antes de escalar gasto.

## Benchmarks / cortes (del Panel de KPIs — confirmar)
- **Breakeven ROAS:** _(pendiente — leer del panel)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad
- Conversión web/PDP por debajo de lo esperado → 🟡 (CRO, no cuenta)

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía.)_

## Estado / notas (actualizar)
- Cuenta en arranque: responsables MLO sin asignar, weekly por definir, Slack por crear. Audit de CRO reciente (PDP/imágenes de producto) — seguir esas mejoras.
- _(Rellenar con el estado vigente. Última actualización: pendiente.)_
