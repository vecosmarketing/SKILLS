# Brand Profile — i-Energy

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos.

## Identidad
- **Marca:** i-Energy. Categoría: suplementos (Ienergy Supplements).
- **Mercado / moneda:** Colombia / COP.
- **Cliente:** _(confirmar contacto del cliente)_. Idioma client-facing: ES.
- **Responsables MLO:** _(confirmar responsables MLO)_.

## Accesos por conector

### Meta Ads
- Ad account: **557682626318415** ("i-Energy", business "Ienergy Supplements", COP). **Ads MCP NO habilitado** → datos de Meta vía **Claude in Chrome** (Ads Manager). Monedas en **COP**.

### Shopify
- Store de i-Energy _(confirmar dominio exacto)_. Si el conector está caído, vía Claude in Chrome.

### Triple Whale
- _(confirmar si i-Energy lo tiene activo)_. Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- **#winning-ads-i-energy** (público) — ads ganadores.
- _(Otros canales: descúbrelos en runtime.)_

### Notion
- **Portal de Cliente:** https://www.notion.so/27d6c9977eb78060b824ee33fcf3c4e4
- Dentro del portal: Client Task Board, Project Board, Planning Calendar, Announcements/Message Board, KPI panel/SOP y Listicle & CRO Tracker (localízalos en el portal en runtime).

### Fireflies
- Calls con el cliente _(confirmar cadencia/título recurrente)_.

## Cómo medir i-Energy
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito. Moneda: COP.
- Reconciliar con el KPI Panel (cuando exista) y P&L.

## Benchmarks / cortes (del KPI Panel — confirmar)
- **Breakeven ROAS:** _(pendiente)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía.)_

## Estado / notas (actualizar)
- _(Rellenar con el estado vigente: campañas activas, lanzamientos, prioridades. Última actualización: pendiente.)_
