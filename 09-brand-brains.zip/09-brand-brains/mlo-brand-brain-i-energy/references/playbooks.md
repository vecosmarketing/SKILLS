# Playbooks — Brand Brain i-Energy

Lee `brand-profile-i-energy.md` primero para los IDs. Estos son guías; cruza fuentes y usa criterio. "Saca de X" = localiza el conector de X y consúltalo en vivo; no inventes números.

## Routing

| Si preguntan…                                                        | Playbook |
| -------------------------------------------------------------------- | -------- |
| "cómo va i-Energy", "reporte", "estado de la cuenta"                   | Reporte semanal |
| "por qué caen / suben las ventas", "qué está pasando"               | Diagnóstico de ventas |
| "cuántos creativos esta semana", "cuello de botella", "flujo creativo"| Flujo creativo & cuello de botella |
| "qué ha dicho el cliente", "qué pidió en Slack", "pendientes"        | Pulso del cliente |
| "pásale un update al equipo", "directriz semanal"                   | Mensaje/directriz al equipo |
| "hazme un dashboard / gráfica / vista de anuncios"                   | Dashboard / vista (ver "Qué puedes producir" en SKILL.md) |
| "¿hay algo que vigilar?", "alertas", "semáforos"                    | Alertas / semáforos |
| "anota esto", "qué cambió esta semana", "changelog"                 | Memoria / changelog semanal |
| "reporte para el cliente", "versión para cliente"                   | Modo cliente vs interno |
| "monta el reporte automático", "que corra cada lunes"               | Cadencia automática (ver SKILL.md) |

---

## Reporte semanal

1. **Shopify** — ventas, pedidos, AOV de la ventana (vs. periodo anterior), en COP. La verdad del negocio.
2. **Meta Ads** — gasto, ROAS de plataforma (en ventana), CPA, frecuencia, top creativos.
3. **Triple Whale** (si aplica) — MER/blended y atribución first-party.
4. **Notion (Client Task Board / CRO Tracker)** — creativos subidos/lanzados esta semana y qué ángulos.
5. **Slack + Fireflies** — qué ha pedido o comentado el cliente, acuerdos de la última call, bloqueos.
6. **Sintetiza:** (a) Cómo vamos (tendencia blended + negocio), (b) Qué funciona, (c) Cuello de botella / riesgo, (d) Próximas acciones con owner. Cierra con el "por qué importa".

> Regla: lee la **tendencia en ventana (7/14 días)**, nunca un día suelto. Reconcilia Meta con Shopify.

---

## Diagnóstico de ventas ("¿por qué caen/suben?")

1. Confirma en **Shopify** la caída/subida real (ventana, no día) y en qué (producto, AOV, nº pedidos, conversión).
2. Descarta por capas: **medición/atribución** (cruza Triple Whale/Shopify), **margen** (descuentos/promos), **caja/operativa** (stock, envíos, web, checkout), **cuenta/creativo** (fatiga, falta de diversidad, CPM/frecuencia, cambios recientes).
3. Mira días de la semana y estacionalidad.
4. Conclusión: causa más probable + evidencia + acción concreta.

---

## Flujo creativo & cuello de botella

1. **Notion — Client Task Board / Listicle & CRO Tracker** de i-Energy: piezas briefeadas, en edición, listas, subidas/lanzadas.
2. **Figma/Drive** — estado de los assets aprobados.
3. **Fireflies/Slack** — qué se acordó producir y feedback del cliente.
4. Identifica el **cuello de botella** real y quién lo desbloquea.
5. Reporta: nº de creativos por estado, ritmo, dónde se atasca, acción.

---

## Pulso del cliente

1. **Slack** (canales de i-Energy) — qué ha pedido/comentado el cliente, mensajes sin responder, urgencias.
2. **Fireflies** — última call: acuerdos, pendientes.
3. Devuelve: "esto es lo que el cliente espera / le preocupa ahora mismo" + pendientes + tono. Conecta con el estado real de la cuenta.

---

## Mensaje/directriz al equipo

1. Parte del reporte y del pulso del cliente.
2. Mensaje corto, en voz de equipo: **Update** (2-4 bullets), **A vigilar** (1-3 riesgos), **Ángulos / próximos pasos** (qué trabajar y quién).
3. Tono directo y accionable. Cada punto, con su "por qué" o su owner.
4. **Muéstraselo a Marcel antes de enviarlo.** Solo se manda a Slack tras su OK.

> Molde: "Equipo, update i-Energy de la semana: [X]. A vigilar: [Y]. Ángulos que podríamos trabajar: [Z]. Owners: […]."

---

## Alertas / semáforos

1. Lee el **KPI Panel** (breakeven/target ROAS, target CPA, margen) — sin esto no hay umbral real. Si no existe, propón construirlo.
2. Saca de **Meta** (ventana 7d) ROAS, CPA, frecuencia, reparto por creativo; de **Shopify** la tendencia de ventas.
3. Evalúa y asigna color (ver umbrales del brand profile).
4. Para cada bandera: **causa probable + acción + owner**. Si todo en verde, dilo en una línea.

---

## Memoria / changelog semanal

1. Antes de un reporte, lee el **Changelog** del brand profile: qué se cambió/lanzó y qué se esperaba.
2. Compara "esta semana vs. la pasada".
3. Al cerrar un análisis con cambios relevantes, **ofrece anotar la entrada**: fecha + qué cambió + por qué + resultado.

---

## Modo cliente vs interno

1. Identifica el destinatario: equipo MLO (interno) o cliente. Si no está claro, pregunta.
2. **Interno:** directo, números crudos, jerga de casa, riesgos sin filtro, owners.
3. **Cliente:** más contexto y "por qué importa", tono calmado y seguro, sin vanity ni alarmismo. Menos siglas, más narrativa de negocio.
4. Mismos hechos, distinto envoltorio — nunca números distintos entre versiones.
5. Si va al cliente: enséñaselo a Marcel antes y envía tras su OK.
