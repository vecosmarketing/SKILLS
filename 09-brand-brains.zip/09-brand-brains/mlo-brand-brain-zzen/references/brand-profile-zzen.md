# Brand Profile — ZZEN

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos y conviene verificarlos.

## Identidad
- **Marca:** ZZEN (ZZEN Labs). Grupo principal de MLO Growth. Se escribe **ZZEN** siempre (doble Z), nunca "Zen".
- **Productos:** **Modo ZZEN**, Sleep, Calm, Focus, y categoría **Essentials** (Magnesio, Omega 3 — desarrollos nuevos 2026). Lee por producto cuando difieran márgenes/objetivos.
- **Marca hermana del grupo:** **Ancestras** (mismo grupo; cruza aprendizajes cuando aplique).
- **Canales paid:** **Meta Ads + Google Ads** (Demand Gen / Imagen, PMax, Search). Estrategia: captación de valor (Maximize Value), suscripciones, exclusión de compradores recurrentes y puja agresiva para nuevos. Validan **incrementalidad con Triple Whale**.
- **Idioma:** ES (cliente español).

## Accesos por conector

### Meta Ads
- Ad account: **1755269528638876** ("ZZEN LABS", business "ZZEN", EUR). Habilitado en el conector (Ads MCP), queryable.

### Google Ads
- Demand Gen / PMax / Search activos. **Sin conector MCP** → acceder vía Claude in Chrome (Google Ads UI) o apoyarse en el partner de Google (Lucas Parés) y en lo que el equipo deje en Notion/Slack. Histórico de fricción con aprobaciones (imágenes rechazadas, Merchant Center).

### Shopify
- Store de ZZEN _(confirmar dominio exacto)_. **Si el conector de Shopify está caído/desconectado, NO bloquear: acceder vía Claude in Chrome** (admin de Shopify) o tirar de Triple Whale para ventas/atribución.

### Triple Whale
- **Activo** — atribución first-party e incrementalidad (ZZEN la usa para validar). Si no hay conector MCP, vía Claude in Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- **#zzen-mlo** (privado) — coordinación general con el cliente.
- **#zzenlabs-ads** (privado, creado por Roger Viladrosa) — ads / cliente.
- **#winning-ads-zzen** (público) — ads ganadores.
- **#canal-diseño-paid-zzen** (público) — diseño paid.

### Notion
- **Portal de Cliente:** `| ZZEN – Portal de Cliente` → https://www.notion.so/3306c9977eb781fabb01c98f719b5aae
- **KPI Panel META + Budget Distribution ZZENLABS:** https://www.notion.so/3376c9977eb78132b078c785fd9de435
- **Creative Intelligence Pools** (mensuales): p.ej. Apr 27 – May 11 2026 → https://www.notion.so/35d6c9977eb781dba245d0c2a1b155f0
- **VoC — Lenguaje Literal de Clientes ZZEN:** https://www.notion.so/3556c9977eb781d8a6c5fe14828b3959
- **Listicle & CRO Tracker:** https://www.notion.so/42be18607ddf4c6da644ba2097950bf5
- Dentro del portal: Tareas ZZEN (Client Task Board), Project Board, Planning Calendar, Anuncios/Message Board.

### Fireflies
- Calls recurrentes con el cliente. Reunión online: **jueves** → Meet del portal (https://meet.google.com/gua-bszt-zoh). Reu con Google (Lucas Parés): cada 2 semanas, miércoles 10:00.

## Contactos
- **Roger Viladrosa** — lado cliente / ZZEN Labs (roger@rogerviladrosa.com). _(confirmar rol exacto: founder/operativo)_
- **Lucas Parés** — Associate Account Strategist, Google Customer Solutions (Iberia) (lucaspares@google.com). Partner de Google para la cuenta.
- **Responsables MLO:** Marcel (Growth lead) · media buyer y diseño _(confirmar nombres actuales)_.

## Cómo medir ZZEN
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Cuenta **multicanal** (Meta + Google): la verdad está en el blended/MER de Triple Whale + Shopify, no en sumar ROAS de plataforma.
- Incrementalidad y captación de **nuevos clientes** (iCAC), no solo CAC medio.
- Reconciliar con KPI Panel META + Budget Distribution y P&L.

## Benchmarks / cortes (del KPI Panel — confirmar valores en vivo)
Lee siempre el KPI Panel en vivo antes de juzgar. Valores de referencia (rellenar con los reales del panel):
- **Breakeven ROAS:** _(pendiente — leer del panel)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución (por producto):** _(pendiente)_
- **Budget distribution Meta vs Google:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS/MER en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴 según magnitud y días
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad
- Rechazos en Google Ads / Merchant Center → 🟡/🔴

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta ni Google (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición / incrementalidad (decisión deliberada).

## Changelog semanal
Registro de cambios/tests/decisiones para continuidad. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía. Añadir al cerrar análisis con cambios relevantes.)_

## Estado / notas (actualizar)
- _(Rellenar con el estado vigente: campañas activas por canal, productos en foco, lanzamientos, prioridades. Última actualización: pendiente.)_
