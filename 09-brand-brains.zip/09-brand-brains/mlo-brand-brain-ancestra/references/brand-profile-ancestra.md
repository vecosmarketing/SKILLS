# Brand Profile — ANCESTRA

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos.

## Identidad
- **Marca:** ANCESTRA (Ancestra Tallow). Producto: skincare a base de **tallow / sebo**.
- **Grupo:** marca hermana del **grupo ZZEN**. Cruza aprendizajes con ZZEN.
- **Responsables MLO:** **Facu Gallo** y **Diego Gross**. Diseño/creativo en canal propio.
- **Cliente:** vía **Slack Connect** _(confirmar nombre/rol del contacto principal)_.
- **Idioma:** ES.
- **Issue abierto:** Merchant Center suspendido/baneado → bloquea lanzamiento en Google Ads.

## Accesos por conector

### Meta Ads
- Ad account: **1555748052135703** ("Cuenta publicitaria 1", business "Ancestra Tallow", EUR).
- **Ads MCP NO habilitado** para esta cuenta → datos de Meta vía **Claude in Chrome** (Ads Manager).

### Google Ads / Merchant Center
- Previsto, **bloqueado por suspensión de Merchant Center**. Vigilar estado; cuando se resuelva, acceder vía Chrome o partner de Google.

### Shopify
- Store de Ancestra _(confirmar dominio exacto)_. Si el conector está caído, vía Claude in Chrome.

### Triple Whale
- _(confirmar si Ancestra lo tiene activo)_. Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- **#general-ancestra-hub** (privado) — hub general.
- **#performance-marketing-ancestra** (privado) — performance/ads.
- **#ideas-ancestra** (privado) — ideas/estrategia.
- **#winning-ads-ancestra** (público) — ads ganadores.
- **#canal-diseño-paid-ancestra** (privado) — diseño paid.
- **#creativos-paid-mlo-growth-x-ancestra** (privado) — creativos paid.
- Comunicación con el cliente por **Slack Connect** (ver SOP: https://www.notion.so/b8460895d4ea402ca78466ce4a4bc29f).

### Notion
- **Portal de Cliente:** `| ANCESTRA – Portal de Cliente` → https://www.notion.so/32a6c9977eb7809a8313e03e1f4f60cb
- **Listicle & CRO Tracker:** https://www.notion.so/fbdcce7bae7740028b98ee279c77eaaf
- **Biweekly Report — 27 Abr / 10 May 2026:** https://www.notion.so/35d6c9977eb7816ab439f1a774e41523
- **Biweekly Report — 4/05 - 17/05 2026:** https://www.notion.so/3646c9977eb78112a1c6de863ad7f449
- **SOP — Comunicación con Ancestra (Slack Connect):** https://www.notion.so/b8460895d4ea402ca78466ce4a4bc29f
- Dentro del portal: Tareas Client (Client Task Board), Project Board, Planning Calendar, Announcements/Message Board.
- **KPI Panel:** _(no localizado — confirmar si existe; si no, proponer construirlo con kpi-panel-builder.)_

### Fireflies
- Calls con el cliente. Reunión online: **martes** → Meet del portal (https://meet.google.com/cax-nszh-rha).

## Cómo medir Ancestra
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito.
- Reconciliar con KPI Panel (cuando exista) y P&L. Apóyate en los Biweekly Reports.

## Benchmarks / cortes (del KPI Panel — confirmar)
- **Breakeven ROAS:** _(pendiente)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad
- Merchant Center suspendido sin resolver → 🔴

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta/Google (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía. Apóyate también en los Biweekly Reports del portal.)_

## Estado / notas (actualizar)
- Merchant Center baneado (mayo 2026) bloqueando Google Ads — seguimiento activo.
- _(Rellenar con el estado vigente: campañas Meta activas, lanzamientos, prioridades. Última actualización: pendiente.)_
