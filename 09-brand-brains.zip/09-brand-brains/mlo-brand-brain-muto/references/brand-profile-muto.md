# Brand Profile — MUTO

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos.

## Identidad
- **Marca:** MUTO (Muto Longevity). Categoría: **longevity / suplementos**. Mercado **UK**, moneda **GBP**.
- **Cliente:** **Richie Barclay** _(confirmar rol — founder/operativo)_. **Angloparlante** → comunicación client-facing en **inglés**.
- **Responsables MLO:** **Marc Boix**. (Antonio figura en el portal pero **posible baja** — confirmar quién lleva la cuenta ahora.)
- **Idioma:** interno ES / cliente EN.

## Accesos por conector

### Meta Ads
- **MUTO V2 (activa):** ad account **1207062217851760** (business "Muto Longevity", GBP). Ads MCP habilitado, queryable.
- **Muto (legacy):** ad account **8923257947713583** (business "Muto Longevity", GBP). Ads MCP habilitado. _(confirmar si sigue en uso o solo histórico.)_
- Usa la cuenta **activa (V2)** salvo que necesites histórico de la legacy.

### Shopify
- Store de MUTO _(confirmar dominio exacto; UK/GBP)_. Si el conector está caído, vía Claude in Chrome.

### Triple Whale
- _(confirmar si MUTO lo tiene activo)_. Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- **#muto-growth-channel** (privado, creado por Richie Barclay) — coordinación con el cliente.
- **#creatives-paid-muto** (privado) — creativos paid.

### Notion
- **Portal de Cliente:** `| MUTO – Portal de Cliente` → https://www.notion.so/3466c9977eb78099bedbd4784c0d7b8f
- **SOP — Panel de KPIs (Meta Ads):** https://www.notion.so/490291b8519749b385532985a7076a44
- **Listicle & CRO Tracker:** https://www.notion.so/817a359016ac4b39a9cf0a66642c1262
- **Biweekly Report — 27 Abr – 10 May 2026:** https://www.notion.so/35d6c9977eb781be9e51f09b5d00f0ca
- **Biweekly Report — 04/05 - 17/05 2026:** https://www.notion.so/3646c9977eb781e4a0a2d908ae0d388c
- Dentro del portal: Tareas MUTO (Client Task Board), Project Board, Planning Calendar, Announcements/Message Board.

### Fireflies
- Calls con el cliente (en inglés). Weekly recurrente _(por programar — portal indica "pendiente de definir")_.

## Cómo medir MUTO
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito. Todo en **GBP**.
- Reconciliar con el Panel de KPIs (Meta Ads) y P&L. Apóyate en los Biweekly Reports.

## Benchmarks / cortes (del Panel de KPIs — confirmar, en GBP)
- **Breakeven ROAS:** _(pendiente — leer del panel)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía. Apóyate también en los Biweekly Reports del portal.)_

## Estado / notas (actualizar)
- Dos cuentas de Meta (V2 activa + legacy). Weekly por definir. Confirmar quién lleva la cuenta tras la posible baja de Antonio.
- _(Rellenar con el estado vigente: campañas activas, lanzamientos, prioridades. Última actualización: pendiente.)_
