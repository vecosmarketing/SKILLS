# Brand Profile — Bala di Gala

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos.

## Identidad
- **Marca:** Bala di Gala. Categoría: _(confirmar categoría)_.
- **Mercado / moneda:** _(confirmar)_ / _(confirmar)_.
- **Cliente:** _(confirmar contacto del cliente)_. Idioma client-facing: ES.
- **Responsables MLO:** _(confirmar responsables MLO)_.

## Accesos por conector

### Meta Ads
- **Cuenta de Meta no localizada** por nombre en el conector → confírmala (puede estar bajo otro business o no conectada). Mientras tanto, datos de Meta vía **Claude in Chrome**.

### Shopify
- Store de Bala di Gala _(confirmar dominio exacto)_. Si el conector está caído, vía Claude in Chrome.

### Triple Whale
- _(confirmar si Bala di Gala lo tiene activo)_. Si sí y no hay conector, vía Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- _(Sin canal localizado por búsqueda directa — descúbrelo en runtime.)_

### Notion
- **Portal de Cliente:** https://www.notion.so/3676c9977eb78009a536f2ba61fcdf07
- Dentro del portal: Client Task Board, Project Board, Planning Calendar, Announcements/Message Board, KPI panel/SOP y Listicle & CRO Tracker (localízalos en el portal en runtime).

### Fireflies
- Calls con el cliente _(confirmar cadencia/título recurrente)_.

## Cómo medir Bala di Gala
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito. Moneda: _(confirmar)_.
- Reconciliar con el KPI Panel (cuando exista) y P&L.

## Benchmarks / cortes (del KPI Panel — confirmar)
- **Breakeven ROAS:** _(pendiente)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía.)_

## Estado / notas (actualizar)
- _(Rellenar con el estado vigente: campañas activas, lanzamientos, prioridades. Última actualización: pendiente.)_
