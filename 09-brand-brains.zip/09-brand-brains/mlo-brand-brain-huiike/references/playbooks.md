# Playbooks — Brand Brain HUIIKE

Lee `brand-profile-huiike.md` primero para los IDs. Estos son guías; cruza fuentes y usa criterio. "Saca de X" = localiza el conector de X y consúltalo en vivo; no inventes números. Recuerda: el **Ads MCP de Meta no está habilitado** para HUIIKE → datos de Meta vía Chrome.

## Routing

| Si preguntan…                                                        | Playbook |
| -------------------------------------------------------------------- | -------- |
| "cómo va HUIIKE", "reporte", "estado de la cuenta"                   | Reporte semanal |
| "por qué caen / suben las ventas", "qué está pasando"                | Diagnóstico de ventas |
| "cuántos creativos esta semana", "cuello de botella", "flujo creativo"| Flujo creativo & cuello de botella |
| "qué ha dicho el cliente / Jose", "qué pidió en Slack", "pendientes" | Pulso del cliente |
| "pásale un update al equipo", "directriz semanal", "qué vigilar / qué ángulos"| Mensaje/directriz al equipo |
| "hazme un dashboard / gráfica / vista de anuncios de HUIIKE"         | Dashboard / vista (ver "Qué puedes producir" en SKILL.md) |
| "¿hay algo que vigilar?", "alertas", "semáforos", "¿algo en rojo?"   | Alertas / semáforos |
| "anota esto", "qué cambió esta semana", "changelog", "registro"      | Memoria / changelog semanal |
| "reporte para Jose / el cliente", "versión para cliente"            | Modo cliente vs interno |
| "monta el reporte automático", "que corra cada lunes", "chequeo diario" | Cadencia automática (ver SKILL.md) |

---

## Reporte semanal

Objetivo: foto clara de la semana en una lectura, conciliando cuenta con negocio.

1. **Shopify** — ventas, pedidos, AOV de la ventana (vs. periodo anterior). Esta es la verdad del negocio. (Vía Chrome si el conector está caído.)
2. **Meta Ads (vía Chrome)** — gasto, ROAS de plataforma (en ventana), CPA, frecuencia, top creativos por gasto/alcance.
3. **Triple Whale** (si aplica) — MER/blended y atribución first-party. Compara con lo que dice Meta.
4. **Notion (Client Task Board / Creative Pool / Weekly Accionables)** — cuántos creativos se han subido/lanzado esta semana y qué ángulos.
5. **Slack + Fireflies** — qué ha pedido o comentado el cliente (Jose), acuerdos de la última call, bloqueos.
6. **Sintetiza** así: (a) Cómo vamos (tendencia blended + negocio), (b) Qué está funcionando, (c) Cuello de botella / riesgo, (d) Próximas acciones con owner. Cierra con el "por qué importa".

> Regla: lee la **tendencia en ventana (7/14 días)**, nunca un día suelto. Reconcilia Meta con Shopify.

---

## Diagnóstico de ventas ("¿por qué caen/suben?")

1. Confirma en **Shopify** la caída/subida real (ventana, no día) y en qué (producto, AOV, nº pedidos, tasa de conversión).
2. Descarta por capas, en este orden:
   - **Medición/atribución:** ¿es caída real o solo se ve peor en Meta por las ventanas estrictas? Cruza con Triple Whale/Shopify.
   - **Margen:** ¿hubo descuentos/promos que comprimen el margen real?
   - **Caja/operativa:** stock, envíos, web caída, checkout.
   - **Cuenta/creativo:** fatiga, falta de diversidad, CPM/frecuencia disparados, cambios recientes.
3. Mira **días de la semana** y estacionalidad.
4. Conclusión: causa más probable + evidencia + acción concreta. No te quedes en "el ROAS bajó".

---

## Flujo creativo & cuello de botella

1. **Notion — Client Task Board / Creative Intelligence Pool / Listicle & CRO Tracker** de HUIIKE: cuántas piezas se han briefeado, en edición, listas, y subidas/lanzadas esta semana.
2. **Figma/Drive** — estado de los assets aprobados. Recuerda el SOP: **9:16 por placement, sin música**.
3. **Fireflies/Slack** — qué se acordó producir y qué feedback dio el cliente (Jose/equipo).
4. Identifica el **cuello de botella** real (brief, edición, feedback, subida) y quién lo desbloquea (Manu/diseño).
5. Reporta: nº de creativos por estado, ritmo vs. lo acordado, dónde se atasca, acción para destrabarlo.

---

## Pulso del cliente

1. **Slack** (canal de HUIIKE) — qué ha pedido/comentado el cliente últimos días, mensajes sin responder, quejas o urgencias.
2. **Fireflies** — última call: acuerdos, pendientes, qué hay que recordar.
3. Devuelve: "esto es lo que el cliente espera / le preocupa ahora mismo" + qué tenemos pendiente con él + tono. Conecta con el estado real de la cuenta para anticipar la conversación.

---

## Mensaje/directriz al equipo

Objetivo: convertir el análisis en una directriz clara para el equipo (Manu, diseño), lista para Slack.

1. Parte del reporte semanal y del pulso del cliente (no lo repitas desde cero).
2. Redacta un mensaje corto, en voz de equipo, con esta estructura:
   - **Update de la semana:** 2-4 bullets de lo que pasó (números clave en ventana + creativos).
   - **A vigilar:** 1-3 riesgos (fatiga del winner, frecuencia, caída de margen, pendientes con el cliente).
   - **Ángulos / próximos pasos:** qué conceptos o ángulos trabajar y quién (briefs, tests).
3. Tono directo y accionable. Cada punto, con su "por qué" o su owner.
4. **Muéstraselo a Marcel antes de enviarlo.** Solo se manda a Slack tras su OK.

> Ejemplo de molde: "Equipo, update HUIIKE de la semana: [X]. A vigilar: [Y]. Ángulos que podríamos trabajar: [Z]. Owners: […]."

---

## Alertas / semáforos

Objetivo: detectar problemas antes de que escalen, contra los cortes propios de la marca.

1. Lee el **KPI Panel** (breakeven/target ROAS, target CPA, margen) — sin esto no hay umbral real. Si no existe, propón construirlo.
2. Saca de **Meta (vía Chrome)** (ventana 7d) ROAS, CPA, frecuencia, reparto de gasto por creativo; de **Shopify** la tendencia de ventas vs. periodo anterior.
3. Evalúa cada regla y asigna color:
   - ROAS en ventana < breakeven varios días → 🔴
   - Frecuencia > ~2.5–3 (7d) → 🟡 fatiga
   - CPA > target sostenido → 🟡/🔴
   - Caída de ventas > X% en ventana → diagnóstico
   - Un creativo con >~60–70% del alcance → 🟡 falta diversidad
4. Para cada bandera: **causa probable + acción + owner**. Si todo en verde, dilo en una línea. Un día suelto malo no es alerta.

---

## Memoria / changelog semanal

Objetivo: continuidad y reportes comparables.

1. Antes de un reporte/diagnóstico, lee el **Changelog** del brand profile y el **Weekly | Accionables Clave** del portal: qué se cambió/lanzó la semana pasada y qué resultados se esperaban.
2. Compara "esta semana vs. la pasada" en vez de analizar en frío.
3. Al cerrar un análisis con cambios relevantes, **ofrece anotar la entrada**: fecha + qué cambió + por qué + resultado esperado/observado.
4. Mantenlo corto y factual; es un registro, no un reporte.

---

## Modo cliente vs interno

Objetivo: el mismo análisis con la voz correcta según quién lo recibe.

1. Identifica el destinatario: equipo MLO (interno) o cliente/Jose (cliente). Si no está claro, pregunta.
2. **Interno:** directo, números crudos, jerga de casa, riesgos sin filtro, owners.
3. **Cliente:** más narrativa de negocio y "por qué importa", tono calmado y seguro, sin vanity ni alarmismo. **Plural, sin emojis, breve** (preferencia de Jose). Menos siglas.
4. Mismos hechos, distinto envoltorio — nunca números distintos entre versiones.
5. Si va al cliente (Slack/email/portal): enséñaselo a Marcel antes y envía tras su OK.
