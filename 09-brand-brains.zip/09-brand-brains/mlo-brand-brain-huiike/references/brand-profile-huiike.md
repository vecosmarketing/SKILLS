# Brand Profile — HUIIKE

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos y conviene verificarlos.

## Identidad
- **Marca:** HUIIKE (Huiike Brand SL).
- **Cliente:** **Jose** _(confirmar apellido/rol)_. Idioma ES. Prefiere mensajes breves, plurales ("hemos / vamos a") y sin emojis.
- **Responsable MLO:** **Marc Boix** (estrategia/creativo). Cuenta traspasada a **Manu** (media buyer) — ver Handoff.
- **Idioma:** ES.

## Accesos por conector

### Meta Ads
- Ad account: **1050680592558578** ("Huiike Brand SL", business "Huiike", EUR).
- **Ads MCP NO habilitado** para esta cuenta → datos de Meta vía **Claude in Chrome** (Ads Manager).

### Shopify
- Store de HUIIKE _(confirmar dominio exacto)_. Si el conector está caído/desconectado, acceder vía Claude in Chrome.

### Triple Whale
- _(confirmar si HUIIKE lo tiene activo)_. Si sí y no hay conector, vía Claude in Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- _(Canal no localizado por búsqueda directa — descúbrelo en runtime; puede ser Slack Connect o nombre no estándar.)_

### Notion
- **Portal de Cliente:** `| HUIIKE – Portal de Cliente` → https://www.notion.so/3356c9977eb781ee999be097f945379f
- **Listicle & CRO Tracker:** https://www.notion.so/c150cae3c3ec423abc56e12fa0b22d12
- **Creative Intelligence Pool** (quincenal): p.ej. May 6–20 2026 → https://www.notion.so/3666c9977eb781ab9255da85b1add6ce
- **Weekly Huiike | Accionables Clave** (14 May 2026): https://www.notion.so/0f4a6adbb20f417c879ef0e7b6c7d6cb
- **Handoff de Cuenta — HUIIKE → Manu:** https://www.notion.so/3696c9977eb781e5a86dc2ab16d80f7d
- **SOP — Activación de Anuncios HUIIKE** (formatos 9:16 por placement, sin música): https://www.notion.so/3696c9977eb7814b9e8ac191ab2be67f
- Dentro del portal: Tareas Huiike (Client Task Board), Project Board, Planning Calendar, Anuncios/Message Board.
- **KPI Panel:** _(no localizado — confirmar si existe; si no, proponer construirlo con kpi-panel-builder.)_

### Fireflies
- Calls con el cliente _(confirmar cadencia/título recurrente)_.

## Cómo medir HUIIKE
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito.
- Reconciliar con KPI Panel (cuando exista) y P&L.

## Benchmarks / cortes (del KPI Panel — confirmar)
Lee el KPI Panel en vivo antes de juzgar. Valores de referencia (rellenar):
- **Breakeven ROAS:** _(pendiente)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía. Apóyate también en el "Weekly | Accionables Clave" del portal.)_

## Estado / notas (actualizar)
- _(Rellenar con el estado vigente: campañas activas, lanzamientos, prioridades. Última actualización: pendiente.)_
