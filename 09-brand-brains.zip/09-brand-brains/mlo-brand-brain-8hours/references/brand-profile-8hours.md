# Brand Profile — 8hours

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos y conviene verificarlos.

## Identidad
- **Marca:** 8hours (producto estrella: **8hours RISE**). Cofinanciado/gestionado con MLO Growth.
- **Cliente / founder:** **Ollie Aplin** (me@ollieaplin.com). Muy involucrado; valora simplicidad y rapidez (pidió simplificar el ad tracker — "Simplify & Go").
- **Responsables MLO:** Marc Boix Morales (Creative Strategist) · Media Buyer _(confirmar quién lleva la cuenta ahora)_.
- **Idioma:** ES/EN según interlocutor (Ollie es EN).

## Accesos por conector

### Meta Ads
- Ad account: **1336199457035968** ("8hours 2024", business "8hours", EUR). Habilitado en el conector (Ads MCP).

### Shopify
- Store: **8hrsstore** _(confirmar dominio exacto; el workspace de Notion del cliente es notion.so/8hrsstore)_. Si el conector gestiona varias tiendas, selecciona la de 8hours antes de consultar.

### Triple Whale
- _(confirmar si 8hours lo tiene activo)_. Si sí y no hay conector MCP, acceder vía Claude in Chrome.

### Atria
- Análisis de creativos vía navegador (sin MCP). El equipo de 8hours accede por links de invitación.

### Slack
- **#general-8hoursxmlo-growth** (workspace mlogrowthhub) — coordinación general con el cliente.
- **#creative-strategy-8hours** (workspace 8hours-group) — estrategia creativa.
- 8hours tiene **workspace propio de Slack** (8hours-group.slack.com); además canales en mlogrowthhub. Busca en ambos.

### Notion
- **Portal de Cliente:** `| 8hours – Portal de Cliente` → https://www.notion.so/24a6c9977eb78076b3ffe2fef9cef6e6
- **KPI Panel META 8hours (Google Sheets):** https://docs.google.com/spreadsheets/d/1lTcj920O3sB8rL0sNki3qYszKsPBn7mC/edit
- **SOP — KPI Panel META 8hours (Guía Media Buyer):** https://www.notion.so/33a6c9977eb78183a5e9dd2af7a36ea8
- **Ad Tracker / "The Ad Tracker":** en el workspace 8hrsstore (single source of truth de briefing y estado de ads). El propio Ollie pidió usarlo como fuente única.
- **Creator Tracker:** accesible desde Links de 8hours (flujo de creator ads → activación en Meta).
- **Recursos para Editores:** https://www.notion.so/712c3744e22d49f8b3b75c0343febdda (carpetas de estáticos/vídeos en Drive).

### Fireflies
- Calls recurrentes: **"8hours - Weeklys"** y reuniones MUTO/8hours con Ollie (lunes y jueves, Meet del portal).

## Cómo medir 8hours
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Atribución estricta a propósito (penaliza el ROAS de plataforma, refleja mejor la facturación).
- Reconciliar con KPI Panel META (5 pestañas, breakeven/target) y P&L.

## Benchmarks / cortes (del KPI Panel — confirmar valores en vivo)
Lee siempre el KPI Panel META en vivo antes de juzgar. Valores de referencia (rellenar con los reales del panel):
- **Breakeven ROAS:** _(pendiente — leer del panel)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución:** _(pendiente)_
- AOV, COGS, CAC actuales: _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴 según magnitud y días
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición (decisión deliberada).

## Changelog semanal
Registro de cambios/tests/decisiones para continuidad. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- _(Sin entradas todavía. Añadir al cerrar análisis con cambios relevantes.)_

## Estado / notas (actualizar)
- _(Rellenar con el estado vigente: campañas activas, colecciones/lanzamientos, prioridades. Última actualización: pendiente.)_
