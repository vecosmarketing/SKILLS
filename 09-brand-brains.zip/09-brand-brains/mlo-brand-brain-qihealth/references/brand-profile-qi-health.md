# Brand Profile — QiHealth

Perfil operativo de la marca para el Brand Brain. **Mantenlo actualizado**: cuando cambie un ID, contacto o número clave, actualízalo aquí. Items marcados _(confirmar)_ son inferidos o pendientes.

## Identidad
- **Marca:** QiHealth (QI Health). Categoría: **healthtech / monitoreo metabólico** (no vende un sensor, vende "entender cómo responde tu cuerpo").
- **Producto core:** **QiTrax** — sensor continuo de glucosa (CGM), se pega en el **tríceps posterior**, dura **15 días**, **1.440 lecturas/día**, Bluetooth auto-connect. Ecosistema: **QiTrax + Band + Ring + Coach Ana** (la IA integrada que interpreta) (+ báscula en roadmap). Integración **Apple Watch** y **AI coach** en roadmap (sep 2026).
- **Empresa:** Operadora legal **Habits Sync, S.A. de C.V.** · Fabricante del sensor **MicroTech Medical (China)** · Registro **COFEPRIS** desde may-2026 · marca ~1 año.
- **Mercado / moneda:** **México** (CDMX, Guadalajara, Monterrey) / **MXN**. Idioma client-facing: ES (México).
- **Canales de venta:** **Shopify** (DTC principal) · **Amazon** · **Mercado Libre** (marketplaces — la venta ahí no la ve Meta; reconciliar el blended).
- **Cliente (lado marca):** **Jose** (Dirección Marketing QiHealth), **Begoña**, **Jose Antonio**. _(Confirmar apellidos/emails.)_
- **Responsables MLO:** **Media Buyer → Néstor Torres** · **Estratega creativo → Marc Boix** · Diseño → Marcos SM. _(Nombres tipo "Alejandro"/"Daniel" en nombres de campaña NO son responsables MLO — no inventar su rol.)_

## Accesos por conector

### Meta Ads
- **Cuenta "QiHealth" `2043278929768741` (MXN).** Campañas con naming `CBO_MX_...`. Tira los datos vía **Windsor.ai** (`facebook` connector) — fiable; o **Claude in Chrome** (Ads Manager) si el Ads MCP de Meta no responde.
- Campos revenue/compras en Windsor: `action_values_omni_purchase` (ventas) y `actions_purchase` (compras).

### Shopify
- Store de QiHealth _(confirmar handle/dominio)_. Canal DTC principal. Si el conector Shopify está caído, vía Claude in Chrome (ShopifyQL por URL).

### Amazon / Mercado Libre
- Marketplaces con venta propia _(sin conector directo — pedir cifras al cliente o vía panel)_. **Importante para el blended real.**

### Triple Whale
- **En setup (agosto 2026).** Cuando esté activo → MER/blended y atribución first-party. Hasta entonces, reconciliar a mano Shopify + marketplaces + Meta.

### Atria
- Análisis de creativos vía navegador (sin MCP).

### Slack
- _(Canal del cliente/equipo: descúbrelo en runtime.)_

### Notion (TEAM HUB)
- **Portal de Cliente:** https://app.notion.com/p/38d6c9977eb780d8b311c7f281ac414d
- **KPI Panel:** https://app.notion.com/p/39e6c9977eb781f2adade8c7e7290949 — ⚠️ **PROVISIONAL** (Néstor + Marc; "no operar hasta que llegue el form de Begoña"). No ancles decisiones duras sin confirmarlo.
- **Brand DNA:** https://app.notion.com/p/9f76c9977eb7833587c201b88adfcb1c (posicionamiento, tono, guardrails, pruebas clínicas — munición creativa).
- **Research:** https://app.notion.com/p/2016c9977eb783b281698101ec251044
- **Ficha Cliente:** https://app.notion.com/p/4276c9977eb782c19d4601fb31711b40
- Dentro del portal: Client Task Board, Announcements, KPI Panel, Ad Copy Bank (en montaje, calcado a Bridge/8HOURS), reportes. Localízalos en runtime.

### Fireflies
- **Weekly QiHealth** (Marcel + Marc + Néstor + Jose Antonio + Begoña). Cadencia semanal _(confirmar día)_.

## ⚠️ Guardrails COFEPRIS — NO NEGOCIABLES (regulador sanitario mexicano)
Saltárselo puede costar el permiso de publicidad. Aplica a TODO copy/creativo.

**⛔ Prohibido:**
- Palabras **"detecta" / "diagnostica" / "previene"**.
- **Nombrar o comparar competidores** (Abbott, FreeStyle Libre…). Nada de tono "switch".
- Superlativos / tono agresivo.
- **"Sin calibraciones"** (existe calibración de fábrica).
- **"Sin pinchazos" a secas** o "cero piquetes".
- Mostrar el sensor **fuera del tríceps posterior**; modificar forma/color/proporción del sensor en imágenes IA.
- **Emojis.**

**✅ Obligatorio:**
- **"Coach Ana, la inteligencia artificial integrada al sistema"** — nunca solo "Ana".
- Framear como **"interpreta tendencias" / "muestra patrones para llevar a consulta"** — nunca como diagnóstico.
- Claim exacto: **"sin pinchazos diarios en el dedo"**.
- Sensor **siempre en tríceps posterior**.
- Disclaimer en toda pieza: `Reg. SSA 2370E2025 | Permiso Publicidad: 263300201B0771 SSA | Consulta a tu médico. | Lee las instrucciones de uso.`

## Tono de marca
Transparente · Empática · Optimista · Experta · Humana. **Voz activa siempre. Sin emojis.** Hablamos como "nosotros" / por el nombre de la marca. Se permiten palabras en inglés si aportan naturalidad.
- **Taglines:** *Activa tu Qi, activa tu vida* / *Energía que te mueve*.
- **Referentes look & feel:** Oura · WHOOP · Levels Health. Wellness premium, data-driven, limpio. **Nunca estética "farmacia" ni "paciente".**

## Munición creativa (pruebas duras del ensayo clínico)
Resuelven la objeción del miedo físico sin argumentar: **MARD 8,66%** (precisión) · **93,1%** no sintió dolor al insertar · **92%** cómodo los 15 días · **96%** de 174 sensores completaron 15 días · **100%** de lecturas en zona clínicamente segura A+B. · Sensor **22mm × 4mm, 2,2g** (el autorizado más pequeño de México).

## Cómo medir QiHealth
- ROAS/MER en **ventana (7/14 días)**, no día suelto. Reconciliar Shopify **+ Amazon + Mercado Libre** (blended real; Meta no ve marketplaces).
- Unit economics con matiz de **recambio de sensor cada 15 días** → hay recurrencia/LTV, no solo primera compra.
- Moneda: **MXN**.

## Benchmarks / cortes (del KPI Panel — ⚠️ PROVISIONAL)
- **Breakeven ROAS:** _(pendiente — KPI panel provisional, esperando form de Begoña)_
- **Target ROAS:** _(pendiente)_
- **Target CPA / CPA máximo:** _(pendiente)_
- **Margen de contribución / AOV / COGS / CAC:** _(pendiente)_

## Umbrales de alerta (afinar con el equipo)
- ROAS en ventana **< breakeven** durante **≥3 días** → 🔴
- Frecuencia (7d) **> 2.5–3** → 🟡 fatiga
- CPA **> target** sostenido → 🟡/🔴
- Caída de ventas en ventana **> 15%** vs. periodo anterior → diagnóstico
- Un creativo con **> 60–70%** del spend/alcance → 🟡 falta diversidad
- **Creativo/copy que roza COFEPRIS** → 🔴 inmediato (riesgo regulatorio)

## Guardarraíles (no hacer de forma autónoma)
- No cambiar presupuestos, campañas, audiencias ni estructura en Meta (proponer, no ejecutar).
- No enviar mensajes al cliente sin OK de Marcel.
- No tocar atribución / ventanas / medición.
- No aprobar/produccir creativo que incumpla COFEPRIS.

## Snapshot inicial — Julio 2026 (Meta, MXN)
Cuenta `2043278929768741`, julio 2026: **gasto ≈ $140.100 · ventas ≈ $1.207.353 · ROAS ≈ 8,6x · 426 compras** (vía Windsor). Campañas activas: Prospecting Sensor (2.0 / Glucómetro), RET-HOT Sensor, Bundle, Apple Watch, Mundial, Testing Ángulos, Winners Bid Cap.
- **Metas cliente:** 130k (sep) + 150k (oct). Stock: 70 bandas. Roadmap: Apple Watch + AI coach (sep), landing para médicos, Triple Whale setup. Retirada anillo 1.0 y prep 2.0.

## Changelog semanal
Registro de cambios/tests/decisiones. Formato: `YYYY-MM-DD — qué cambió — por qué — resultado esperado/observado`.
- 2026-08-23 — Brand Brain de QiHealth creado (perfil + playbooks) — para reportes/análisis con contexto — base inicial.

## Estado / notas (actualizar)
- Cuenta MX en buen ROAS (~8,6x en julio). Foco: escalar hacia metas sep/oct, integrar Apple Watch + AI coach, cerrar KPI Panel definitivo (form Begoña), montar Ad Copy Bank y activar Triple Whale. Última actualización: 2026-08-23.
